#!/usr/bin/env node

/**
 * Post-install script to finalize the analyzer template
 * This runs after npm install and sets up the complete analysis environment
 */

const path = require('path');
const { spawn } = require('child_process');

// Get the analyzer template path relative to where this script is installed
const packageRoot = path.join(__dirname, '..');
const analyzerTemplatePath = path.join(packageRoot, 'analyzer-template');

console.log('🚀 CodeYam CLI: Finalizing analyzer template...');
console.log('📁 Template path:', analyzerTemplatePath);

async function execAsync(command, args, workingDir) {
  return new Promise((resolve, reject) => {
    console.log(`Running: ${command} ${args.join(' ')}`);
    const process = spawn(command, args, {
      cwd: workingDir,
      stdio: 'inherit',
      shell: true,
    });

    process.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Command failed with exit code ${code}: ${command} ${args.join(' ')}`));
      }
    });

    process.on('error', (error) => {
      reject(new Error(`Failed to start command: ${error.message}`));
    });
  });
}

async function finalizeAnalyzerTemplate() {
  try {
    console.log('📦 Installing analyzer dependencies...');
    await execAsync('npm', ['install'], analyzerTemplatePath);
    
    console.log('🎭 Installing Playwright browsers...');
    await execAsync('npx', ['playwright', 'install'], analyzerTemplatePath);
    
    console.log('🔨 Building analyzer template...');
    await execAsync('npm', ['run', 'build'], analyzerTemplatePath);
    
    // Create finalization marker
    const fs = require('fs');
    const markerPath = path.join(analyzerTemplatePath, '.finalized');
    fs.writeFileSync(markerPath, new Date().toISOString());
    
    console.log('✅ CodeYam CLI analyzer ready!');
    console.log('');
    console.log('You can now use: codeyam init');
  } catch (error) {
    console.error('❌ Failed to finalize CodeYam CLI analyzer:');
    console.error(error.message);
    console.error('');
    console.error('This means the CodeYam CLI installation is incomplete.');
    console.error('You can try manually running:');
    console.error(`  cd ${analyzerTemplatePath}`);
    console.error('  npm install');
    console.error('  npx playwright install');
    console.error('  npm run build');
    console.error('');
    process.exit(1);
  }
}

finalizeAnalyzerTemplate();