import * as fs from 'fs/promises';
import * as fsSync from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';
import { ProjectFramework } from "../../../packages/types/index.js";
import { error, header, info, ProgressReporter, success, withoutSpinner, } from "../utils/progress.js";
import { ensureLocalBranch, ensureProject, getSqlitePath, testEnvironment, } from "../utils/database.js";
import { createAnalyzer } from "../utils/analyzer.js";
import { ProjectAnalyzer } from "../../../packages/analyze/index.js";
import { createSqliteSchema, getSqliteDatabase, loadFiles, } from "../../../packages/supabase/index.js";
import getFilesWithEntitiesFromRepo from "../../../background/src/lib/virtualized/project/getFilesWithEntitiesFromRepo.js";
import createEntitiesAndSortFiles from "../../../background/src/lib/virtualized/project/createEntitiesAndSortFiles.js";
import { findProjectRoot } from "../utils/project.js";
import { setProjectRoot } from "../state.js";
const initCommand = {
    command: 'init',
    describe: 'Initialize a project for CodeYam CLI analysis',
    builder: {
        force: {
            type: 'boolean',
            alias: 'f',
            describe: 'Force initialization even if .codeyam already exists',
            default: false,
        },
        'webapp-path': {
            type: 'string',
            alias: 'w',
            describe: 'Relative path to webapp directory (for monorepos)',
            default: '.',
        },
    },
    handler: async (argv) => {
        header('Initializing CodeYam CLI project');
        let projectRoot = findProjectRoot();
        // Check if already initialized
        if (projectRoot && !argv.force) {
            success('Project already initialized. Use --force to reinitialize.');
            return;
        }
        if (!projectRoot) {
            projectRoot = process.cwd();
        }
        setProjectRoot(projectRoot);
        const codeyamDir = path.join(projectRoot, '.codeyam');
        const configPath = path.join(codeyamDir, 'config.json');
        const progress = new ProgressReporter();
        // Normalize webapp path (relative to project root)
        const webappPath = path.normalize(argv.webappPath || '.');
        try {
            // Create directory structure
            progress.start('Creating .codeyam directory structure...');
            await fs.mkdir(codeyamDir, { recursive: true });
            await fs.mkdir(path.join(codeyamDir, 'results'), { recursive: true });
            await fs.mkdir(path.join(codeyamDir, 'captures'), { recursive: true });
            progress.succeed('Created .codeyam directory structure');
            // Generate project slug
            progress.start('Detecting project configuration...');
            const projectSlug = generateProjectSlug(projectRoot);
            const framework = detectFramework(projectRoot, webappPath);
            const packageManager = detectPackageManager(projectRoot);
            progress.succeed('Detected project configuration');
            // Validate framework - only proceed with known web frameworks
            if (framework === ProjectFramework.Unknown) {
                progress.fail('Unsupported project type');
                error('CodeYam only supports web applications (Next.js, Remix, CRA)');
                info('Detected frameworks: Next.js, Remix, Create React App');
                return;
            }
            // Create config.json
            progress.start('Writing configuration file...');
            const config = {
                projectSlug,
                framework,
                packageManager,
                webappPath,
                createdAt: new Date().toISOString(),
            };
            await fs.writeFile(configPath, JSON.stringify(config, null, 2));
            progress.succeed('Created configuration file');
            const sqlitePath = getSqlitePath();
            if (!fsSync.existsSync(sqlitePath)) {
                progress.start('Creating local database...');
                const newDatabase = getSqliteDatabase(sqlitePath);
                await createSqliteSchema(newDatabase);
                progress.succeed('Local database ready');
            }
            // Test database connection and create project
            progress.start('Validating environment...');
            const connectionOk = await withoutSpinner(() => testEnvironment());
            if (!connectionOk) {
                progress.fail('Environment validation failed');
                return;
            }
            progress.succeed('Environment validated');
            // Create project in database
            progress.start('Creating project and analyzer...');
            try {
                const project = await ensureProject({
                    slug: projectSlug,
                    framework,
                    packageManager,
                    appDirectory: webappPath !== '.' ? `${webappPath}/app` : undefined,
                });
                progress.succeed('Project created in database');
                info(`Database ID: ${project?.id}`);
                info(`Using webapp path: ${webappPath}`);
                // Create _local branch for local development
                progress.start('Creating local development branch...');
                const localBranch = await ensureLocalBranch(project);
                progress.succeed('Created _local branch');
                // Create baseline entities in database
                progress.start('Analyzing project and creating baseline entities...');
                await createBaselineEntities(project, localBranch, projectRoot);
                progress.succeed('Baseline entities created');
                // Update config with branch ID for future reference
                config.branchId = localBranch.id;
                await fs.writeFile(configPath, JSON.stringify(config, null, 2));
                // Warm analyzer cache for faster first analysis
                progress.start('Setting up analyzer...');
                await createAnalyzer(projectSlug);
                progress.succeed('Analyzer ready for fast analysis');
            }
            catch (err) {
                progress.fail('Failed to create project and analyzer');
                error(err.message);
                return;
            }
            console.log();
            success(`Initialized project: ${projectSlug}`);
            info(`Framework: ${framework}`);
            info(`Package Manager: ${packageManager}`);
            if (webappPath !== '.') {
                info(`Webapp Path: ${webappPath}`);
            }
            console.log();
            console.log('Next steps:');
            console.log();
            console.log('  Simulate any code in your project');
            console.log('    1. Run "codeyam analyze --path <file-path>" (to analyze a specific file)');
            console.log();
            console.log('  Or analyze recent changes to your project');
            console.log('    1. Run: "codeyam status" (to see changes since initialization)');
            console.log('    2. Run: "codeyam analyze" (to analyze changed files)');
            console.log('    3. Make changes to your code and repeat!');
        }
        catch (err) {
            progress.fail('Failed to initialize project');
            error(err.message);
            process.exit(1);
        }
    },
};
function generateProjectSlug(projectPath) {
    try {
        // Try to detect GitHub remote
        const gitConfig = execSync('git config --get remote.origin.url', {
            cwd: projectPath,
            encoding: 'utf8',
        }).trim();
        // Parse GitHub URL: https://github.com/owner/repo.git or git@github.com:owner/repo.git
        const githubMatch = gitConfig.match(/github\.com[:/]([^/]+)\/([^/]+?)(?:\.git)?$/);
        if (githubMatch) {
            return `${githubMatch[1]}-${githubMatch[2]}`;
        }
    }
    catch (error) {
        // Not a git repo or no remote, fall back to local naming
    }
    // Fallback: local-{username}-{dirname}
    const username = process.env.USER || process.env.USERNAME || 'user';
    const dirname = path.basename(projectPath);
    return `local-${username}-${dirname}`;
}
function detectFramework(projectPath, webappSubPath = '.') {
    const webappPath = path.join(projectPath, webappSubPath);
    const packageJsonPath = path.join(webappPath, 'package.json');
    if (!fsSync.existsSync(packageJsonPath)) {
        return ProjectFramework.Unknown;
    }
    const packageJson = JSON.parse(fsSync.readFileSync(packageJsonPath, 'utf8'));
    const deps = { ...packageJson.dependencies, ...packageJson.devDependencies };
    if (deps.next)
        return ProjectFramework.Next;
    if (deps['@remix-run/node'] || deps['@remix-run/react'])
        return ProjectFramework.Remix;
    if (deps['react-scripts'])
        return ProjectFramework.CRA;
    return ProjectFramework.Unknown;
}
function detectPackageManager(projectPath) {
    if (fsSync.existsSync(path.join(projectPath, 'pnpm-lock.yaml')))
        return 'pnpm';
    if (fsSync.existsSync(path.join(projectPath, 'yarn.lock')))
        return 'yarn';
    if (fsSync.existsSync(path.join(projectPath, 'package-lock.json')))
        return 'npm';
    return 'npm'; // default fallback
}
/**
 * Create baseline entities for a project during initialization
 * This populates the database so that subsequent status/analyze commands
 * only show actual changes, not every file as "new"
 */
async function createBaselineEntities(project, branch, projectRootPath) {
    // Load project with files to populate project.files
    if (!project.files) {
        project.files = await loadFiles({ projectId: project.id });
    }
    // Initialize ProjectAnalyzer and populate project.files with entities
    const projectAnalyzer = await ProjectAnalyzer.from({
        project: project,
        dirPath: projectRootPath,
    });
    await getFilesWithEntitiesFromRepo({
        project: project,
        projectAnalyzer,
        silent: true,
    });
    // Now create and persist all entities to database
    await createEntitiesAndSortFiles({ project, branch, projectAnalyzer });
}
export default initCommand;
//# sourceMappingURL=init.js.map