import * as fs from 'fs/promises';
import * as path from 'path';
import { error, header, info, ProgressReporter, success, withoutSpinner, } from "../utils/progress.js";
import { testEnvironment } from "../utils/database.js";
import { detectUniversalMocks } from "../utils/universal-mocks.js";
import { loadProject, upsertProjects } from "../../../packages/supabase/index.js";
import { getProjectRoot } from "../state.js";
const detectUniversalMocksCommand = {
    command: 'detect-universal-mocks',
    describe: 'Analyze codebase to detect universal mocks needed for unconfigured startup',
    handler: async () => {
        header('CodeYam Universal Mocks Detection');
        const progress = new ProgressReporter();
        // Find project root directory
        const projectRoot = getProjectRoot();
        if (!projectRoot) {
            error('Not in a CodeYam project. Run: codeyam init');
            return;
        }
        const configPath = path.join(projectRoot, '.codeyam', 'config.json');
        try {
            // Load project configuration
            progress.start('Loading project configuration...');
            const config = JSON.parse(await fs.readFile(configPath, 'utf8'));
            const { projectSlug } = config;
            if (!projectSlug) {
                progress.fail('Invalid project configuration');
                error('Missing project slug. Try reinitializing with: codeyam init --force');
                return;
            }
            progress.succeed('Loaded project configuration');
            // Test database connection
            progress.start('Validating environment...');
            const connectionOk = await withoutSpinner(() => testEnvironment());
            if (!connectionOk) {
                progress.fail('Environment validation failed');
                return;
            }
            progress.succeed('Environment validated');
            // Load project from database
            progress.start('Loading project from database...');
            const project = await loadProject({ slug: projectSlug });
            if (!project) {
                progress.fail('Project not found in database');
                error(`Project "${projectSlug}" not found. Try reinitializing.`);
                return;
            }
            progress.succeed('Loaded project from database');
            // Run universal mocks detection
            progress.start('Analyzing codebase...');
            const existingMocks = project.metadata?.universalMocks || [];
            info(`Found ${existingMocks.length} existing universal mocks`);
            // Create progress callback to update the spinner with message count
            const progressCallback = (messageCount) => {
                progress.update(`Analyzing codebase... (${messageCount} Claude Code messages processed)`);
            };
            const result = await detectUniversalMocks(existingMocks, progressCallback);
            progress.succeed('Universal mocks detection completed');
            // Log the completion info now that the spinner is done
            info(`Claude Code finished in ${result.duration_ms}ms, cost $${result.total_cost_usd.toFixed(4)}`);
            info(`Detected ${result.universalMocks.length} universal mocks`);
            if (result.universalMocks.length === 0) {
                success('No universal mocks detected. Your codebase appears to be already compatible with unconfigured startup.');
                return;
            }
            // Update project metadata with new universal mocks
            progress.start('Updating project metadata...');
            // Re-read the project to minimize race conditions
            const freshProject = await loadProject({ slug: projectSlug });
            if (!freshProject) {
                progress.fail('Project no longer exists');
                error('Project was deleted while processing. Please try again.');
                return;
            }
            // Create updated project with new universal mocks
            const updatedProject = {
                ...freshProject,
                metadata: {
                    ...freshProject.metadata,
                    universalMocks: result.universalMocks,
                },
            };
            // Use upsertProjects to save the updated project
            await upsertProjects([updatedProject]);
            progress.succeed('Project metadata updated');
            // Display results
            console.log();
            success('Universal mocks detection completed successfully!');
            info(`Updated project with ${result.universalMocks.length} universal mocks`);
            // Show summary of detected mocks
            if (result.universalMocks.length > 0) {
                console.log();
                info('Detected universal mocks:');
                result.universalMocks.forEach((mock, index) => {
                    info(`  ${index + 1}. ${mock.entityName} in ${mock.filePath}`);
                });
            }
        }
        catch (err) {
            progress.fail('Universal mocks detection failed');
            error(`Error: ${err.message}`);
            if (err.stack) {
                console.error('Stack trace:', err.stack);
            }
            process.exit(1);
        }
    },
};
export default detectUniversalMocksCommand;
//# sourceMappingURL=detect-universal-mocks.js.map