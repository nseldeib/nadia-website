import * as fs from 'fs';
import * as path from 'path';
import { error, header, info, ProgressReporter, withoutSpinner, } from "../utils/progress.js";
import { requireBranchAndProject, testEnvironment } from "../utils/database.js";
import { startWebServer } from "../webserver/server.js";
import { getProjectRoot } from "../state.js";
const webserveCommand = {
    command: 'webserve',
    describe: 'Start the web server to view analysis results',
    builder: {
        port: {
            type: 'number',
            alias: 'p',
            describe: 'Port to run the web server on',
            default: 3001,
        },
    },
    handler: async (argv) => {
        header('CodeYam Web Server');
        const progress = new ProgressReporter();
        // Find project root directory
        const projectRoot = getProjectRoot();
        if (!projectRoot) {
            error('Not in a CodeYam project. Run: codeyam init');
            return;
        }
        const configPath = path.join(projectRoot, '.codeyam', 'config.json');
        try {
            // Load project configuration
            progress.start('Loading project configuration...');
            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            const { projectSlug } = config;
            if (!projectSlug) {
                progress.fail('Invalid project configuration');
                error('Missing project slug. Try reinitializing with: codeyam init --force');
                return;
            }
            progress.succeed('Loaded project configuration');
            // Test database connection
            progress.start('Validating environment...');
            const connectionOk = await withoutSpinner(() => testEnvironment());
            if (!connectionOk) {
                progress.fail('Environment validation failed');
                return;
            }
            progress.succeed('Environment validated');
            // Load project and branch from database
            progress.start('Loading project from database...');
            const { project, branch } = await requireBranchAndProject(projectSlug);
            progress.succeed('Loaded project and branch');
            // Start web server
            progress.start('Starting web server...');
            const { url } = await startWebServer({
                port: argv.port,
                rootPath: projectRoot,
                project,
                branch,
            });
            progress.succeed('Web server started');
            console.log();
            console.log(`🌐 CodeYam Web Server running at ${url}`);
            console.log(`📁 Project: ${projectSlug}`);
            console.log('💡 Press Ctrl+C to stop');
            console.log();
            // Auto-open on macOS
            try {
                const { execSync } = await import('child_process');
                execSync(`open "${url}"`, { stdio: 'ignore' });
                info('📱 Opening in browser...');
            }
            catch (e) {
                // Silently fail if open command doesn't work
            }
            // Keep the process running
            await new Promise(() => { }); // Never resolves - server runs until Ctrl+C
        }
        catch (err) {
            progress.fail('Failed to start web server');
            error(err);
            process.exit(1);
        }
    },
};
export default webserveCommand;
//# sourceMappingURL=webserve.js.map