import * as fs from 'fs/promises';
import * as path from 'path';
import { error, header, info, ProgressReporter, success, withoutSpinner } from "../utils/progress.js";
import { createFakeCommit, getSqlitePath, requireBranchAndProject, testEnvironment } from "../utils/database.js";
import { detectChangedFilePaths } from "../utils/changeDetection.js";
import { analyzerExists, createAnalyzer, isAnalyzerFresh, runAnalyzerWithProcess, runCaptureWithProcess } from "../utils/analyzer.js";
import { loadSecrets } from "../utils/secrets.js";
import { startWebServer } from "../webserver/server.js";
import { getProjectRoot } from "../state.js";
const analyzeCommand = {
    command: 'analyze [files...]',
    describe: 'Analyze local code changes before committing',
    builder: {
        files: {
            type: 'array',
            describe: 'Specific files to analyze (defaults to detecting changed files)',
        },
    },
    handler: async (argv) => {
        header('CodeYam Analysis');
        const progress = new ProgressReporter();
        // Find project root directory
        const projectRoot = getProjectRoot();
        if (!projectRoot) {
            error('Not in a CodeYam project. Run: codeyam init');
            return;
        }
        const configPath = path.join(projectRoot, '.codeyam', 'config.json');
        try {
            // Load project configuration
            progress.start('Loading project configuration...');
            const config = JSON.parse(await fs.readFile(configPath, 'utf8'));
            const { projectSlug, branchId } = config;
            if (!projectSlug || !branchId) {
                progress.fail('Invalid project configuration');
                error('Missing project slug or branch ID. Try reinitializing with: codeyam init --force');
                return;
            }
            progress.succeed('Loaded project configuration');
            // Test database connection
            progress.start('Validating environment...');
            const connectionOk = await withoutSpinner(() => testEnvironment());
            if (!connectionOk) {
                progress.fail('Environment validation failed');
                return;
            }
            progress.succeed('Environment validated');
            // Load project and branch from database
            progress.start('Loading project from database...');
            const { project, branch } = await requireBranchAndProject(projectSlug);
            progress.succeed('Loaded project and branch');
            // Determine files to analyze
            progress.start('Detecting files to analyze...');
            const filesToAnalyze = argv.files && argv.files.length > 0
                ? argv.files
                : await detectChangedFilePaths(projectSlug, projectRoot);
            if (filesToAnalyze.length === 0) {
                progress.succeed('No files to analyze');
                info('No changed files detected. Specify files explicitly or make changes to your code.');
                return;
            }
            progress.succeed(`Found ${filesToAnalyze.length} files to analyze`);
            // Create fake commit for analysis
            progress.start('Creating analysis commit...');
            const fakeCommit = await createFakeCommit(project, branch, filesToAnalyze);
            progress.succeed(`Created commit ${fakeCommit.sha.substring(0, 8)}`);
            // Start web server to view live results
            progress.start('Starting web server...');
            const { url } = await startWebServer({
                port: 3001,
                rootPath: projectRoot,
                project,
                branch,
            });
            progress.succeed('Web server started');
            // Show URLs and auto-open
            const commitUrl = `${url}/commit/${fakeCommit.sha}`;
            console.log();
            info(`🌐 Live results: ${commitUrl}`);
            // Auto-open on macOS
            try {
                const { execSync } = await import('child_process');
                execSync(`open "${commitUrl}"`, { stdio: 'ignore' });
                info('📱 Opening in browser...');
            }
            catch (e) {
                // Silently fail if open command doesn't work
            }
            // Show what we're analyzing
            console.log();
            info(`Analyzing ${filesToAnalyze.length} files:`);
            filesToAnalyze.forEach((file) => info(`  • ${file}`));
            console.log();
            progress.start('Starting analysis pipeline...');
            // Lazy creation - only if missing
            if (!analyzerExists(projectSlug)) {
                progress.update('Creating persistent analyzer...');
                await createAnalyzer(projectSlug);
            }
            progress.succeed('Analyzer ready');
            // Check if analyzer is fresh
            progress.start('Checking analyzer freshness...');
            const freshnessCheck = isAnalyzerFresh(projectSlug);
            if (!freshnessCheck.isFresh) {
                progress.fail('Analyzer is outdated');
                error('Cached analyzer is outdated!');
                error(`Reason: ${freshnessCheck.reason}`);
                info('');
                info('To fix this, run: codeyam init --force');
                info('This will refresh your analyzer with the latest build.');
                process.exit(1);
            }
            progress.succeed('Analyzer is up-to-date');
            progress.start('Running analysis and capture...');
            // Prepare environment and arguments for the analyzer
            const analyzerEnvironment = {
                ...(await loadSecrets()),
                PROJECT_SLUG: projectSlug,
                USE_WORKER_THREADS: 'true',
                COMMIT_SHA: fakeCommit.sha,
                CODEYAM_LOCAL_PROJECT_PATH: projectRoot,
                SQLITE_PATH: getSqlitePath(),
            };
            const analyzerStartArgs = {
                packageManager: project.metadata?.packageManager || 'npm',
                absoluteProjectRootPath: `/tmp/codeyam/local-dev/${projectSlug}/project`,
                port: 3000,
                noServer: false,
                framework: project.metadata?.framework,
            };
            // Progress tracking callback
            let totalChars = 0;
            let lastProgressUpdate = 0;
            const progressCallback = (chars) => {
                totalChars += chars;
                const now = Date.now();
                // Update every 500ms or every 5KB, whichever comes first
                if (now - lastProgressUpdate > 500 ||
                    totalChars - lastProgressUpdate > 5000) {
                    let formattedSize;
                    if (totalChars < 10000) {
                        formattedSize = `${totalChars.toLocaleString()} chars`;
                    }
                    else if (totalChars < 10 * 1024 * 1024) {
                        formattedSize = `${(totalChars / 1024).toFixed(1)}KB`;
                    }
                    else {
                        formattedSize = `${(totalChars / (1024 * 1024)).toFixed(2)}MB`;
                    }
                    progress.update(`Running analysis and capture... (${formattedSize})`);
                    lastProgressUpdate = now;
                }
            };
            // Run both processes concurrently - either completing will finish the analysis
            const analysisResult = runAnalyzerWithProcess(projectSlug, analyzerEnvironment, analyzerStartArgs, progressCallback);
            const captureResult = runCaptureWithProcess(projectSlug, progressCallback);
            const analysisPromise = analysisResult.promise;
            const capturePromise = captureResult.promise;
            try {
                await Promise.race([analysisPromise, capturePromise]);
            }
            finally {
                // Kill any remaining processes
                try {
                    analysisResult.process.kill('SIGTERM');
                }
                catch (e) {
                    // Process may have already exited
                }
                try {
                    captureResult.process.kill('SIGTERM');
                }
                catch (e) {
                    // Process may have already exited
                }
            }
            progress.succeed('Analysis completed');
            console.log();
            success('Analysis completed successfully!');
            info(`Commit SHA: ${fakeCommit.sha}`);
            info('Results saved to .codeyam/results/');
            console.log();
            info(`🌐 View results: ${commitUrl}`);
            info('💡 Web server will continue running. Press Ctrl+C to stop.');
        }
        catch (err) {
            progress.fail('Analysis failed');
            error(err);
            process.exit(1);
        }
    },
};
export default analyzeCommand;
//# sourceMappingURL=analyze.js.map