import * as fs from 'fs';
import * as path from 'path';
import { error, header, info, ProgressReporter, success, withoutSpinner, } from "../utils/progress.js";
import { detectEntityChanges } from "../utils/changeDetection.js";
import { testEnvironment } from "../utils/database.js";
import { getProjectRoot } from "../state.js";
const statusCommand = {
    command: 'status',
    describe: 'Show status of local code changes compared to database',
    handler: async () => {
        header('CodeYam Status');
        const progress = new ProgressReporter();
        // Find project root directory
        const projectRoot = getProjectRoot();
        if (!projectRoot) {
            error('Not in a CodeYam project. Run: codeyam init');
            return;
        }
        const configPath = path.join(projectRoot, '.codeyam', 'config.json');
        try {
            // Load project configuration
            progress.start('Loading project configuration...');
            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            const { projectSlug } = config;
            if (!projectSlug) {
                progress.fail('Invalid project configuration');
                error('Missing project slug. Try reinitializing with: codeyam init --force');
                return;
            }
            progress.succeed('Loaded project configuration');
            // Test database connection
            progress.start('Validating environment...');
            const connectionOk = await withoutSpinner(() => testEnvironment());
            if (!connectionOk) {
                progress.fail('Environment validation failed');
                return;
            }
            progress.succeed('Environment validated');
            // Detect changes
            progress.start('Detecting changes...');
            const changes = await detectEntityChanges(projectSlug, projectRoot);
            progress.succeed('Change detection completed');
            // Display results
            console.log();
            if (changes.newFiles.length === 0 &&
                changes.modifiedFiles.length === 0 &&
                changes.deletedFiles.length === 0) {
                success('No changes detected');
                info('Local repository matches database state');
                return;
            }
            // Show new files
            if (changes.newFiles.length > 0) {
                info(`New files (${changes.newFiles.length}):`);
                for (const file of changes.newFiles) {
                    const entityCount = file.entities?.length || 0;
                    const entityText = entityCount === 1 ? 'entity' : 'entities';
                    info(`  📄 ${file.path} (${entityCount} ${entityText})`);
                    // Show entities in new files
                    if (file.entities && file.entities.length > 0) {
                        for (const entity of file.entities) {
                            info(`    ├─ ${entity.name} (${entity.entityType})`);
                        }
                    }
                }
                console.log();
            }
            // Show modified files
            if (changes.modifiedFiles.length > 0) {
                info(`Modified files (${changes.modifiedFiles.length}):`);
                for (const { file, modifiedEntities, newEntities, } of changes.modifiedFiles) {
                    const totalChanges = modifiedEntities.length + newEntities.length;
                    info(`  📝 ${file.path} (${totalChanges} changes)`);
                    // Show modified entities
                    if (modifiedEntities.length > 0) {
                        for (const entity of modifiedEntities) {
                            info(`    ├─ ${entity.name} (${entity.entityType}) - modified`);
                        }
                    }
                    // Show new entities
                    if (newEntities.length > 0) {
                        for (const entity of newEntities) {
                            info(`    ├─ ${entity.name} (${entity.entityType}) - new`);
                        }
                    }
                }
                console.log();
            }
            // Show deleted files
            if (changes.deletedFiles.length > 0) {
                info(`Deleted files (${changes.deletedFiles.length}):`);
                for (const file of changes.deletedFiles) {
                    info(`  🗑️  ${file.path}`);
                }
                console.log();
            }
            // Summary
            const totalChangedFiles = changes.newFiles.length + changes.modifiedFiles.length;
            if (totalChangedFiles > 0) {
                info(`${totalChangedFiles} file(s) with changes ready for analysis`);
                info('Run "codeyam analyze" to process these changes');
            }
        }
        catch (err) {
            progress.fail('Status check failed');
            error(err.message);
            process.exit(1);
        }
    },
};
export default statusCommand;
//# sourceMappingURL=status.js.map