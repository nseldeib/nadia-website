import { error, header, info } from "../utils/progress.js";
const listCommand = {
    command: 'list [type]',
    describe: 'List entities or analyses',
    builder: {
        type: {
            type: 'string',
            choices: ['entities', 'analyses'],
            default: 'entities',
            describe: 'What to list',
        },
    },
    handler: async (argv) => {
        header(`Listing ${argv.type}`);
        switch (argv.type) {
            case 'entities':
                error('Entity listing not yet implemented');
                info('This will show all discoverable entities in the current project');
                break;
            case 'analyses':
                error('Analysis listing not yet implemented');
                info('This will show completed analyses for the current project');
                break;
        }
        // TODO: Implement listing functionality
        // 1. For entities: scan project files and discover analyzable entities
        // 3. For analyses: query database for analyses belonging to current project
    },
};
export default listCommand;
//# sourceMappingURL=list.js.map