#!/usr/bin/env node
import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';
// Command implementations
import initCommand from "./commands/init.js";
import analyzeCommand from "./commands/analyze.js";
import statusCommand from "./commands/status.js";
import listCommand from "./commands/list.js";
import detectUniversalMocksCommand from "./commands/detect-universal-mocks.js";
import webserveCommand from "./commands/webserve.js";
// Set up the CLI with yargs
yargs(hideBin(process.argv))
    .scriptName('codeyam')
    .version('0.1.0')
    .usage('CodeYam local development CLI')
    .command(initCommand)
    .command(analyzeCommand)
    .command(statusCommand)
    .command(listCommand)
    .command(detectUniversalMocksCommand)
    .command(webserveCommand)
    .demandCommand(1)
    .help()
    .alias('help', 'h')
    .strict()
    .parseAsync()
    .catch((error) => {
    console.error('CLI Error:', error.message);
    process.exit(1);
});
//# sourceMappingURL=cli.js.map