import { Router } from 'express';
import { renderLayout } from "../templates/layout.js";
import { getCommitById } from "../utils/database.js";
import { extractAnalysisStatusString, getAnalysisStatusClass, } from "../utils/status.js";
export const commitRouter = Router();
commitRouter.get('/:sha', async (req, res) => {
    try {
        const { sha } = req.params;
        const { project } = req.app.locals;
        const commit = await getCommitById(project.id, sha);
        if (!commit) {
            const errorContent = `
        <div class="no-results">
          <h2>Commit Not Found</h2>
          <p class="text-gray-400">Commit ${sha} was not found.</p>
          <p class="text-sm mt-2">
            <a href="/">← Back to runs</a>
          </p>
        </div>
      `;
            const html = renderLayout({
                title: 'Commit Not Found',
                content: errorContent,
                breadcrumbs: [
                    { label: 'Runs', href: '/' },
                    { label: sha.substring(0, 8) },
                ],
            });
            res.status(404).send(html);
            return;
        }
        const content = `
      <div class="commit-details">
        <h2>Commit ${commit.sha.substring(0, 8)}</h2>
        <p class="text-gray-400 mb-6">${commit.message || 'No message'}</p>
        
        <div class="mb-8">
          <h3>Commit Information</h3>
          <table class="mb-4">
            <tbody>
              <tr>
                <td class="font-semibold">SHA</td>
                <td class="font-mono">${commit.sha}</td>
              </tr>
              <tr>
                <td class="font-semibold">Author</td>
                <td>${commit.author?.username || 'Unknown'}</td>
              </tr>
              <tr>
                <td class="font-semibold">Date</td>
                <td>${new Date(commit.committedAt).toLocaleString()}</td>
              </tr>
              <tr>
                <td class="font-semibold">Files</td>
                <td>${commit.files?.length || 0}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="analyses-section">
          <h3>Analyses (${commit.analyses?.length || 0})</h3>
          
          ${!commit.analyses || commit.analyses.length === 0
            ? `
            <div class="no-results">
              <p>No analyses found for this commit.</p>
            </div>
          `
            : `
            <table>
              <thead>
                <tr>
                  <th>File</th>
                  <th>Entity</th>
                  <th>Scenarios</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${commit.analyses
                .map((analysis) => `
                  <tr>
                    <td class="font-mono text-blue-400">
                      ${analysis.file?.path || 'Unknown file'}
                    </td>
                    <td class="text-gray-300">
                      ${analysis.entityName || 'Unknown entity'}
                    </td>
                    <td class="text-gray-400">
                      ${analysis.scenarios?.length || 0} scenarios
                    </td>
                    <td>
                      ${(() => {
                const statusStr = extractAnalysisStatusString(analysis.status);
                return `<span class="status-badge ${getAnalysisStatusClass(analysis.status)}">
                          ${statusStr}
                        </span>`;
            })()}
                    </td>
                    <td>
                      <a href="/analysis/${analysis.id}">View Details →</a>
                    </td>
                  </tr>
                `)
                .join('')}
              </tbody>
            </table>
          `}
        </div>

        ${commit.files && commit.files.length > 0
            ? `
          <div class="files-section mt-8">
            <h3>Files Changed (${commit.files.length})</h3>
            <table>
              <thead>
                <tr>
                  <th>File</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${commit.files
                .map((file) => `
                  <tr>
                    <td class="font-mono">${file.fileName}</td>
                    <td class="text-gray-400">${file.status}</td>
                  </tr>
                `)
                .join('')}
              </tbody>
            </table>
          </div>
        `
            : ''}
      </div>
    `;
        const html = renderLayout({
            title: `Commit ${commit.sha.substring(0, 8)}`,
            content,
            breadcrumbs: [
                { label: 'Runs', href: '/' },
                { label: commit.sha.substring(0, 8) },
            ],
        });
        res.send(html);
    }
    catch (error) {
        console.error('Error loading commit:', error);
        const errorContent = `
      <div class="no-results">
        <h2>Error Loading Commit</h2>
        <p class="text-red-400">Failed to load commit details.</p>
        <p class="text-gray-400 text-sm mt-2">Check console for details.</p>
      </div>
    `;
        const html = renderLayout({
            title: 'Error',
            content: errorContent,
        });
        res.status(500).send(html);
    }
});
//# sourceMappingURL=commit.js.map