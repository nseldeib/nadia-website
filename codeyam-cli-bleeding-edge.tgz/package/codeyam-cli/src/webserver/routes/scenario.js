import { Router } from 'express';
import { renderLayout } from "../templates/layout.js";
import { loadAnalysis, loadScenario } from "../../../../packages/supabase/index.js";
export const scenarioRouter = Router();
scenarioRouter.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { project } = req.app.locals;
        const scenario = await loadScenario({
            id,
            projectId: project.id,
        });
        if (!scenario) {
            const errorContent = `
        <div class="no-results">
          <h2>Scenario Not Found</h2>
          <p class="text-gray-400">Scenario ${id} was not found.</p>
          <p class="text-sm mt-2">
            <a href="/">← Back to runs</a>
          </p>
        </div>
      `;
            const html = renderLayout({
                title: 'Scenario Not Found',
                content: errorContent,
                breadcrumbs: [
                    { label: 'Runs', href: '/' },
                    { label: 'Scenario Not Found' },
                ],
            });
            res.status(404).send(html);
            return;
        }
        // Load analysis to get runtime status information
        const analysis = await loadAnalysis({
            id: scenario.analysisId,
            includeFile: true,
        });
        scenario.analysis = analysis; // back-reference for easier access
        // Find runtime status for this scenario
        const scenarioStatus = analysis?.status?.scenarios?.find((s) => s.name === scenario.name);
        const analysisName = analysis?.entityName || 'Unknown Analysis';
        const filePath = analysis?.file?.path || 'Unknown File';
        const content = `
      <div class="scenario-details">
        <h2>Scenario: ${scenario.name || 'Unnamed Scenario'}</h2>
        <p class="text-gray-400 mb-6">
          Analysis: <a href="/analysis/${analysis?.id}" class="text-blue-400">${analysisName}</a> 
          from <span class="font-mono">${filePath}</span>
        </p>
        
        <div class="mb-8">
          <h3>Scenario Information</h3>
          <table class="mb-4">
            <tbody>
              <tr>
                <td class="font-semibold">Name</td>
                <td>${scenario.name || 'Unnamed scenario'}</td>
              </tr>
              <tr>
                <td class="font-semibold">Status</td>
                <td>
                  ${scenarioStatus?.finishedAt
            ? `<span class="status-badge status-completed">Completed</span>`
            : scenarioStatus?.startedAt
                ? `<span class="status-badge status-pending">Running</span>`
                : `<span class="status-badge status-pending">Pending</span>`}
                </td>
              </tr>
              ${scenarioStatus?.startedAt
            ? `
                <tr>
                  <td class="font-semibold">Started</td>
                  <td>${new Date(scenarioStatus.startedAt).toLocaleString()}</td>
                </tr>
              `
            : ''}
              ${scenarioStatus?.finishedAt
            ? `
                <tr>
                  <td class="font-semibold">Finished</td>
                  <td>${new Date(scenarioStatus.finishedAt).toLocaleString()}</td>
                </tr>
              `
            : ''}
            </tbody>
          </table>
        </div>

        ${scenario.description
            ? `
          <div class="description-section mb-8">
            <h3>Description</h3>
            <div class="bg-gray-800 p-4 rounded">
              <p class="text-gray-300">${scenario.description}</p>
            </div>
          </div>
        `
            : ''}

        ${scenario.metadata?.screenshotPaths?.[0]
            ? `
          <div class="screenshot-section mb-8">
            <h3>Screenshot</h3>
            <div class="bg-gray-800 p-4 rounded">
              <img 
                src="/screenshots/${scenario.metadata.screenshotPaths[0]}" 
                alt="${scenario.name || 'Unnamed scenario'}" 
                style="max-width: 100%; height: auto; border-radius: 4px; border: 1px solid #4B5563;"
              />
            </div>
          </div>
        `
            : ''}

        ${scenario.metadata?.data
            ? `
          <div class="data-section mb-8">
            <h3>Scenario Data</h3>
            <div class="bg-gray-800 p-4 rounded">
              <pre class="text-sm text-gray-300 overflow-x-auto"><code>${JSON.stringify(scenario.metadata.data, null, 2)}</code></pre>
            </div>
          </div>
        `
            : ''}

        ${scenario.metadata
            ? `
          <div class="metadata-section mb-8">
            <h3>Metadata</h3>
            <div class="bg-gray-800 p-4 rounded">
              <pre class="text-sm text-gray-300 overflow-x-auto"><code>${JSON.stringify(scenario.metadata, null, 2)}</code></pre>
            </div>
          </div>
        `
            : ''}

        ${scenarioStatus?.error
            ? `
          <div class="errors-section mb-8">
            <h3>Runtime Error</h3>
            <div class="bg-red-900 p-4 rounded">
              <div class="text-red-200 mb-2">
                <strong>Error:</strong> ${scenarioStatus.error}
              </div>
              ${scenarioStatus.errorStack
                ? `
                <details class="mt-2">
                  <summary class="cursor-pointer text-red-300">Stack Trace</summary>
                  <pre class="text-xs text-red-200 mt-2 overflow-x-auto">${scenarioStatus.errorStack}</pre>
                </details>
              `
                : ''}
            </div>
          </div>
        `
            : ''}

        ${analysis?.status?.errors && analysis.status.errors.length > 0
            ? `
          <div class="analysis-errors-section mb-8">
            <h3>Analysis Errors</h3>
            <div class="bg-red-900 p-4 rounded">
              ${analysis.status.errors
                .map((error) => `
                <div class="text-red-200 mb-2">
                  <strong>Error:</strong> ${error.message}
                  <div class="text-xs text-red-300 mt-1">${error.timestamp}</div>
                </div>
              `)
                .join('')}
            </div>
          </div>
        `
            : ''}
      </div>
    `;
        const html = renderLayout({
            title: `Scenario: ${scenario.name || 'Unnamed'}`,
            content,
            breadcrumbs: [
                { label: 'Runs', href: '/' },
                { label: analysisName, href: `/analysis/${analysis?.id}` },
                { label: scenario.name || 'Unnamed Scenario' },
            ],
        });
        res.send(html);
    }
    catch (error) {
        console.error('Error loading scenario:', error);
        const errorContent = `
      <div class="no-results">
        <h2>Error Loading Scenario</h2>
        <p class="text-red-400">Failed to load scenario details.</p>
        <p class="text-gray-400 text-sm mt-2">Check console for details.</p>
      </div>
    `;
        const html = renderLayout({
            title: 'Error',
            content: errorContent,
        });
        res.status(500).send(html);
    }
});
//# sourceMappingURL=scenario.js.map