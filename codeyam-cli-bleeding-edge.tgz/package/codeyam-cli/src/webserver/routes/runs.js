import { Router } from 'express';
import { renderLayout } from "../templates/layout.js";
import { getProjectRuns } from "../utils/database.js";
export const runsRouter = Router();
runsRouter.get('/', async (req, res) => {
    try {
        const { project, branch } = req.app.locals;
        const runs = await getProjectRuns(project.id, branch.id);
        const content = `
      <div class="runs-list">
        <h2>Analysis Runs for ${project.slug}</h2>
        <p class="text-gray-400 mb-6">
          Recent analysis runs from your local development branch.
        </p>
        
        ${runs.length === 0 ? `
          <div class="no-results">
            <p>No analysis runs found.</p>
            <p class="text-sm mt-2">Run <code>codeyam analyze</code> to create your first analysis.</p>
          </div>
        ` : `
          <table>
            <thead>
              <tr>
                <th>Commit</th>
                <th>Message</th>
                <th>Files</th>
                <th>Analyses</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              ${runs.map(run => `
                <tr>
                  <td>
                    <a href="/commit/${run.sha}" class="font-mono">
                      ${run.sha.substring(0, 8)}
                    </a>
                  </td>
                  <td class="text-gray-300">
                    ${run.message || 'No message'}
                  </td>
                  <td class="text-gray-400">
                    ${run.files?.length || 0} files
                  </td>
                  <td class="text-blue-400">
                    ${run.analyses?.length || 0} analyses
                  </td>
                  <td class="text-gray-400 text-sm">
                    ${new Date(run.committedAt).toLocaleString()}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `}
      </div>
    `;
        const html = renderLayout({
            title: 'Analysis Runs',
            content,
            breadcrumbs: []
        });
        res.send(html);
    }
    catch (error) {
        console.error('Error loading runs:', error);
        const errorContent = `
      <div class="no-results">
        <h2>Error Loading Runs</h2>
        <p class="text-red-400">Failed to load analysis runs.</p>
        <p class="text-gray-400 text-sm mt-2">Check console for details.</p>
      </div>
    `;
        const html = renderLayout({
            title: 'Error',
            content: errorContent
        });
        res.status(500).send(html);
    }
});
//# sourceMappingURL=runs.js.map