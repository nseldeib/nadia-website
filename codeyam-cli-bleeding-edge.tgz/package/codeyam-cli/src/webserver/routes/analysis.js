import { Router } from 'express';
import { renderLayout } from "../templates/layout.js";
import { loadAnalysis } from "../../../../packages/supabase/index.js";
import { extractAnalysisScenarioStatusString, extractAnalysisStatusString, getAnalysisScenarioStatusClass, getAnalysisStatusClass } from "../utils/status.js";
export const analysisRouter = Router();
analysisRouter.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const analysis = await loadAnalysis({
            id,
            includeFile: true,
            includeScenarios: true,
        });
        if (!analysis) {
            const errorContent = `
        <div class="no-results">
          <h2>Analysis Not Found</h2>
          <p class="text-gray-400">Analysis ${id} was not found.</p>
          <p class="text-sm mt-2">
            <a href="/">← Back to runs</a>
          </p>
        </div>
      `;
            const html = renderLayout({
                title: 'Analysis Not Found',
                content: errorContent,
                breadcrumbs: [
                    { label: 'Runs', href: '/' },
                    { label: 'Analysis Not Found' },
                ],
            });
            res.status(404).send(html);
            return;
        }
        const content = `
      <div class="analysis-details">
        <h2>Analysis: ${analysis.entityName}</h2>
        <p class="text-gray-400 mb-6">
          File: <span class="font-mono text-blue-400">${analysis.file?.path || 'Unknown'}</span>
        </p>
        
        <div class="mb-8">
          <h3>Analysis Information</h3>
          <table class="mb-4">
            <tbody>
              <tr>
                <td class="font-semibold">Entity Name</td>
                <td>${analysis.entityName}</td>
              </tr>
              <tr>
                <td class="font-semibold">File Path</td>
                <td class="font-mono">${analysis.file?.path || 'Unknown'}</td>
              </tr>
              <tr>
                <td class="font-semibold">Status</td>
                <td>
                  ${(() => {
            const statusStr = extractAnalysisStatusString(analysis.status);
            return `<span class="status-badge ${getAnalysisStatusClass(analysis.status)}">
                      ${statusStr}
                    </span>`;
        })()}
                </td>
              </tr>
              <tr>
                <td class="font-semibold">Created</td>
                <td>${analysis.createdAt ? new Date(analysis.createdAt).toLocaleString() : 'Unknown'}</td>
              </tr>
              <tr>
                <td class="font-semibold">Updated</td>
                <td>${analysis.updatedAt ? new Date(analysis.updatedAt).toLocaleString() : 'Unknown'}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="scenarios-section">
          <h3>Scenarios (${analysis.scenarios?.length || 0})</h3>
          
          ${!analysis.scenarios || analysis.scenarios.length === 0
            ? `
            <div class="no-results">
              <p>No scenarios found for this analysis.</p>
            </div>
          `
            : `
            <table>
              <thead>
                <tr>
                  <th>Screenshot</th>
                  <th>Scenario Name</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${analysis.scenarios
                .map((scenario) => {
                const statusScenario = analysis?.status.scenarios?.find((s) => s.name === scenario.name);
                return `
                  <tr>
                    <td style="width: 120px; padding: 8px;">
                      ${scenario.metadata?.screenshotPaths?.[0]
                    ? `
                        <img 
                          src="/screenshots/${scenario.metadata.screenshotPaths[0]}" 
                          alt="${scenario.name || 'Unnamed scenario'}" 
                          style="width: 100px; height: 60px; object-fit: cover; border-radius: 4px; border: 1px solid #374151;"
                        />
                      `
                    : `
                        <div style="width: 100px; height: 60px; background: #374151; border-radius: 4px; display: flex; align-items: center; justify-content: center; color: #6B7280; font-size: 12px;">
                          No image
                        </div>
                      `}
                    </td>
                    <td class="text-gray-300">
                      ${scenario.name || 'Unnamed scenario'}
                    </td>
                    <td>
                      <span class="status-badge ${getAnalysisScenarioStatusClass(statusScenario)}">
                        ${extractAnalysisScenarioStatusString(statusScenario)}
                      </span>
                    </td>
                    <td>
                      <a href="/scenario/${scenario.id}">View Details →</a>
                    </td>
                  </tr>
                `;
            })
                .join('')}
              </tbody>
            </table>
          `}
        </div>

        ${analysis.metadata
            ? `
          <div class="metadata-section mt-8">
            <h3>Metadata</h3>
            <div class="bg-gray-800 p-4 rounded">
              <pre class="text-xs text-gray-300 overflow-x-auto"><code>${JSON.stringify(analysis.metadata, null, 2)}</code></pre>
            </div>
          </div>
        `
            : ''}
        ${analysis.status
            ? `
          <div class="metadata-section mt-8">
            <h3>Status</h3>
            <div class="bg-gray-800 p-4 rounded">
              <pre class="text-xs text-gray-300 overflow-x-auto"><code>${JSON.stringify(analysis.status, null, 2)}</code></pre>
            </div>
          </div>
        `
            : ''}
  </div>
    `;
        const html = renderLayout({
            title: `Analysis: ${analysis.entityName}`,
            content,
            breadcrumbs: [
                { label: 'Runs', href: '/' },
                { label: analysis.entityName },
            ],
        });
        res.send(html);
    }
    catch (error) {
        console.error('Error loading analysis:', error);
        const errorContent = `
      <div class="no-results">
        <h2>Error Loading Analysis</h2>
        <p class="text-red-400">Failed to load analysis details.</p>
        <p class="text-gray-400 text-sm mt-2">Check console for details.</p>
      </div>
    `;
        const html = renderLayout({
            title: 'Error',
            content: errorContent,
        });
        res.status(500).send(html);
    }
});
//# sourceMappingURL=analysis.js.map