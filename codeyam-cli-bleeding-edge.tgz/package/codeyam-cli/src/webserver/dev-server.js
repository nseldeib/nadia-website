import * as fs from 'fs';
import * as path from 'path';
import { startWebServer } from "./server.js";
import { requireBranchAndProject, testEnvironment } from "../utils/database.js";
import { findProjectRoot } from "../utils/project.js";
import { setProjectRoot } from "../state.js";
async function main() {
    console.log('🚀 Starting CodeYam Dev Server...\n');
    // Get project path from command line argument or find it
    let projectRoot;
    if (process.argv[2]) {
        // Use provided path
        const providedPath = path.resolve(process.argv[2]);
        // normalize & verify
        projectRoot = findProjectRoot(providedPath);
        if (!projectRoot) {
            console.error(`❌ No CodeYam project found at: ${providedPath}`);
            console.error('Make sure the path contains a .codeyam/config.json file');
            process.exit(1);
        }
    }
    else {
        // Search from current directory
        projectRoot = findProjectRoot();
        if (!projectRoot) {
            console.error('❌ Usage: pnpm webdev [project-path]');
            console.error('Either run from within a CodeYam project, or provide a project path');
            console.error('Example: pnpm webdev /path/to/your/project');
            process.exit(1);
        }
    }
    // configure this to be the root path for all CLI operations henceforth
    setProjectRoot(projectRoot);
    const configPath = path.join(projectRoot, '.codeyam', 'config.json');
    try {
        // Load project configuration
        console.log('📋 Loading project configuration...');
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        const { projectSlug, branchId } = config;
        if (!projectSlug || !branchId) {
            console.error('❌ Invalid project configuration');
            console.error('Missing project slug or branch ID. Try reinitializing with: codeyam init --force');
            process.exit(1);
        }
        console.log('✅ Loaded project configuration');
        // Test database connection
        console.log('🔌 Validating environment...');
        const connectionOk = await testEnvironment();
        if (!connectionOk) {
            console.error('❌ Environment validation failed');
            process.exit(1);
        }
        console.log('✅ Environment validated');
        // Load project and branch from database
        console.log('📂 Loading project from database...');
        const { project, branch } = await requireBranchAndProject(projectSlug);
        console.log('✅ Loaded project');
        // Start web server
        console.log('🌐 Starting web server...');
        const { url } = await startWebServer({
            port: 3003,
            rootPath: projectRoot,
            project,
            branch,
        });
        console.log('\n🎉 Dev Server Ready!');
        console.log(`🌐 Server: ${url}`);
        console.log(`📁 Project: ${projectSlug}`);
        console.log(`🔥 Hot reload enabled via nodemon`);
        console.log('💡 Press Ctrl+C to stop\n');
        // Auto-open on macOS
        try {
            const { execSync } = await import('child_process');
            execSync(`open "${url}"`, { stdio: 'ignore' });
            console.log('📱 Opening in browser...');
        }
        catch (e) {
            // Silently fail if open command doesn't work
        }
    }
    catch (err) {
        console.error('❌ Failed to start dev server:', err);
        process.exit(1);
    }
}
main().catch(console.error);
//# sourceMappingURL=dev-server.js.map