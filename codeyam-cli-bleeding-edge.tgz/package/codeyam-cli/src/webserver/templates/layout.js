export function renderLayout({ title, content, breadcrumbs = [] }) {
    const breadcrumbsHtml = breadcrumbs.length > 0 ? `
    <nav class="breadcrumbs mb-6">
      <div class="flex items-center space-x-2 text-sm text-gray-400">
        ${breadcrumbs.map((crumb, i) => `
          ${i > 0 ? '<span class="text-gray-600">/</span>' : ''}
          ${crumb.href
        ? `<a href="${crumb.href}" class="text-blue-400 hover:text-blue-300">${crumb.label}</a>`
        : `<span class="text-gray-200">${crumb.label}</span>`}
        `).join('')}
      </div>
    </nav>
  ` : '';
    return `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} - CodeYam</title>
  <link href="/static/styles.css" rel="stylesheet">
</head>
<body class="bg-gray-900 text-gray-100 min-h-screen">
  <div class="container mx-auto px-6 py-8 max-w-6xl">
    <header class="mb-8">
      <h1 class="text-2xl font-mono font-bold text-blue-400 mb-2">
        <a href="/" class="hover:text-blue-300">CodeYam</a>
      </h1>
      ${breadcrumbsHtml}
    </header>
    
    <main>
      ${content}
    </main>
    
    <footer class="mt-12 pt-8 border-t border-gray-800">
      <p class="text-sm text-gray-500 text-center">
        CodeYam CLI Web Interface
      </p>
    </footer>
  </div>
</body>
</html>`;
}
//# sourceMappingURL=layout.js.map