/**
 * Classify the current state of various runtime-updated entities.
 *
 * TODO: All this logic needs work.
 */
export function getAnalysisStatusClass(status) {
    const statusString = extractAnalysisStatusString(status);
    switch (statusString) {
        case 'completed':
            return 'status-completed';
        case 'processing':
        case 'running':
        case 'pending':
            return 'status-pending';
        case 'partial':
            return 'status-partial';
        case 'failed':
        case 'error':
            return 'status-failed';
        default:
            return 'status-pending';
    }
}
export function extractAnalysisStatusString(status) {
    if (!status)
        return 'pending';
    // Check for errors
    if (status.errors && status.errors.length > 0) {
        return 'failed';
    }
    // Check for step errors
    if (status.steps) {
        const hasStepErrors = status.steps.some((step) => step.error);
        if (hasStepErrors)
            return 'failed';
    }
    // Check for scenario errors
    if (status.scenarios) {
        const hasScenarioErrors = status.scenarios.some((scenario) => scenario.error);
        if (hasScenarioErrors)
            return 'partial'; // Some scenarios failed
        const allScenariosComplete = status.scenarios.every((scenario) => scenario.finishedAt);
        if (allScenariosComplete)
            return 'completed'; // Some scenarios still running
    }
    if (status.processingForCaptureAt) {
        return 'capturing';
    }
    if (status.readyToBeCaptured) {
        return 'capturable';
    }
    if (status.finishedAt) {
        // TODO: not really – this refers to analyzed only, not captured
        return 'completed';
    }
    return 'running';
}
export function getAnalysisScenarioStatusClass(status) {
    const statusString = extractAnalysisScenarioStatusString(status);
    switch (statusString) {
        case 'completed':
            return 'status-completed';
        case 'running':
        case 'pending':
            return 'status-pending';
        case 'failed':
            return 'status-failed';
        default:
            return 'status-pending';
    }
}
export function extractAnalysisScenarioStatusString(status) {
    if (!status)
        return 'pending';
    // Check for errors
    if (status.error) {
        return 'failed';
    }
    if (status.finishedAt) {
        return 'completed';
    }
    return 'running';
}
//# sourceMappingURL=status.js.map