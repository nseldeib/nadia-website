import { loadCommits } from "../../../../packages/supabase/index.js";
import { initializeEnvironment } from "../../utils/database.js";
export async function getProjectRuns(projectId, branchId, limit = 50) {
    await initializeEnvironment();
    const commits = await loadCommits({
        projectId,
        branchId,
        limit,
    });
    return commits;
}
export async function getCommitById(projectId, commitSha) {
    await initializeEnvironment();
    const commits = await loadCommits({
        projectId,
        shas: [commitSha],
    });
    if (commits.length > 1) {
        throw new Error(`CodeYam Error: Multiple commits found with SHA ${commitSha} in project ${projectId}`);
    }
    return commits[0] || null;
}
//# sourceMappingURL=database.js.map