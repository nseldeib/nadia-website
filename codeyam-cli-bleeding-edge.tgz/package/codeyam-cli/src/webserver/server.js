import express from 'express';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { runsRouter } from "./routes/runs.js";
import { commitRouter } from "./routes/commit.js";
import { analysisRouter } from "./routes/analysis.js";
import { scenarioRouter } from "./routes/scenario.js";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
export async function startWebServer({ port = 3001, rootPath, project, branch, }) {
    const app = express();
    // Serve static files (CSS, favicon, etc)
    app.use('/static', express.static(path.join(__dirname, 'static')));
    // Serve screenshots from .codeyam/captures/screenshots directory
    const screenshotsPath = path.join(rootPath, '.codeyam', 'captures', 'screenshots');
    app.use('/screenshots', express.static(screenshotsPath));
    // Make project info available to all routes
    app.locals.rootPath = rootPath;
    app.locals.project = project;
    app.locals.branch = branch;
    // Routes
    app.use('/', runsRouter);
    app.use('/commit', commitRouter);
    app.use('/analysis', analysisRouter);
    app.use('/scenario', scenarioRouter);
    // Health check
    app.get('/health', (req, res) => {
        res.json({ status: 'ok', projectSlug: project.slug });
    });
    return new Promise((resolve) => {
        const server = app.listen(port, () => {
            const url = `http://localhost:${port}`;
            resolve({ port, url });
        });
        // Handle cleanup
        process.on('SIGINT', () => {
            console.log('\n👋 Shutting down web server...');
            server.close();
            process.exit(0);
        });
    });
}
//# sourceMappingURL=server.js.map