import { setupSecrets } from "./secrets.js";
import { generateSha, loadBranches, loadProject, upsertBranches, upsertCommits, upsertProjects, } from "../../../packages/supabase/index.js";
import { randomUUID } from 'crypto';
import path from 'path';
import { getProjectRoot } from "../state.js";
import { updateCommitBranchesInDb } from "../../../packages/github/index.js";
export function getSqlitePath() {
    const projectRoot = getProjectRoot();
    if (!projectRoot) {
        throw new Error('Could not find project root. Please run this command inside a CodeYam project.');
    }
    return path.join(projectRoot, '.codeyam', 'db.sqlite3');
}
/**
 * Initialize environment variables for DB & LLM access
 */
export async function initializeEnvironment() {
    const secrets = await setupSecrets();
    process.env.SQLITE_PATH = getSqlitePath();
    // invariably overwrite whatever the user happened to have in their env
    process.env.OPENAI_API_KEY = secrets.OPENAI_API_KEY;
}
/**
 * Verify environment is ready for DB & LLM access
 */
export async function testEnvironment() {
    try {
        await initializeEnvironment();
        await loadProject({
            slug: '__test_connection__',
            silent: true,
        });
        // If we get here without error, connection is working
        return true;
    }
    catch (error) {
        console.error('Database connection test failed:', error);
        return false;
    }
}
/**
 * Load the project & branch information for an existing project.
 */
export async function requireBranchAndProject(slug) {
    await initializeEnvironment();
    // First try to load existing project
    const project = await loadProject({ slug });
    if (!project) {
        throw new Error(`Project with slug "${slug}" not found in database`);
    }
    // Check if _local branch already exists
    const existingBranches = await loadBranches({
        projectId: project.id,
        names: ['_local'],
    });
    const branch = existingBranches?.[0];
    if (!branch) {
        throw new Error(`Local development branch not found for project "${slug}". Please run "codeyam init" to set up local analysis.`);
    }
    return { project, branch };
}
/**
 * Create or load a project using the existing supabase package
 */
export async function ensureProject(projectData) {
    await initializeEnvironment();
    // First try to load existing project
    const project = await loadProject({ slug: projectData.slug });
    if (project) {
        return project;
    }
    const newProject = {
        id: randomUUID(),
        name: projectData.slug, // Use slug as name for local projects
        slug: projectData.slug,
        path: `local:${process.cwd()}`, // Mark as local project
        metadata: {
            framework: projectData.framework,
            packageManager: projectData.packageManager,
            appDirectory: projectData.appDirectory,
        },
    };
    try {
        return await upsertProjects([newProject]);
    }
    catch (error) {
        throw new Error(`Failed to create project: ${error.message}`);
    }
}
/**
 * Ensure the _local branch exists for a project
 */
export async function ensureLocalBranch(project) {
    await initializeEnvironment();
    // Check if _local branch already exists
    const existingBranches = await loadBranches({
        projectId: project.id,
        names: ['_local'],
    });
    if (existingBranches && existingBranches.length > 0) {
        return existingBranches[0];
    }
    // Create _local branch
    const localBranch = {
        projectId: project.id,
        name: '_local',
        ref: '_local',
        primary: true,
        activeAt: new Date().toISOString(),
        contentChangedAt: new Date().toISOString(),
        metadata: {
            contributors: [
                {
                    username: 'local-dev',
                    avatarUrl: 'https://github.com/identicons/local-dev.png',
                },
            ],
            commits: { total: 0, last7Days: [] },
            timeline: [
                {
                    title: 'Local branch created',
                    date: new Date().toISOString(),
                    authors: [
                        {
                            username: 'local-dev',
                            avatarUrl: 'https://github.com/identicons/local-dev.png',
                        },
                    ],
                    sha: 'local-init',
                },
            ],
        },
    };
    const createdBranches = await upsertBranches([localBranch]);
    if (!createdBranches || createdBranches.length === 0) {
        throw new Error('Failed to create _local branch');
    }
    return createdBranches[0];
}
/**
 * Create a fake commit for local analysis
 */
export async function createFakeCommit(project, branch, files) {
    await initializeEnvironment();
    // Generate unique commit SHA
    const sha = generateSha(`${project.slug}-local-${Date.now()}-${Math.random()}`);
    const commit = {
        sha,
        projectId: project.id,
        branchId: branch.id,
        message: `Local analysis: ${files.join(', ')} at ${new Date().toISOString()}`,
        url: `local://codeyam/${project.slug}/${sha}`,
        htmlUrl: `local://codeyam/${project.slug}/${sha}`,
        author: {
            username: 'local-dev',
            avatarUrl: 'https://github.com/identicons/local-dev.png',
        },
        committedAt: new Date().toISOString(),
        parents: [], // No parents for simplicity
        files: files.map((fileName) => ({
            fileName,
            status: 'modified', // Safe default for analysis
            patch: '', // Empty patch is fine - system doesn't require it
        })),
        metadata: {
            baseline: false,
            receivedAt: new Date().toISOString(),
        },
    };
    const createdCommits = await upsertCommits({
        projectId: project.id,
        commits: [commit],
    });
    if (!createdCommits || createdCommits.length === 0) {
        throw new Error('Failed to create fake commit');
    }
    await updateCommitBranchesInDb({
        projectId: project.id,
        commit: createdCommits[0],
        branch,
    });
    return createdCommits[0];
}
//# sourceMappingURL=database.js.map