import { ensureLocalBranch } from "./database.js";
import { loadEntities, loadProject } from "../../../packages/supabase/index.js";
import { ProjectAnalyzer } from "../../../packages/analyze/index.js";
import getFilesWithEntitiesFromRepo from "../../../background/src/lib/virtualized/project/getFilesWithEntitiesFromRepo.js";
/**
 * Compare local repository state with database state at entity level
 */
export async function detectEntityChanges(projectSlug, projectRootPath) {
    const project = await loadProject({
        slug: projectSlug,
        withFiles: true,
    });
    if (!project) {
        throw new Error(`Project "${projectSlug}" not found in database`);
    }
    // Capture initial files list to detect new files later
    const initialDbFiles = project.files || [];
    const initialDbFilePaths = new Set(initialDbFiles.map(f => f.path));
    // Get local branch for entity queries
    const localBranch = await ensureLocalBranch(project);
    // Initialize ProjectAnalyzer and get current local state with entities
    const projectAnalyzer = await ProjectAnalyzer.from({ project, dirPath: projectRootPath });
    const localFiles = await getFilesWithEntitiesFromRepo({
        project,
        projectAnalyzer,
        silent: true,
    });
    // Load existing entities from database for this branch
    const dbEntities = await loadEntities({
        projectId: project.id,
        branchId: localBranch.id,
    });
    if (!dbEntities) {
        throw new Error(`Failed to load entities from database for project ${project.id}, branch ${localBranch.id}`);
    }
    // Create lookup maps for comparison using (filePath, name) as persistent identity
    const dbEntityByKey = new Map();
    for (const entity of dbEntities) {
        const key = `${entity.filePath}:${entity.name}`;
        dbEntityByKey.set(key, entity);
    }
    const sampleKeys = Array.from(dbEntityByKey.keys()).slice(0, 3);
    // Detect changes
    const newFiles = [];
    const modifiedFiles = [];
    const allModifiedFilePaths = [];
    // Check each local file
    for (const localFile of localFiles) {
        const isNewFile = !initialDbFilePaths.has(localFile.path);
        if (isNewFile) {
            newFiles.push(localFile);
            allModifiedFilePaths.push(localFile.path);
        }
        else {
            // Check entities within existing files
            const modifiedEntities = [];
            const newEntities = [];
            if (localFile.entities) {
                for (const localEntity of localFile.entities) {
                    const key = `${localEntity.filePath}:${localEntity.name}`;
                    const dbEntity = dbEntityByKey.get(key);
                    if (!dbEntity) {
                        // Entity doesn't exist in DB - it's new
                        newEntities.push(localEntity);
                    }
                    else if (dbEntity.sha !== localEntity.sha) {
                        // Entity exists but SHA changed - it's modified
                        modifiedEntities.push(localEntity);
                    }
                }
            }
            // If any entities are modified or new, include this file
            if (modifiedEntities.length > 0 || newEntities.length > 0) {
                modifiedFiles.push({
                    file: localFile,
                    modifiedEntities,
                    newEntities,
                });
                allModifiedFilePaths.push(localFile.path);
            }
        }
    }
    // Detect deleted files (exist in DB but not locally)
    const localFilePaths = new Set(localFiles.map(f => f.path));
    const deletedFiles = initialDbFiles.filter(dbFile => !localFilePaths.has(dbFile.path));
    return {
        newFiles,
        modifiedFiles,
        deletedFiles,
        allModifiedFilePaths,
    };
}
/**
 * Get list of file paths that have changes (for analyze command)
 */
export async function detectChangedFilePaths(projectSlug, projectRootPath) {
    const changes = await detectEntityChanges(projectSlug, projectRootPath);
    return changes.allModifiedFilePaths;
}
//# sourceMappingURL=changeDetection.js.map