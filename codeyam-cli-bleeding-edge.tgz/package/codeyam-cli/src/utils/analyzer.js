import * as fs from 'fs/promises';
import * as fsSync from 'fs';
import * as path from 'path';
import { runLocalAnalyzerCapture, runLocalAnalyzerStart, runLocalAnalyzerStartWithProcess, runLocalAnalyzerCaptureWithProcess, } from "../../../background/src/lib/local/createLocalAnalyzer.js";
import { rsyncCopy } from "../../../background/src/lib/virtualized/common/rsyncCopy.js";
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
/**
 * Utilities for managing the pre-built analyzer template
 */
/**
 * Get the path to the pre-built analyzer template
 */
export function getAnalyzerTemplatePath() {
    // analyzer-template is in ./dist after build & in the root of the published NPM
    return path.join(__dirname, '../../../analyzer-template');
}
/**
 * Get the analyzer path for a specific project
 */
export function getAnalyzerPath(projectSlug) {
    return `/tmp/codeyam/local-dev/${projectSlug}/codeyam`;
}
/**
 * Check if analyzer exists for a project
 */
export function analyzerExists(projectSlug) {
    const analyzerPath = getAnalyzerPath(projectSlug);
    return fsSync.existsSync(analyzerPath);
}
/**
 * Create analyzer for a project by copying from template
 * This replaces the old runtime compilation approach
 */
export async function createAnalyzer(projectSlug) {
    const templatePath = getAnalyzerTemplatePath();
    const analyzerPath = getAnalyzerPath(projectSlug);
    // Verify template exists
    if (!fsSync.existsSync(templatePath)) {
        throw new Error(`Analyzer template not found at ${templatePath}. Did the build process complete successfully?`);
    }
    // Create parent directory
    await fs.mkdir(path.dirname(analyzerPath), { recursive: true });
    // Copy template to analyzer location using rsync (handles symlinks properly)
    await rsyncCopy({
        sourcePath: templatePath,
        destinationPath: analyzerPath,
    });
}
/**
 * Run the analyzer start process
 */
export async function runAnalyzer(projectSlug, environment, startArgs) {
    const analyzerPath = getAnalyzerPath(projectSlug);
    if (!fsSync.existsSync(analyzerPath)) {
        throw new Error(`Analyzer not found for project ${projectSlug}. Run init first.`);
    }
    // Import the stateless function
    return await runLocalAnalyzerStart(analyzerPath, environment, startArgs);
}
/**
 * Run the analyzer capture process
 */
export async function runCapture(projectSlug) {
    const analyzerPath = getAnalyzerPath(projectSlug);
    if (!fsSync.existsSync(analyzerPath)) {
        throw new Error(`Analyzer not found for project ${projectSlug}. Run init first.`);
    }
    return await runLocalAnalyzerCapture(projectSlug, analyzerPath);
}
/**
 * Run the analyzer start process and return both promise and process handle
 */
export function runAnalyzerWithProcess(projectSlug, environment, startArgs, outputCharCountCallback) {
    const analyzerPath = getAnalyzerPath(projectSlug);
    if (!fsSync.existsSync(analyzerPath)) {
        throw new Error(`Analyzer not found for project ${projectSlug}. Run init first.`);
    }
    const callback = outputCharCountCallback
        ? (line) => {
            outputCharCountCallback(line.length);
        }
        : undefined;
    return runLocalAnalyzerStartWithProcess({
        absoluteCodeyamRootPath: analyzerPath,
        startEnv: environment,
        startArgs: startArgs,
        outputOptions: {
            stdoutToConsole: false,
            stdoutToFile: true,
            stdoutCallback: callback,
            stderrToConsole: false,
            stderrToFile: true,
            stderrCallback: callback,
        },
    });
}
/**
 * Run the analyzer capture process and return both promise and process handle
 */
export function runCaptureWithProcess(projectSlug, outputCharCountCallback) {
    const analyzerPath = getAnalyzerPath(projectSlug);
    if (!fsSync.existsSync(analyzerPath)) {
        throw new Error(`Analyzer not found for project ${projectSlug}. Run init first.`);
    }
    const callback = outputCharCountCallback
        ? (line) => {
            outputCharCountCallback(line.length);
        }
        : undefined;
    return runLocalAnalyzerCaptureWithProcess({
        projectSlug: projectSlug,
        absoluteCodeyamRootPath: analyzerPath,
        outputOptions: {
            stdoutToConsole: false,
            stdoutToFile: true,
            stdoutCallback: callback,
            stderrToConsole: false,
            stderrToFile: true,
            stderrCallback: callback,
        },
    });
}
/**
 * Check if the cached analyzer is fresh compared to the template
 */
export function isAnalyzerFresh(projectSlug) {
    const templatePath = getAnalyzerTemplatePath();
    const analyzerPath = getAnalyzerPath(projectSlug);
    const templateMarkerPath = path.join(templatePath, '.build-info.json');
    const analyzerMarkerPath = path.join(analyzerPath, '.build-info.json');
    // Template marker must exist (should be created during build)
    if (!fsSync.existsSync(templateMarkerPath)) {
        return {
            isFresh: false,
            reason: 'Template build marker missing - template may be corrupted',
        };
    }
    // Cached analyzer must exist
    if (!fsSync.existsSync(analyzerPath)) {
        return {
            isFresh: false,
            reason: 'Cached analyzer does not exist',
        };
    }
    // Cached analyzer marker must exist
    if (!fsSync.existsSync(analyzerMarkerPath)) {
        return {
            isFresh: false,
            reason: 'Cached analyzer build marker missing - was created with old version',
        };
    }
    try {
        const templateMarker = JSON.parse(fsSync.readFileSync(templateMarkerPath, 'utf8'));
        const analyzerMarker = JSON.parse(fsSync.readFileSync(analyzerMarkerPath, 'utf8'));
        // Compare build timestamps
        if (templateMarker.buildTime > analyzerMarker.buildTime) {
            return {
                isFresh: false,
                reason: `Template is newer (${templateMarker.buildTimestamp}) than cached version (${analyzerMarker.buildTimestamp})`,
            };
        }
        return { isFresh: true };
    }
    catch (error) {
        return {
            isFresh: false,
            reason: `Error reading build markers: ${error.message}`,
        };
    }
}
/**
 * Clean up analyzer for a project
 */
export async function cleanupAnalyzer(projectSlug) {
    const analyzerPath = getAnalyzerPath(projectSlug);
    if (fsSync.existsSync(analyzerPath)) {
        await fs.rm(analyzerPath, { recursive: true });
    }
}
//# sourceMappingURL=analyzer.js.map