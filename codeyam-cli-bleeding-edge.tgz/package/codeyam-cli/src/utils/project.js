import * as fs from 'fs';
import * as path from 'path';
/**
 * Find the root directory of a CodeYam project by walking up the directory tree
 * looking for .codeyam/config.json, similar to how git finds .git directories.
 *
 * @param startDir - Directory to start searching from (defaults to process.cwd())
 * @returns Project root path if found, null otherwise
 */
export function findProjectRoot(startDir = process.cwd()) {
    let currentDir = path.resolve(startDir);
    const root = path.parse(currentDir).root;
    while (currentDir !== root) {
        const configPath = path.join(currentDir, '.codeyam', 'config.json');
        if (fs.existsSync(configPath)) {
            return currentDir;
        }
        currentDir = path.dirname(currentDir);
    }
    // Check root directory as well
    const configPath = path.join(root, '.codeyam', 'config.json');
    if (fs.existsSync(configPath)) {
        return root;
    }
    return null;
}
//# sourceMappingURL=project.js.map