import { runClaudeCode } from "./claude-code.js";
export async function detectUniversalMocks(existingMocks = [], progressCallback) {
    const claudeResult = await runClaudeCode({
        prompt: getPrompt(existingMocks),
        allowedTools: ['Bash(jq:*)'],
        progressCallback,
    });
    let resultString = claudeResult.result;
    // use regexp to extract ths ```json\n...\n``` block
    const jsonMatch = resultString.match(/```json\n([\s\S]*?)\n```/);
    if (jsonMatch && jsonMatch.length > 1) {
        resultString = jsonMatch[1].trim();
    }
    else {
        console.warn(`CodeYam Warning: Claude Code did not return markdown-wrapped JSON`);
        // fall back to the entire result if no JSON block is found
    }
    const result = JSON.parse(resultString);
    const universalMocks = result && result.universalMocks && Array.isArray(result.universalMocks)
        ? result.universalMocks
            .map((mock) => {
            if (mock.content &&
                typeof mock.content === 'string' &&
                mock.filePath &&
                typeof mock.filePath === 'string' &&
                mock.entityName &&
                typeof mock.entityName === 'string') {
                return {
                    content: mock.content,
                    filePath: mock.filePath,
                    entityName: mock.entityName,
                };
            }
            console.warn(`CodeYam Warning: Invalid universal mock format`, mock);
            return null;
        })
            .filter((mock) => mock !== null)
        : [];
    return {
        universalMocks,
        duration_ms: claudeResult.duration_ms,
        total_cost_usd: claudeResult.total_cost_usd,
    };
}
function getPrompt(existingMocks) {
    const mocksString = JSON.stringify(existingMocks);
    return `
  Hi Claude! You should find in this directory a primarily TypeScript-based web application. If that doesn't seem to be the case, return an error object:
\`\`\`
{
  "error": "<reason for failure>"
}
\`\`\`

Now, your job is to explore the codebase and read enough source modules to determine if any of them rely on environment variables in a way which needs to be mocked out for the project to start up in an unconfigured environment. You will MODIFY NO FILES. You are only gathering data, and you will finish by outputting a JSON object of these 'universal mocks'.

We will illustrate the process with a canonical example. Imagine a hypothetical file \`/example/lib/supabase.ts\` like so:
\`\`\`
import { createClient } from "@supabase/supabase-js"

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
\`\`\`

This is a very common pattern, and one that would fail without configuration, because \`supabase\` is initialized on load. If the code had looked like this instead:
\`\`\`
export function getSupabaseClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

  return createClient(supabaseUrl, supabaseAnonKey);
}
\`\`\`
then we would **not** need to mock it, not at this stage. We are not concerned with runtime errors here.

What do we mock it with? For Supabase, we have a standard template we typically use:
\`\`\`
export const supabase = {
  auth: {
    getSession: async () => ({ data: { session: {} } }),
    onAuthStateChange: (callback) => ({
      data: {
        subscription: {
          unsubscribe: () => {
          },
        },
      },
    }),
    exchangeCodeForSession: async (code: string) => {
    },
    getUser: async () => ({ data: { user: {} } }),
    signUp: async ({ email, password }) => ({ data: null, error: null }),
    signInWithPassword: async ({ email, password }) => ({ data: null, error: null }),
    signOut: async () => ({ error: null }),
    resetPasswordForEmail: async ({ email }) => ({ data: null, error: null }),
  },
};
\`\`\`

Remember, the only requirement is that all the modules which depend on \`supabase\` **compile**, not run. Only the structure is important, not the data that's returned. When you've determined that a file like this requires a universal mock, you will include it in your output, which might look something like this:
\`\`\`
{
  "universalMocks": [
    {
      "content": "export const supabase = {\\n  auth: {\\n    getSession: async () => ({ data: { session: {} } }),\\n    onAuthStateChange: (callback) => ({\\n      data: {\\n        subscription: {\\n          unsubscribe: () => {},\\n        },\\n      },\\n    }),\\n    exchangeCodeForSession: async (code: string) => {},\\n    getUser: async () => ({ data: { user: {} } }),\\n    signUp: async ({ email, password }) => ({ error: null }),\\n    signInWithPassword: async ({ email, password }) => ({ error: null }),\\n    signOut: async () => ({ error: null }),\\n  },\\n};\\n",
      "filePath": "lib/supabase.ts",
      "entityName": "supabase"
    }
  ]
}

Note: You MUST wrap the result JSON in \`\`\`json\n...\n\`\`\` so that it can later be extracted programmatically.

So a "universal mock" object contains of a file path (\`/example/lib/supabase.ts\` in our case), an entity name (\`supabase\`), and the full text of the TypeScript with which to replace that entity in the mocked-up module.
- There can be multiple mocks in the same file, for different entities. An entity is e.g. a function, a type, a variable, a React component, etc.
- Each universal mock should contain ONLY the replacement content for a single entity. If a file exports multiple entities that need mocking, create separate mock objects for each entity.
- Remember that the JSON string must be escaped.

The current \`universalMocks\` array, which you should merge into / append to, is as follows:
\`\`\`
${mocksString}
\`\`\`

Now put on your best sleuthing cap and figure out how to scan this repository for likely signs of external dependencies that may need mocking, compile a list of universal mocks, and return it as JSON on the format shown above.
  `;
}
//# sourceMappingURL=universal-mocks.js.map