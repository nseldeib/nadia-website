import { query } from '@anthropic-ai/claude-code';
export async function runClaudeCode({ prompt, allowedTools, progressCallback, }) {
    const messages = [];
    for await (const message of query({
        prompt,
        options: {
            allowedTools,
        },
    })) {
        messages.push(message);
        if (progressCallback) {
            progressCallback(messages.length);
        }
    }
    const result = messages.find((m) => m.type === 'result');
    if (!result) {
        console.warn(`CodeYam Warning: Claude Code returned no result message`);
        return null;
    }
    return {
        result: result.result,
        duration_ms: result.duration_ms,
        total_cost_usd: result.total_cost_usd,
    };
}
//# sourceMappingURL=claude-code.js.map