import * as fs from 'fs/promises';
import * as fsSync from 'fs';
import * as path from 'path';
import * as os from 'os';
import prompts from 'prompts';
import chalk from 'chalk';
const SECRETS_FILE_PATH = path.join(os.homedir(), '.codeyam', 'secrets.json');
/**
 * Load secrets from ~/.codeyam/secrets.json or environment variables
 */
export async function loadSecrets() {
    let secrets = {};
    // Try to load from file first
    try {
        if (fsSync.existsSync(SECRETS_FILE_PATH)) {
            const secretsFile = await fs.readFile(SECRETS_FILE_PATH, 'utf8');
            secrets = JSON.parse(secretsFile);
        }
    }
    catch (error) {
        // If file is corrupted or unreadable, fall back to env vars
        console.warn(chalk.yellow('⚠ Could not read secrets file, falling back to environment variables'));
    }
    // Fall back to environment variables for any missing secrets
    return {
        OPENAI_API_KEY: secrets.OPENAI_API_KEY || process.env.OPENAI_API_KEY,
    };
}
/**
 * Save secrets to ~/.codeyam/secrets.json with secure permissions
 */
export async function saveSecrets(secrets) {
    const secretsDir = path.dirname(SECRETS_FILE_PATH);
    // Ensure the directory exists
    await fs.mkdir(secretsDir, { recursive: true });
    // Write the secrets file
    await fs.writeFile(SECRETS_FILE_PATH, JSON.stringify(secrets, null, 2));
    // Set secure permissions (owner read/write only)
    await fs.chmod(SECRETS_FILE_PATH, 0o600);
}
/**
 * Check if all required secrets are available
 */
export async function validateRequiredSecrets() {
    const secrets = await loadSecrets();
    const required = ['OPENAI_API_KEY'];
    const missing = [];
    for (const key of required) {
        if (!secrets[key]) {
            missing.push(key);
        }
    }
    if (missing.length === 0) {
        return {
            isValid: true,
            missing: [],
            secrets: secrets,
        };
    }
    return {
        isValid: false,
        missing,
    };
}
/**
 * Interactive prompt for missing secrets
 */
export async function promptForSecrets(missing) {
    console.log();
    console.log(chalk.blue('ℹ Configuration needed'));
    console.log();
    const secrets = {};
    for (const secretKey of missing) {
        switch (secretKey) {
            case 'OPENAI_API_KEY':
                const openaiResponse = await prompts({
                    type: 'password',
                    name: 'key',
                    message: 'OpenAI API Key',
                    validate: (value) => {
                        if (value && !value.startsWith('sk-')) {
                            return 'OpenAI API key should start with sk-';
                        }
                        return true;
                    },
                });
                if (openaiResponse.key) {
                    secrets.OPENAI_API_KEY = openaiResponse.key;
                }
                break;
        }
    }
    return secrets;
}
/**
 * Setup secrets interactively and save them
 */
export async function setupSecrets() {
    const validation = await validateRequiredSecrets();
    if (validation.isValid) {
        return validation.secrets;
    }
    // Prompt for missing secrets
    const newSecrets = await promptForSecrets(validation.missing);
    // Load existing secrets to merge with new ones
    const existingSecrets = await loadSecrets();
    const mergedSecrets = { ...existingSecrets, ...newSecrets };
    // Save the merged secrets
    await saveSecrets(mergedSecrets);
    // Validate again
    const finalValidation = await validateRequiredSecrets();
    if (!finalValidation.isValid) {
        throw new Error('Failed to configure all required secrets');
    }
    console.log(chalk.green('✓ Configuration saved to ~/.codeyam/secrets.json'));
    return finalValidation.secrets;
}
//# sourceMappingURL=secrets.js.map