import spinners from 'cli-spinners';
import chalk from 'chalk';
export class ProgressReporter {
    constructor() {
        this.spinnerIndex = 0;
        this.currentMessage = '';
        this.isSpinning = false;
        this.spinnerFrames = spinners.dots.frames;
        this.spinnerInterval = spinners.dots.interval;
    }
    start(message) {
        this.currentMessage = message;
        this.isSpinning = true;
        this.spinnerIndex = 0;
        ProgressReporter.activeInstance = this;
        this.spinner = setInterval(() => {
            process.stdout.write('\r' + chalk.cyan(this.spinnerFrames[this.spinnerIndex]) + ' ' + this.currentMessage);
            this.spinnerIndex = (this.spinnerIndex + 1) % this.spinnerFrames.length;
        }, this.spinnerInterval);
    }
    static pause() {
        ProgressReporter.activeInstance?.stop();
    }
    static resume() {
        const instance = ProgressReporter.activeInstance;
        if (instance && instance.currentMessage) {
            instance.start(instance.currentMessage);
        }
    }
    update(message) {
        this.currentMessage = message;
    }
    succeed(message) {
        this.stop();
        const finalMessage = message || this.currentMessage;
        console.log(chalk.green('✓') + ' ' + finalMessage);
    }
    fail(message) {
        this.stop();
        const finalMessage = message || this.currentMessage;
        console.log(chalk.red('✗') + ' ' + finalMessage);
    }
    warn(message) {
        this.stop();
        console.log(chalk.yellow('⚠') + ' ' + message);
    }
    info(message) {
        this.stop();
        console.log(chalk.blue('ℹ') + ' ' + message);
    }
    stop() {
        if (this.spinner) {
            clearInterval(this.spinner);
            this.spinner = undefined;
        }
        if (this.isSpinning) {
            process.stdout.write('\r' + ' '.repeat(this.currentMessage.length + 2) + '\r');
            this.isSpinning = false;
        }
        if (this === ProgressReporter.activeInstance) {
            ProgressReporter.activeInstance = undefined;
        }
    }
}
/**
 * Helper wrapper to automatically pause/resume spinner during interactive operations
 */
export async function withoutSpinner(fn) {
    ProgressReporter.pause();
    try {
        return await fn();
    }
    finally {
        ProgressReporter.resume();
    }
}
// Convenience functions for one-off messages
export const success = (message) => console.log(chalk.green('✓') + ' ' + message);
export const error = (message) => console.log(chalk.red('✗') + ' ' + message);
export const warn = (message) => console.log(chalk.yellow('⚠') + ' ' + message);
export const info = (message) => console.log(chalk.blue('ℹ') + ' ' + message);
// Create a styled header
export const header = (message) => {
    console.log();
    console.log(chalk.cyan.bold('🚀 ' + message));
    console.log();
};
//# sourceMappingURL=progress.js.map