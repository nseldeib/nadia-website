import { findProjectRoot } from "./utils/project.js";
let projectRoot = findProjectRoot();
export function getProjectRoot() {
    return projectRoot;
}
export function setProjectRoot(root) {
    projectRoot = root;
}
//# sourceMappingURL=state.js.map