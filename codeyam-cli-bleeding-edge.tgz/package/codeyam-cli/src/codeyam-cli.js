#!/usr/bin/env node
// Main CLI entry point - simply exports from cli.ts
export * from "./cli.js";
//# sourceMappingURL=codeyam-cli.js.map