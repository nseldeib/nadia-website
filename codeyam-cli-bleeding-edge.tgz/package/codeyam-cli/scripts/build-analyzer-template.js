#!/usr/bin/env tsx
/**
 * Build script to create a pre-compiled analyzer template
 * This runs during the CLI build process to avoid runtime compilation
 */
import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { createAnalyzerTemplate } from "../../background/src/lib/local/createLocalAnalyzer.js";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TEMPLATE_PATH = path.join(__dirname, '../dist/analyzer-template');
const BACKGROUND_PATH = path.join(__dirname, '../../background');
async function buildAnalyzerTemplate() {
    console.log('🔨 Building analyzer template...');
    // Clean existing template
    if (fs.existsSync(TEMPLATE_PATH)) {
        fs.rmSync(TEMPLATE_PATH, { recursive: true });
    }
    fs.mkdirSync(TEMPLATE_PATH, { recursive: true });
    // Use createLocalAnalyzer to build the template
    try {
        // Change to background directory for relative paths to work
        process.chdir(BACKGROUND_PATH);
        console.log('📁 Working directory:', process.cwd());
        console.log('📁 Template path:', TEMPLATE_PATH);
        await createAnalyzerTemplate(TEMPLATE_PATH);
        // Create build marker file
        const buildInfo = {
            buildTimestamp: new Date().toISOString(),
            buildTime: Date.now(),
            gitCommit: getGitCommit(),
            nodeVersion: process.version,
        };
        const markerPath = path.join(TEMPLATE_PATH, '.build-info.json');
        fs.writeFileSync(markerPath, JSON.stringify(buildInfo, null, 2));
        console.log('✅ Analyzer template built successfully');
        console.log('📁 Template size:', getDirSize(TEMPLATE_PATH));
        console.log('🏷️  Build marker:', buildInfo.buildTimestamp);
    }
    catch (error) {
        console.error('❌ Failed to build analyzer template:', error);
        process.exit(1);
    }
}
function getDirSize(dirPath) {
    try {
        const stats = execSync(`du -sh "${dirPath}"`, { encoding: 'utf8' });
        return stats.trim().split('\t')[0];
    }
    catch {
        return 'unknown';
    }
}
function getGitCommit() {
    try {
        return execSync('git rev-parse HEAD', { encoding: 'utf8' }).trim();
    }
    catch {
        return 'unknown';
    }
}
// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
    buildAnalyzerTemplate().catch(console.error);
}
export { buildAnalyzerTemplate };
//# sourceMappingURL=build-analyzer-template.js.map