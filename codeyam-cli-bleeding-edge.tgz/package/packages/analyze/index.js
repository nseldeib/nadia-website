/**
 * This is the external API of packages/analyze. Please be thoughtful when
 * adding exports to it.
 */
// If you don't export classes directly you run into issues where TS thinks you
// are exporting a namespace/object.
//
// e.g., (BAD) `export const SomeClass = lib.SomeClass;`
//
// TS thinks this is a namespace or object and so disallows using the class as
// both a class and a type declaration. The fix is a direct export of a class,
// as seen below.
export { FileAnalyzer } from "./src/lib/FileAnalyzer.js";
export { ProjectAnalyzer } from "./src/lib/ProjectAnalyzer.js";
export { default as analyzeEntity, } from "./src/lib/files/analyzeEntity.js";
export { AnalysisContext, } from "./src/lib/analysisContext.js";
export { default as findOrCreateEntity } from "./src/lib/files/analyze/findOrCreateEntity.js";
export { default as gatherEntityMap } from "./src/lib/files/analyze/gatherEntityMap.js";
export { default as setImportedExports } from "./src/lib/files/setImportedExports.js";
// New exports for non-recursive analysis
export { default as validateDependencyAnalyses } from "./src/lib/files/analyze/validateDependencyAnalyses.js";
export { default as analyzeEntities } from "./src/lib/files/analyze/analyzeEntities.js";
export { default as getEntityType } from "./src/lib/files/getEntityType.js";
export { default as getEntityCode } from "./src/lib/files/getEntityCode.js";
export { getAllEntityNodes } from "./src/lib/asts/sourceFiles/getAllEntityNodes.js";
export { default as safeStringify } from "./src/lib/utils/safeStringify.js";
export { default as fileAnalyzerFromCode } from "./src/lib/files/fileAnalyzerFromCode.js";
export { default as isolateDataStructure } from "./src/lib/files/scenarios/isolateDataStructure.js";
export { default as mergeInDependentDataStructure } from "./src/lib/files/scenarios/mergeInDependentDataStructure.js";
export { default as mergeValidatedDataStructures } from "./src/lib/files/scenarios/mergeValidatedDataStructures.js";
export { discoverDirectDependencies } from "./src/lib/files/analyze/dependencyResolver.js";
export { default as getAnalysisError } from "./src/lib/utils/getAnalysisError.js";
// Rough mocks to help debug build failures.
//
// import { Entity, EntityMap, EntityType, Project } from "../../packages/types/index.js";
// import { SourceFile, TypeChecker } from 'typescript';
//
// export class FileAnalyzer {
//   sourceFile = {} as unknown as SourceFile;
//   typeChecker = {} as unknown as TypeChecker;
//   getEntityCode = (a, b?) => '';
//   getRelativeImportMappings = () => ({});
//   getImportsCode = () => [];
//   isDefaultExport= (a) => false;
//   isExported = (a) => false;
//   getEntityType = (a) => 'visual' as EntityType;
//   getAllEntityNodesNoAliases = () => { return [] }
// }
// export class ProjectAnalyzer {
//   project = {} as unknown as Project;
//   getAllSourceFiles = () => [];
//   getFileAnalyzer = (a) => { return {} as unknown as FileAnalyzer };
//   static async from(a) { return {} as unknown as ProjectAnalyzer };
// }
// export interface AnalyzeEntityArgs {}
// export const analyzeEntity = (a) => {
//   return {
//     analysisMap: {},
//     entityMap: {} as unknown as EntityMap,
//     entity: {} as unknown as Entity,
//     file: {},
//     filePath: '',
//     analysis: {},
//     existingProjectNodeModuleMocks: [],
//   }
// };
// export const analyzeIndirectEntities = (a) => {
//   return {
//     entityMap: {} as unknown as EntityMap,
//     analysisMap: {},
//   }
// };
// export const findOrCreateEntity = (a) => {
//   return {} as unknown as Entity;
// };
// export const gatherEntityMap = (a) => {
//   return {} as unknown as EntityMap
// };
// export const analyzeProjectType = (a) => {
//   return {
//     packageManager: '',
//     monorepo: false,
//   }
// };
// export const isRemixRoute = (a, b, c) => {
//   return false
// };
// export const setImportedExports = (a) => {
//   return {
//     entities: [],
//     entityMap: {} as unknown as EntityMap,
//   }
// };
// export const getEntityType = () => {};
// export const getEntityCode = () => {};
// export const getAllEntityNodes = () => {};
// export const safeStringify = (x) => {};
//# sourceMappingURL=index.js.map