export const DEFAULT_SCENARIO_NAME = 'Default Scenario';
//# sourceMappingURL=constants.js.map