export var ProjectFramework;
(function (ProjectFramework) {
    ProjectFramework["Remix"] = "Remix";
    ProjectFramework["CodeYam"] = "CodeYam";
    ProjectFramework["CRA"] = "CRA";
    ProjectFramework["Next"] = "Next";
    ProjectFramework["NextPages"] = "NextPages";
    ProjectFramework["Unknown"] = "Unknown";
})(ProjectFramework || (ProjectFramework = {}));
//# sourceMappingURL=ProjectFramework.js.map