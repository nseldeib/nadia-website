export {};
//# sourceMappingURL=StatementInfo.js.map