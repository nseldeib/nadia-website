export {};
//# sourceMappingURL=TsConfigPaths.js.map