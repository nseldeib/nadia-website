export {};
//# sourceMappingURL=FileProp.js.map