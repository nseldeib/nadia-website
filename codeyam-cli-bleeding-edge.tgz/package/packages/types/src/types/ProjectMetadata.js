export {};
//# sourceMappingURL=ProjectMetadata.js.map