export {};
//# sourceMappingURL=ScenarioComment.js.map