export {};
//# sourceMappingURL=ScenariosDataStructure.js.map