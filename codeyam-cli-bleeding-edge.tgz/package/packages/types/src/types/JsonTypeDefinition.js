export {};
//# sourceMappingURL=JsonTypeDefinition.js.map