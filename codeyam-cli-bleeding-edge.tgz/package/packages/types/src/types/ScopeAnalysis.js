export {};
//# sourceMappingURL=ScopeAnalysis.js.map