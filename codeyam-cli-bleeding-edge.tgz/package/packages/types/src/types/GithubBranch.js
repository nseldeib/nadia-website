export {};
//# sourceMappingURL=GithubBranch.js.map