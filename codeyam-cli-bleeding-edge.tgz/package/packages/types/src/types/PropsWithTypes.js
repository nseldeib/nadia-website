export {};
//# sourceMappingURL=PropsWithTypes.js.map