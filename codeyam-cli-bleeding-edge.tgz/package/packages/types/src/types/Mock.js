export {};
//# sourceMappingURL=Mock.js.map