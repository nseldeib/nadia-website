export {};
//# sourceMappingURL=GithubRepoInfo.js.map