export {};
//# sourceMappingURL=GithubRepoData.js.map