export {};
//# sourceMappingURL=TypeStructures.js.map