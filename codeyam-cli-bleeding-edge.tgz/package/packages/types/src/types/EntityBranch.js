export {};
//# sourceMappingURL=EntityBranch.js.map