export {};
//# sourceMappingURL=EntityMap.js.map