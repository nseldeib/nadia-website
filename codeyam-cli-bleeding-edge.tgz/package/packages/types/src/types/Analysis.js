// used for e.g. analyzedTreeSha for analyses that have no meaningful content to hash
export const EMPTY_SHA_MARKER = '0000000000000000000000000000000000000000';
//# sourceMappingURL=Analysis.js.map