export {};
//# sourceMappingURL=CommitBranch.js.map