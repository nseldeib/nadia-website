export {};
//# sourceMappingURL=FilePreMock.js.map