// Direct export for sqs functions only
export { default as sqsGetQueueSizeStats } from "../src/lib/sqs/getSqsQueueSizeStats.js";
export { default as sqsSendMessage } from "../src/lib/sqs/sendSqsMessage.js";
//# sourceMappingURL=index.js.map