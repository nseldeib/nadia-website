export { default as isRemixRoute } from "./src/lib/frameworks/isRemixRoute.js";
export { default as isNextRoute } from "./src/lib/frameworks/isNextRoute.js";
export { default as isFrameworkRoute } from "./src/lib/frameworks/isFrameworkRoute.js";
export { default as remixRouteFileNameToRoute } from "./src/lib/frameworks/remixRouteFileNameToRoute.js";
export { default as nextRouteFileNameToRoute } from "./src/lib/frameworks/nextRouteFileNameToRoute.js";
export { default as frameworkRouteFileNameToRoute } from "./src/lib/frameworks/frameworkRouteFileNameToRoute.js";
export { default as getRemixRoutePath } from "./src/lib/frameworks/getRemixRoutePath.js";
export { default as getNextRoutePath } from "./src/lib/frameworks/getNextRoutePath.js";
export { default as getFrameworkRoutePath } from "./src/lib/frameworks/getFrameworkRoutePath.js";
export { default as safeFileName } from "./src/lib/safeFileName.js";
export { default as normalizeKey } from "./src/lib/normalizeKey.js";
export { default as awsLog } from "./src/lib/awsLog.js";
export { default as pushAnalysisError } from "./src/lib/analyses/pushAnalysisError.js";
export { pushNewCommitRun } from "./src/lib/commitRuns.js";
export const CODEYAM_MOCKS_DIRNAME = '__codeyamMocks__';
export const CODEYAM_DEMO_PAGES_DIRNAME = '__codeyamDemoPages__';
export const PROJECT_RELATIVE_PATH = '../project';
//# sourceMappingURL=index.js.map