/**
 * This is the public API of `packages/ai`.
 *
 * Please be careful adding new exports to this file.
 */
export { DEFAULT_SMALLER_MODEL, DEFAULT_LARGER_MODEL, } from "./src/lib/aiConfig.js";
export { default as commitMessage } from "./src/lib/commitMessage.js";
export { default as generateEntityDocumentation } from "./src/lib/generateEntityDocumentation.js";
export { default as generateChangesEntityDocumentation } from "./src/lib/generateChangesEntityDocumentation.js";
export { default as codeQualityEntityAnalysis } from "./src/lib/codeQualityEntityAnalysis.js";
export { default as summarizeDiff } from "./src/lib/summarizeDiff.js";
export { default as generateEntityDataMap } from "./src/lib/generateEntityDataMap.js";
export { default as generateEntityDataStructure } from "./src/lib/generateEntityDataStructure.js";
export { default as generateEntityScenarios } from "./src/lib/generateEntityScenarios.js";
export { default as generateEntityScenarioData, generateDataForScenario, } from "./src/lib/generateEntityScenarioData.js";
export { default as generateChangesEntityScenarios } from "./src/lib/generateChangesEntityScenarios.js";
export { default as generateChangesEntityScenarioData } from "./src/lib/generateChangesEntityScenarioData.js";
export { default as generateEntityKeyAttributes } from "./src/lib/generateEntityKeyAttributes.js";
export { default as generateChangesEntityKeyAttributes } from "./src/lib/generateChangesEntityKeyAttributes.js";
export { default as guessScenarioDataFromName, } from "./src/lib/guessScenarioDataFromName.js";
export { default as guessScenarioDataFromDescription, } from "./src/lib/guessScenarioDataFromDescription.js";
export { default as extractOverlappingMocks } from "./src/lib/extractOverlappingMocks.js";
export { default as mergeJsonTypeDefinitions } from "./src/lib/mergeJsonTypeDefinitions.js";
export { default as jsonTypeDefinitionToStandardTypeDefinition } from "./src/lib/jsonTypeDefinitionToStandardTypeDefinition.js";
export { default as getCodeExplanation } from "./src/lib/getCodeExplanation.js";
export { default as describeCodeChange } from "./src/lib/describeCodeChange.js";
export { default as validateTypeStructure } from "./src/lib/validateTypeStructure.js";
export { default as validateDataStructure } from "./src/lib/validateDataStructure.js";
export { default as isolateScopes } from "./src/lib/isolateScopes.js";
export { default as analyzeScope } from "./src/lib/analyzeScope.js";
export { default as logOrderedMap } from "./src/lib/logOrderedMap.js";
export { default as splitOutsideParentheses, splitOutsideParenthesesAndArrays, joinParenthesesAndArrays, functionArguments, } from "./src/lib/splitOutsideParentheses.js";
export { cleanKnownObjectFunctionsFromMapping } from "./src/lib/dataStructure/helpers/cleanKnownObjectFunctions.js";
export { default as convertDotNotation } from "./src/lib/dataStructure/helpers/convertDotNotation.js";
export { default as cleanOutBoundary } from "./src/lib/cleanOutBoundary.js";
export { fillInDirectSchemaGapsAndUnknowns } from "./src/lib/dataStructure/helpers/fillInSchemaGapsAndUnknowns.js";
export { default as gatherRelevantDependentKeyAttributes } from "./src/lib/gatherRelevantDependentKeyAttributes.js";
export { ScopeDataStructure, } from "./src/lib/dataStructure/ScopeDataStructure.js";
export { AI } from "./src/lib/types/index.js";
/**
 * This is the beginning of the new public API for packages/ai
 *
 * ## Examples
 *
 * ```ts
 * import ai from `~codeyam/ai`
 *
 * const results = ai.actions.getBranchSummary(...)
 * ```
 */
import { actions } from "./src/index.js";
// import validatePropsStructure from "./src/lib/validateDataStructure.js";
// import mergeScopeAnalyses from "./src/lib/mergeScopeAnalyses.js";
/**
 * placeholder docs for `ai`
 */
const ai = {
    /**
     * placholder docs for actions
     */
    actions,
};
export default ai;
//# sourceMappingURL=index.js.map