import sharp from 'sharp';
import pixelmatch from 'pixelmatch';

interface ImageDimensions {
  width: number;
  height: number;
}

interface ComparisonResult {
  diffPixels: number;
  diffPercentage: string;
  diffImage: Buffer;
  dimensions: ImageDimensions;
  scalingApplied: boolean;
  originalDimensions: {
    image1: ImageDimensions;
    image2: ImageDimensions;
  };
}

async function getImageData(buffer: Buffer): Promise<{ 
  metadata: sharp.Metadata; 
  data: Uint8ClampedArray; 
}> {
  const metadata = await sharp(buffer).metadata();
  const rawData = await sharp(buffer)
    .raw()
    .ensureAlpha()
    .toBuffer();

  return {
    metadata,
    data: new Uint8ClampedArray(rawData)
  };
}

async function resizeImage(
  buffer: Buffer,
  width: number,
  height: number
): Promise<Uint8ClampedArray> {
  const rawData = await sharp(buffer)
    .resize(width, height)
    .raw()
    .ensureAlpha()
    .toBuffer();

  return new Uint8ClampedArray(rawData);
}

export default async function compareImages(
  image1Buffer: Buffer,
  image2Buffer: Buffer,
  options = { maxDimensionDifference: 2 }
): Promise<ComparisonResult> {
  try {
    const [img1Data, img2Data] = await Promise.all([
      getImageData(image1Buffer),
      getImageData(image2Buffer)
    ]);

    const originalDimensions = {
      image1: { width: img1Data.metadata.width!, height: img1Data.metadata.height! },
      image2: { width: img2Data.metadata.width!, height: img2Data.metadata.height! }
    };

    const scalingNeeded = 
      originalDimensions.image1.width !== originalDimensions.image2.width || 
      originalDimensions.image1.height !== originalDimensions.image2.height;

    const width = Math.min(originalDimensions.image1.width!, originalDimensions.image2.width!);
    const height = Math.min(originalDimensions.image1.height!, originalDimensions.image2.height!);

    if (scalingNeeded) {
      const widthDiff = Math.abs(1 - originalDimensions.image2.width / originalDimensions.image1.width);
      const heightDiff = Math.abs(1 - originalDimensions.image2.height / originalDimensions.image1.height);
      
      if (widthDiff > options.maxDimensionDifference || 
          heightDiff > options.maxDimensionDifference) {
        console.log(`Image 1 dimensions: ${originalDimensions.image1.width}x${originalDimensions.image1.height}`);
        console.log(`Image 2 dimensions: ${originalDimensions.image2.width}x${originalDimensions.image2.height}`);
        console.log(`Width difference: ${widthDiff}`);
        throw new Error('Images dimensions differ too much for reliable comparison');
      }
    }

    const [img1Scaled, img2Scaled] = await Promise.all([
      scalingNeeded ? resizeImage(image1Buffer, width, height) : img1Data.data,
      scalingNeeded ? resizeImage(image2Buffer, width, height) : img2Data.data
    ]);

    const diffData = new Uint8ClampedArray(width * height * 4);
    
    const diffPixels = pixelmatch(
      img1Scaled,
      img2Scaled,
      diffData,
      width,
      height,
      { 
        threshold: 0.1,
        includeAA: true
      }
    );

    const diffImage = await sharp(Buffer.from(diffData.buffer), {
      raw: {
        width,
        height,
        channels: 4
      }
    }).png().toBuffer();

    return {
      diffPixels,
      diffPercentage: (diffPixels / (width * height) * 100).toFixed(2),
      diffImage,
      dimensions: { width, height },
      scalingApplied: scalingNeeded,
      originalDimensions
    };
    
  } catch (error) {
    console.error(`Error comparing images: ${error}`);
    throw error;
  }
}