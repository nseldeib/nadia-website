import { AnalysisStatus, Scenario } from '~codeyam/types';
import generateStaticBuild from './generateStaticBuild';
import {
  updateCommitMetadata,
  updateFreshAnalysisStatus,
  updateFreshAnalysisStatusWithScenarios,
} from '~codeyam/supabase';
import { uploadAssetDirectory } from './uploadAssets';
import invalidateCloudFrontPath from './invalidateCloudFrontPath';
import { pushAnalysisError } from '~codeyam/utils';

export default async function captureStatic({
  analysis,
  scenario,
  projectUrl,
  relativePath,
  framework,
  file,
  job,
}): Promise<{ errors: string[] }> {
  const errors: string[] = [];
  if (!['visual', 'library'].includes(analysis.entity?.entityType))
    return { errors };

  try {
    if (analysis.commitId) {
      const now = new Date().toISOString();
      await updateCommitMetadata({
        commitId: analysis.commitId,
        updateCallback: (metadata, commit) => {
          if (metadata.currentRun) {
            metadata.currentRun.firstCaptureAt ??= now;
            metadata.currentRun.lastCaptureAt = now;
          }
        },
      });
    }

    await updateFreshAnalysisStatus(analysis.id, (freshStatus, _inAnalysis) => {
      freshStatus.scenarios ||= [];
      const scenarioIndex = freshStatus.scenarios.findIndex(
        (s) => s.name === scenario.name,
      );

      if (scenarioIndex > -1) {
        if (!freshStatus.scenarios[scenarioIndex].error) {
          freshStatus.scenarios[scenarioIndex].interactiveStartedAt =
            new Date().toISOString();
        }
      } else {
        freshStatus.scenarios.push({
          name: scenario.name,
          startedAt: new Date().toISOString(),
          interactiveStartedAt: new Date().toISOString(),
        });
      }
    });

    await generateStaticBuild({ domain: projectUrl, relativePath, framework });
    const staticPath = relativePath.replace('static/', '');

    // cannot convert: updates scenario.metadata
    await updateFreshAnalysisStatusWithScenarios(
      analysis.id,
      (freshStatus: AnalysisStatus, freshScenarios: Scenario[]) => {
        const freshScenario = freshScenarios.find(
          (s) => s.name === scenario.name,
        );
        freshScenario.metadata.interactiveExamplePath = staticPath;

        const scenarioIndex = freshStatus.scenarios.findIndex(
          (s) => s.name === scenario.name,
        );
        if (scenarioIndex > -1 && !freshStatus.scenarios[scenarioIndex].error) {
          freshStatus.scenarios[scenarioIndex].interactiveFinishedAt =
            new Date().toISOString();
        }
      },
    );
    const pathPrefix = relativePath.split('/')[0];
    console.log(`CodeYam: Uploading static build ${relativePath} to S3`);
    await uploadAssetDirectory(`./${pathPrefix}`);
    if (process.env.INVALIDATE_EXISTING) {
      await invalidateCloudFrontPath(
        `/${relativePath.split('/').slice(0, 2).join('/')}/*`,
      );
    }
  } catch (e) {
    console.log(
      'CodeYam Error: Error generating or saving static build',
      file?.id,
      !!analysis,
      analysis?.id,
      analysis?.entityName,
      job?.commitId,
      analysis?.id,
      e.message,
    );
    errors.push(
      `Error generating interactives for ${file?.id}, ${analysis?.id}, ${analysis?.entityName}: ${e.message}`,
    );

    await updateFreshAnalysisStatus(analysis.id, (freshStatus, _inAnalysis) => {
      freshStatus.scenarios ||= [];
      const scenarioIndex = freshStatus.scenarios.findIndex(
        (s) => s.name === scenario.name,
      );
      if (scenarioIndex > -1 && !freshStatus.scenarios[scenarioIndex].error) {
        freshStatus.scenarios[scenarioIndex].error = e.message;
        freshStatus.scenarios[scenarioIndex].errorStack = e.stack;
      }

      if (!freshStatus.errors) {
        pushAnalysisError({
          status: freshStatus,
          error: e,
          phase: 'capture',
        });
      }
    });
  }

  return { errors };
}
