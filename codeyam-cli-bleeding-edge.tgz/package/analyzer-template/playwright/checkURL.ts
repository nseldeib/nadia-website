export enum URLStatus {
  Ok,
  NotFound,
  Error,
  NetworkError,
  Other,
}

export default async function checkURL(url: string): Promise<[URLStatus, number | null]> {
  try {
    const response = await fetch(url, { method: 'HEAD' });
    switch (response.status) {
      case 200:
      case 204:
      case 206:
        return [URLStatus.Ok, response.status];
      case 404:
      case 410:
        return [URLStatus.NotFound, response.status];
      case 500:
      case 502:
      case 503:
      case 504:
        return [URLStatus.Error, response.status];
      default:
        return [URLStatus.Other, response.status];
    }
  } catch (error) {
    // this is not uncommon: the virtual server often shuts down in mid-request upon errors
    return [URLStatus.NetworkError, null];
  }
}
