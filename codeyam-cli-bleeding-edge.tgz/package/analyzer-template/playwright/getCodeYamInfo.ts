/* eslint-disable */

import { ProjectFramework } from '~codeyam/types';

export interface CodeYamInfo {
  framework: ProjectFramework;
  analysisId: string;
  scenarioName: string;
  isLastScenario: boolean;
  projectPort: number;
}

export default async function getCodeYamInfo(
  serverUrl: string,
): Promise<CodeYamInfo | null> {
  try {
    const response = await fetch(`${serverUrl}/static/codeyam-info`, {
      method: 'GET',
      headers: {
        'cache-control': 'no-cache',
      },
    });
    if (response.ok) {
      const body = await response.text();

      const { phase, info } = JSON.parse(body);

      // if we're in Serving and info is non-null, we're ready
      if (phase === 'SERVING' && info !== null) {
        return info as CodeYamInfo;
      }

      // all other cases mean 'keep waiting'
      return null;
    }

    throw new Error(
      `CodeYam: Error response fetching /static/codeyam-info: ${response.status}`,
    );
  } catch (error) {
    if (error.code !== 'ECONNREFUSED') {
      throw error;
    }
    // let caller know the server just isn't up yet
    return null;
  }
}
