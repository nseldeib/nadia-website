import * as path from 'path';
import { mkdirSync, rmSync } from 'fs';
import copy from '../common/copy';
import replacePaths from '../common/replacePaths';
import deleteFolder from '../common/deleteFolder';
import { ProjectFramework } from '~codeyam/types';
import removeQueryParamsFromFileNames from '../common/removeQueryParamsFromFileNames';
import { downloadPage } from './downloadPage';

type GenerateStaticBuildArgs = {
  domain: string;
  relativePath: string;
  framework: string;
  defaultBuildFolder?: string;
};

/**
 * Builds a static remix app at the given path.
 *
 * @param {string} domain - The domain of the app. e.g. http://localhost:3000
 * @param {string} relativePath - The relative path of the page. e.g. static/recentlychangedcomponents-7dee2d86-eb0f-46fb-8439-ecbfb5dc619c/default
 * @returns {Promise<void>} - A promise that resolves with the URL of the started app.
 */
export default async function generateStaticBuild({
  domain,
  relativePath,
  framework,
  defaultBuildFolder,
}: GenerateStaticBuildArgs): Promise<void> {
  const rootFolder = defaultBuildFolder ?? '.';
  const normalizedPath = path.resolve(
    path.join(rootFolder, relativePath.split('/')[0]),
  );

  console.log(`CodeYam: Building static site`, domain, relativePath);
  rmSync(normalizedPath, { recursive: true, force: true });
  mkdirSync(normalizedPath, { recursive: true });

  const folders = relativePath.split('/');
  folders.pop(); // The last path in relativePath will become the html file (e.g. default.html)
  const foldersPath = folders.join('/');

  mkdirSync(path.join(rootFolder, foldersPath), { recursive: true });

  try {
    await downloadPage(`${domain}/${relativePath}`, './');
    // const stdout = await execAsync({
    //   command: 'wget',
    //   args: [
    //     '--mirror',
    //     `${domain}/${relativePath}`,
    //     '-P',
    //     rootFolder,
    //     '--no-host-directories',
    //     '--page-requisites',
    //     '--adjust-extension',
    //     // '--output-file=wget.log',
    //     // '--append-output=wget.log',
    //     // '--debug',
    //     // '--verbose'
    //   ],
    //   stepNames: ['generate-interactives'],
    //   hideErrors: true,
    // });
    // console.log(`Static build output: ${JSON.stringify(stdout, null, 2)}`);
  } catch (error) {
    console.log(
      `CodeYam: Error executing static build for ${domain} - ${relativePath}: ${error}`,
    );
  }

  let buildFolder = '';
  switch (framework) {
    case ProjectFramework.CodeYam:
    case ProjectFramework.CRA:
    case ProjectFramework.Remix:
      // the routePath looks like: relative/path/dashboard/app/routes/static.c054b7ee-3961-4697-8354-886062a95a9d.default.default.tsx
      // the path should look like: static/c054b7ee-3961-4697-8354-886062a95a9d/default/default
      buildFolder = 'build';
      break;
    default:
      buildFolder = '_next';
  }

  // read the contents of the build folder and console.log them
  // const buildFolderContents = await execAsync({
  //   command: 'ls',
  //   args: [path.join(rootFolder, buildFolder)]
  // });
  // console.log(`CodeYam: Static build folder contents: ${JSON.stringify(buildFolderContents, null, 2)}`);

  const regexp = new RegExp(`(['"])\/${buildFolder}`, 'g');

  await removeQueryParamsFromFileNames(path.join(rootFolder, buildFolder));

  await replacePaths(
    path.join(rootFolder, buildFolder),
    regexp,
    `$1/${foldersPath}/${buildFolder}`,
  );

  await replacePaths(
    normalizedPath,
    regexp,
    `$1/${foldersPath}/${buildFolder}`,
  );

  await copy(
    path.join(rootFolder, buildFolder),
    path.join(rootFolder, `${foldersPath}/${buildFolder}`),
  );

  await deleteFolder(path.join(rootFolder, buildFolder));

  console.log(`CodeYam: Static build succeeded`, relativePath);
}
