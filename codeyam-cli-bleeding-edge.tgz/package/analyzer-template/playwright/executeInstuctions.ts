import { Page, Locator } from 'playwright';

export interface PlaywrightStep {
  selectorFn: keyof Page;       // e.g. "getByLabel", "locator", "getByText" …
  selectorArgs?: string[];
  actionFn: keyof Locator;      // e.g. "fill", "click", "press" …
  actionArgs?: unknown[];
}

export interface ExecuteOptions {
  /**
   * Keep going when a step fails? (Default: true)
   * If false the very first failure aborts the loop and re-throws.
   */
  continueOnError?: boolean;

  /**
   * When Playwright complains that a locator matches >1 element,
   * automatically fall back to locator.first() and retry once.
   * (Default: true)
   */
  autoFirstOnStrictViolation?: boolean;

  /** How long to wait for the target element to appear / become visible. */
  waitTimeoutMs?: number;
}

export interface ExecutionResult {
  step: PlaywrightStep;
  success: boolean;
  error?: unknown;
}

/**
 * Execute a list of Playwright instructions generated at runtime.
 */
export default async function executeInstructions(
  page: Page,
  steps: PlaywrightStep[],
  options: ExecuteOptions = {},
): Promise<ExecutionResult[]> {
  const {
    continueOnError          = true,
    autoFirstOnStrictViolation = true,
    waitTimeoutMs            = 5_000,
  } = options;

  const results: ExecutionResult[] = [];

  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];

    try {
      /* ───────────────────────────── locator ───────────────────────────── */
      const selectorMethod = (page as any)[step.selectorFn] as
        | ((...args: any[]) => Locator)
        | undefined;

      if (typeof selectorMethod !== 'function') {
        throw new Error(`Unknown selectorFn "${String(step.selectorFn)}"`);
      }

      let locator: any;
      try {
        locator = selectorMethod.apply(page, step.selectorArgs ?? []);
        // Ensure it's actually a Locator-like object
        if (!locator || typeof locator.waitFor !== 'function') {
          throw new Error(`Expected Locator, got ${typeof locator}`);
        }
      } catch (err) {
        throw new Error(
          `Selector "${String(step.selectorFn)}" failed: ${err.message}`,
        );
      }

      /* Optional: wait until the element is actually present/visible. */
      await locator
        .waitFor({ state: 'visible', timeout: waitTimeoutMs })
        .catch(() => {
          /* ignore – element might be invisible for legitimate reasons */
        });

      /* ───────────────────────────── action ────────────────────────────── */
      const actionMethod = (locator as any)[step.actionFn] as
        | ((...args: any[]) => Promise<unknown>)
        | undefined;

      if (typeof actionMethod !== 'function') {
        throw new Error(`Unknown actionFn "${String(step.actionFn)}"`);
      }

      try {
        await actionMethod.apply(locator, step.actionArgs ?? []);
      } catch (err: any) {
        /* Retry once with `.first()` if we hit a strict-mode violation. */
        const strictMsg = 'strict mode violation';
        if (
          autoFirstOnStrictViolation &&
          typeof err?.message === 'string' &&
          err.message.includes(strictMsg)
        ) {
          locator = locator.first();
          await actionMethod.apply(locator, step.actionArgs ?? []);
        } else {
          throw err; // re-throw – not the strictness problem
        }
      }

      results.push({ step, success: true });
    } catch (err) {
      console.error(`❌  Step ${i + 1} failed\n`, step, '\n', err);
      results.push({ step, success: false, error: err });

      if (!continueOnError) throw err;
    }
  }

  return results;
}
