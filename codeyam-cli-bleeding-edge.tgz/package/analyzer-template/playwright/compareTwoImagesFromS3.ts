import { awsLog } from "~codeyam/utils";
import compareImages from "./compareImages";
import downloadImageFromS3 from "./downloadImageFromS3";

export default async function compareTwoImagesFromS3({
  key1,
  key2
}: {
  key1: string;
  key2: string;
}) {
  try {
    const image1Buffer = await downloadImageFromS3({ key: key1 });
    const image2Buffer = await downloadImageFromS3({ key: key2 });
    const comparisonResult = await compareImages(image1Buffer, image2Buffer);

    awsLog("CodeYam: screenshot comparisonResult", {
      image1: `${process.env.S3_BUCKET_NAME}/${key1}`,
      image2: `${process.env.S3_BUCKET_NAME}/${key2}`,
      dimensions1: image1Buffer.length,
      dimensions2: image2Buffer.length,
      comparisonResult: {
        diffPercentage: comparisonResult.diffPercentage,
        diffPixels: comparisonResult.diffPixels,
        dimensions: comparisonResult.dimensions,
        originalDimensions: comparisonResult.originalDimensions,
      },
    });

    return {
      same: parseFloat(comparisonResult.diffPercentage) < 0.02,
      diffPercentage: comparisonResult.diffPercentage,
    }
  } catch (e) {
    awsLog("CodeYam: Error comparing screenshots", {
      error: e,
    });
    return { same: false, diffPercentage: `Error: ${e.message}`, error: e };
  }
}