import {
  CloudFrontClient,
  CreateInvalidationCommand,
} from '@aws-sdk/client-cloudfront';

const cloudFrontClient = new CloudFrontClient({ });

export default async function invalidateCloudFrontPath(
  pathToInvalidate: string,
) {
  return;
  try {
    const params = {
      DistributionId: process.env.CLOUDFRONT_DISTRIBUTION_ID,
      InvalidationBatch: {
        CallerReference: Date.now().toString(),
        Paths: {
          Quantity: 1,
          Items: [pathToInvalidate],
        },
      },
    };

    const data = await cloudFrontClient.send(
      new CreateInvalidationCommand(params),
    );
    console.log('CodeYam: Invalidation created successfully:', pathToInvalidate, data);
  } catch (err) {
    if (err.Code === 'Throttling') {
      console.log(
        'CodeYam Error: Error creating invalidation: Throttling error, retrying in 5 seconds',
      );
      setTimeout(() => invalidateCloudFrontPath(pathToInvalidate), 5000);
    } else {
      console.log('CodeYam Error: Error creating invalidation:', pathToInvalidate, err);
    }
  }
}
