import * as fs from 'fs/promises';
import * as path from 'path';
import { fetch } from 'undici';
import { JSDOM } from 'jsdom';
import { URL } from 'url';
import { awsLog } from '~codeyam/utils';

async function downloadPage(url: string, outputDir: string): Promise<void> {
    const processedUrls = new Set<string>();
    
    try {
        const baseUrl = new URL(url);
        
        // Extract path from URL and create target directory
        let urlPath = baseUrl.pathname;
        urlPath = urlPath.replace(/^\/|\/$/g, '');
        if (!urlPath) urlPath = ''; 
        const urlPathParts = urlPath.split('/');
        const indexPage = (urlPathParts.pop() || 'default') + '.html';
        
        const htmlDir = path.join(outputDir, urlPathParts.join('/'));
        await fs.mkdir(htmlDir, { recursive: true });

        // Fetch the main HTML page
        const response = await fetch(url);
        const html = await response.text();

        // Parse HTML using jsdom
        const dom = new JSDOM(html);
        const document = dom.window.document;

        const downloadResource = async (resourceUrl: string): Promise<string> => {
            try {
                if (processedUrls.has(resourceUrl)) {
                    return resourceUrl; // Skip if already processed
                }
                processedUrls.add(resourceUrl);

                const absoluteUrl = new URL(resourceUrl, baseUrl.href);
                
                let resourcePath = absoluteUrl.pathname;
                if (resourcePath.startsWith('/')) {
                    resourcePath = resourcePath.slice(1);
                }

                // Create the full output path
                const outputPath = path.join(outputDir, resourcePath);
                const outputDirectory = path.dirname(outputPath);
                
                await fs.mkdir(outputDirectory, { recursive: true });
                
                const resourceResponse = await fetch(absoluteUrl.href);
                
                if (!resourceResponse.ok) {
                    throw new Error(`HTTP error! status: ${resourceResponse.status}`);
                }
        
                const contentType = resourceResponse.headers.get('content-type');
                const arrayBuffer = await resourceResponse.arrayBuffer();
                const content = Buffer.from(arrayBuffer);
                
                if (content.length === 0) {
                    throw new Error('Received empty content');
                }
        
                if (contentType?.startsWith('image/')) {
                    const isValidImage = validateImageHeader(content);
                    if (!isValidImage) {
                        throw new Error('Invalid image format');
                    }
                }
        
                await fs.mkdir(outputDirectory, { recursive: true });
                await fs.writeFile(outputPath, content, { encoding: null });
                
                // Process JS files for additional imports
                if (contentType?.includes('javascript') || resourcePath.endsWith('.js') || resourcePath.endsWith('.mjs')) {
                    const jsContent = content.toString('utf-8');
                    await processJavaScriptImports(jsContent);
                }

                const savedContent = await fs.readFile(outputPath);
                if (savedContent.length !== content.length) {
                    throw new Error(`File size mismatch after save: ${savedContent.length} vs ${content.length}`);
                }
        
                return resourceUrl;
            } catch (error) {
                awsLog(`Failed to download resource ${resourceUrl}:`, error);
            }
        };
        
        const validateImageHeader = (buffer: Buffer): boolean => {
            const headers = {
                png: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A],
                jpeg: [0xFF, 0xD8, 0xFF],
                gif: [0x47, 0x49, 0x46, 0x38],
                webp: [0x52, 0x49, 0x46, 0x46],
                bmp: [0x42, 0x4D]
            };
        
            if (!buffer || buffer.length < 4) return false;
        
            for (const [format, header] of Object.entries(headers)) {
                if (buffer.length >= header.length) {
                    if (header.every((byte, i) => buffer[i] === byte)) {
                        return true;
                    }
                }
            }
            return false;
        }

        const processJavaScriptImports = async (content: string): Promise<void> => {
            // Match static imports and dynamic imports
            const importRegex = /(?:import\s+(?:(?:\* as \w+|{\s*[\w\s,]+}\s*|\w+)\s+from\s+)?["']([^"']+)["']|import\(["']([^"']+)["']\))|(?:require\(["']([^"']+)["']\))/g;
            
            const importPromises: Promise<string>[] = [];
            let matches;
            
            while ((matches = importRegex.exec(content)) !== null) {
                const importPath = matches[1] || matches[2] || matches[3];
                if (importPath) {
                    // Skip node built-in modules and absolute npm package imports
                    if (!importPath.startsWith('.') && !importPath.startsWith('/')) {
                        continue;
                    }
                    
                    try {
                        importPromises.push(downloadResource(importPath));
                    } catch (error) {
                        console.error(`Failed to process import: ${importPath}`, error);
                    }
                }
            }

            await Promise.all(importPromises);
        };

        const processElementResource = async (element: Element, attribute: string): Promise<string> => {
            const resourceUrl = element.getAttribute(attribute);
            if (!resourceUrl) return '';
            return downloadResource(resourceUrl);
        }

        const processInlineModuleImports = async (scriptElement: Element): Promise<string[]> => {
            const content = scriptElement.textContent || '';
            if (!content.includes('import')) return [];

            const importRegex = /import\s+(?:(?:\* as \w+|{\s*[\w\s,]+}\s*|\w+)\s+from\s+)?["']([^"']+)["']|import\(["']([^"']+)["']\)/g;
            const downloadPromises: Promise<string>[] = [];

            let matches;
            while ((matches = importRegex.exec(content)) !== null) {
                const importPath = matches[1] || matches[2];
                if (importPath && (importPath.startsWith('/') || importPath.startsWith('.'))) {
                    downloadPromises.push(downloadResource(importPath));
                }
            }

            return Promise.all(downloadPromises);
        }

        const resourceSelectors = [
          // JavaScript related
          { selector: 'script[src]', attribute: 'src' },
          { selector: 'link[rel="modulepreload"]', attribute: 'href' },
          { selector: 'link[rel="preload"][as="script"]', attribute: 'href' },
          { selector: 'link[rel="prefetch"][as="script"]', attribute: 'href' },
          
          // CSS related
          { selector: 'link[rel="stylesheet"]', attribute: 'href' },
          { selector: 'link[rel="preload"][as="style"]', attribute: 'href' },
          { selector: 'link[rel="prefetch"][as="style"]', attribute: 'href' },
          
          // Images related
          { selector: 'img[src]', attribute: 'src' },
          { selector: 'link[rel="preload"][as="image"]', attribute: 'href' },
          { selector: 'link[rel="prefetch"][as="image"]', attribute: 'href' },
          { selector: 'img[srcset]', attribute: 'srcset' },
          { selector: 'source[srcset]', attribute: 'srcset' },
          { selector: 'link[rel="icon"]', attribute: 'href' },
          { selector: 'link[rel="apple-touch-icon"]', attribute: 'href' },
          { selector: 'link[rel="mask-icon"]', attribute: 'href' },
          { selector: 'meta[property="og:image"]', attribute: 'content' },
          { selector: 'meta[name="twitter:image"]', attribute: 'content' },
          
          // Font related
          { selector: 'link[rel="preload"][as="font"]', attribute: 'href' },
          { selector: 'link[rel="prefetch"][as="font"]', attribute: 'href' },
        ];

        // Collect all promises for resource downloads
        const allPromises: Promise<string | string[]>[] = [];
        
        // Process resources with attributes
        for (const { selector, attribute } of resourceSelectors) {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                allPromises.push(processElementResource(element, attribute));
            });
        }

        // Process inline module imports
        const scriptElements = document.querySelectorAll('script[type="module"]');
        scriptElements.forEach(element => {
            allPromises.push(processInlineModuleImports(element));
        });

        // Wait for ALL resources to be downloaded before writing the HTML
        await Promise.all(allPromises);

        await fs.writeFile(
            path.join(htmlDir, indexPage), 
            html
        );

        console.log('Website downloaded successfully!');
    } catch (error) {
        console.error('Error downloading website:', error);
    }
}

export { downloadPage };