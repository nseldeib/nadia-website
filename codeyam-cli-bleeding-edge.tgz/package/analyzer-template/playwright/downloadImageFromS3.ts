import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import * as fs from 'fs/promises';
import * as path from 'path';

export default async function downloadImageFromS3({
  key
}: {
  key: string;
}): Promise<Buffer> {
  if (process.env.CODEYAM_LOCAL_PROJECT_PATH) {
    const localPath = path.join(
      process.env.CODEYAM_LOCAL_PROJECT_PATH,
      '.codeyam',
      'captures',
      key,
    );

    try {
      const buffer = await fs.readFile(localPath);
      return buffer;
    } catch (error) {
      console.error(`Error reading image from local filesystem: ${error}`);
      throw error;
    }
  }
  const bucket = process.env.S3_BUCKET_NAME;
  const s3Client = new S3Client({ });

  try {
    const response = await s3Client.send(
      new GetObjectCommand({
        Bucket: bucket,
        Key: key
      })
    );
    
    if (!response.Body) {
      throw new Error('No image data received from S3');
    }
    
    // Convert readable stream to buffer
    const chunks: Uint8Array[] = [];
    for await (const chunk of response.Body as any) {
      chunks.push(chunk);
    }
    return Buffer.concat(chunks);
    
  } catch (error) {
    console.error(`Error downloading image from S3: ${error}`);
    throw error;
  }
}
