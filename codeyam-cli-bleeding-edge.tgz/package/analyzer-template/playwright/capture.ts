import waitForServer from './waitForServer';

import * as dotenv from 'dotenv';

import {
  loadAnalysis,
  loadBackgroundJob,
  loadScenario,
  updateFreshAnalysisStatus,
  updateFreshAnalysisStatusWithScenarios,
} from '~codeyam/supabase';
import { default as checkURL, URLStatus } from './checkURL';
import { Analysis, AnalysisStatus, Scenario } from '~codeyam/types';
import getCodeYamInfo, { CodeYamInfo } from './getCodeYamInfo';
import taskComplete from './taskComplete';
import findStep from './findStep';
import updateBackgroundJob from './updateBackgroundJob';
import captureStatic from './captureStatic';
import takeScreenshot from './takeScreenshot';
import {
  awsLog,
  frameworkRouteFileNameToRoute,
  isFrameworkRoute,
  pushAnalysisError,
  safeFileName,
} from '~codeyam/utils';
import killProcessAndSubprocesses from '../common/killProcessesAndSubprocesses';
import compareTwoImagesFromS3 from './compareTwoImagesFromS3';
import { DEFAULT_SCENARIO_NAME } from '../common/constants';

dotenv.config();

const SCREENSHOT_S3_FOLDER = 'screenshots';

// Flag to control the main capture loop
let isShuttingDown = false;
let hasErrors = false;

// Handle shutdown signals
process.on('SIGTERM', () => {
  if (isShuttingDown) return;
  awsLog('Received SIGTERM signal, initiating graceful shutdown...');
  isShuttingDown = true;
});

process.on('SIGINT', () => {
  if (isShuttingDown) return;
  awsLog('Received SIGINT signal, initiating graceful shutdown...');
  isShuttingDown = true;
});

process.on('unhandledRejection', (reason, promise) => {
  awsLog('CodeYam Error: Unhandled Promise Rejection:', reason);
  // Don't exit - just log and continue to prevent process death
});

export default async function capture({
  projectSlug,
}: {
  projectSlug?: string;
}) {
  const screenshotsErrors = [];
  const interactivesErrors = [];

  if (!projectSlug || projectSlug === '$PROJECT_SLUG') {
    projectSlug = process.env.PROJECT_SLUG;
  }

  awsLog('CodeYam: Capture Start', projectSlug);

  const job = process.env.COMMIT_ID
    ? await loadBackgroundJob({ commitId: process.env.COMMIT_ID })
    : undefined;

  const updateJob = async () => {
    await updateBackgroundJob(job, screenshotsErrors, interactivesErrors);
  };

  let analysis: Analysis = null;
  while (!isShuttingDown) {
    try {
      analysis = null;
      await captureOneAnalysis();
      if (analysis) {
        awsLog(`CodeYam: Capture of analysis ${analysis.id} complete.`);
        await updateJob();
      } else if (!isShuttingDown) {
        awsLog('CodeYam Error: Expect analysis !== null');
        hasErrors = true;
      }
    } catch (e) {
      awsLog(
        'CodeYam Error: Root error capturing screenshots and interactives',
        job?.commitId,
        e,
      );
      screenshotsErrors.push(e.message);
      interactivesErrors.push(e.message);
      hasErrors = true;
      await updateJob();

      // if we did load an analysis before hitting an error, update it with the error
      if (analysis) {
        await updateFreshAnalysisStatus(
          analysis.id,
          (freshStatus, _inAnalysis) => {
            pushAnalysisError({
              status: freshStatus,
              error: e,
              phase: 'capture',
            });
          },
        );
      }

      // If we're shutting down, don't continue after an error
      if (isShuttingDown) {
        break;
      }
    }
  }

  if (isShuttingDown) {
    awsLog('Gracefully shutting down capture process...');
    setupShutdownTimeout();

    try {
      await updateJob();
      awsLog('Final job update complete, exiting...');

      // Kill child processes and exit with appropriate code
      await killProcessAndSubprocesses(
        'playwright',
        projectSlug,
        process.pid,
        (msg) => {
          awsLog('CodeYam: ' + msg);
        },
        hasErrors ? 1 : 0,
      );
    } catch (err) {
      console.error('Error during final cleanup:', err);
      // Kill processes and exit with error code
      await killProcessAndSubprocesses(
        'playwright',
        projectSlug,
        process.pid,
        (msg) => {
          awsLog('CodeYam: ' + msg);
        },
        1,
      );
    }
  }

  async function captureOneAnalysis() {
    // TODO: $PROJECT_URL should become $CONTROLLER_URL
    const controllerUrl = process.env.PROJECT_URL ?? 'http://localhost:3000';

    await waitForServer(controllerUrl, () => isShuttingDown);

    // Exit early if we're shutting down
    if (isShuttingDown) {
      return;
    }

    let codeYamInfo: CodeYamInfo = null;
    let numRetriesForScenario = 0;

    // the server takes some time to come back for each scenario
    while (!isShuttingDown && ++numRetriesForScenario <= 200) {
      // wait until 1) CodeYamInfo is being served and 2) it's not a lingering previous run
      try {
        const newCodeYamInfo = await getCodeYamInfo(controllerUrl);
        if (
          !newCodeYamInfo ||
          JSON.stringify(newCodeYamInfo) === JSON.stringify(codeYamInfo) // TODO
        ) {
          awsLog(
            newCodeYamInfo
              ? 'CodeYam: Waiting for updated CodeYam Info...'
              : 'CodeYam: Waiting for CodeYam Info...',
          );
          await new Promise((resolve) => setTimeout(resolve, 3000));
          continue;
        }

        awsLog('CodeYam: Received CodeYam Info', newCodeYamInfo);

        codeYamInfo = newCodeYamInfo;
      } catch (e) {
        // this is a scenario-failing error
        throw new Error("Couldn't get CodeYam Info: " + e);
      }

      numRetriesForScenario = 0;

      const {
        projectPort,
        framework,
        analysisId,
        scenarioName,
        isLastScenario,
      } = codeYamInfo;
      if (!framework || !analysisId || !scenarioName || !(projectPort > 0)) {
        // this is a scenario-failing error
        throw new Error('Invalid CodeYam Info: ' + JSON.stringify(codeYamInfo));
      }

      awsLog('CodeYam: Capture Info', { analysisId, scenarioName });

      analysis = await loadAnalysis({
        id: analysisId,
        includeFile: true,
        includeScenarios: true,
      });

      if (!analysis) {
        awsLog('CodeYam Error: Analysis not found from info', { analysisId });
        throw new Error('Analysis not found from info');
      }

      const scenario = analysis.scenarios.find((s) => s.name === scenarioName);

      if (!scenario) {
        awsLog('CodeYam Error: Scenario not found in analysis', {
          analysisId,
          scenarioName,
          scenarios: analysis.scenarios?.map((s) => s.name),
        });
        throw new Error('Scenario not found for analysis');
      }

      const { file } = analysis;

      analysis.status ||= {
        startedAt: new Date().toISOString(),
        steps: [],
        errors: [],
      };

      awsLog('CodeYam: Initializing Capture', {
        fileId: file?.id,
        analysisId: analysis.id,
        filePath: file?.path,
        entityName:
          analysis.entity?.metadata?.exportAlias ?? analysis.entityName,
        scenarioName: scenario?.name,
        entityType: analysis?.entity?.entityType,
      });

      // we construct the project url using the controller url & the received port.
      // this assumes the project is accessible on the same host as the controller!
      const projectUrl = urlWithNewPort(controllerUrl, projectPort);

      try {
        const scenarioSlug = safeFileName(scenario.name);
        const entitySlug = safeFileName(analysis.entityName);
        const screenshotFileName = `${projectSlug}/${file?.id}/${analysis?.id}/${scenarioSlug}.png`;
        const screenshotPath = `./${SCREENSHOT_S3_FOLDER}/${screenshotFileName}`;

        let relativePath = `static/${projectSlug}/${analysis.id}/${entitySlug}/${scenarioSlug}/default`;
        let selector;
        if (isFrameworkRoute(file, analysis.entity, framework)) {
          awsLog('CodeYam: Route file', file.name);
          relativePath = frameworkRouteFileNameToRoute(
            projectSlug,
            file,
            analysis,
            framework,
          );
        } else {
          selector = '#component';
        }

        // now fetch the URL to see if it exists, and executes cleanly
        const [urlStatus, httpCode] = await checkURL(
          `${projectUrl}/${relativePath}`,
        );
        if (urlStatus !== URLStatus.Ok) {
          awsLog(
            urlStatus === URLStatus.NetworkError
              ? `CodeYam Error: Network Error accessing URL (virtual server may have shut down)`
              : URLStatus.Error
                ? `CodeYam Error: Error [code=${httpCode}] accessing URL`
                : `CodeYam Error: Not Found [code=${httpCode}] accessing URL`,
            `${projectUrl}/${relativePath}`,
          );

          // notify the server to move onto the next scenario
          await taskComplete(controllerUrl, scenario.id);
          continue;
        }

        analysis.metadata ||= {};
        const screenshotResult = await takeScreenshot({
          analysis,
          scenario,
          projectSlug,
          projectUrl,
          screenshotPath,
          screenshotFileName,
          selector,
          relativePath,
          file,
          job,
        });
        screenshotsErrors.push(...screenshotResult.errors);

        const screenshotPathKey = `${SCREENSHOT_S3_FOLDER}/${screenshotFileName}`;
        let foundSameAsDefault = false;
        if (scenarioName === DEFAULT_SCENARIO_NAME) {
          for (const otherScenario of analysis.scenarios) {
            if (otherScenario.name === DEFAULT_SCENARIO_NAME) continue;

            if (otherScenario.metadata?.screenshotPaths?.[0]) {
              const otherScreenshotPathKey = `${SCREENSHOT_S3_FOLDER}/${otherScenario.metadata.screenshotPaths[0]}`;
              const comparisonResult = await compareTwoImagesFromS3({
                key1: screenshotPathKey,
                key2: otherScreenshotPathKey,
              });

              if (comparisonResult.same) {
                awsLog('CodeYam: Default screenshot is the same', {
                  analysisId: scenario.analysisId,
                  scenarioName: otherScenario.name,
                  scenarioId: otherScenario.id,
                  screenshotPathKey,
                  otherScreenshotPathKey,
                  comparisonResult,
                });

                otherScenario.metadata ||= {};
                otherScenario.metadata.sameAsDefault = true;
                foundSameAsDefault = true;
              } else {
                awsLog('CodeYam: Default screenshot is not the same', {
                  analysisId: scenario.analysisId,
                  scenarioName: scenario.name,
                  scenarioId: scenario.id,
                  screenshotPathKey,
                  otherScreenshotPathKey,
                  comparisonResult,
                });
              }
            }
          }
        } else {
          const defaultScenario = analysis.scenarios.find(
            (s) => s.name === DEFAULT_SCENARIO_NAME,
          );
          if (defaultScenario?.metadata?.screenshotPaths?.[0]) {
            const defaultScreenshotPathKey = `${SCREENSHOT_S3_FOLDER}/${defaultScenario.metadata.screenshotPaths[0]}`;
            const defaultComparisonResult = await compareTwoImagesFromS3({
              key1: screenshotPathKey,
              key2: defaultScreenshotPathKey,
            });

            if (defaultComparisonResult.same) {
              awsLog('CodeYam: Default screenshot is the same', {
                analysisId: scenario.analysisId,
                scenarioName: scenario.name,
                scenarioId: scenario.id,
                screenshotPath: screenshotPathKey,
                defaultScreenshotPath: defaultScreenshotPathKey,
                defaultComparisonResult,
              });

              scenario.metadata ||= {};
              scenario.metadata.sameAsDefault = true;
              foundSameAsDefault = true;
            } else {
              awsLog('CodeYam: Default screenshot is not the same', {
                analysisId: scenario.analysisId,
                scenarioName: scenario.name,
                scenarioId: scenario.id,
                screenshotPath: screenshotPathKey,
                defaultScreenshotPath: defaultScreenshotPathKey,
                defaultComparisonResult,
              });
            }
          }
        }

        if (foundSameAsDefault) {
          await updateFreshAnalysisStatusWithScenarios(
            scenario.analysisId,
            (_: AnalysisStatus, freshScenarios: Scenario[]) => {
              for (const freshScenario of freshScenarios) {
                const updatedScenario =
                  scenario.id === freshScenario.id
                    ? scenario
                    : analysis.scenarios.find((s) => s.id === freshScenario.id);

                if (!updatedScenario) continue;

                freshScenario.metadata ||= {};
                freshScenario.metadata.sameAsDefault =
                  updatedScenario.metadata?.sameAsDefault;
              }
            },
          );
        }

        if (scenario.previousVersionId) {
          const previousVersion = await loadScenario({
            id: scenario.previousVersionId,
            projectId: analysis.projectId,
          });

          if (previousVersion?.metadata?.screenshotPaths?.length > 0) {
            const previousInteractiveExamplePath =
              previousVersion?.metadata?.interactiveExamplePath;
            const previousScreenshotPath =
              previousVersion.metadata.screenshotPaths[0];
            const previousScreenshotPathKey = `${SCREENSHOT_S3_FOLDER}/${previousScreenshotPath}`;

            const comparisonResult = await compareTwoImagesFromS3({
              key1: screenshotPathKey,
              key2: previousScreenshotPathKey,
            });

            if (comparisonResult.same) {
              awsLog('CodeYam: Previous screenshot is the same', {
                analysisId: scenario.analysisId,
                scenarioName: scenario.name,
                scenarioId: scenario.id,
                previousVersionId: scenario.previousVersionId,
                screenshotPath: screenshotPathKey,
                previousScreenshotPath: previousScreenshotPathKey,
              });
            } else {
              awsLog('CodeYam: Previous screenshot is different', {
                analysisId: scenario.analysisId,
                scenarioId: scenario.id,
                scenarioName: scenario.name,
                previousVersionId: scenario.previousVersionId,
                screenshotPath: screenshotPathKey,
                previousScreenshotPath: previousScreenshotPathKey,
              });

              await updateFreshAnalysisStatusWithScenarios(
                scenario.analysisId,
                (_: AnalysisStatus, freshScenarios: Scenario[]) => {
                  const freshScenario = freshScenarios.find(
                    (s) => s.id === scenario.id,
                  );
                  freshScenario.metadata ||= {};
                  freshScenario.metadata.previousInteractiveExamplePath =
                    previousInteractiveExamplePath;
                  freshScenario.metadata.screenshotsChangedFromPreviousVersion ||=
                    [];
                  if (
                    !freshScenario.metadata.screenshotsChangedFromPreviousVersion.find(
                      (p) => p.new === screenshotFileName,
                    )
                  ) {
                    freshScenario.metadata.screenshotsChangedFromPreviousVersion.push(
                      {
                        new: screenshotFileName,
                        old: previousScreenshotPath,
                        diffPercentage: comparisonResult.diffPercentage,
                      },
                    );
                  }
                },
              );
            }
          } else {
            awsLog('CodeYam: Previous screenshot does not exist', {
              analysisId: scenario.analysisId,
              scenarioId: scenario.id,
              scenarioName: scenario.name,
              previousVersionId: scenario.previousVersionId,
              screenshotPath: screenshotPathKey,
            });

            await updateFreshAnalysisStatusWithScenarios(
              scenario.analysisId,
              (_: AnalysisStatus, freshScenarios: Scenario[]) => {
                const freshScenario = freshScenarios.find(
                  (s) => s.id === scenario.id,
                );
                freshScenario.metadata ||= {};
                freshScenario.metadata.screenshotsChangedFromPreviousVersion ||=
                  [];
                if (
                  !freshScenario.metadata.screenshotsChangedFromPreviousVersion.find(
                    (p) => p.new === screenshotFileName,
                  )
                ) {
                  freshScenario.metadata.screenshotsChangedFromPreviousVersion.push(
                    {
                      new: screenshotFileName,
                    },
                  );
                }
              },
            );
          }
        }

        const staticResult = await captureStatic({
          analysis,
          scenario,
          projectUrl,
          relativePath,
          framework,
          file,
          job,
        });
        interactivesErrors.push(...staticResult.errors);

        await updateFreshAnalysisStatus(
          analysis.id,
          (freshStatus, inAnalysis) => {
            awsLog(
              `CodeYam: Saving analysis ${inAnalysis.id} scenario ${scenario.name} status`,
            );

            freshStatus.scenarios ||= [];
            const scenarioStatus = freshStatus.scenarios.find(
              (s) => s.name === scenario.name,
            );
            if (scenarioStatus) {
              scenarioStatus.finishedAt = new Date().toISOString();
              awsLog(
                `CodeYam DEBUG: after captureStatic(): Updating analysis ${inAnalysis.id} scenario ${scenario.name} status with finishedAt = ${scenarioStatus.finishedAt}`,
              );
            } else {
              const newStatusScenario = {
                name: scenario.name,
                startedAt: new Date().toISOString(),
                finishedAt: new Date().toISOString(),
              };
              freshStatus.scenarios.push(newStatusScenario);
              awsLog(
                `CodeYam DEBUG: after captureStatic(): Updating analysis ${inAnalysis.id} with new scenario ${newStatusScenario.name} and finishedAt = ${newStatusScenario.finishedAt}`,
              );
            }

            const allScenariosAvailable =
              freshStatus.scenarios.length >= inAnalysis.scenarios?.length;
            if (
              allScenariosAvailable &&
              freshStatus.scenarios.every((s) => !!s.finishedAt)
            ) {
              freshStatus.finishedAt = new Date().toISOString();
              freshStatus.readyToBeCaptured = false;
            }
          },
        );

        awsLog('CodeYam: Capture Complete', {
          fileId: file?.id,
          analysisId: analysis?.id,
          filePath: file?.path,
          entityName:
            analysis?.entity?.metadata?.exportAlias ?? analysis?.entityName,
          scenarioName: scenario?.name,
          entityType: analysis?.entity?.entityType,
        });

        await taskComplete(controllerUrl, scenario.id);

        // Exit the loop if this is the last scenario or we're shutting down
        if (isLastScenario || isShuttingDown) {
          awsLog(
            'CodeYam: Last scenario detected or shutdown initiated, exiting loop.',
          );
          break;
        }
      } catch (e) {
        awsLog(
          'CodeYam Error: Error capturing screenshots and interactives',
          {
            fileId: file?.id,
            analysisId: analysis?.id,
            filePath: file?.path,
            entityName:
              analysis?.entity?.metadata?.exportAlias ?? analysis?.entityName,
            scenarioName: scenario?.name,
            entityType: analysis?.entity?.entityType,
            jobCommitId: job?.commitId,
          },
          e,
        );
        awsLog(e);
        const screenshotsStep = findStep(analysis, 'captureScreenshots');
        if (screenshotsStep && !screenshotsStep?.error) {
          screenshotsStep.error = e.message;
          screenshotsStep.errorStack = e.stack;
        }

        const interactivesStep = findStep(analysis, 'captureInteractives');
        if (interactivesStep && !interactivesStep.error) {
          interactivesStep.error = e.message;
          interactivesStep.errorStack = e.stack;
        }

        await updateFreshAnalysisStatus(
          analysis.id,
          (freshStatus, _inAnalysis) => {
            pushAnalysisError({
              status: freshStatus,
              error: e,
              phase: 'capture',
            });
          },
        );

        // If we're shutting down, don't continue after an error
        if (isShuttingDown) {
          break;
        }
      }
    }
  }
}

function urlWithNewPort(controllerUrl: string, projectPort: number) {
  const url = new URL(controllerUrl);
  url.port = projectPort.toString();
  return `${url.protocol}//${url.host}`;
}

function setupShutdownTimeout() {
  if (isShuttingDown) {
    const forceExitTimeout = setTimeout(() => {
      awsLog('Graceful shutdown timed out after 30s, forcing exit...');
      process.exit(1);
    }, 30 * 1000);
    forceExitTimeout.unref(); // Don't let this timeout prevent process exit
  }
}

// Main entry point for the Playwright flow in production
const args = process.argv.slice(2);

const slugIndex = args.indexOf('--slug');
if (slugIndex >= 0) {
  const slug = args[slugIndex + 1];
  capture({ projectSlug: slug }).catch((err) => {
    console.error(err);
    process.exit(1);
  });
}
