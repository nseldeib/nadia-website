import { Analysis } from '~codeyam/types';

export default function findStep(analysis: Analysis, name: string) {
  const steps = analysis.status.steps.filter((s) => s.name === name);
  return steps[steps.length - 1];
}
