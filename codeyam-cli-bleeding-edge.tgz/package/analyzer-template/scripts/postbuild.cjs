/* eslint-disable @typescript-eslint/no-var-requires */
const fs = require('fs');
const path = require('path');

function updateImportStatements(directory, level = 0) {
  const relativeLevel = Array(level).fill('..').join('/');
  const files = fs.readdirSync(directory, { withFileTypes: true });

  files.forEach((file) => {
    const filePath = path.join(directory, file.name);
    if (file.isDirectory()) {
      updateImportStatements(filePath, level + 1);
    } else if (file.isFile() && file.name.endsWith('.js')) {
      fs.readFile(filePath, 'utf8', function (err, data) {
        if (err) {
          console.log('Error reading file:', filePath, err);
          return;
        }

        let result = data.replace(
          /import \* as lib from ['"](.*)lib['"]/g,
          "import * as lib from '$1lib/index.js'",
        );
        result = result.replace(
          /import \* as lib from ['"](.*)['"]/g,
          "import * as lib from '$1/index.js'",
        );
        result = result.replace(
          /import \* as (.*)(_\d)* from\s+['"](\.+\/)(.*?)['"]/g,
          "import * as $1 from '$3$4/index.js'",
        );
        result = result.replace(
          /from\s+['"](\.+\/)(.*?)['"]/g,
          (match, relativePath, moduleName) => {
            const fullPath = path.resolve(path.dirname(filePath), relativePath + moduleName);
            const indexPath = path.join(fullPath, 'index.js');
            
            // Check if there's a directory with index.js
            if (fs.existsSync(indexPath)) {
              return `from "${relativePath}${moduleName}/index.js"`;
            } else {
              return `from "${relativePath}${moduleName}.js"`;
            }
          }
        );
        result = result.replace(
          /['"]~codeyam\/(.*)['"]/g,
          `'${relativeLevel}/packages/$1/index.js'`,
        );
        result = result.replace(/.js.js/g, '.js');
        result = result.replace(/index\/index\.js/g, 'index.js');
        result = result.replace(/(index\.js\/)+/g, '');

        fs.writeFile(filePath, result, 'utf8', function (err) {
          if (err) {
            console.log('Error writing file:', filePath, err);
          }
        });
      });
    }
  });
}

updateImportStatements(path.join(__dirname, '..', 'dist'));
