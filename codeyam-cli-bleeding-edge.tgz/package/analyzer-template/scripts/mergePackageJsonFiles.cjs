/* eslint-disable @typescript-eslint/no-var-requires */
const fs = require('fs');
const path = require('path');

async function findPackageJsonFiles(rootPackageJsonPath, dir) {
  let filesToMerge = [];
  const files = await fs.readdirSync(dir);

  for (const file of files) {
    const filePath = path.join(dir, file);
    const stat = await fs.statSync(filePath);

    if (stat.isDirectory()) {
      const nestedFiles = await findPackageJsonFiles(
        rootPackageJsonPath,
        filePath,
      );
      filesToMerge = filesToMerge.concat(nestedFiles);
    } else if (
      file === 'package.json' &&
      filePath !== path.resolve(rootPackageJsonPath)
    ) {
      filesToMerge.push(filePath);
    }
  }

  return filesToMerge;
}

function mergeDependencies(rootDependencies, newDependencies) {
  for (const [dep, version] of Object.entries(newDependencies)) {
    if (!rootDependencies[dep] || rootDependencies[dep] < version) {
      rootDependencies[dep] = version;
    }
  }
}

async function mergePackageJsonFiles(rootPackageJsonPath, searchDirectory) {
  try {
    const rootPackageJsonString = await fs.readFileSync(
      rootPackageJsonPath,
      'utf8',
    );
    const rootPackageJson = JSON.parse(rootPackageJsonString);
    const packageJsonFiles = await findPackageJsonFiles(
      rootPackageJsonPath,
      searchDirectory,
    );

    for (const file of packageJsonFiles) {
      const packageJsonString = await fs.readFileSync(file, 'utf8');
      const packageJson = JSON.parse(packageJsonString);
      if (packageJson.dependencies) {
        mergeDependencies(
          rootPackageJson.dependencies ?? {},
          packageJson.dependencies ?? {},
        );
      }

      if (packageJson.devDependencies) {
        mergeDependencies(
          rootPackageJson.devDependencies ?? {},
          packageJson.devDependencies ?? {},
        );
      }
    }

    await fs.writeFileSync(
      rootPackageJsonPath,
      JSON.stringify(rootPackageJson, null, 2),
    );
    console.log('Merged dependencies into root package.json');
  } catch (error) {
    console.log('Error merging package.json files:', error);
  }
}

mergePackageJsonFiles(
  path.join(__dirname, '..', 'package.json'),
  path.join(__dirname, '..', 'packages'),
);
