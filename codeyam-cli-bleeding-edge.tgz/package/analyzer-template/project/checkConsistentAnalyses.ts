import { Analysis } from '~codeyam/types';

type Bucket = {
  type: 'commit' | 'branch-commit';
  ids: string[];
};

/**
 * Assert that all analyses are from the same commit or branch-commit, and return
 * one of the analyses.
 */
export function checkConsistentAnalyses(analyses: Analysis[]) {
  // sort analyses by commitId or branchCommitSha
  const groups = new Map<string, Bucket>();

  for (const analysis of analyses) {
    const key = analysis.commitId ?? analysis.branchCommitSha!;
    if (!key) {
      throw new Error(
        `CodeYam Interal Error: Analysis ${analysis.id} has neither commitId nor branchCommitSha`,
      );
    }

    const type = analysis.commitId ? 'commit' : 'branch-commit';

    if (!groups.has(key)) {
      groups.set(key, { type, ids: [] });
    }
    groups.get(key)!.ids.push(analysis.id);
  }

  if (groups.size === 0) {
    throw new Error('Codeyam Internal Error: No analyses to check');
  }
  if (groups.size === 1) {
    // they're all from the same commit or branch-commit
    return analyses[0];
  }

  // otherwise fail helpfully
  const details = [...groups.entries()]
    .map(
      ([key, data]) => `${data.ids.length} analyses from ${data.type} ${key}.`,
    )
    .join('\n');

  const largest = [...groups.entries()].reduce((best, current) =>
    current[1].ids.length > best[1].ids.length ? current : best,
  );

  const suggestion = `\nTry using only analyses from ${largest[1].type} ${
    largest[0]
  }: ${largest[1].ids.join(', ')}`;

  throw new Error(
    `Analyses must all be from the same commit or branch-commit. Found:\n${details}${suggestion}`,
  );
}
