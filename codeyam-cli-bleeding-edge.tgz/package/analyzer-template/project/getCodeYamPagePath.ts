import { Project, ProjectFramework } from '~codeyam/types';
import { PROJECT_RELATIVE_PATH } from '~codeyam/utils';

export interface GetCodeYamPagePathArgs {
  project: Project;
  framework: ProjectFramework;
}

export default function getCodeYamPagePath({
  project,
  framework,
}: GetCodeYamPagePathArgs) {
  const relativePath = PROJECT_RELATIVE_PATH;
  switch (framework) {
    case ProjectFramework.CodeYam:
      return getSamplePagePathForCodeyam(relativePath);
    case ProjectFramework.Remix:
    case ProjectFramework.CRA:
      return getSamplePagePathForRemix(project, relativePath);
    case ProjectFramework.Next:
      return getSamplePagePathForNext(project, relativePath);
    case ProjectFramework.NextPages:
      return getSamplePagePathForNextPages(project, relativePath);
    default:
      throw new Error('Unsupported framework');
  }
}

const getSamplePagePathForCodeyam = (relativePath: string): string => {
  const routesDir = `${relativePath}/dashboard/app/routes`;
  return `${routesDir}/static.codeyam-sample.tsx`; // e.g. ./app/routes/static.codeyam-sample.tsx
};

const getSamplePagePathForRemix = (project: Project, relativePath: string): string => {
  const appDirectory = project.metadata?.appDirectory ?? 'app';
  const routesDir = `${relativePath}/${appDirectory}/routes`;
  return `${routesDir}/static.codeyam-sample.tsx`; // e.g. ./app/routes/static.codeyam-sample.tsx
};

const getSamplePagePathForNext = (project: Project, relativePath: string): string => {
  const appDirectory = project.metadata?.appDirectory ?? 'app';
  return `${relativePath}/${appDirectory}/static/codeyam-sample/page.tsx`; // e.g. ./app/static/codeyam-sample.tsx
};

const getSamplePagePathForNextPages = (project: Project, relativePath: string): string => {
  const appDirectory = project.metadata?.appDirectory ?? 'pages';
  return `${relativePath}/${appDirectory}/static/codeyam-sample/index.tsx`; // e.g. ./app/static/codeyam-sample.tsx
};