import { Analysis, Scenario } from '~codeyam/types';
import emailErrorReport from '../emailErrorReport';
import { updateFreshAnalysisStatus } from '~codeyam/supabase';

export async function recordErrorMessageForScenario(
  analysis: Analysis,
  scenario: Scenario,
  error: Error,
  shouldEmailReport = true,
) {
  try {
    await updateFreshAnalysisStatus(analysis.id, (freshStatus, _inAnalysis) => {
      try {
        freshStatus.scenarios ||= [];
        const scenarioIndex = freshStatus.scenarios.findIndex(
          (s) => s.name === scenario.name,
        );
        if (scenarioIndex === -1) {
          freshStatus.scenarios.push({
            name: scenario.name,
            startedAt: new Date().toISOString(),
            error: error.message,
          });
        } else {
          freshStatus.scenarios[scenarioIndex].error = error.message;
        }
      } catch (e) {
        console.log(
          'CodeYam Error: Error recording error message for scenario in fresh analysis',
          e,
        );
      }
    });

    if (shouldEmailReport) {
      await emailErrorReport({
        analysis,
        scenario,
        errorMessage: error.message,
      });
    }
  } catch (e) {
    console.log('CodeYam Error: Error recording error message for scenario', e);
  }
}
