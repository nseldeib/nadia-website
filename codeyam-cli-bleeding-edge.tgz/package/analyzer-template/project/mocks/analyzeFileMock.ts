import {
  Analysis,
  AnalysisMap,
  Entity,
  EntityMap,
  EntityType,
} from '~codeyam/types';

type AnalyzeFileFunction = () => Promise<{
  analysisMap: AnalysisMap;
  entityMap: EntityMap;
}>;

async function analyzeReturnsEmptyArray() {
  return { analysisMap: {}, entityMap: {} };
}

const standaloneComponentAnalysis = {
  id: 'c054b7ee-3961-4697-8354-886062a95a9d',
  projectId: '',
  commitId: '',
  entitySha: '',
  fileId: '',
  filePath: 'app/components/StandaloneCounter.tsx',
  entityType: 'visual' as EntityType,
  entityName: 'StandaloneCounter',
  dependencyAnalyzedTreeSha: 'standaloneComponentAnalysis',
  status: {
    startedAt: new Date().toISOString(),
    readyToBeCaptured: true,
    steps: [],
    errors: [],
  },
  metadata: {
    propsWithTypes: { props: [] },
    localImports: [],
    scenariosDataStructure: {
      dataForMocks: {},
    },
  },
  scenarios: [
    {
      projectId: '',
      analysisId: 'c054b7ee-3961-4697-8354-886062a95a9d',
      name: 'Default Scenario',
      description:
        'The counter is initialized at 0, with the ability to increment and decrement the count.',
      metadata: {
        dataMapping: {},
        keyAttributeInstructions: {},
        data: {
          argumentsData: [],
          mockData: {},
        },
      },
    },
  ],
  committedAt: '1970-01-01T00:00:00Z',
  createdAt: '1970-01-01T00:00:00Z',
  updatedAt: '1970-01-01T00:00:00Z',
} as Analysis;

const standaloneComponentEntity = {
  sha: '',
  fileId: '',
  filePath: 'app/components/StandaloneCounter.tsx',
  projectId: '',
  name: 'StandaloneCounter',
  entityType: 'visual' as EntityType,
  metadata: {
    llmCalls: {},
  },
  committedAt: '1970-01-01T00:00:00Z',
  createdAt: '1970-01-01T00:00:00Z',
  updatedAt: '1970-01-01T00:00:00Z',
} as Entity;

async function analyzeReturnsStandaloneComponent() {
  return {
    analysisMap: {
      'app/components/StandaloneCounter.tsx': {
        StandaloneCounter: standaloneComponentAnalysis,
      },
    },
    entityMap: {
      'app/components/StandaloneCounter.tsx': {
        StandaloneCounter: standaloneComponentEntity,
      },
    },
  };
}

async function simplePropsComponent() {
  return {
    analysisMap: await analyzeReturnsSimplePropsFileOnlyOnNonPrimaryBranch(
      'app/components/SimpleProps.tsx',
      'UserProfile',
    ),
    entityMap: await entityReturnsSimplePropsFileOnlyOnNonPrimaryBranch(
      'app/components/SimpleProps.tsx',
      'UserProfile',
    ),
  };
}

async function componentsSpecificToThisBranchComponent() {
  const path = 'app/components/ComponentSpecificToThisBranch.tsx';
  const analysisMap = await analyzeReturnsSimplePropsFileOnlyOnNonPrimaryBranch(
    path,
    'StandaloneCounter',
  );
  const entityMap = await entityReturnsSimplePropsFileOnlyOnNonPrimaryBranch(
    path,
    'StandaloneCounter',
  );
  analysisMap[path].StandaloneCounter.entityName = 'StandaloneCounter';
  entityMap[path].StandaloneCounter.name = 'StandaloneCounter';
  return {
    analysisMap,
    entityMap,
  };
}

// async function simplePropsComponent() {
//   return analyzeReturnsSimplePropsFileOnlyOnNonPrimaryBranch("app/components/SimpleProps.tsx");
// }

async function analyzeReturnsSimplePropsFileOnlyOnNonPrimaryBranch(
  path: string,
  entityName: string,
) {
  const standaloneComponentOnlyOnNonPrimaryBranchAnalysis = JSON.parse(
    JSON.stringify(standaloneComponentAnalysis),
  ) as Analysis;

  standaloneComponentOnlyOnNonPrimaryBranchAnalysis.filePath = path;

  return {
    [path]: {
      [entityName]: standaloneComponentOnlyOnNonPrimaryBranchAnalysis,
    },
  };
}

async function entityReturnsSimplePropsFileOnlyOnNonPrimaryBranch(
  path: string,
  entityName: string,
) {
  const standaloneComponentOnlyOnNonPrimaryBranchEntity = JSON.parse(
    JSON.stringify(standaloneComponentEntity),
  ) as Entity;

  standaloneComponentOnlyOnNonPrimaryBranchEntity.filePath = path;

  return {
    [path]: {
      [entityName]: standaloneComponentOnlyOnNonPrimaryBranchEntity,
    },
  };
}

async function analyzeReturnsSimplePropsFile(): Promise<{
  analysisMap: AnalysisMap;
  entityMap: EntityMap;
}> {
  return {
    analysisMap: {
      'app/components/SimpleProps.tsx': {
        UserProfile: {
          id: 'c054b7ee-3961-4697-8354-886062a95a9d',
          projectId: '',
          commitId: '',
          fileId: '',
          filePath: 'app/components/SimpleProps.tsx',
          entitySha: '',
          entityType: 'visual' as EntityType,
          entityName: 'UserProfile',
          dependencyAnalyzedTreeSha: 'standaloneComponentAnalysis',
          status: {
            startedAt: new Date().toISOString(),
            readyToBeCaptured: true,
            steps: [],
            errors: [],
          },
          metadata: {
            propsWithTypes: {
              props: [
                {
                  name: 'name',
                  type: 'string',
                  required: true,
                },
                {
                  name: 'age',
                  type: 'number',
                  required: true,
                },
                {
                  name: 'isActive',
                  type: 'boolean',
                  required: true,
                },
              ],
            },
            scenariosDataStructure: {
              arguments: [
                {
                  name: 'string',
                  age: 'number',
                  isActive: 'boolean',
                },
              ],
            },
          },
          scenarios: [
            {
              projectId: '',
              analysisId: 'c054b7ee-3961-4697-8354-886062a95a9d',
              name: 'Default Scenario',
              description:
                'A user who is under 18 years old and is currently active.',
              metadata: {
                dataMapping: {},
                keyAttributeInstructions: {},
                data: {
                  argumentsData: [
                    {
                      age: 17,
                      name: 'Default Scenario',
                      isActive: true,
                    },
                  ],
                  mockData: {},
                },
              },
            },
            {
              projectId: '',
              analysisId: 'c054b7ee-3961-4697-8354-886062a95a9d',
              name: 'Active adult user',
              description:
                'A user who is between 18 and 39 years old and is currently active.',
              metadata: {
                dataMapping: {},
                keyAttributeInstructions: {},
                data: {
                  argumentsData: [
                    {
                      age: 25,
                      name: 'Adult Active User',
                      isActive: true,
                    },
                  ],
                  mockData: {},
                },
              },
            },
            {
              projectId: '',
              analysisId: 'c054b7ee-3961-4697-8354-886062a95a9d',
              name: 'Active senior user',
              description:
                'A user who is 40 years or older and is currently active.',
              metadata: {
                dataMapping: {},
                keyAttributeInstructions: {},
                data: {
                  argumentsData: [
                    {
                      age: 65,
                      name: 'Senior Active User',
                      isActive: true,
                    },
                  ],
                  mockData: {},
                },
              },
            },
            {
              projectId: '',
              analysisId: 'c054b7ee-3961-4697-8354-886062a95a9d',
              name: 'Inactive young user',
              description:
                'A user who is under 18 years old and is currently inactive.',
              metadata: {
                dataMapping: {},
                keyAttributeInstructions: {},
                data: {
                  argumentsData: [
                    {
                      age: 16,
                      name: 'Young Inactive User',
                      isActive: false,
                    },
                  ],
                  mockData: {},
                },
              },
            },
            {
              projectId: '',
              analysisId: 'c054b7ee-3961-4697-8354-886062a95a9d',
              name: 'Inactive adult user',
              description:
                'A user who is between 18 and 39 years old and is currently inactive.',
              metadata: {
                dataMapping: {},
                keyAttributeInstructions: {},
                data: {
                  argumentsData: [
                    {
                      age: 30,
                      name: 'Adult Inactive User',
                      isActive: false,
                    },
                  ],
                  mockData: {},
                },
              },
            },
          ],
          committedAt: '1970-01-01T00:00:00Z',
          createdAt: '1970-01-01T00:00:00Z',
          updatedAt: '1970-01-01T00:00:00Z',
        },
      },
    },
    entityMap: {
      'app/components/SimpleProps.tsx': {
        UserProfile: {
          sha: '',
          fileId: '',
          filePath: 'app/components/SimpleProps.tsx',
          projectId: '',
          name: 'UserProfile',
          entityType: 'visual' as EntityType,
          metadata: {},
          createdAt: '1970-01-01T00:00:00Z',
          updatedAt: '1970-01-01T00:00:00Z',
        },
      },
    },
  };
}

async function analyzeReturnsImportedComponentsFile(): Promise<{
  analysisMap: AnalysisMap;
  entityMap: EntityMap;
}> {
  return {
    analysisMap: {
      'app/components/Imports.tsx': {
        ImportsComponent: {
          id: 'c054b7ee-3961-4697-8354-886062a95a9d',
          projectId: '',
          commitId: '',
          fileId: '',
          filePath: 'app/components/Imports.tsx',
          entitySha: '',
          entityType: 'visual' as EntityType,
          entityName: 'ImportsComponent',
          dependencyAnalyzedTreeSha: '',
          status: {
            startedAt: new Date().toISOString(),
            readyToBeCaptured: true,
            steps: [],
            errors: [],
          },
          metadata: {
            propsWithTypes: { props: [] },
            scenariosDataStructure: {},
          },
          scenarios: [
            {
              projectId: '',
              analysisId: 'c054b7ee-3961-4697-8354-886062a95a9d',
              name: 'Default Scenario',
              description: 'Default scenario description',
              metadata: {
                dataMapping: {},
                keyAttributeInstructions: {},
                data: {
                  argumentsData: [],
                  mockData: {},
                },
              },
            },
          ],
          committedAt: '1970-01-01T00:00:00Z',
          createdAt: '1970-01-01T00:00:00Z',
          updatedAt: '1970-01-01T00:00:00Z',
        },
      },
    },
    entityMap: {
      'app/components/Imports.tsx': {
        ImportsComponent: {
          sha: '',
          fileId: '',
          filePath: 'app/components/Imports.tsx',
          projectId: '',
          name: 'ImportsComponent',
          entityType: 'visual' as EntityType,
          metadata: {},
          createdAt: '1970-01-01T00:00:00Z',
          updatedAt: '1970-01-01T00:00:00Z',
        },
      },
    },
  };
}

type AnalyzeFileMocks = {
  [key: string]: AnalyzeFileFunction;
};

export enum AnalyzeFileMockName {
  Empty = 'empty',
  Standalone = 'standalone',
  SimplePropsComponent = 'simplePropsComponent',
  ComponentsSpecificToThisBranchComponent = 'componentsSpecificToThisBranchComponent',
  SimplePropsFile = 'simplePropsFile',
  ImportedComponentsFile = 'importedComponentsFile',
}

export const analyzeFileMocks: AnalyzeFileMocks = {
  [AnalyzeFileMockName.Empty]: analyzeReturnsEmptyArray,
  [AnalyzeFileMockName.Standalone]: analyzeReturnsStandaloneComponent,
  [AnalyzeFileMockName.SimplePropsComponent]: simplePropsComponent,
  [AnalyzeFileMockName.ComponentsSpecificToThisBranchComponent]:
    componentsSpecificToThisBranchComponent,
  [AnalyzeFileMockName.SimplePropsFile]: analyzeReturnsSimplePropsFile,
  [AnalyzeFileMockName.ImportedComponentsFile]:
    analyzeReturnsImportedComponentsFile,
};