import { Commit, Project } from '~codeyam/types';
import createEntitiesAndSortFiles, {
  EntityWithImportCount,
} from './createEntitiesAndSortFiles';
import {
  AnalysisContext,
  analyzeEntities,
  ProjectAnalyzer,
} from '~codeyam/analyze';
import {
  loadAnalyses,
  loadFile,
  updateCommitMetadata,
  updateProjectMetadata,
} from '~codeyam/supabase';
import checkApprovedPath from './checkApprovedPath';

interface AnalyzeBranchCommitArgs {
  project: Project;
  projectAnalyzer: ProjectAnalyzer;
  branchCommit: Commit;
  analysisIds?: string[];
  context: AnalysisContext;
  steps: string[];
}

export default async function analyzeBranchCommit({
  project,
  projectAnalyzer,
  branchCommit,
  analysisIds,
  context,
  steps,
}: AnalyzeBranchCommitArgs) {
  const shouldUpdateBaselineStatus = !analysisIds || analysisIds.length === 0;

  if (shouldUpdateBaselineStatus) {
    branchCommit.metadata = await updateCommitMetadata({
      commitId: branchCommit.id,
      runStatusUpdate: {
        createdAt: new Date().toISOString(),
        fileCount: project.files.length,
        filesCompleted: 0,
        entityCount: 0,
        analysesCompleted: 0,
      },
    });
    project.metadata = await updateProjectMetadata({
      projectId: project.id,
      metadataUpdate: {
        baselineSha: branchCommit.sha,
      },
    });
  }

  // Step 1: Create the sorted entities and map
  const sortedEntitiesAndMap = await createEntitiesAndSortFiles({
    project,
    branch: branchCommit.branch,
    projectAnalyzer,
    branchCommit,
  });

  // Step 2: Initialize context with all entities from the map
  for (const fileEntities of Object.values(sortedEntitiesAndMap.entityMap)) {
    for (const [entityName, entity] of Object.entries(fileEntities)) {
      if (entity.name !== entityName) {
        // for entities that were double-registered under an 'alias', preserve that alias
        context.addEntity(entity, entityName);
      } else {
        context.addEntity(entity);
      }
    }
  }

  // Step 3: Determine which entities to analyze
  let entitiesToAnalyze: EntityWithImportCount[] = [];

  if (analysisIds) {
    // If we have analysis IDs, load those specific entities
    const analyses = await loadAnalyses({
      projectId: project.id,
      ids: analysisIds,
    });

    if (!analyses || analyses.length === 0) {
      console.log(
        'CodeYam Error: Analyses not found in analyzeBranchCommit for ids',
        analysisIds,
      );
      throw new Error('Specified analyses not found');
    }

    for (const analysis of analyses) {
      const entity = analysis.entity;
      const file = project.files.find((f) => f.path === entity.filePath);
      const fileAnalyzer = projectAnalyzer.getFileAnalyzer(file);
      entity.code = fileAnalyzer.getEntityCode(entity.name);
      entitiesToAnalyze.push(entity);
    }

    console.log(
      'CodeYam Analyzing specified entities',
      entitiesToAnalyze.map((e) => ({ path: e.filePath, name: e.name })),
    );
  } else {
    // Otherwise, use the sorted entities
    entitiesToAnalyze = sortedEntitiesAndMap.sortedEntities;

    // Useful for running analysis for specific entities (if already analyzed use analysisIds)
    // entitiesToAnalyze = Object.values(sortedEntitiesAndMap.sortedEntities)
    //   .flat()
    //   .filter(
    //     (e) =>
    //       e.sha ===
    //       'aca34a70dfbc6ad07d9abdacb35404f4493bed44790aea6d533a56a5274f54b1',
    //   );

    console.log('Analyzing entities', entitiesToAnalyze.length);
  }

  // Step 4: Filter out entities from unapproved paths and already completed
  const filteredEntities = [];
  for (const entity of entitiesToAnalyze) {
    // if (
    //   entity.filePath !==
    //     'dashboard/app/components/phases/PhaseSection.tsx' ||
    //     !['PhaseSection', 'default'].includes(entity.name)

    //   // entity.filePath !==
    //   //   'dashboard/app/routes/dashboard.projects.$id.recent.($branchId).tsx' ||
    //   //   !['RecentChangesPage', 'default'].includes(entity.name)
    // )
    //   continue;

    // Skip unapproved paths
    if (!checkApprovedPath({ project, path: entity.filePath })) {
      console.log('CodeYam: Skipping unapproved path', entity.filePath);
      continue;
    }

    // Skip already completed entities
    if (entity.completed) {
      console.log(
        'Entity already completed',
        entity.filePath,
        entity.name,
        entity.completed ? 'Completed' : 'Not Completed',
      );
      continue;
    }

    // Find the entity's file
    let file = project.files.find((f) => f.id === entity.fileId);
    if (!file) {
      try {
        file = await loadFile({ id: entity.fileId });
        if (!file) {
          console.log(
            'CodeYam Error: Branch commit prep file not found for entity',
            JSON.stringify(
              {
                entitySha: entity.sha,
                entityFileId: entity.fileId,
                entityFilePath: entity.filePath,
                entityName: entity.name,
              },
              null,
              2,
            ),
          );
          continue; // Skip this entity rather than failing the whole batch
        }
      } catch (error) {
        console.log(
          'Error loading file for entity',
          entity.filePath,
          entity.name,
          error,
        );
        continue;
      }
    }

    // Associate the file with the entity for later use
    entity.file = file;

    // Mark entity as started
    entity.started = new Date().toISOString();

    filteredEntities.push(entity);
  }

  if (shouldUpdateBaselineStatus) {
    // now we know the total number of entities, we can update the baseline status
    branchCommit.metadata = await updateCommitMetadata({
      commitId: branchCommit.id,
      runStatusUpdate: {
        entityCount: filteredEntities.length,
      },
    });
  }

  // Step 5: Analyze the filtered entities
  if (filteredEntities.length > 0) {
    try {
      console.log(
        `CodeYam: analyzeBranchCommit: Starting analysis of ${filteredEntities.length} root entities`,
      );

      await analyzeEntities({
        rootEntities: filteredEntities,
        context,
        project,
        projectAnalyzer,
        commit: branchCommit,
        options: {
          branchCommitSha: branchCommit.sha,
          steps,
          force: !!process.env.FORCE,
          forceAll: !!process.env.FORCE_ALL,
        },
      });
    } catch (error) {
      console.log(`CodeyYam Error: Baseline ${branchCommit.sha} FAILED`, error);
      throw error;
    }

    // Mark all entities as completed
    for (const entity of filteredEntities) {
      entity.completed = new Date().toISOString();
    }
  }

  // Final log for branch commit analysis
  if (!analysisIds) {
    console.log('Completed Branch Commit Analysis', branchCommit.sha);
  }

  // Return all entities that were processed
  return {
    entities: filteredEntities,
  };
}
