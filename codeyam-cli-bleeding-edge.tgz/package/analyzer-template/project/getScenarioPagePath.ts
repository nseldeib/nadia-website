import { Analysis, Project, ProjectFramework } from '~codeyam/types';
import { safeFileName, PROJECT_RELATIVE_PATH } from '~codeyam/utils';

export interface GetScenarioPagePathArgs {
  project: Project;
  analysis: Analysis;
  scenarioName: string;
  framework: ProjectFramework;
}

export default function getScenarioPagePath({
  project,
  analysis,
  scenarioName,
  framework,
}: GetScenarioPagePathArgs) {
  const scenarioSlug = safeFileName(scenarioName);

  const relativePath = PROJECT_RELATIVE_PATH;
  switch (framework) {
    case ProjectFramework.CodeYam:
      return getPagePathForCodeYam(project, analysis, scenarioSlug, relativePath);
    case ProjectFramework.Remix:
    case ProjectFramework.CRA:
      return getPagePathForRemix(project, analysis, scenarioSlug, relativePath);
    case ProjectFramework.Next:
      return getPagePathForNext(project, analysis, scenarioSlug, relativePath);
    case ProjectFramework.NextPages:
      return getPagePathForNextPages(project, analysis, scenarioSlug, relativePath);
    default:
      throw new Error(`Unsupported framework ${framework}`);
  }
}

const getPagePathForRemix = (
  project: Project,
  analysis: Analysis,
  scenarioSlug: string,
  relativePath: string,
): string => {
  const entitySlug = safeFileName(analysis.entityName);
  const appDirectory = project.metadata?.appDirectory ?? 'app';
  const routesDir = `${relativePath}/${appDirectory}/routes`;

  const pageName = `static.${project.slug}.${analysis.id}.${entitySlug}.${scenarioSlug}.default`; // e.g. static.123.button-123-314-342.19202928282289.default
  const pagePath = `${routesDir}/${pageName}.tsx`; // e.g. ./app/routes/static.button-123-314-342.19202928282289.default.tsx
  return pagePath;
};

const getPagePathForCodeYam = (
  project: Project,
  analysis: Analysis,
  scenarioSlug: string,
  relativePath: string,
): string => {
  const entitySlug = safeFileName(analysis.entityName);
  const routesDir = `${relativePath}/dashboard/app/routes`;

  const pageName = `static.${project.slug}.${analysis.id}.${entitySlug}.${scenarioSlug}.default`; // e.g. static.123.button-123-314-342.19202928282289.default
  const pagePath = `${routesDir}/${pageName}.tsx`; // e.g. ./app/routes/static.button-123-314-342.19202928282289.default.tsx
  return pagePath;
};

const getPagePathForNext = (
  project: Project,
  analysis: Analysis,
  scenarioSlug: string,
  relativePath: string,
): string => {
  const entitySlug = safeFileName(analysis.entityName);
  const appDirectory = project.metadata?.appDirectory ?? 'app';
  const pageName = `${analysis.id}/${entitySlug}/${scenarioSlug}`; // e.g. button-123-314-342/19202928282289/123
  const pagePath = `${relativePath}/${appDirectory}/static/${project.slug}/${pageName}/default/page.tsx`; // e.g. ./app/static/123/button-123-314-342/19202928282289/default/page.tsx
  return pagePath;
};

const getPagePathForNextPages = (
  project: Project,
  analysis: Analysis,
  scenarioSlug: string,
  relativePath: string,
): string => {
  const entitySlug = safeFileName(analysis.entityName);
  const appDirectory = project.metadata?.appDirectory ?? 'pages';
  const pageName = `${analysis.id}/${entitySlug}/${scenarioSlug}`; // e.g. button-123-314-342/19202928282289/123
  const pagePath = `${relativePath}/${appDirectory}/static/${project.slug}/${pageName}/default/index.tsx`; // e.g. ./pages/static/123/button-123-314-342/19202928282289/default/index.tsx
  return pagePath;
};
