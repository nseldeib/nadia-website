import sgMail from '@sendgrid/mail';
import { Analysis, Scenario } from '~codeyam/types';

sgMail.setApiKey(process.env.SENDGRID_API_KEY!);

export default async function emailErrorReport({
  analysis,
  scenario,
  errorMessage,
}: {
  analysis: Analysis;
  scenario: Scenario;
  errorMessage: string;
}) {
  return;
  const msg = {
    to: 'jared@codeyam.com', // Change to your recipient
    from: 'support@ethoswallet.xyz', // Change to your verified sender
    subject: 'A Simulation Analysis Failed',
    text: errorText({ analysis, scenario, errorMessage }),
    html: errorHtml({ analysis, scenario, errorMessage }),
  };

  try {
    await sgMail.send(msg);
    console.log('Email sent successfully');
  } catch (error) {
    console.log('CodeYam Error: Error sending email:', error);
    if (error.response) {
      console.log(error.response.body);
    }
  }
}

function errorText({
  analysis,
  scenario,
  errorMessage,
}: {
  analysis: Analysis;
  scenario: Scenario;
  errorMessage: string;
}) {
  return `A Simulation Analysis Failed
Analysis ID: ${analysis.id}
File Path: ${analysis.file.path}
Entity Name: ${analysis.entityName}
Scenario Name: ${scenario.name}

Link: https://${process.env.PROJECT_URL}/admin/analysis/${analysis.id}

Error:
${errorMessage}
`;
}

function errorHtml({
  analysis,
  scenario,
  errorMessage,
}: {
  analysis: Analysis;
  scenario: Scenario;
  errorMessage: string;
}) {
  return `<strong>A Simulation Analysis Failed</strong>
<br/>
<p>Analysis ID: ${analysis.id}</p>
<p>File Path: ${analysis.file.path}</p>
<p>Entity Name: ${analysis.entityName}</p>
<p>Scenario Name: ${scenario.name}</p>
<br/>
<p><a href="https://${process.env.PROJECT_URL}/admin/analysis/${analysis.id}">View Admin Analysis</a></p>
<br/>
<strong>Error:</strong>
<pre>${errorMessage}</pre>
`;
}
