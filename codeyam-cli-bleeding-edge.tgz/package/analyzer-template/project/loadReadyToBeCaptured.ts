import {
  AnalysisContext,
  discoverDirectDependencies,
} from '~codeyam/analyze';
import {
  loadAnalysis,
  loadReadyToBeCapturedAnalyses,
} from '~codeyam/supabase';
import { Analysis, Project } from '~codeyam/types';

interface LoadReadyToBeCapturedArgs {
  project: Project;
  branchCommitSha?: string;
  analysisIds?: string[];
  context: AnalysisContext;
}

/**
 * Load the minimal set of analyses required to successfully run scenario capture.
 * This includes the root analyses (with scenarios) plus all recursive mock dependencies.
 */
export default async function loadReadyToBeCaptured({
  project,
  branchCommitSha,
  analysisIds,
  context,
}: LoadReadyToBeCapturedArgs): Promise<{
  readyToBeCaptured: Analysis[];
}> {
  console.log('CodeYam: Loading ready to be captured analyses...');

  // Discovery call: Load the initial set of ready-to-be-captured analyses (with scenarios but no mocks)
  const readyToBeCapturedAnalyses = await loadReadyToBeCapturedAnalyses({
    projectId: project.id,
    branchCommitSha: branchCommitSha,
    ids: analysisIds,
  });

  if (!readyToBeCapturedAnalyses || readyToBeCapturedAnalyses.length === 0) {
    return {
      readyToBeCaptured: [],
    };
  }

  console.log(
    'CodeYam: Found ready to be captured analyses',
    readyToBeCapturedAnalyses.length,
    readyToBeCapturedAnalyses.map((a) => ({
      id: a.id,
      filePath: a.filePath,
      entityName: a.entityName,
      scenarioCount: a.scenarios?.length ?? 0,
    })),
  );

  const allRequiredAnalyses = new Map<string, Analysis>();

  // Start with just the discovered analyses - these need to be loaded with mocks
  const stillNeeded = new Set(
    readyToBeCapturedAnalyses.map((a) => `${a.filePath}:${a.entityName}`),
  );

  console.log(
    `CodeYam: Loading ${stillNeeded.size} analyses with mock dependencies...`,
  );

  // Load analyses one by one, discovering new dependencies as we go
  let foundNewDependencies = true;
  let isFirstBatch = true;
  while (foundNewDependencies && stillNeeded.size > 0) {
    foundNewDependencies = false;
    const currentBatch = Array.from(stillNeeded);

    // Load analyses for current batch
    const loadPromises = currentBatch.map(async (keyString) => {
      const [filePath, entityName] = keyString.split(':');

      // Find the file ID for this file path
      const file = project.files.find((f) => f.path === filePath);
      if (!file) {
        console.log(
          `CodeYam Warning: File not found in project: ${filePath} for key ${keyString}`,
        );
        return null;
      }

      try {
        const analysis = await loadAnalysis({
          projectId: project.id,
          fileId: file.id,
          entityName,
          includeScenarios: isFirstBatch, // Only include scenarios for the root analyses
        });

        if (analysis) {
          console.log(`CodeYam: Loaded analysis ${filePath}:${entityName}`);
          return { key: keyString, analysis };
        } else {
          console.log(
            `CodeYam Warning: Analysis not found: ${filePath}:${entityName}`,
          );
          return null;
        }
      } catch (error) {
        console.log(
          `CodeYam Error loading analysis ${filePath}:${entityName}:`,
          error,
        );
        return null;
      }
    });

    const results = await Promise.all(loadPromises);

    // Process loaded analyses and find new dependencies
    for (const result of results) {
      if (!result) continue;

      const { key, analysis } = result;
      allRequiredAnalyses.set(key, analysis);
      stillNeeded.delete(key);

      // Use shared dependency discovery logic
      const newDeps = discoverDirectDependencies(analysis);
      for (const dep of newDeps) {
        if (!allRequiredAnalyses.has(dep) && !stillNeeded.has(dep)) {
          stillNeeded.add(dep);
          foundNewDependencies = true;
        }
      }
    }

    // After first batch, we don't need scenarios for dependency analyses
    isFirstBatch = false;
  }

  // Final check - warn about any missing analyses but don't fail
  if (stillNeeded.size > 0) {
    console.log(
      'CodeYam Warning: Some required analyses could not be loaded:',
      Array.from(stillNeeded),
    );
  }

  console.log(
    `CodeYam: Loaded ${allRequiredAnalyses.size} total analyses for scenario capture`,
  );

  // Populate the provided analysis context
  for (const analysis of allRequiredAnalyses.values()) {
    // Add the entity if it exists
    if (analysis.entity) {
      context.addEntity(analysis.entity);
    }

    // Add the analysis
    context.addAnalysis(analysis, analysis.filePath, analysis.entityName);
  }

  // Extract the root analyses with scenarios from allRequiredAnalyses (they were reloaded with mocks)
  const finalReadyToBeCaptured = readyToBeCapturedAnalyses.map(
    (originalAnalysis) => {
      const key = `${originalAnalysis.filePath}:${originalAnalysis.entityName}`;
      const reloadedAnalysis = allRequiredAnalyses.get(key);
      if (!reloadedAnalysis) {
        throw new Error(
          `Internal error: Failed to reload analysis with mocks for ${key}. This indicates a bug in loadReadyToBeCaptured.`,
        );
      }
      return reloadedAnalysis;
    },
  );

  return {
    readyToBeCaptured: finalReadyToBeCaptured,
  };
}
