import { loadFiles, saveFiles, generateSha } from '~codeyam/supabase';
import { File, Project } from '~codeyam/types';
import { ProjectAnalyzer } from '~codeyam/analyze';

interface GetFilesWithEntitiesFromRepoArgs {
  project: Project;
  projectAnalyzer: ProjectAnalyzer;
  silent?: boolean;
}

export default async function getFilesWithEntitiesFromRepo({
  project,
  projectAnalyzer,
  silent,
}: GetFilesWithEntitiesFromRepoArgs) {
  const validFiles: File[] = [];

  const sourceFiles = projectAnalyzer.getAllSourceFiles();
  if (!silent) {
    console.log(
      `CodeYam: Enumerating ${sourceFiles.length} source files for ${project.slug}`,
    );
  }

  // Filter valid source files
  const validSourceFiles = sourceFiles.filter((sourceFile) => {
    if (sourceFile.absolutePath.indexOf('node_modules') > -1) return false;
    if (sourceFile.content.length === 0) return false;
    if (project.metadata.approvedPaths) {
      const approved = project.metadata.approvedPaths.find((path) =>
        sourceFile.absolutePath.includes(path),
      );
      if (!approved) return false;
    }
    return true;
  });

  // Separate files that exist in project vs need to be loaded from DB
  const filesNeedingDbLookup: typeof validSourceFiles = [];
  const sourceFileMap = new Map<string, (typeof validSourceFiles)[0]>();

  for (const sourceFile of validSourceFiles) {
    sourceFileMap.set(sourceFile.path, sourceFile);
    const existingFile = project.files.find((f) => f.path === sourceFile.path);
    if (!existingFile) {
      filesNeedingDbLookup.push(sourceFile);
    } else {
      existingFile.content = sourceFile.content;
      validFiles.push(existingFile);
    }
  }

  // Bulk load missing files from DB
  let filesFromDb: File[] = [];
  if (filesNeedingDbLookup.length > 0) {
    const filePaths = filesNeedingDbLookup.map((sf) => sf.path);
    filesFromDb = await loadFiles({
      projectId: project.id,
      filePaths,
    });
  }

  // Identify files that still need to be created
  const filesToCreate: Array<{
    name: string;
    path: string;
    project_id: string;
  }> = [];
  for (const sourceFile of filesNeedingDbLookup) {
    const existingDbFile = filesFromDb.find((f) => f.path === sourceFile.path);
    if (existingDbFile) {
      existingDbFile.content = sourceFile.content;
      validFiles.push(existingDbFile);
    } else {
      const name = sourceFile.path.split('/').pop();
      filesToCreate.push({
        name,
        path: sourceFile.path,
        project_id: project.id.toString(),
      });
    }
  }

  // Bulk save new files
  let newFiles: File[] = [];
  if (filesToCreate.length > 0) {
    newFiles = await saveFiles(filesToCreate);
    for (const newFile of newFiles) {
      const sourceFile = sourceFileMap.get(newFile.path);
      if (sourceFile) {
        newFile.content = sourceFile.content;
        validFiles.push(newFile);
      }
    }
  }

  for (const file of validFiles) {
    const fileAnalyzer = projectAnalyzer.getFileAnalyzer(file);

    file.entities = [];
    const allEntityNodes = fileAnalyzer.getAllEntityNodesOnlyAliases();
    for (const entityName in allEntityNodes) {
      const entityType = fileAnalyzer.getEntityType(entityName);
      const entityCode = fileAnalyzer.getEntityCode(entityName);
      const sha = generateSha(file.path, entityName, entityCode);
      file.entities.push({
        name: entityName,
        entityType,
        code: entityCode,
        sha,
        fileId: file.id,
        projectId: project.id,
        filePath: file.path,
        metadata: {
          notExported: !fileAnalyzer.isExported(entityName),
          namedExport: !fileAnalyzer.isDefaultExport(entityName),
        },
      });
    }
  }

  project.files = validFiles;
  if (!silent) {
    console.log(
      'CodeYam: Valid Files',
      project.files.length,
      'Valid Entities',
      project.files.reduce((acc, file) => acc + file.entities.length, 0),
    );
  }

  return validFiles;
}
