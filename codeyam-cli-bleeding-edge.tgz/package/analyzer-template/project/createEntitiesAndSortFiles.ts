import { Branch, Commit, Entity, File, Project } from '~codeyam/types';
import {
  AnalysisContext,
  FileAnalyzer,
  findOrCreateEntity,
  gatherEntityMap,
  ProjectAnalyzer,
  setImportedExports,
} from '~codeyam/analyze';
import {
  updateCommitMetadata,
  upsertEntities,
  upsertEntityBranches,
} from '~codeyam/supabase';

export interface EntityWithImportCount extends Entity {
  importCount?: number;
  started?: string;
  completed?: string;
}

export interface SortedEntitiesAndMap {
  sortedEntities: EntityWithImportCount[];
  entityMap: { [key: string]: { [key: string]: EntityWithImportCount } };
}

async function findAndGatherEntity({
  project,
  branch,
  file,
  entityName,
  fileAnalyzer,
  projectAnalyzer,
  context,
}: {
  project: Project;
  branch: Branch;
  file: File;
  entityName: string;
  fileAnalyzer: FileAnalyzer;
  projectAnalyzer: ProjectAnalyzer;
  context: AnalysisContext;
}) {
  let entityWithImportCount: EntityWithImportCount = context.getEntity(
    file.path,
    entityName,
  ) as EntityWithImportCount;
  if (entityWithImportCount?.importCount === undefined) {
    try {
      entityWithImportCount = await findOrCreateEntity({
        file,
        branchId: branch?.id,
        entityName,
        fileAnalyzer,
        projectAnalyzer,
        context,
      });
    } catch (e) {
      console.log(
        'CodeYam Warning: Entity not found in create and sort entities',
        { filePath: file.path, entityName, branchId: branch?.id, error: e },
      );
      return { entityWithImportCount };
    }

    // Add entity to context
    context.addEntity(entityWithImportCount);

    await gatherEntityMap({
      entity: entityWithImportCount,
      branchId: branch?.id,
      context,
      projectAnalyzer,
    });

    entityWithImportCount.importCount = 0;
    for (const importedEntity of entityWithImportCount.metadata
      ?.importedExports ?? []) {
      const importedEntityFilePath =
        importedEntity.resolvedFilePath ?? importedEntity.filePath;
      const importedEntityName =
        importedEntity.resolvedName ?? importedEntity.name;

      const entityFile = project.files.find(
        (f) => f.path === importedEntityFilePath,
      );
      if (!entityFile) {
        if (!entityFile) {
          console.log(
            'CodeYam Error: Entity file not found for create and sort entities',
            importedEntityName,
            importedEntityFilePath,
          );
          throw new Error('Entity file not found for create and sort entities');
        }
      }

      const info = await findAndGatherEntity({
        project,
        branch,
        file: entityFile,
        entityName: importedEntityName,
        fileAnalyzer: projectAnalyzer.getFileAnalyzer(entityFile),
        projectAnalyzer,
        context,
      });
      entityWithImportCount.importCount +=
        info.entityWithImportCount.importCount;
    }

    entityWithImportCount.importCount += (
      entityWithImportCount.metadata?.importedExports ?? []
    ).length;
  }

  // Add entity to context
  context.addEntity(entityWithImportCount);

  return { entityWithImportCount };
}

interface EntitiesAndSortFiles {
  project: Project;
  branch: Branch;
  projectAnalyzer: ProjectAnalyzer;
  branchCommit?: Commit;
}

export default async function createEntitiesAndSortFiles({
  project,
  branch,
  projectAnalyzer,
  branchCommit, // just for progress updates
}: EntitiesAndSortFiles): Promise<SortedEntitiesAndMap> {
  const sortedEntities: Entity[] = [];

  // We slightly abuse the AnalysisContext here, initializing and later throwing it away
  // just to gather entities in a way that's compatible with the rest of the codebase.
  const context = new AnalysisContext();

  // Enable baseline mode to skip DB reads during entity creation
  context.setBaselineMode(true);
  for (let ii = 0; ii < project.files.length; ii++) {
    const file = project.files[ii];

    if (branchCommit) {
      branchCommit.metadata = await updateCommitMetadata({
        commitId: branchCommit.id,
        runStatusUpdate: {
          filesCompleted: ii + 1,
        },
      });
    }

    const fileAnalyzer = projectAnalyzer.getFileAnalyzer(file);
    const allEntityNodes = fileAnalyzer.getAllEntityNodesOnlyAliases();

    for (const entityName of Object.keys(allEntityNodes)) {
      const { entityWithImportCount: entity } = await findAndGatherEntity({
        project,
        branch,
        file,
        entityName,
        fileAnalyzer,
        projectAnalyzer,
        context,
      });

      sortedEntities.push(entity);
    }
  }

  await setImportedExports({
    entities: Object.values(sortedEntities).flat(),
    context,
    projectAnalyzer,
  });

  // Batch write all entities and entity branches in baseline mode
  console.log('Codeyam DEBUG: Starting batch write for baseline mode');
  const entityMap = context.getMutableEntityMap();
  const allEntities = Object.values(entityMap).flatMap((fileEntities) =>
    Object.values(fileEntities),
  );

  // Deduplicate entities by SHA (caused by alias registrations like 'default')
  const entityBySha = new Map();
  allEntities.forEach((entity) => {
    entityBySha.set(entity.sha, entity);
  });
  const uniqueEntities = Array.from(entityBySha.values());

  if (allEntities.length !== uniqueEntities.length) {
    console.log(
      `Codeyam DEBUG: Deduplicated entities from ${allEntities.length} to ${uniqueEntities.length} (removed ${allEntities.length - uniqueEntities.length} duplicate SHAs from alias registrations)`,
    );
  }

  console.log(
    `Codeyam DEBUG: Batch writing ${uniqueEntities.length} unique entities`,
  );
  const savedEntities = await upsertEntities(uniqueEntities);

  // Create entity-branch records for all entities with the single branch
  const entityBranches = savedEntities.map((entity) => ({
    entitySha: entity.sha,
    branchId: branch?.id,
    active: true,
  }));

  // Chunk entity branches to avoid URL length limits in upsertEntityBranches
  const ENTITY_BRANCH_BATCH_SIZE = 50;
  console.log(
    `Codeyam DEBUG: Batch writing ${entityBranches.length} entity branches in chunks of ${ENTITY_BRANCH_BATCH_SIZE}`,
  );

  for (let i = 0; i < entityBranches.length; i += ENTITY_BRANCH_BATCH_SIZE) {
    const chunk = entityBranches.slice(i, i + ENTITY_BRANCH_BATCH_SIZE);
    await upsertEntityBranches(chunk);
  }

  console.log('Codeyam DEBUG: Batch write completed');

  return { sortedEntities, entityMap };
}
