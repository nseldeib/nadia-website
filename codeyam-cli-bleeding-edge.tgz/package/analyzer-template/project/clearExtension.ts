export default function clearExtension(filename?: string): string {
  if (!filename) return filename ?? '';
  if (filename.startsWith('.') && !filename.substring(1).includes('.')) {
    return filename;
  }
  const parts = filename.split('.');
  parts.pop();
  return parts.join('.');
}
