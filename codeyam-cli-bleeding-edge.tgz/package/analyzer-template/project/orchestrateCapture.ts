/****************************************************************************************
 * Overview of the Distributed Capture System
 *
 * The capture part of the analysis flow is an interaction between two processes: one to
 * serve up an entity through a variety of scenarios, and another to capture screenshots,
 * errors, and other artifacts.
 *
 * Historically, these two processes have run as dual containers within one ECS task, and
 * all captures occurred strictly after all other analysis was complete.
 *
 * The distributed system combines the two capture processes in a single new docker image
 * and launches some configurable number of instances of it as ECS worker tasks. Each one
 * listens to a shared SQS queue of work batches (currently just analysisIds) that are up
 * for grabs, claims one, and executes the serve & capture process for that analysis.
 * On the worker task end, this is governed by the script "comboWorkerLoop.cjs".
 *
 * This file, meanwhile (orchestrateCapture.ts) controls the flow of ready-to-be-captured
 * analyses from the DB into the SQS queue, and is responsible for the lifecycles of the
 * worker tasks. It's an async function which runs until it's told to stop (or times out
 * waiting for work).
 *
 * IMPORTANT: 'ready-to-be-captured' serves two purposes here: it is used to enumerate the
 * work available, and it's *also* used to identify when an analysis has been successfully
 * captured – it will no longer be present in the reloaded list of ready analyses.
 */

import type { Commit } from '~codeyam/types';
import {
  getSupabase,
  loadProject,
  updateCommitMetadata,
} from '~codeyam/supabase';

import { sqsSendMessage, sqsGetQueueSizeStats } from '~codeyam/aws/sqs';

import {
  ecsStartTask,
  ecsCheckTaskStatus,
  getEcsStartConfigForOrchestrationTask,
} from '~codeyam/aws/ecs';

import {
  SQSClient,
  CreateQueueCommand,
  DeleteQueueCommand,
  ReceiveMessageCommand,
  DeleteMessageCommand,
} from '@aws-sdk/client-sqs';
import { loadOrCreateCommit } from '~codeyam/github';
import { DbAnalysis } from '~codeyam/supabase';

const MAX_BATCH_SIZE = 6;
const POLLING_INTERVAL = 30 * 1000; // 30 seconds
const TASK_HEALTH_CHECK_INTERVAL = 60 * 1000; // 1 minute
const ANALYSIS_TIMEOUT = 20 * 60 * 1000;
const PROGRESS_WINDOW = 30 * 60 * 1000; // 30 minutes of no progress before stopping tasks

type ControlMessage = 'drain' | 'shutdown';
type ReadyAnalysisData = Pick<
  DbAnalysis,
  'id' | 'commit_id' | 'branch_commit_sha'
> & {
  processingForCaptureAt?: string; // PostgREST extracts this directly, not nested under status
};

interface OrchestrateCaptureArgs {
  controlCallback?: (callback: (message: ControlMessage) => void) => void;
  projectSlug: string;
  branchCommitSha?: string;
  commitSha?: string;
  analysisIds?: string[];
  entityShas?: string[];
  full?: boolean;
  taskCount?: number;
}

interface QueueInfo {
  workQueueUrl: string;
  controlQueueUrl: string;
}

export default async function orchestrateCapture({
  controlCallback,
  projectSlug,
  branchCommitSha,
  commitSha,
  analysisIds,
  entityShas,
  full = false,
  taskCount = 3,
}: OrchestrateCaptureArgs) {
  if (!full && !analysisIds && !commitSha && !entityShas && !branchCommitSha) {
    throw new Error(
      'Must provide at least one of analysisIds, commitSha, entityShas, or branchCommitSha',
    );
  }

  if (taskCount < 1) {
    throw new Error('taskCount must be at least 1');
  }

  const project = await loadProject({ slug: projectSlug });
  if (!project) {
    throw new Error(`Project not found for slug: ${projectSlug}`);
  }

  let commit: Commit = null;
  const sha = commitSha ?? branchCommitSha;
  if (sha) {
    ({ commit } = await loadOrCreateCommit(project, sha, !!branchCommitSha));
    if (!commit) {
      throw new Error(`Commit not found for sha: ${sha}`);
    }
  }

  const sqs = new SQSClient({});
  const enqueuedAnalyses = new Set<string>();
  const inFlight = new Set<string>();
  let firstLoop = true;
  let queueInfo: QueueInfo | null = null;
  let taskArns: string[] = [];
  let healthCheckInterval: NodeJS.Timeout | undefined;
  let isDraining = false;
  let shouldShutdown = false;
  let isDbStale = false;
  let lastAnalysisTime = Date.now();
  let lastProgressTime = Date.now();
  let previousCapturedCount = 0;
  const knownAnalyses = new Set<string>();
  let allReadyAnalysisIds: string[] = [];

  // New tracking variables for retry logic
  const attemptCount = new Map<string, number>();
  const maxAttempts = 2;

  // Function to categorize analyses based on enqueueing and processing state
  function categorizeAnalyses(
    analysesData: ReadyAnalysisData[],
    enqueuedAnalyses: Set<string>,
    inFlight: Set<string>,
    attemptCount: Map<string, number>,
    maxAttempts: number,
  ) {
    const remaining: string[] = [];
    const toRetry: string[] = [];
    const abandoned: string[] = [];

    for (const analysisData of analysesData) {
      const hasBeenEnqueued = enqueuedAnalyses.has(analysisData.id);
      const isInFlight = inFlight.has(analysisData.id);
      const attempts = attemptCount.get(analysisData.id) || 0;

      if (!hasBeenEnqueued) {
        remaining.push(analysisData.id);
      } else if (isInFlight) {
        // Don't re-enqueue - still being processed by worker
      } else if (attempts < maxAttempts) {
        toRetry.push(analysisData.id);
      } else {
        abandoned.push(analysisData.id);
      }
    }

    return { remaining, toRetry, abandoned };
  }

  // Set up control message handling
  if (controlCallback) {
    controlCallback((message: ControlMessage) => {
      if (message === 'drain') {
        console.log('CodeYam Capture: Received drain signal from upstream');
        isDraining = true;
      } else if (message === 'shutdown') {
        console.log(
          'CodeYam Capture: Received shutdown signal, terminating immediately',
        );
        shouldShutdown = true;
      }
    });
  }

  try {
    // TODO: don't rely on Date.now() for queue name
    const now = Date.now();
    const workQueueName = `codeyam-capture-work-${projectSlug}-${now}`;
    const workQueueResponse = await sqs.send(
      new CreateQueueCommand({
        QueueName: workQueueName,
        Attributes: {
          MessageRetentionPeriod: '86400', // 1 day
        },
      }),
    );

    if (!workQueueResponse.QueueUrl) {
      throw new Error('Failed to create work SQS queue');
    }

    const controlQueueName = `codeyam-capture-control-${projectSlug}-${now}`;
    const controlQueueResponse = await sqs.send(
      new CreateQueueCommand({
        QueueName: controlQueueName,
        Attributes: {
          MessageRetentionPeriod: '3600', // 1 hour
        },
      }),
    );

    if (!controlQueueResponse.QueueUrl) {
      throw new Error('Failed to create control SQS queue');
    }

    queueInfo = {
      workQueueUrl: workQueueResponse.QueueUrl,
      controlQueueUrl: controlQueueResponse.QueueUrl,
    };

    console.log(
      `CodeYam Capture: Created work queue: ${queueInfo.workQueueUrl}`,
    );
    console.log(
      `CodeYam Capture: Created control queue: ${queueInfo.controlQueueUrl}`,
    );

    console.log(`CodeYam Capture: Starting ${taskCount} ECS worker tasks...`);

    // Launch tasks with runtime environment variables
    const ecsStartConfig = getEcsStartConfigForOrchestrationTask({
      SQS_QUEUE_URL: queueInfo.workQueueUrl,
      SQS_CONTROL_QUEUE_URL: queueInfo.controlQueueUrl,
      PROJECT_SLUG: projectSlug,
      FRAMEWORK: project.metadata?.framework ?? '',
      PACKAGE_MANAGER: project.metadata?.packageManager ?? '',
      ECS_CLUSTER: process.env.ECS_CLUSTER ?? '',
    });

    const taskPromises = Array(taskCount)
      .fill(null)
      .map(() => ecsStartTask(ecsStartConfig));
    taskArns = await Promise.all(taskPromises);

    if (commit) {
      commit.metadata = await updateCommitMetadata({
        commitId: commit.id,
        runStatusUpdate: {
          captureTaskArns: taskArns,
        },
      });
    }

    console.log(
      `CodeYam Capture: Successfully started ${taskCount} ECS worker tasks`,
    );

    // Start task health check loop
    // eslint-disable-next-line @typescript-eslint/no-misused-promises
    healthCheckInterval = setInterval(async () => {
      if (isDraining) return;

      let runningTasks = 0;
      for (const arn of taskArns) {
        const status = await ecsCheckTaskStatus(arn, true);
        if (status && status !== 'STOPPED') {
          runningTasks++;
        } else {
          console.warn(`CodeYam Capture: Task ${arn} has stopped.`);
        }
      }

      if (runningTasks === 0) {
        throw new Error('All ECS tasks have stopped. Aborting orchestration.');
      }
    }, TASK_HEALTH_CHECK_INTERVAL);

    while (true) {
      // check for shutdown signal first
      if (shouldShutdown) {
        console.log('CodeYam Capture: Shutdown requested, exiting immediately');
        break;
      }

      // Process control queue messages (batch completion notifications)
      try {
        const controlResponse = await sqs.send(
          new ReceiveMessageCommand({
            QueueUrl: queueInfo.controlQueueUrl,
            MaxNumberOfMessages: 10,
            WaitTimeSeconds: 1,
            VisibilityTimeout: 60,
          }),
        );

        if (controlResponse.Messages && controlResponse.Messages.length > 0) {
          for (const message of controlResponse.Messages) {
            try {
              const body = JSON.parse(message.Body || '');
              if (
                body.type === 'batch_completed' &&
                body.analysisIds &&
                Array.isArray(body.analysisIds)
              ) {
                console.log(
                  `CodeYam Capture: Received batch completion for ${body.analysisIds.length} analyses: ${body.analysisIds.join(', ')}`,
                );

                // Remove from inFlight and increment attempt count for each analysis
                for (const analysisId of body.analysisIds) {
                  inFlight.delete(analysisId);
                  attemptCount.set(
                    analysisId,
                    (attemptCount.get(analysisId) || 0) + 1,
                  );
                }
              }

              // Delete the processed message
              await sqs.send(
                new DeleteMessageCommand({
                  QueueUrl: queueInfo.controlQueueUrl,
                  ReceiptHandle: message.ReceiptHandle!,
                }),
              );
            } catch (parseError) {
              console.warn(
                'CodeYam Capture: Failed to parse control message:',
                parseError,
              );
            }
          }
        }
      } catch (controlError) {
        // Log but don't fail the main loop for control queue errors
        console.warn(
          'CodeYam Capture: Error processing control queue:',
          controlError,
        );
      }

      const readyAnalysesData = await getReadyToBeCapturedAnalyses();

      if (readyAnalysesData === null) {
        // DB error occurred - set stale flag and continue with existing data
        isDbStale = true;
      } else {
        // DB query succeeded - clear stale flag and update data
        isDbStale = false;
        allReadyAnalysisIds = readyAnalysesData.map((analysis) => analysis.id);
      }

      // we track all analyses we've ever seen
      for (const id of allReadyAnalysisIds) {
        // DEV TODO: leave for a while, still debugging
        // if (!knownAnalyses.has(id)) {
        //   console.log(`Codeyam Debug: New Analysis ${id} (type: ${typeof id})`);
        // }
        knownAnalyses.add(id);
      }

      // an analysis we've seen, but is no longer "ready to be captured", is captured!
      const capturedAnalysisIds = Array.from(knownAnalyses).filter(
        (id) => !allReadyAnalysisIds.includes(id),
      );

      // Remove captured analyses from inFlight tracking
      for (const capturedId of capturedAnalysisIds) {
        inFlight.delete(capturedId);
      }

      // track progress
      if (capturedAnalysisIds.length > previousCapturedCount) {
        lastProgressTime = Date.now();
        previousCapturedCount = capturedAnalysisIds.length;
      }

      // Categorize current ready analyses using retry logic
      let remaining: string[] = [];
      let toRetry: string[] = [];
      let abandoned: string[] = [];

      if (!isDbStale && readyAnalysesData) {
        const categorization = categorizeAnalyses(
          readyAnalysesData,
          enqueuedAnalyses,
          inFlight,
          attemptCount,
          maxAttempts,
        );
        remaining = categorization.remaining;
        toRetry = categorization.toRetry;
        abandoned = categorization.abandoned;
      }

      // Determine what to enqueue - with new approach, remaining are never enqueued, toRetry are always eligible
      const allToEnqueue = [...remaining, ...toRetry];

      if (allToEnqueue.length > 0) {
        lastAnalysisTime = Date.now();

        if (isDraining) {
          console.log(
            `CodeYam Capture: Note - ${allToEnqueue.length} analyses became ready during drain phase (${remaining.length} remaining, ${toRetry.length} retries):`,
            allToEnqueue,
          );
        }
      }

      // Batch analyses to enqueue by commitId/branchCommitSha
      // Only proceed with batching if we have fresh data (not stale)
      const analysesToEnqueueData =
        !isDbStale && readyAnalysesData
          ? readyAnalysesData.filter((analysis) =>
              allToEnqueue.includes(analysis.id),
            )
          : [];

      // Group analyses to enqueue by commitId or branchCommitSha
      const groups = new Map<string, string[]>();

      for (const analysis of analysesToEnqueueData) {
        // Use commitId if available, otherwise branchCommitSha
        const groupKey =
          analysis.commit_id || analysis.branch_commit_sha || 'unknown';

        if (!groups.has(groupKey)) {
          groups.set(groupKey, []);
        }

        groups.get(groupKey)!.push(analysis.id);
      }

      // Convert groups to batched arrays
      const batchesToEnqueue: string[][] = [];

      for (const [, analysisIds] of groups) {
        // Split each group into batches of MAX_BATCH_SIZE
        for (let i = 0; i < analysisIds.length; i += MAX_BATCH_SIZE) {
          const batch = analysisIds.slice(i, i + MAX_BATCH_SIZE);
          batchesToEnqueue.push(batch);
        }
      }

      if (!isDraining && Date.now() - lastAnalysisTime > ANALYSIS_TIMEOUT) {
        console.log(
          'CodeYam Capture: No new analyses for 20 minutes. Beginning queue drain.',
        );
        isDraining = true;
      }

      // First loop messaging
      if (firstLoop && !isDraining) {
        if (allToEnqueue.length === 0) {
          console.log(
            'CodeYam Capture: Prepared to capture analyses as they become ready.',
          );
        } else {
          console.log(
            `CodeYam Capture: On orchestration startup, enqueueing ${allToEnqueue.length} readyToBeCaptured analyses (${remaining.length} remaining, ${toRetry.length} retries) in ${batchesToEnqueue.length} batches.`,
          );
        }
      }

      // enqueue any new work, even if we're "draining"
      for (const batch of batchesToEnqueue) {
        await sqsSendMessage(
          sqs,
          queueInfo.workQueueUrl,
          { type: 'work_items', analysisIds: batch },
          1200, // 20 minutes
        );
        // Update tracking: mark all analyses as enqueued and in flight
        for (const id of batch) {
          enqueuedAnalyses.add(id);
          inFlight.add(id);
        }
      }

      // Get queue stats
      const stats = await sqsGetQueueSizeStats(sqs, queueInfo.workQueueUrl);

      if (!firstLoop) {
        const drainIndicator = isDraining ? '[DRAINING] ' : '';
        const staleIndicator = isDbStale ? '[DB STALE] ' : '';
        const phaseIndicator = `${drainIndicator}${staleIndicator}`;
        console.log(
          `CodeYam Capture: ${phaseIndicator}Status - ${knownAnalyses.size} total analyses, ${capturedAnalysisIds.length} captured, ${abandoned.length} abandoned, ${remaining.length} remaining, ${toRetry.length} to retry, ${inFlight.size} in flight | ${stats.inflight} batches in SQS, ${stats.unreceived} waiting`,
        );
        // DEV TODO: leave for a while, still debugging
        // console.log(
        //   `Codeyam Debug: All known analyses: ${Array.from(knownAnalyses).join(', ')}`,
        // );
        if (commit) {
          commit.metadata = await updateCommitMetadata({
            commitId: commit.id,
            runStatusUpdate: {
              readyToBeCaptured: knownAnalyses.size,
              capturesAttempted: capturedAnalysisIds.length + abandoned.length,
              capturesCompleted: capturedAnalysisIds.length,
            },
          });
        }
      }

      if (isDraining) {
        // Only check for completion when no work is in flight
        if (inFlight.size === 0) {
          // check if all enqueued analyses have been either captured or abandoned
          const allAnalysesSettled = Array.from(enqueuedAnalyses).every(
            (id) => {
              const captured = !allReadyAnalysisIds.includes(id);
              const abandoned = (attemptCount.get(id) || 0) >= maxAttempts;
              return captured || abandoned;
            },
          );

          if (allAnalysesSettled) {
            console.log(
              'CodeYam Capture: All analyses either captured or abandoned, cleaning up',
            );
            break;
          }
        }

        if (Date.now() - lastProgressTime > PROGRESS_WINDOW) {
          console.log(
            'CodeYam Capture: No progress detected for 30 minutes while draining, stopping remaining tasks',
          );
          break;
        }

        if (taskCount > 0) {
          const taskStatuses = await Promise.all(
            taskArns.map((arn) => ecsCheckTaskStatus(arn, true)),
          );
          const allTasksStopped = taskStatuses.every(
            (status) => !status || status === 'STOPPED',
          );
          if (allTasksStopped) {
            console.log('CodeYam Capture: All tasks have completed');
            break;
          }
        }
      }

      firstLoop = false;
      await new Promise((resolve) => setTimeout(resolve, POLLING_INTERVAL));
    }
  } catch (error) {
    console.log(
      'CodeYam Error: An error occurred in orchestrateCapture:',
      error,
    );
  } finally {
    // Always clean up resources in finally block
    if (healthCheckInterval) {
      clearInterval(healthCheckInterval);
      healthCheckInterval = undefined;
    }

    if (queueInfo) {
      try {
        // note: this serves as a signal to the ECS tasks to gracefully exit
        console.log(
          `CodeYam Capture: Deleting work queue: ${queueInfo.workQueueUrl}`,
        );
        await sqs.send(
          new DeleteQueueCommand({
            QueueUrl: queueInfo.workQueueUrl,
          }),
        );

        console.log(
          `CodeYam Capture: Deleting control queue: ${queueInfo.controlQueueUrl}`,
        );
        await sqs.send(
          new DeleteQueueCommand({
            QueueUrl: queueInfo.controlQueueUrl,
          }),
        );

        console.log('CodeYam Capture: Successfully deleted SQS queues');
      } catch (error) {
        console.log('CodeYam Capture: Error deleting SQS queues:', error);
      }
    }
  }

  async function getReadyToBeCapturedAnalyses() {
    const args = {
      projectid: project.id,
    };
    if (analysisIds) {
      args['analysisids'] = analysisIds;
    }
    if (commitSha) {
      args['commitids'] = commit.id;
    }
    if (entityShas) {
      args['entityshas'] = entityShas;
    }
    if (branchCommitSha) {
      args['branchcommitsha'] = branchCommitSha;
    }

    const pageSize = 1000;
    const allData: ReadyAnalysisData[] = [];
    let pageOffset = 0;

    while (true) {
      const query = getSupabase()
        .rpc('get_ready_to_be_captured_analyses', args)
        .select(
          'id, commit_id, branch_commit_sha, status->processingForCaptureAt',
        )
        .range(pageOffset, pageOffset + pageSize - 1)
        .returns<ReadyAnalysisData[]>();

      const { data, error } = await query;

      if (error) {
        console.error(
          'CodeYam Capture: Error: Failed to load readyToBeCaptured analyses',
          args,
          error,
        );
        return null;
      }

      if (!data || data.length === 0) {
        break;
      }

      allData.push(...data);

      if (data.length < pageSize) {
        break;
      }

      pageOffset += pageSize;
    }

    return allData;
  }
}
