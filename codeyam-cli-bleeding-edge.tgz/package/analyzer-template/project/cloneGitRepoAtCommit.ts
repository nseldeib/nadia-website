import * as fs from 'fs';
import simpleGit, { SimpleGit } from 'simple-git';

export default async function cloneGitRepoAtCommit({
  repoUrl,
  localPath,
  commitShaOrBranchName,
  gitToken,
}: {
  repoUrl: string;
  localPath: string;
  commitShaOrBranchName?: string;
  gitToken: string;
}): Promise<void> {
  console.log('commitShaOrBranchName :>> ', commitShaOrBranchName);
  // Ensure the local path directory exists
  fs.mkdirSync(localPath, { recursive: true });

  // Initialize simple-git with the correct local path
  const git: SimpleGit = simpleGit(localPath);

  try {
    // Modify the repository URL to include the authentication token
    if (!gitToken) {
      console.log('Git token is not provided.');
      return;
    }
    const authRepoUrl = repoUrl.replace('https://', `https://x-access-token:${gitToken}@`);

    // Clone the repository to the specified local path

    // COMMENTED OUT AS IT IS NOT WORKING FOR SPECIFIC COMMITS
    // await git.clone(authRepoUrl, '.', ["--no-single-branch", "--depth", "1"]); // Clone into the current working directory of the simple-git instance
    console.log("CodeYam: Cloning repo", localPath)
    await git.clone(authRepoUrl, '.');
    
    // If there's no commit SHA or branch name provided, we're done because we cloned the latest commit (main branch)
    if (commitShaOrBranchName) {
      // Checkout the specific commit
      await git.checkout(commitShaOrBranchName);
      console.log(`Checked out commit sha or branch ${commitShaOrBranchName}`);
    }
  } catch (error) {
    console.log('cloneGitRepoAtCommit failed:', error);
  }
}
