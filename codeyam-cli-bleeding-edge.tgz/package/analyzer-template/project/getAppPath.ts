import { Project, ProjectFramework } from '~codeyam/types';
import { PROJECT_RELATIVE_PATH } from '~codeyam/utils';

export default function getAppPath(
  project: Project,
  framework: ProjectFramework,
  relative?: boolean,
) {
  let appPath = '';
  switch (framework) {
    case ProjectFramework.Remix:
    case ProjectFramework.CRA:
    case ProjectFramework.Next:
      const nextAppFolder = project.metadata?.appDirectory ?? 'app';
      appPath = relative
        ? nextAppFolder
        : `${PROJECT_RELATIVE_PATH}/${nextAppFolder}`;
      break;
    case ProjectFramework.NextPages:
      const nextAppPagesFolder = project.metadata?.appDirectory ?? 'pages';
      appPath = relative
        ? nextAppPagesFolder
        : `${PROJECT_RELATIVE_PATH}/${nextAppPagesFolder}`;
      break;
    case ProjectFramework.CodeYam:
      const codeyamAppFolder = 'dashboard/app';
      appPath = relative
        ? codeyamAppFolder
        : `${PROJECT_RELATIVE_PATH}/${codeyamAppFolder}`;
      break;
    default:
      break;
  }
  return appPath;
}
