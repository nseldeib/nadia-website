import {
  ProjectAnalyzer,
  AnalysisContext,
  analyzeEntities,
  findOrCreateEntity,
  gatherEntityMap,
} from '~codeyam/analyze';
import { Commit, Entity, Project } from '~codeyam/types';

interface AnalyzeAndGatherIndirectEntitiesArgs {
  entities: Entity[];
  project: Project;
  projectAnalyzer: ProjectAnalyzer;
  commit: Commit;
  context: AnalysisContext;
  steps: string[];
}

export default async function analyzeAndGatherIndirectEntities({
  entities,
  project,
  projectAnalyzer,
  commit,
  context,
  steps,
}: AnalyzeAndGatherIndirectEntitiesArgs) {
  const indirectEntities: Entity[] = [];

  for (const entity of entities) {
    if (!['visual', 'library'].includes(entity.entityType)) continue;

    if (!entity.metadata.importedBy) {
      continue;
    }

    for (const path of Object.keys(entity.metadata.importedBy)) {
      for (const entityName of Object.keys(entity.metadata.importedBy[path])) {
        const importedFile = project.files.find((f) => f.path === path);

        if (!importedFile) {
          console.log(`CodeYam Warning: Imported by file not found: ${path}`);
          continue;
        }

        const importedFileAnalyzer =
          projectAnalyzer.getFileAnalyzer(importedFile);

        console.log('CodeYam: Initial indirect entity', path, entityName);
        const importedBy = await findOrCreateEntity({
          file: importedFile,
          commitId: commit.id,
          branchId: commit.branchId,
          fileAnalyzer: importedFileAnalyzer,
          entityName,
          projectAnalyzer,
          context,
        });

        if (!importedBy) {
          console.log(`CodeYam Warning: Imported by entity not found: ${path}`);
          continue;
        }

        context.addEntity(importedBy);
        indirectEntities.push(importedBy);

        await gatherEntityMap({
          entity: importedBy,
          commitId: commit.id,
          branchId: commit.branchId,
          context,
          projectAnalyzer,
        });
      }
    }
  }

  console.log(
    `CodeYam: analyzeAndGatherIndirectEntities: Analyzing ${indirectEntities.length} indirect imports of ${entities.length} entities`,
  );

  await analyzeEntities({
    rootEntities: indirectEntities,
    context,
    project,
    projectAnalyzer,
    commit,
    options: {
      steps,
      force: !!process.env.FORCE,
      forceAll: !!process.env.FORCE_ALL,
    },
  });

  for (const entity of entities) {
    if (!['visual', 'library'].includes(entity.entityType)) continue;

    if (!entity.metadata.importedBy) {
      continue;
    }

    for (const path of Object.keys(entity.metadata.importedBy)) {
      for (const entityName of Object.keys(entity.metadata.importedBy[path])) {
        const analysis = context.getAnalysis(path, entityName);
        if (!analysis) continue;

        const newEntity = context.getMutableEntity(path, entityName);
        if (!newEntity) continue;

        if (entities.findIndex((e) => e.sha === newEntity.sha) === -1) {
          entities.push(newEntity);
        }
      }
    }
  }

  return {
    entities,
  };
}
