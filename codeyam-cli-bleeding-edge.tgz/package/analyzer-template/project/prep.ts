import {
  loadAnalyses,
  loadAnalysis,
  loadAnalysisBranches,
  loadBackgroundJob,
  loadCommit,
  loadEntities,
  loadEntity,
  loadProject,
  loadScenario,
  updateBackgroundJobProgress,
  updateCommitMetadata,
  updateProjectMetadata,
  upsertAnalysesWithScenarios,
  upsertAnalysisBranches,
} from '~codeyam/supabase';

import * as dotenv from 'dotenv';
import { AnalysisContext, ProjectAnalyzer } from '~codeyam/analyze';
import {
  Analysis,
  BackgroundJob,
  Commit,
  Entity,
  ProjectFramework,
} from '~codeyam/types';
import measureAndReportExecutionTime from '../common/measureAndRepordExecutionTime';
import {
  loadOrCreateCommit,
  syncHeadBranches,
  syncPrimaryBranch,
} from '~codeyam/github';
import updateCommitBackgroundJob from './updateCommitBackgroundJob';
import prepareRepo from './prepareRepo';
import loadReadyToBeCaptured from './loadReadyToBeCaptured';
import analyzeBranchCommit from './analyzeBranchCommit';
import analyzeFileEntities from './analyzeFileEntities';
import analyzeAndGatherIndirectEntities from './analyzeAndGatherIndirectEntities';
import getFilesWithEntitiesFromRepo from './getFilesWithEntitiesFromRepo';
import { checkConsistentAnalyses as checkConsistentAnalyses } from './checkConsistentAnalyses';
import { checkConsistentEntities as checkConsistentEntities } from './checkConsistentEntities';
import { Controller } from './controller/startController';
import { awsLog } from '~codeyam/utils';

dotenv.config();

export interface PrepArgs {
  steps?: string[];
  controller?: Controller;
  absoluteProjectRootPath: string;
  absoluteTempPath?: string;
  analyzeMockName?: string;
  packageManager: string;
  framework: ProjectFramework;
  fast?: boolean;
}

async function entitiesReadyToBeCaptured(
  entities: Entity[],
  entityShas: string[],
  context: AnalysisContext,
  analysisIds: string[],
) {
  const readyToBeCaptured: Analysis[] = [];
  for (const entity of entities) {
    let analysis = context.getAnalysis(
      entity.filePath,
      entity.name,
    ) as Analysis;
    if (
      !analysis?.status?.readyToBeCaptured &&
      !analysisIds?.includes(analysis.id)
    )
      continue;

    // Due to circular dependencies, double check if any indirect entities are not properly labeled
    if (!entityShas?.includes(entity.sha) && !analysis.indirect) {
      analysis.indirect = true;
      analysis = (
        await upsertAnalysesWithScenarios({
          analysesToUpsert: [analysis],
        })
      )[0];

      context.addAnalysis(analysis, entity.filePath, entity.name);
    }

    analysis.entity = entity;
    readyToBeCaptured.push(analysis);
  }

  return readyToBeCaptured;
}

export default async function prep({
  steps,
  controller,
  absoluteProjectRootPath,
  absoluteTempPath,
  analyzeMockName,
  packageManager,
  framework,
  fast,
}: PrepArgs) {
  awsLog('CodeYam: Prep Args', {
    steps,
    absoluteProjectRootPath,
    analyzeMockName,
    framework,
  });
  awsLog(
    `CodeYam: Prep ENV commitId: ${process.env.COMMIT_ID} - analysisIds: ${process.env.ANALYSIS_IDS} - scenarioIds: ${process.env.SCENARIO_IDS}`,
    {
      PROJECT_SLUG: process.env.PROJECT_SLUG,
      ENTITY_SHAS: process.env.ENTITY_SHAS,
      COMMIT_SHA: process.env.COMMIT_SHA,
      BRANCH_COMMIT_SHA: process.env.BRANCH_COMMIT_SHA,
      ANALYSIS_IDS: process.env.ANALYSIS_IDS,
      SCENARIO_IDS: process.env.SCENARIO_IDS,
      BRANCH_NAME: process.env.BRANCH_NAME,
      READY_TO_BE_CAPTURED: process.env.READY_TO_BE_CAPTURED,
      COMMIT_ID: process.env.COMMIT_ID,
      FRESH: process.env.FRESH,
      FORCE: process.env.FORCE,
      FORCE_ALL: process.env.FORCE_ALL,
      CODEYAM_LOCAL_PROJECT_PATH: process.env.CODEYAM_LOCAL_PROJECT_PATH,
    },
  );

  try {
    const stepName = 'analyze-files';
    let backgroundJob: BackgroundJob | undefined;
    if (process.env.COMMIT_ID) {
      backgroundJob = await loadBackgroundJob({
        commitId: process.env.COMMIT_ID,
      });
      if (backgroundJob) {
        await updateCommitBackgroundJob(backgroundJob, stepName);
      }
    }

    const projectSlug = process.env.PROJECT_SLUG;
    const project = await loadProject({
      slug: projectSlug,
      withBranches: true,
      withFiles: true,
    });

    if (!project.branches || project.branches.length === 0) {
      project.branches = await syncHeadBranches({
        project,
        commitSha: process.env.BRANCH_COMMIT_SHA ?? process.env.COMMIT_SHA,
      });
    }

    const isLocalMode = !!process.env.CODEYAM_LOCAL_PROJECT_PATH;

    if (!isLocalMode) {
      // ensure branches are up to date with github, unless in local mode
      const branchesAfterPrimarySync = await syncPrimaryBranch({
        project,
      });
      if (branchesAfterPrimarySync) {
        project.branches = branchesAfterPrimarySync;
      }
    }
    const runReadyToBeCapturedPath = !!process.env.READY_TO_BE_CAPTURED;
    let commit: Commit | null = process.env.COMMIT_SHA
      ? (await loadOrCreateCommit(project, process.env.COMMIT_SHA))?.commit
      : null;
    let branchCommit: Commit | null = process.env.BRANCH_COMMIT_SHA
      ? (await loadOrCreateCommit(project, process.env.BRANCH_COMMIT_SHA, true))
          ?.commit
      : null;
    const runBranchCommitPath = !!branchCommit;

    let entityShas = process.env.ENTITY_SHAS
      ? process.env.ENTITY_SHAS.split(',')
      : undefined;
    let analysisIds = process.env.ANALYSIS_IDS
      ? process.env.ANALYSIS_IDS.split(',')
      : undefined;
    const scenarioIds = process.env.SCENARIO_IDS?.split(',');

    if (
      !scenarioIds &&
      !analysisIds &&
      !branchCommit &&
      !project.metadata?.baselineCompleted &&
      !process.env.FORCE &&
      // The CodeYam CLI bet: we can do without the baseline, in local mode
      !isLocalMode
    ) {
      awsLog('CodeYam Error: Project baseline is not yet completed', {
        projectPath: project.path,
        projectSlug,
      });
      return {};
    }

    if (
      !scenarioIds &&
      !analysisIds &&
      !entityShas &&
      !commit &&
      !runBranchCommitPath &&
      !runReadyToBeCapturedPath
    ) {
      awsLog(
        'CodeYam Error: must provide SCENARIO_IDS, ANALYSIS_IDS or ENTITY_SHAS or COMMIT_SHA or BRANCH_COMMIT_SHA or READY_TO_BE_CAPTURED',
        process.env.ANALYSIS_IDS,
        process.env.ENTITY_SHAS,
        process.env.COMMIT_SHA,
        process.env.BRANCH_COMMIT_SHA,
        process.env.READY_TO_BE_CAPTURED,
      );
      throw new Error(
        'No ANALYSIS_IDS or ENTITY_SHAS or COMMIT_SHA or BRANCH_COMMIT_SHA or READY_TO_BE_CAPTURED found',
      );
    }

    let branch = commit?.branch ?? branchCommit?.branch;

    if (!branch) {
      if (process.env.BRANCH_NAME) {
        branch = project.branches.find(
          (b) => b.name === process.env.BRANCH_NAME,
        );
      }
    }

    let desiredAnalyses: Analysis[] = [];
    if (!branch) {
      if (entityShas && entityShas.length > 0) {
        let entity = null;
        if (analyzeMockName) {
          // skip consistency checks when running in mocked mode
          entity = await loadEntity({
            projectId: project.id,
            sha: entityShas[0],
          });
        } else {
          // otherwise load all entities to validate they're from the same commit
          const entities = await loadEntities({
            projectId: project.id,
            shas: entityShas,
          });
          entity = checkConsistentEntities(entities);
        }
        if (entity?.commitId) {
          commit = await loadCommit({
            projectId: project.id,
            id: entity.commitId,
          });
          branch = commit?.branch;
        }
      } else if (
        (scenarioIds && scenarioIds.length > 0) ||
        (analysisIds && analysisIds.length > 0)
      ) {
        let analysis: Analysis;
        if (analyzeMockName) {
          // skip consistency checks when running in mocked mode
          analysis = await loadAnalysis({
            projectId: project.id,
            id: analysisIds[0],
          });
        } else if (!analysisIds && scenarioIds && scenarioIds.length > 0) {
          const scenario = await loadScenario({
            projectId: project.id,
            id: scenarioIds[0],
          });

          desiredAnalyses = await loadAnalyses({
            projectId: project.id,
            ids: [scenario.analysisId],
          });

          analysis = checkConsistentAnalyses(desiredAnalyses);
          analysisIds = [analysis.id];
        } else {
          // otherwise load all analyses to validate they're from the same commit/branch
          desiredAnalyses = await loadAnalyses({
            projectId: project.id,
            ids: analysisIds,
          });

          analysis = checkConsistentAnalyses(desiredAnalyses);
        }
        if (analysis?.commitId) {
          commit = await loadCommit({
            projectId: project.id,
            id: analysis.commitId,
          });
          branch = commit?.branch;
        } else if (analysis?.branchCommitSha) {
          branchCommit = await loadCommit({
            projectId: project.id,
            sha: analysis.branchCommitSha,
          });
          branch = branchCommit?.branch;
        }
      }
    }

    if (!branch) {
      branch = project.branches.find((b) => b.primary);
      awsLog('CodeYam Error: Branch not found, assuming primary branch', {
        commitBranch: commit?.branch,
        branchCommitBranch: branchCommit?.branch,
        entityShas,
        branchName: branch?.name,
      });
    }

    // after this block, 'commit' is the union of a regular or baseline commit,
    // and is guaranteed non-null. branchCommit itself remains non-null when
    // and only when it was specifically requested via $BRANCH_COMMIT_SHA
    commit ??= branchCommit;
    if (!commit) {
      commit = await loadCommit({
        projectId: project.id,
        branchId: branch.id,
      });
      // this is actually fine now, leaving it as a reminder since it's a recent change
      if (!commit) {
        console.log(
          `CodeYam Warning: No fallback commit found for project ${project.slug} on branch ${branch.name}`,
        );
      }
    }

    if (!fast) {
      controller?.setRepoCheckoutPhase();

      await prepareRepo({
        absoluteProjectRootPath,
        absoluteTempPath,
        commit,
        branch,
        project,
        packageManager,
        framework,
      });
    }

    const { result: projectAnalyzer } = await measureAndReportExecutionTime(
      () => ProjectAnalyzer.from({ project, dirPath: absoluteProjectRootPath }),
      'Created the ProjectAnalyzer',
    );

    project.files = await getFilesWithEntitiesFromRepo({
      project,
      projectAnalyzer,
    });

    if (!commit) {
      commit = await loadCommit({
        projectId: project.id,
        branchId: branch.id,
      });
    }

    if (commit) {
      // mark the start of the analysis phase
      const ecsTaskArn = process.env.CODEYAM_ECS_TASK_ARN;
      commit.metadata = await updateCommitMetadata({
        commitId: commit.id,
        updateCallback: (metadata) => {
          if (!runReadyToBeCapturedPath) {
            // the readyToBeCaptured path is read-only in terms of analysis
            metadata.startedAnalyzingAt = new Date().toISOString();
          }

          // $CODEYAM_ECS_TASK_ARN is set in src/lib/configs/aws/entrypoint.sh
          // whenever this code executes within an ECS task
          if (ecsTaskArn && metadata.currentRun) {
            metadata.currentRun.analyzeTaskArns ??= [];
            metadata.currentRun.analyzeTaskArns.push(ecsTaskArn);
          }
        },
      });
    }

    controller?.setAnalysisPhase();

    let entities: Entity[] = [];

    // Create a single context for the entire analysis process that will maintain all entity and analysis state
    const context = new AnalysisContext();

    if (runReadyToBeCapturedPath) {
      awsLog('CodeYam: Prep - readyToBeCaptured path');
      const { readyToBeCaptured: loadedReadyToBeCaptured } =
        await loadReadyToBeCaptured({
          project,
          branchCommitSha: branchCommit?.sha,
          analysisIds,
          context,
        });

      if (!loadedReadyToBeCaptured || loadedReadyToBeCaptured.length === 0) {
        awsLog('No analyses ready to be captured, exiting');
        process.exit(0);
      }

      // We already have the ready-to-be-captured analyses, so we can return early
      return {
        projectAnalyzer,
        readyToBeCaptured: loadedReadyToBeCaptured,
        context,
      };
    } // readyToBeCapturedPath COMPLETE

    if (runBranchCommitPath) {
      awsLog('CodeYam: Prep - branchCommit path', {
        analysisIds: process.env.ANALYSIS_IDS,
      });
      if (
        project.metadata?.baselineCompleted &&
        !analysisIds &&
        !process.env.FORCE
      ) {
        throw new Error(
          'CodeYam Error: Cannot analyze branch commits after baseline is completed',
        );
      }

      const { entities: branchEntities } = await analyzeBranchCommit({
        project,
        projectAnalyzer,
        branchCommit,
        analysisIds,
        context,
        steps,
      });
      entities = branchEntities;

      const primaryBranchId = project.branches.find((b) => b.primary)?.id;

      // Use context to get the analysisMap
      let analysisBranches = Object.values(context.getAnalysisMap())
        .flatMap((a) => Object.values(a))
        .map((a) => ({
          branchId: primaryBranchId,
          entitySha: a.entitySha,
          analysisId: a.id,
          active: true,
        }));

      const existingAnalysisBranches = await loadAnalysisBranches({
        projectId: project.id,
        branchId: primaryBranchId,
        analysisIds: analysisBranches.map((a) => a.analysisId).filter(Boolean),
      });

      analysisBranches = analysisBranches.filter(
        (a) =>
          a.analysisId &&
          !existingAnalysisBranches.find(
            (ab) => ab.analysisId === a.analysisId,
          ),
      );

      await upsertAnalysisBranches(analysisBranches);

      const now = new Date().toISOString();
      branchCommit.metadata = await updateCommitMetadata({
        commitId: branchCommit.id,
        runStatusUpdate: {
          analysisCompletedAt: now,
        },
        metadataUpdate: {
          entitiesAnalyzedAt: now,
        },
      });

      awsLog(`CodeYam: Marking baseline completed for project ${project.slug}`);

      // configure project metadata with baseline info
      project.metadata = await updateProjectMetadata({
        projectId: project.id,
        metadataUpdate: {
          baselineCompleted: true,
          // but the worker won't submit new commits until `readyForCommits` is true as well
        },
      });

      const readyToBeCaptured: Analysis[] = Object.values(
        context.getAnalysisMap(),
      )
        .flatMap(Object.values)
        .filter((analysis) => {
          if (analysisIds) {
            return analysisIds.includes(analysis.id);
          }

          if (scenarioIds) {
            return analysis.scenarios?.some((s) => scenarioIds.includes(s.id));
          }

          return analysis.status.readyToBeCaptured;
        });

      if (analysisIds || scenarioIds) {
        if ((analysisIds || scenarioIds) && readyToBeCaptured.length === 0) {
          awsLog(
            `CodeYam: branchCommit path complete with specified analysisIds but no analyses ready to be captured...`,
            {
              analysisIds,
              scenarioIds,
              desiredAnalyses: desiredAnalyses.map((a) => ({
                id: a.id,
                filePath: a.filePath,
                entityName: a.entityName,
              })),
              allAnalyses: Object.keys(context.getAnalysisMap())
                .filter(
                  (filePath) =>
                    desiredAnalyses.length === 0 ||
                    desiredAnalyses.some((a) => a.filePath === filePath),
                )
                .flatMap((filePath) =>
                  Object.keys(context.getAnalysisMap()[filePath] || {})
                    .filter(
                      (entityName) =>
                        desiredAnalyses.length === 0 ||
                        desiredAnalyses.some(
                          (a) =>
                            a.filePath === filePath &&
                            a.entityName === entityName,
                        ),
                    )
                    .flatMap((entityName) => {
                      const analysis =
                        context.getAnalysisMap()[filePath][entityName];
                      return {
                        id: analysis.id,
                        filePath,
                        entityName,
                        readyToBeCaptured: analysis.status.readyToBeCaptured,
                      };
                    }),
                ),
            },
          );
          await new Promise((resolve) => setTimeout(resolve, 1000));
          throw new Error(
            `CodeYam Error: No analyses ready to be captured for the specified analysisIds or scenarioIds: ${analysisIds} or ${scenarioIds}`,
          );
        }
      } else {
        awsLog(
          `CodeYam: branchCommit path complete, ${readyToBeCaptured.length} analyses ready to be captured! Exiting...`,
        );
      }
      return {
        projectAnalyzer,
        readyToBeCaptured,
        context,
      };
    } // branchCommit path COMPLETE

    awsLog('CodeYam: Prep - commit path');
    let fileCount: number | undefined = undefined;
    if (!entityShas || entityShas.length === 0) {
      if (analysisIds) {
        desiredAnalyses = await loadAnalyses({
          projectId: project.id,
          ids: analysisIds,
        });

        entityShas = desiredAnalyses.map((a) => a.entitySha);
      } else if (!commit) {
        throw new Error('Unimplemented code path.');
      } else if (runReadyToBeCapturedPath) {
        desiredAnalyses = await loadAnalyses({
          projectId: project.id,
          commitIds: [commit.id],
        });

        entityShas = desiredAnalyses
          .filter((a) => a.status.readyToBeCaptured)
          .map((a) => a.entitySha);
      } else {
        // for commit analysis, we actually do know how many files were involved
        fileCount = commit.files.length;
        entityShas = commit.files
          .flatMap((commitFile) =>
            project.files
              .find((file) => file.path === commitFile.fileName)
              ?.entities?.map((entity) => entity.sha),
          )
          .filter(Boolean);

        const existingAnalysisBranches = await loadAnalysisBranches({
          projectId: project.id,
          branchId: branch.id,
          filePaths: commit.files.map((f) => f.fileName),
        });

        for (const existingAnalysisBranch of existingAnalysisBranches) {
          existingAnalysisBranch.active = false;
        }

        await upsertAnalysisBranches(existingAnalysisBranches);
      }
    }

    // deduplicate entity SHAs
    entityShas = Array.from(new Set(entityShas));

    if (commit) {
      const entityCount = entityShas.length;
      commit.metadata = await updateCommitMetadata({
        commitId: commit.id,
        runStatusUpdate: {
          entityCount,
          fileCount,
          filesCompleted: fileCount,
        },
      });
    }

    const { entities: fileEntities } = await analyzeFileEntities({
      project,
      projectAnalyzer,
      commit,
      branchId: branch.id,
      entityShas,
      scenarioIds,
      analyzeMockName,
      steps,
      context,
    });
    entities = fileEntities;

    if (commit) {
      if (branchCommit) {
        console.log(`CodeYam: Skipping indirect analysis for branch commit`);
      } else if (analysisIds) {
        console.log(
          `CodeYam: Skipping indirect analysis for specific analysisIds`,
        );
      } else if (isLocalMode) {
        console.log(`CodeYam: Skipping indirect analysis for local mode`);
      } else if (analyzeMockName) {
        console.log(`CodeYam: Skipping indirect analysis for mock analysis`);
      } else {
        awsLog(`CodeYam: Prep - indirect entities`);
        if (entities.length > 0) {
          const { entities: withIndirectEntities } =
            await analyzeAndGatherIndirectEntities({
              entities,
              project,
              projectAnalyzer,
              commit,
              context,
              steps,
            });

          entities = withIndirectEntities;
        }
      }
    }

    const readyToBeCaptured = await entitiesReadyToBeCaptured(
      entities,
      entityShas,
      context,
      analysisIds,
    );

    awsLog(
      'CodeYam: readyToBeCaptured',
      readyToBeCaptured.map((analysis) => ({
        path: analysis.entity.filePath,
        entityName: analysis.entity.name,
        entityType: analysis.entity.entityType,
        analysisId: analysis.id,
        scenarios: (analysis.scenarios ?? []).map((s) => s.name),
        indirect: analysis.indirect,
      })),
    );

    if (commit) {
      const now = new Date().toISOString();
      commit.metadata = await updateCommitMetadata({
        commitId: commit.id,
        runStatusUpdate: {
          analysisCompletedAt: now,
        },
        metadataUpdate: {
          entitiesAnalyzedAt: now,
        },
      });
    }

    if (backgroundJob) {
      await updateBackgroundJobProgress(backgroundJob, {
        initiated: backgroundJob.progress.initiated,
        steps: [
          {
            name: stepName,
            initiated:
              backgroundJob.progress.steps.find((s) => s.name === stepName)
                ?.initiated ?? new Date().toISOString(),
            completed: new Date().toISOString(),
          },
        ],
        completed: new Date().toISOString(),
      });
    }

    return {
      projectAnalyzer,
      readyToBeCaptured,
      context,
    };
  } catch (e) {
    awsLog('CodeYam Error: prep failed', {
      projectSlug: process.env.PROJECT_SLUG,
      entityShas: process.env.ENTITY_SHAS,
      e,
    });
    throw e;
  }
}
