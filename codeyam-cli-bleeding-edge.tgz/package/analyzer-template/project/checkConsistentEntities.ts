import assert from 'assert';
import { Entity } from '~codeyam/types';

/**
 * Assert that all entities are from the same commit, and return one of them.
 */
export function checkConsistentEntities(entities: Entity[]) {
  const entitiesWithCommit = entities.filter((entity) => entity.commitId);

  if (entitiesWithCommit.length === 0) {
    return entities[0];
  }

  // sort entities by commitId
  const groups = new Map<string, string[]>();
  for (const entity of entitiesWithCommit) {
    const commitId = entity.commitId!;

    if (!groups.has(commitId)) {
      groups.set(commitId, []);
    }
    groups.get(commitId)!.push(`${entity.filePath}:${entity.name}`);
  }

  assert(groups.size > 0);
  if (groups.size === 1) {
    // they're all from the same commit
    return entitiesWithCommit[0];
  }

  // otherwise fail helpfully
  const details = [...groups.entries()]
    .map(
      ([commitId, paths]) => `${paths.length} entities from commit ${commitId}`,
    )
    .join('\n');

  const largest = [...groups.entries()].reduce((best, current) =>
    current[1].length > best[1].length ? current : best,
  );

  const suggestion = `\nTry using only entities from commit ${
    largest[0]
  }: ${largest[1].join(', ')}`;

  throw new Error(
    `Entities must all be from the same commit. Found:\n${details}${suggestion}`,
  );
}
