import { Project } from '~codeyam/types';

export default function checkApprovedPath({ project, path }: { project: Project, path: string}) {
  const checkPathStatus = (path: string, type: 'approved' | 'unapproved') => {
    if (!path || path.length === 0) return false;

    const pathList = (type === 'approved' 
      ? project.metadata?.approvedPaths 
      : project.metadata?.unapprovedPaths
    )?.filter(Boolean)?.filter(patternPath => patternPath.length > 0);

    if (!pathList?.length) {
      return type === 'approved';
    }
  
    return pathList.some(patternPath => {
      const pathRegex = new RegExp(patternPath);
      return pathRegex.test(path);
    });
  };

  const isApproved = checkPathStatus(path, 'approved');
  const isUnapproved = checkPathStatus(path, 'unapproved');

  if (isApproved && !isUnapproved) {
    return true;
  }

  return false;
}