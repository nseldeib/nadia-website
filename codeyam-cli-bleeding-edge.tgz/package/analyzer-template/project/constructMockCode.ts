import { joinParenthesesAndArrays, splitOutsideParenthesesAndArrays, functionArguments, cleanOutBoundary } from "~codeyam/ai";
import { DataStructure, DeepReadonly } from "~codeyam/types";

interface ReturnValuePart {
  name: string;
  args?: string[][];
  isArray?: boolean;
  returnsFunctionArgs?: string[];
  returnsFunctionArray?: boolean;
  isFunction?: boolean;
  nested?: ReturnValuePart[];
  isAsyncFunction?: boolean;
  isStructural?: boolean;
}

const RETURN_VALUE = 'functionCallReturnValue'

function isFunctionCallReturnValue(key: string) {
  return key === RETURN_VALUE
}

function indent (str: string) {
  return str.split('\n').map(line => `  ${line}`).join('\n');
}

function safeString(str: string) {
  return str.replace(/"/g, "'") 
}

function cleanOutTypes(str: string) {
  return cleanOutBoundary(str, '<', '>').replace(/<>/g, '');
}

function funcArgs(functionSignature: string): string[] {
  const args = functionArguments(functionSignature);
  return args?.map(arg => safeString(arg)) ?? [];
}

// isValidKey ensures that the key does not contain any characters that would make it invalid in a JavaScript object.
// For example, it should not contain spaces, special characters, or start with a number.
function isValidKey(key: string) {
  if (!key || key.length === 0) return false;
  const keyWithOutArguments = key.split('(')[0];
  return !(/\s/.test(keyWithOutArguments))
}

export default function constructMockCode(mockName: string, dependencySchemas: DeepReadonly<DataStructure['dependencySchemas']>) {
  const mockNameParts = splitOutsideParenthesesAndArrays(mockName);
  
  let relevantReturnValueSchema: DataStructure['returnValueSchema'] | undefined;
  let dataStructurePath: string | undefined;
  let dataStructureValue: string | undefined;
  for (const filePath in dependencySchemas) {
    for (const entityName in dependencySchemas[filePath]) {
      if (entityName !== mockNameParts[0]) continue;
      dataStructurePath = Object.keys(
        dependencySchemas[filePath][entityName]?.returnValueSchema ?? {}
      ).find(
        path => {
          const pathParts = splitOutsideParenthesesAndArrays(path);
          return (
            mockNameParts.slice(0, -1).every(
              (part, index) => pathParts[index] === part
            ) &&
            pathParts[mockNameParts.length - 1].startsWith(
              mockNameParts[mockNameParts.length - 1]
            )
          )
        }
      );
      if (dataStructurePath) {
        relevantReturnValueSchema = dependencySchemas[filePath][entityName]?.returnValueSchema;
        dataStructureValue = relevantReturnValueSchema?.[dataStructurePath];
        break;
      }
    }
  }

  if (!relevantReturnValueSchema || !dataStructurePath) return;

  const dataStructureName = joinParenthesesAndArrays(
    splitOutsideParenthesesAndArrays(dataStructurePath).slice(0, mockNameParts.length)
  );

  const isFunction = dataStructureName.includes('(');
  const isRootAsyncFunction = dataStructureValue === 'async-function';

  const returnValueParts: ReturnValuePart = {
    name: dataStructureName,
  };

  if (dataStructureName.includes('(')) {
    returnValueParts.args = [funcArgs(dataStructureName)];
    returnValueParts.name = returnValueParts.name.split('(')[0];
  }

  const constructReturnValueString = (returnValue: ReturnValuePart, basePaths=['']) => {
    const root = basePaths.length === 1 && basePaths[0] === '';
    if (root) {
      basePaths[0] = "scenarios().data()"
    }

    const optionalAccess = (name, stripArguments=false) => {
      if (stripArguments && name.includes('(')) {
        name = name.split('(')[0] + '()';
      }

      if (name.match(/\[\d+\]/)) {
        return `?.${name}`;
      }

      return `?.["${name.replace(/\n/g, '\\n')}"]`;
    }

    const constructDataPaths = () => {
      // For structural elements, return modified base paths for children
      if (returnValue.isStructural && returnValue.name === '[0]') {
        return basePaths.map(path => `${path}${optionalAccess('[0]')}`);
      }

      // Skip data paths generation for other structural elements
      if (returnValue.isStructural) {
        return [];
      }

      const addReturnValueFunctionAccessor = (dataPath: string) => {
        if (returnValue.returnsFunctionArgs) {
          if (returnValue.isArray) {
            dataPath = `${dataPath}${optionalAccess('[0]')}`;
          }
          dataPath = `${dataPath}${optionalAccess(`(${safeString(returnValue.returnsFunctionArgs.join(', '))})`)}`
        }
        return dataPath;
      }

      return basePaths.flatMap((basePath) => {
        if (!returnValue.args) {
          let dataPath = `${basePath}${optionalAccess(safeString(returnValue.name))}`;
          dataPath = addReturnValueFunctionAccessor(dataPath);
          return dataPath;
        }
        return returnValue.args.map((argSet) => {
          const signature = returnValue.name.match(/\[\d*\]$/) ?
            returnValue.name :
            `${returnValue.name}(${argSet.join(', ')})`;

          let dataPath = `${basePath}${optionalAccess(safeString(signature), root)}`;
          dataPath = addReturnValueFunctionAccessor(dataPath);

          return dataPath;
        })
      }).filter(Boolean);
    }

    const constructContent = (dataPaths: string[]) => {
      const { name, args, nested, isArray, returnsFunctionArgs, returnsFunctionArray, isAsyncFunction } = returnValue;
      
      const nestedContent = (nested ?? []).map(nestedItem => {
        const nestedContent = constructReturnValueString(nestedItem, dataPaths);
        return nestedContent
      })

      const levelContentItems = [];
      if (!returnsFunctionArray && (returnsFunctionArgs || !isArray) && !returnValue.isStructural) {
        levelContentItems.push(...dataPaths.map(path => `...${path}`));
      }
      levelContentItems.push(...nestedContent);

      let levelContents = levelContentItems.filter(Boolean).join(',\n')
      if (returnsFunctionArgs) {
        const argsString = returnsFunctionArgs.map((_, index) => `arg${index + 1}`).join(', ');
        let funcContents = ''
        if (returnsFunctionArray) {
          if (levelContents.length === 0) {
            funcContents = 'return []';
          } else {
            funcContents = `return [\n${indent(levelContents)}\n]`
          }
        } else {
          if (levelContentItems.length === 1 && dataPaths.length === 1) {
            funcContents = `return ${dataPaths[0]}`;
          } else {
            funcContents = `return {\n${indent(levelContents)}\n}`
          }
        }

        levelContents = `(${argsString}) => {\n${indent(funcContents)}\n}`
        
        if (!isArray) {
          return levelContents;
        }
      }

      let returnValueContents = '';
      if (!returnsFunctionArgs && nestedContent.length === 0 && dataPaths.length === 1) {
        returnValueContents = dataPaths[0];
      } else {
        if (isArray) {
          returnValueContents = `[\n${indent(levelContents)}\n]`;
        } else {       
          returnValueContents = `{\n${indent(levelContents)}\n}`
        }
      }

      if (root) {
        return returnValueContents;
      }
      
      let content = '';
      if (args && args.length > 0) {       
        if (!isValidKey(name)) return;

        const mostArgs = args.sort((a, b) => b.length - a.length)[0];
        const argsString = mostArgs.map((_, index) => `arg${index + 1}`).join(', ');
        const funcContents = `return ${returnValueContents}`;
        content = `${cleanOutTypes(name)}: ${isAsyncFunction ? 'async ' : ''}(${argsString}) => {\n${indent(funcContents)}\n}`;
      } else {
        if (!isValidKey(name)) {
          return
        } else if (name.match(/\[\d*\]/)) {
          content = returnValueContents;
        } else {
          content = `${safeString(name)}: ${returnValueContents}`;
        }
      }
      return content;
    }
    
    const dataPaths = constructDataPaths();
    const content = constructContent(dataPaths);

    return content;
  }

  // Create the return value structure
  const sortedKeys = Object.keys(relevantReturnValueSchema ?? {}).sort((a, b) => {
    const aParts = splitOutsideParenthesesAndArrays(a);
    const bParts = splitOutsideParenthesesAndArrays(b);

    const maxLength = Math.max(aParts.length, bParts.length);
    for (let i=0; i<maxLength; ++i) {
      const aPart = aParts[i];
      const bPart = bParts[i];

      if (!aPart) return -1;
      if (!bPart) return 1;

      if (aPart === bPart) continue;

      const aName = aPart.split('(')[0];
      const bName = bPart.split('(')[0];
      
      if (aName !== bName) {
        return aName.localeCompare(bName);
      } else {
        return aPart.localeCompare(bPart);
      }
    }

    return 0;
  });

  for (const key of sortedKeys) {
    const value = relevantReturnValueSchema[key];
    const parts = splitOutsideParenthesesAndArrays(key);

    if (mockNameParts.length > 1) {
      const firstPart = joinParenthesesAndArrays(parts.slice(0, mockNameParts.length));
      parts.splice(0, mockNameParts.length, firstPart);
    }

    if (parts[0].split('(')[0] !== mockName) continue;

    if (!parts.some(p => isFunctionCallReturnValue(p))) continue;
    
    let returnValueSection = returnValueParts as ReturnValuePart;
    for (let i=1; i<parts.length; ++i) {
      let part = parts[i];
      const hasNestedFunction = parts.slice(i+1).some(p => p.endsWith(')'));
      const nextPart = parts[i + 1];
      const isLastPart = i === parts.length - 1;
      const nextIsArray = !!nextPart?.match(/^\[\d*\]/);
      const isDifferentiatedArray = !!part?.match(/^\[\d+\]/);
      const nextIsDifferentiatedArray = !!nextPart?.match(/^\[\d+\]/);
      // Find the correct value for the current part being processed
      let partValue = value; // default to the final value
      if (isFunctionCallReturnValue(part) && nextIsArray) {
        // For functionCallReturnValue followed by [], we need to look up the value for the array
        const arrayPath = joinParenthesesAndArrays(parts.slice(0, i + 2)); // include the [] part
        partValue = relevantReturnValueSchema[arrayPath] || value;
      }

      // For generic array parts [], look up the actual value from schema
      if (part === '[]') {
        const arrayPath = joinParenthesesAndArrays(parts.slice(0, i + 1)); // path up to and including []
        partValue = relevantReturnValueSchema[arrayPath] || value;
      }

      const returnsFunction = (
        isFunctionCallReturnValue(part) &&
        (nextIsArray || i === parts.length - 1) &&
        ['function', 'async-function'].includes(partValue)
      );
      const isKeyWord = [new RegExp(RETURN_VALUE), /signature\[\d+\]/].some(
        r => r.test(part)
      )

      if (isDifferentiatedArray) {
        returnValueSection.nested ||= [];
        const index = parseInt(part.match(/^\[(\d+)\]/)?.[1]) ?? 0;
        for (let j=0; j<=index; ++j) {
          if (!returnValueSection.nested[j]) {
            returnValueSection.nested.push({ name: `[${j}]` });
          }
        }
        returnValueSection = returnValueSection.nested[index];
        part = part.split(']')[1];
      } else if (part.includes('(') && part.startsWith(RETURN_VALUE)) {
        part = part.split(RETURN_VALUE)[1];
        returnValueSection.returnsFunctionArgs = funcArgs(part);
        if (value === 'array') {
          returnValueSection.returnsFunctionArray = true;
        }
      }

      if (!part || part.length === 0 || part.startsWith('(')) {
        if (part.startsWith('(')) {
          returnValueSection.returnsFunctionArgs = funcArgs(part);
          if (returnValueSection.returnsFunctionArgs && value === 'array') {
            returnValueSection.returnsFunctionArray = true;
          }
        }

        if (nextIsDifferentiatedArray || hasNestedFunction) {
          continue;
        }
        break;
      }

      if (isKeyWord && !hasNestedFunction) {
        if (isFunctionCallReturnValue(part)) {
          if (nextIsArray) {
            returnValueSection.isArray = true;
          }

          if (returnsFunction) {
            if (nextIsDifferentiatedArray) {
              if (i === parts.length - 2) {
                const withoutArgs = (p) => p.split('(')[0];
                const relevantPart = returnValueSection?.nested?.find(p => withoutArgs(p.name) === withoutArgs(part));
                if (!relevantPart) {
                  returnValueSection.nested ||= [];
                  if (!returnValueSection.nested.find(p => p.name === nextPart)) {
                    returnValueSection.nested.push({
                      name: nextPart,
                      args: [funcArgs(part)],
                      returnsFunctionArgs: value === 'function' ? [] : null
                    });
                  }
                }
              }
            } else {
              returnValueSection.returnsFunctionArgs = [];
            }
          }
        }

        if (nextIsDifferentiatedArray) {
          continue;
        } else {
          break;
        }
      } else if (isKeyWord) {
        continue;
      }

      const withoutArgs = (p) => p.split('(')[0];        
      let relevantPart = returnValueSection.nested?.find(p => withoutArgs(p.name) === withoutArgs(part));
      if (!relevantPart) {
        const hasArguments = part.includes('(') && part.endsWith(')');
        if (part === '[]') {
          // For generic arrays, if the array contains objects (not functions),
          // we need to create a structure representing array element [0]
          if (partValue === 'object' && !isLastPart) {
            // Create a generic array element structure
            returnValueSection.nested ||= [];
            if (!returnValueSection.nested.find(p => p.name === '[0]')) {
              returnValueSection.nested.push({
                name: '[0]',
                nested: [],
                isStructural: true  // Mark as structural-only, no data paths
              });
            }
            // Move to the [0] element for processing subsequent parts
            returnValueSection = returnValueSection.nested.find(p => p.name === '[0]');
          }
          continue;
        }

        if (isLastPart && ['function', 'async-function'].includes(value) && !hasArguments) {
          continue;
        }

        const relevantPath = joinParenthesesAndArrays(parts.slice(0, i + 1));
        const relevantValue = relevantReturnValueSchema[relevantPath]
        relevantPart = {
          name: part.split('(')[0],
          args: hasArguments ? [funcArgs(part)] : undefined,
          isArray: nextIsDifferentiatedArray,
          returnsFunctionArgs: returnsFunction ? [] : null,
          nested: [],
          isAsyncFunction: relevantValue === 'async-function',
        };

        returnValueSection.nested ||= [];
        if (!parts.some(p => p.startsWith('signature[')) || parts[parts.length - 1].startsWith('signature[')) {
          returnValueSection.nested.push(relevantPart);
        }
      } else if (funcArgs(part).join(',') !== funcArgs(relevantPart.name).join(',')) {
        const existingArgs = relevantPart.args.find(
          args => args.join(',') === funcArgs(part).join(',')
        );
        
        if (!existingArgs) {
          relevantPart.args ||= [];
          relevantPart.args.push(funcArgs(part));
        }
      }

      if (!hasNestedFunction) {
        break;
      } 

      returnValueSection = relevantPart;
    }
    
  }

  const contents = constructReturnValueString(returnValueParts);

  if (mockNameParts.length > 1) {
    const originalLib = `${mockNameParts[0]}__cyOriginal`;

    const subPart = (parts: string[], originalLib: string) => {
      const part = parts.shift();
      if (!isValidKey(part)) return;
      const isLast = parts.length === 0;

      const partContents = isLast ? 
        contents :
        `...${originalLib}.${part},\n${subPart(parts, originalLib)}`;
      
      let code = `${part}: {\n${indent(partContents)}\n}`;

      if (part.includes('(') || (isFunction && isLast)) {
        const args = funcArgs(part).map((_, index) => `arg${index + 1}`).join(', ');
        code = `${part}: ${isRootAsyncFunction ? 'async ' : ''}(${args}) => {\n${indent(`return ${partContents}`)}\n}`;
      }

      return code;
    }

    const returnParts = [
      `...${mockNameParts[0]}__cyOriginal`,
      subPart(mockNameParts.slice(1), originalLib)
    ].filter(Boolean);

    return `const ${mockNameParts[0]} = {\n${indent(returnParts.join(',\n'))}\n};`
  } else if (isFunction) {
    return `const ${mockName}ReturnValue = ${contents};\n\n${isRootAsyncFunction ? 'async ' : ''}function ${mockName}() {\n${indent(`return ${mockName}ReturnValue;`)}\n}`;
  } else {
    return `const ${mockName} = ${contents}`;
  }
}