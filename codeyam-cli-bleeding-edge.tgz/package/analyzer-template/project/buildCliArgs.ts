// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function buildCliArgs(options: Record<string, any>): string[] {
  const args: string[] = [];
  Object.keys(options).forEach((key) => {
    const value = options[key];
    if (value !== undefined) {
      if (typeof value === 'boolean') {
        if (value) args.push(`--${key}`);
      } else if (value !== null) {
        args.push(`--${key}`, String(value));
      }
    }
  });
  return args;
}
