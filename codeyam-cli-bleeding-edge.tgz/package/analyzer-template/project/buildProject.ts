import { ProjectFramework } from '~codeyam/types';
import execAsync from '../common/execAsync';

export default async function buildProject(
  packageManager: string,
  framework: ProjectFramework,
  projectPath: string,
) {
  console.log(
    `CodeYam: Building project with framework ${framework}, package manager: ${packageManager}...`,
  );
  
  const maxRetries = 3;
  let attempt = 0;
  while (attempt < maxRetries) {
    try {
      await execAsync({
        command: packageManager,
        args: ['i'],
        workingDir: projectPath,
      });
      break;
    } catch (error) {
      attempt++;
      console.warn(`Installation attempt ${attempt} failed. Retrying...`);
      if (attempt >= maxRetries) {
        throw error;
      }
    }
  }

  console.log('CodeYam: Dependencies installed');

  // const isNextOrVanillaRemix = framework === ProjectFramework.Next || framework === ProjectFramework.Remix;
  // if (isNextOrVanillaRemix) {
  //   await execAsync({
  //     command: packageManager,
  //     args: ['run', 'build'],
  //     workingDir: '../project',
  //     acceptableErrorsRegexes: [
  //       /DeprecationWarning: The 'typeParameters' property is deprecated on CallExpression nodes. Use 'typeArguments' instead./, // out of the box Next build error
  //       /Error when using sourcemap for reporting an error: Can't resolve original location of error./, // out of the box Remix build error
  //     ]
  //   });
  // }
}
