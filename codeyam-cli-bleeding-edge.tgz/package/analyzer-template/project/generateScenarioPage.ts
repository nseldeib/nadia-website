import {
  componentScenarioPageNext,
  componentScenarioPageRemix,
  getRelativePath,
} from '~codeyam/generate';
import {
  Analysis,
  Entity,
  File,
  Scenario,
  ProjectFramework,
  Project,
} from '~codeyam/types';
import getAppPath from './getAppPath';

export default function generateScenarioPage(
  project: Project,
  file: File,
  entity: Entity,
  analysis: Analysis,
  currentPath: string,
  mocksDir: string,
  scenario: Scenario,
  framework: ProjectFramework,
) {
  const relativeMocksDir = getRelativePath(currentPath, mocksDir);

  const appPath = getAppPath(project, framework, true);
  switch (framework) {
    case ProjectFramework.CodeYam:
    case ProjectFramework.Remix:
    case ProjectFramework.CRA:
      return componentScenarioPageRemix(
        file,
        entity,
        analysis,
        currentPath,
        appPath,
        scenario,
        relativeMocksDir,
      );
    case ProjectFramework.Next:
    case ProjectFramework.NextPages:
      return componentScenarioPageNext({
        file,
        entity,
        analysis,
        scenario,
        currentPath,
        appPath,
        relativeMocksDir,
      });
    default:
      throw new Error('Unsupported framework');
  }
}
