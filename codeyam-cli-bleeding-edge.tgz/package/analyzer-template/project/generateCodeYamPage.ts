import {
  Analysis,
  File,
  Scenario,
  ProjectFramework,
  Project,
} from '~codeyam/types';
import getScenarioPagePaths from './getScenarioPagePath';
import { frameworkRouteFileNameToRoute, isFrameworkRoute, PROJECT_RELATIVE_PATH } from '~codeyam/utils';

export interface GenerateCodeYamPageArgs {
  project: Project;
  file: File;
  analysis: Analysis;
  scenario: Scenario;
  framework: ProjectFramework;
  controllerPort?: number;
}

export function safeText(text: string | null | undefined): string {
  if (!text) return '';
  return text
    .replace(/{/g, '&#123;')
    .replace(/}/g, '&#125;')
    .replace(/>/g, '&gt;')
    .replace(/</g, '&lt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export default function generateCodeYamPage({
  project,
  file,
  analysis,
  scenario,
  framework,
  controllerPort,
}: GenerateCodeYamPageArgs) {
  const routePath = getScenarioPagePaths({
    project,
    analysis,
    scenarioName: scenario.name,
    framework,
  });

  let path = '';
  switch (framework) {
    case ProjectFramework.CodeYam:
    case ProjectFramework.CRA:
    case ProjectFramework.Remix:
      // the routePath looks like: relative/path/dashboard/app/routes/static.123.c054b7ee-3961-4697-8354-886062a95a9d.default.default.tsx
      // the path should look like: static/123/c054b7ee-3961-4697-8354-886062a95a9d/default/default
      path = routePath.split('/').pop().split('.').slice(0, -1).join('/');
      break;
    case ProjectFramework.Next:
      // the routePath looks like: relative/path/app/123/static/c054b7ee-3961-4697-8354-886062a95a9d/default/page.tsx
      // the path should look like: static/123/c054b7ee-3961-4697-8354-886062a95a9d/default/0
      const appDirectory = project.metadata?.appDirectory ?? 'app';
      path = routePath
        .replace(PROJECT_RELATIVE_PATH + '/' + appDirectory + '/', '')
        .split('/')
        .slice(0, -1)
        .join('/');
      break;
    case ProjectFramework.NextPages:
      // the routePath looks like: relative/path/app/123/static/c054b7ee-3961-4697-8354-886062a95a9d/default/page.tsx
      // the path should look like: static/123/c054b7ee-3961-4697-8354-886062a95a9d/default/0
      const pagesDirectory = project.metadata?.appDirectory ?? 'pages';
      path = routePath
        .replace(PROJECT_RELATIVE_PATH + '/' + pagesDirectory + '/', '')
        .split('/')
        .slice(0, -1)
        .join('/');
      break;
    default:
      break;
  }

  if (isFrameworkRoute(file, analysis.entity, framework)) {
    path = frameworkRouteFileNameToRoute(project.slug, file, analysis, framework);
  }

  const safeEntityName = safeText(analysis.entityName);
  const safeFilePath = safeText(file.path);
  const safeScenarioName = safeText(scenario.name);
  const safeScenarioDescription = safeText(scenario.description);

  return `'use client';
export default function CodeyamSamples() {  
  function getControllerUrl(pathname) {
    const baseUrl = new URL(window.location.href);
    const controllerPort = ${controllerPort};
    if (controllerPort) {
      // the controller is on a different port on the same host
      baseUrl.port = String(controllerPort);
    }
    baseUrl.pathname = pathname;
    return baseUrl.href;
  }

  const onNextScenario = async () => {
    // Tell the controller to complete the current scenario and start the next one.
    fetch(getControllerUrl('/static/codeyam-task-complete'));
    const linkElem = document.getElementById('link');
    linkElem.innerHTML = 'Loading...';
    linkElem.onclick = null;

    // Poll the controller for new project info.
    const pollInfo = () => {
      setTimeout(async () => {
        try {
          const response = await fetch(getControllerUrl('/static/codeyam-info'));
          if (response.status === 200) {
            const context = await response.json();
            const projectPort = context?.info?.projectPort;
            // only when projectPort is present and non-zero do we know the project server is up
            if (projectPort) {
              const baseUrl = new URL(window.location.href);
              baseUrl.port = String(projectPort);
              baseUrl.pathname = '/static/codeyam-sample';
              const newUrl = baseUrl.href;
              // Replace the clickable element with a plain link that navigates directly.
              linkElem.outerHTML = \`<a id="link" href="\${newUrl}" target="_blank" class="underline text-blue-600">Open Scenario</a>\`;
              return;
            }
          }
          pollInfo();
        } catch (e) {
          pollInfo();
        }
      }, 1000);
    };
    pollInfo();
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      gap: '3rem',
      height: '100vh',
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{
        padding: '1.5rem',
        display: 'flex',
        flexDirection: 'column',
        gap: '0.75rem',
        height: '100%'
      }}>
        <div style={{
          display: 'flex',
          gap: '0.75rem',
          alignItems: 'flex-end',
          flexWrap: 'wrap'
        }}>
          <h1 style={{
            fontSize: '1.125rem',
            fontWeight: 600,
            margin: 0
          }}>
            ${safeEntityName}
          </h1>
          <div style={{ color: '#4b5563' }}>
            ${safeFilePath}
          </div>
          <div
            onClick={onNextScenario}
            style={{
              textDecoration: 'underline',
              color: '#2563eb',
              cursor: 'pointer'
            }}
          >
            Next Scenario
          </div>
          <a
            href="/${path}"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              textDecoration: 'underline',
              color: '#2563eb'
            }}
          >
            Open scenario in a new tab
          </a>
        </div>

        <div>
          <b>Analysis:</b> ${analysis.id} -- <b>Scenario:</b> ${scenario.id}
        </div>

        <h2 style={{
          fontSize: '1.125rem',
          fontWeight: 600,
          margin: '0.5rem 0 0'
        }}>
          ${safeScenarioName}
        </h2>

        <p style={{
          fontSize: '0.875rem',
          color: '#6b7280',
          marginTop: '0.25rem'
        }}>
          ${safeScenarioDescription}
        </p>

        <iframe
          src="/${path}"
          style={{
            width: '100%',
            height: '600px',
            flexGrow: 1,
            border: 'none'
          }}
        />
      </div>
    </div>
  );
}`;
}
