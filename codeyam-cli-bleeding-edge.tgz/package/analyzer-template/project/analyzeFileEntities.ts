import {
  analyzeEntities,
  findOrCreateEntity,
  gatherEntityMap,
  ProjectAnalyzer,
  setImportedExports,
  AnalysisContext,
} from '~codeyam/analyze';
import { Commit, Entity, Project } from '~codeyam/types';
import checkApprovedPath from './checkApprovedPath';
import { updateCommitMetadata, upsertCommits } from '~codeyam/supabase';
import { analyzeFileMocks } from './mocks/analyzeFileMock';

interface AnalyzeFileEntitiesArgs {
  project: Project;
  projectAnalyzer: ProjectAnalyzer;
  commit?: Commit;
  branchId: string;
  entityShas: string[];
  scenarioIds?: string[];
  analyzeMockName?: string;
  steps: string[];
  context: AnalysisContext;
}

export default async function analyzeFileEntities({
  project,
  projectAnalyzer,
  commit,
  branchId,
  entityShas,
  scenarioIds,
  analyzeMockName,
  steps,
  context,
}: AnalyzeFileEntitiesArgs) {
  // Create a basic entity map for the requested entity SHAs
  const basicEntityMap = project.files.reduce(
    (acc, file) => {
      const fileEntities = file.entities.filter((entity) => {
        return entityShas.includes(entity.sha);
      });
      for (const entity of fileEntities) {
        entity.file = file;
        acc[entity.sha] = entity;
      }
      return acc;
    },
    {} as { [key: string]: Entity },
  );

  console.log(
    `CodeYan: analyzeFileEntities: Gathering dependencies for ${entityShas.length} entity SHAs`,
  );

  // Initial entity discovery and setup
  const entities: Entity[] = [];
  for (const entitySha of entityShas) {
    const basicEntity = basicEntityMap[entitySha];

    if (!basicEntity) {
      console.log('CodeYam Error: Basic entity not found', entitySha);
      throw new Error('Basic Entity not found');
    }

    const { name, file } = basicEntity;

    const approvedPath = checkApprovedPath({ project, path: file.path });
    if (!approvedPath) {
      console.log(
        'CodeYam: Skipping analysis, unapproved path :>> ',
        JSON.stringify({ path: file.path }),
      );
      commit.metadata ||= {};
      commit.metadata.skippedFiles ||= [];
      commit.metadata.skippedFiles.push(file.path);
      continue;
    }

    const fileAnalyzer = projectAnalyzer.getFileAnalyzer(file);
    const entity = await findOrCreateEntity({
      file,
      branchId,
      commitId: commit?.id,
      entityName: name,
      fileAnalyzer,
      projectAnalyzer,
      context,
    });

    if (!entity) {
      console.log(
        'CodeYam Error: findOrCreateEntity not created',
        file.path,
        name,
      );
      continue;
    }

    entities.push(entity);
    context.addEntity(entity);

    // Gather dependencies for this entity
    await gatherEntityMap({
      entity,
      commitId: commit?.id,
      branchId,
      context,
      projectAnalyzer,
    });
  }

  console.log(
    `CodeYan: analyzeFileEntities: Establishing bidirectional mapping of ${entities.length} entities`,
  );

  // Establish bidirectional relationships between entities
  await setImportedExports({
    entities,
    commit,
    context,
    projectAnalyzer,
  });

  console.log(
    `CodeYam: analyzeFileEntities: Starting analysis of ${entities.length} anchor entities`,
  );

  if (analyzeMockName) {
    // mocked-out analyzeEntities()
    for (const entity of entities) {
      const { file } = entity;

      const analyzeFn = analyzeFileMocks[analyzeMockName];
      const { analysisMap, entityMap } = await analyzeFn();

      for (const entityName of Object.keys(analysisMap[file.path])) {
        analysisMap[file.path][entityName].fileId = file.id;
      }
      context.mergeAnalysisMap(analysisMap);
      context.mergeEntityMap(entityMap);
    }
  } else {
    // normal execution path
    await analyzeEntities({
      rootEntities: entities,
      context,
      project,
      projectAnalyzer,
      commit,
      options: {
        branchId,
        scenarioIds,
        steps,
        fresh: !!process.env.FRESH,
        force: !!process.env.FORCE,
        forceAll: !!process.env.FORCE_ALL,
      },
    });
  }

  console.log(
    `CodeYam: analyzeFileEntities: Analysis completed for ${entities.length} entities`,
  );

  // Update commit if needed
  if (commit) {
    await upsertCommits({ projectId: project.id, commits: [commit] });
  }

  return {
    entities,
  };
}
