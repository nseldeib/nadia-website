import { rm } from 'node:fs/promises';

export default async function deleteFolder(folderPath: string): Promise<void> {
  await rm(folderPath, {
    recursive: true,
    force: true,
  });
}
