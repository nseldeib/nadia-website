import execAsync from './execAsync';

export default async function openPage(url: string, test?: boolean) {
  console.log('Opening page...', url, test);
  if (test) {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(
        `Failed to open page: ${url} (test: ${test}) ${response.statusText}`,
      );
    } else {
      console.log('Page opened successfully');
    }
  } else {
    await execAsync({
      command: 'open',
      args: [url],
    });
  }
}
