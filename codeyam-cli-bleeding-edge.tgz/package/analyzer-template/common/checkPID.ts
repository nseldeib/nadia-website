export default async function checkPID(pid: number): Promise<boolean> {
  try {
    // process.kill() with signal 0 tests for process existence
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return false;
  }
}
