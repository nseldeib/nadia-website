import { execSync } from 'child_process';
import { killProcess } from './killProcess';

/**
 * Gets child process IDs for a given PID using ps command.
 * Works on Unix-like systems including Linux and macOS.
 */
function getChildPids(parentPid: number): number[] {
  try {
    // -o ppid,pid shows parent and child process IDs in a simple format
    const output = execSync(`ps -o ppid,pid`).toString();
    return output
      .split('\n')
      .slice(1) // Skip header row
      .map((line) => {
        const [ppid, pid] = line.trim().split(/\s+/).map(Number);
        return ppid === parentPid ? pid : null;
      })
      .filter((pid): pid is number => pid !== null && !isNaN(pid));
  } catch (e) {
    return []; // Return empty array if command fails
  }
}

export default async function killProcessAndSubprocesses(
  kind: string,
  projectSlug: string,
  pid: number,
  log: (msg: string) => void,
  exitCode = 0,
): Promise<void> {
  // First kill all child processes recursively
  const childPids = getChildPids(pid);
  for (const childPid of childPids) {
    log(`Killing child process (${childPid})`);
    await killProcessAndSubprocesses(kind, projectSlug, childPid, log);
  }

  // Then kill the parent process
  log(`Killing process (${pid})`);

  if (pid === process.pid) {
    // If we're killing our own process, use process.exit() for a clean exit
    process.exit(exitCode);
  }
  await killProcess(pid, log);
}
