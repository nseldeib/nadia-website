export default async function measureExecutionTime<T>(
  callback: () => T | Promise<T>,
): Promise<{ result: T; seconds: number; milliseconds: number }> {
  const startTime = performance.now();

  // Ensure the callback is treated as a Promise, whether it's async or not
  const result = await Promise.resolve().then(callback);

  const endTime = performance.now();
  const timeTaken = endTime - startTime; // time in milliseconds

  const seconds = Math.floor(timeTaken / 1000);
  const milliseconds = Math.floor(timeTaken % 1000);

  return { result, seconds, milliseconds };
}
