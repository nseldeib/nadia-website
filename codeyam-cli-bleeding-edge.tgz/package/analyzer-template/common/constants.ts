// This should exactly match packages/types/src/constants.ts
export const DEFAULT_SCENARIO_NAME = 'Default Scenario';
