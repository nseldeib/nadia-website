async function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function isProcessRunning(pid: number): Promise<boolean> {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return false;
  }
}

async function attemptKill(
  pid: number,
  signal: NodeJS.Signals,
  log?: (msg: string) => void,
): Promise<void> {
  try {
    process.kill(pid, signal);
  } catch (e) {
    log?.(`Error sending ${signal} to process ${pid}: ${e}`);
  }
}

/**
 * Attempts to kill a process gracefully using progressively stronger signals.
 * First tries SIGINT, then SIGTERM, and finally SIGKILL if process persists.
 */
export async function killProcess(
  pid: number,
  log: (msg: string) => void = console.log,
  killRepeats = 1,
): Promise<boolean> {
  if (pid == process.pid) {
    throw new Error(`Eek! killProcess(${pid}) called on self!`);
  }

  let cumulativeWait = 0;

  async function killWithSignal(signal: NodeJS.Signals, waitSeconds: number) {
    await attemptKill(pid, signal, log);

    for (let i = 0; i < waitSeconds; i++) {
      await sleep(1000);
      cumulativeWait += 1000;
      const running = await isProcessRunning(pid);
      if (!running) {
        log(
          `Process ${pid} successfully killed with ${signal} after ${
            cumulativeWait / 1000
          } seconds.`,
        );
        return true;
      }
    }
    log(`Process still running after ${signal}...`);
    return false;
  }

  if (await killWithSignal('SIGINT', 5)) {
    return true;
  }
  if (await killWithSignal('SIGTERM', 5)) {
    return true;
  }
  for (let i = 0; i < killRepeats; i++) {
    if (await killWithSignal('SIGKILL', 2)) {
      return true;
    }
  }
  console.warn(
    `CodeYam Warning: Completely failed to kill process ${pid} after ${cumulativeWait / 1000} seconds.`,
  );

  return false;
}
