import {
  loadBackgroundJob,
  updateBackgroundJobProgress,
} from '~codeyam/supabase';
import * as fs from 'fs';
import { ChildProcessWithoutNullStreams, spawn } from 'child_process';

import * as dotenv from 'dotenv';
dotenv.config();

export interface ExecAsyncArgs {
  command: string;
  args: string[];
  env?: { [key: string]: string };
  workingDir?: string;
  log?: string;
  stepNames?: string[];
  onStart?: (process: ChildProcessWithoutNullStreams) => Promise<void>;
  onData?: (
    data: string,
    process?: ChildProcessWithoutNullStreams,
  ) => Promise<void>;
  onError?: (data: string) => Promise<void>;
  failOnErrorsRegexes?: RegExp[];
  acceptableErrorsRegexes?: RegExp[];
  logErrors?: boolean;
}

interface ExecAsyncOutput {
  code: number;
  message: string;
}

export default async function execAsync({
  command,
  args,
  env,
  workingDir,
  log,
  stepNames = ['generate-screenshots', 'generate-interactives'],
  onStart,
  onData,
  onError,
  logErrors = true,
  failOnErrorsRegexes,
  acceptableErrorsRegexes,
}: ExecAsyncArgs): Promise<ExecAsyncOutput> {
  // const projectSlug = process.env.PROJECT_SLUG;
  const commitId = process.env.COMMIT_ID;
  // const entityShas = process.env.ENTITY_SHAS;

  return new Promise((resolve, reject) => {
    const spawnedProcess = spawn(command, args, {
      cwd: workingDir,
      env: {
        ...process.env,
        ...env,
      },
      detached: true,
    });

    onStart?.(spawnedProcess);

    spawnedProcess.stdout.on('data', async function (data) {
      const dataString = `${data?.toString()}`;

      fs.appendFile(log ?? 'log.txt', dataString + '\n', (err) => {
        if (err) {
          console.log('CodeYam Error: Error writing to log file:', err);
        }
      });

      await onData?.(dataString, spawnedProcess);
      console.log(dataString);
    });

    spawnedProcess.stderr.on('data', async function (data) {
      if (acceptableErrorsRegexes) {
        for (const regex of acceptableErrorsRegexes) {
          if (regex.test(data?.toString())) {
            return;
          }
        }
      }

      await onError?.(data?.toString());

      if (logErrors) {
        console.log('CodeYam Error: execAsync stderr', data?.toString());
      }

      if (stepNames && commitId) {
        const backgroundJob = await loadBackgroundJob({ commitId });

        if (!backgroundJob) return;

        const error = `${command} ${args.join(' ')}: ${data?.toString()}`;

        for (const name of stepNames) {
          updateBackgroundJobProgress(backgroundJob, {
            initiated: backgroundJob.progress?.initiated,
            steps: [
              {
                name,
                initiated:
                  (backgroundJob.progress?.steps ?? []).find(
                    (s) => s.name === name,
                  )?.initiated ?? new Date().toISOString(),
                error,
                completed: new Date().toISOString(),
              },
            ],
            completed: new Date().toISOString(),
          });
        }
      }

      if (failOnErrorsRegexes) {
        for (const regex of failOnErrorsRegexes) {
          if (regex.test(data?.toString())) {
            console.log(
              'CodeYam ExecAsync Rejected',
              command,
              args,
              data?.toString(),
            );
            reject({ code: 1, message: data?.toString() });
          }
        }
      }
    });

    spawnedProcess.on('exit', function (code) {
      console.log(
        'CodeYam ExecAsync Resolved',
        command,
        args,
        code?.toString(),
      );
      // console.log(`${projectSlug} | ${fileSlugs} | ${command} ${args}: ${code?.toString()}`);
      resolve({ code, message: JSON.stringify({ command, args, code }) });
    });
  });
}
