import { cp } from 'node:fs/promises';

// Async function to copy file or directory
export default async function copy(
  sourcePath: string,
  destinationPath: string,
): Promise<void> {
  try {
    await cp(sourcePath, destinationPath, {
      recursive: true,
      force: false,
    });
    console.log(
      `File or directory copied from ${sourcePath} to ${destinationPath}`,
    );
  } catch (err) {
    console.log('Error occurred:', err);
    throw err; // Re-throw to maintain similar error handling behavior
  }
}
