import { getPID } from './getPID';
import { killProcess } from './killProcess';

export default async function closePort(port: number) {
  const pid = await getPID(port);
  if (pid === null) {
    return { portWasOpen: false, portIsClosed: true, pid: null };
  }

  const numericPid = Number(pid);
  console.log('Attempting to close port', port, 'with PID', numericPid);

  const success = await killProcess(numericPid, console.log, 10);
  return {
    portWasOpen: true,
    portIsClosed: success,
    pid: numericPid,
  };
}
