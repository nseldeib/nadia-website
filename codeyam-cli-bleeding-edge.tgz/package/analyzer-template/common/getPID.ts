import { exec } from 'child_process';

export async function getPID(port: number): Promise<string | null> {
  return new Promise((resolve) => {
    const ssCommand = `ss -tlnp | grep ':${port}'`;
    exec(ssCommand, (error, stdout, stderr) => {
      if (error || stderr) {
        const lsofCommand = `lsof -i tcp:${port} | grep LISTEN`;
        exec(lsofCommand, (error, stdout, stderr) => {
          if (error || stderr) {
            resolve(null);
            return;
          }

          try {
            const outputLines = stdout.trim().split('\n');
            const pids = outputLines.map((line) => line.split(/\s+/)[1]);
            resolve(pids.length > 0 ? pids[0] : null);
          } catch (e) {
            console.log('CodeYam Error: getPID lsofCommand', stdout, e);
            resolve(null);
          }
        });

        return;
      }

      try {
        const outputLines = stdout.trim().split('\n');
        const pidSection = outputLines[0].split('pid=')[1];
        if (!pidSection) return null;

        const pid = pidSection.split(',')[0];
        resolve(pid ?? null);
      } catch (e) {
        console.log('CodeYam Error: getPID ssCommand', stdout, e);
        resolve(null);
      }
    });
  });
}
