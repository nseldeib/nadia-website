import measureExecutionTime from './measureExecutionTime';

export default async function measureAndReportExecutionTime<T>(
  callback: () => T | Promise<T>,
  headline: string,
  report?: (message: string) => void,
): Promise<{ result: T }> {
  const { result, seconds, milliseconds } =
    await measureExecutionTime(callback);

  const message = `${headline}: ${seconds}.${milliseconds} seconds.`;
  console.log(`⏰ ${message}`);
  report?.(message);

  return { result };
}
