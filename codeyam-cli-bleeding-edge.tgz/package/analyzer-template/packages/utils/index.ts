export { default as isRemixRoute } from './src/lib/frameworks/isRemixRoute';
export { default as isNextRoute } from './src/lib/frameworks/isNextRoute';
export { default as isFrameworkRoute } from './src/lib/frameworks/isFrameworkRoute';
export { default as remixRouteFileNameToRoute } from './src/lib/frameworks/remixRouteFileNameToRoute';
export { default as nextRouteFileNameToRoute } from './src/lib/frameworks/nextRouteFileNameToRoute';
export { default as frameworkRouteFileNameToRoute } from './src/lib/frameworks/frameworkRouteFileNameToRoute';
export { default as getRemixRoutePath } from './src/lib/frameworks/getRemixRoutePath';
export { default as getNextRoutePath } from './src/lib/frameworks/getNextRoutePath';
export { default as getFrameworkRoutePath } from './src/lib/frameworks/getFrameworkRoutePath';
export { default as safeFileName } from './src/lib/safeFileName';
export { default as normalizeKey } from './src/lib/normalizeKey';
export { default as awsLog } from './src/lib/awsLog';
export { default as pushAnalysisError } from './src/lib/analyses/pushAnalysisError';

export { pushNewCommitRun } from './src/lib/commitRuns';

export const CODEYAM_MOCKS_DIRNAME = '__codeyamMocks__';
export const CODEYAM_DEMO_PAGES_DIRNAME = '__codeyamDemoPages__';
export const PROJECT_RELATIVE_PATH = '../project';
