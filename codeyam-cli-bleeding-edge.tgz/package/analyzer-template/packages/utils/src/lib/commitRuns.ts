import { CommitMetadata } from '~codeyam/types';
import { randomUUID } from 'node:crypto';

export function pushNewCommitRun(metadata: CommitMetadata) {
  const now = new Date().toISOString();

  if (metadata.currentRun) {
    metadata.currentRun.archivedAt = now;
    metadata.historicalRuns ??= [];
    metadata.historicalRuns.push(metadata.currentRun);
  }
  metadata.currentRun = {
    id: randomUUID(),
    createdAt: now,
  };
}
