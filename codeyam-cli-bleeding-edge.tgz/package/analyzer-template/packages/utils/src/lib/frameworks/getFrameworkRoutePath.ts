import { isNextRoute, isRemixRoute } from '~codeyam/utils';
import {
  Analysis,
  ReadonlyEntity,
  File,
  Project,
  ProjectFramework,
} from '~codeyam/types';
import getRemixRoutePath from './getRemixRoutePath';
import getNextRoutePath from './getNextRoutePath';

export default function getFrameworkRoutePath({
  file,
  rootFile,
  entity,
  rootAnalysis,
  scenarioComponentPath,
  extension,
  project,
  framework,
}: {
  file: File;
  rootFile: File;
  entity: ReadonlyEntity;
  rootAnalysis: Analysis;
  scenarioComponentPath: string;
  extension?: string;
  project: Project;
  framework: ProjectFramework;
}) {
  if (isRemixRoute(file, entity, framework)) {
    return getRemixRoutePath({
      file,
      rootFile,
      entity,
      rootAnalysis,
      extension,
      project,
    });
  }

  if (isNextRoute(file, entity, framework, file === rootFile)) {
    return getNextRoutePath({
      file,
      rootFile,
      entity,
      rootAnalysis,
      project,
      framework,
    });
  }

  return scenarioComponentPath;
}
