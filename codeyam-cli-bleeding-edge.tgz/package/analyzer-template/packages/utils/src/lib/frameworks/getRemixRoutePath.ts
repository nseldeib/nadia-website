import { safeFileName, PROJECT_RELATIVE_PATH } from '~codeyam/utils';
import { Analysis, ReadonlyEntity, File, Project } from '~codeyam/types';

export default function getRemixRoutePath({
  file,
  rootFile,
  entity,
  rootAnalysis,
  extension = 'tsx',
  project,
}: {
  file: File;
  rootFile: File;
  entity: ReadonlyEntity;
  rootAnalysis: Analysis;
  extension?: string;
  project: Project;
}) {
  const basePath = `${project.metadata.appDirectory ? project.metadata.appDirectory : 'app'}/routes`;
  const routesIndex = file.path.indexOf('/routes/') + '/routes/'.length;
  const route = file.path.slice(routesIndex);
  const cleanRoute = route
    .replace(/\//g, '.')
    .replace('$', '')
    .replace(/_/g, 'x');

  let routePath = `${PROJECT_RELATIVE_PATH}/${basePath}/static.${project.slug}.${rootAnalysis.id}.${safeFileName(rootAnalysis.entityName)}.${cleanRoute}`;

  if (file.id === rootFile.id) {
    routePath = routePath.replace(`.${extension}`, `.default.${extension}`);
  }
  console.log(
    'CodeYam: Scenario route component',
    file.path,
    entity.name,
    routePath,
  );

  return routePath;
}
