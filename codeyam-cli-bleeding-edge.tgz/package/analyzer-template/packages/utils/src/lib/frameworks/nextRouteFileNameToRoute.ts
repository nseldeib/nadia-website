import { Analysis, File } from '~codeyam/types';
import safeFileName from '../safeFileName';

export default function nextRouteFileNameToRoute(
  projectSlug: string,
  file: File,
  analysis: Analysis,
) {
  const route = file.path.split('/').slice(1, -1);
  return [
    'static',
    projectSlug,
    analysis.id,
    safeFileName(analysis.entityName),
    ...route,
  ].join('/');
}
