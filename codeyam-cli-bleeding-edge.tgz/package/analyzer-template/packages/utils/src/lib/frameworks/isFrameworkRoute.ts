import { File, ProjectFramework, ReadonlyEntity } from '~codeyam/types';
import isRemixRoute from './isRemixRoute';
import isNextRoute from './isNextRoute';

export default function isFrameworkRoute(
  file: File,
  entity: ReadonlyEntity,
  framework: ProjectFramework,
  isRootFile = true,
) {
  return (
    isRemixRoute(file, entity, framework) ||
    isNextRoute(file, entity, framework, isRootFile)
  );
}
