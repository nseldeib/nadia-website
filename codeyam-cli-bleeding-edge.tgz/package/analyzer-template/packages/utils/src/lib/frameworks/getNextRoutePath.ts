import { safeFileName } from '~codeyam/utils';
import {
  Analysis,
  ReadonlyEntity,
  File,
  Project,
  ProjectFramework,
} from '~codeyam/types';
import { PROJECT_RELATIVE_PATH } from '~codeyam/utils';

export default function getNextRoutePath({
  file,
  entity,
  rootAnalysis,
  project,
  framework,
}: {
  file: File;
  rootFile: File;
  entity: ReadonlyEntity;
  rootAnalysis: Analysis;
  project: Project;
  framework: ProjectFramework;
}) {
  const routePath = file.path.split('/').slice(1);
  const pagePath = [
    PROJECT_RELATIVE_PATH,
    'app',
    'static',
    project.slug,
    rootAnalysis.id,
    safeFileName(rootAnalysis.entityName),
    ...routePath,
  ].join('/');

  console.log(
    'CodeYam: Scenario page (NextJS)',
    file.path,
    entity.name,
    pagePath,
  );

  return pagePath;
}
