import { Analysis, File, ProjectFramework } from '~codeyam/types';
import isRemixRoute from './isRemixRoute';
import isNextRoute from './isNextRoute';
import remixRouteFileNameToRoute from './remixRouteFileNameToRoute';
import nextRouteFileNameToRoute from './nextRouteFileNameToRoute';

export default function frameworkRouteFileNameToRoute(
  projectSlug: string,
  file: File,
  analysis: Analysis,
  framework: ProjectFramework,
) {
  if (isRemixRoute(file, analysis.entity, framework)) {
    return remixRouteFileNameToRoute(projectSlug, file, analysis);
  }

  if (isNextRoute(file, analysis.entity, framework)) {
    return nextRouteFileNameToRoute(projectSlug, file, analysis);
  }
}
