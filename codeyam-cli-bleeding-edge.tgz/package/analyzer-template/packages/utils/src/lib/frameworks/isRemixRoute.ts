import { File, ProjectFramework, ReadonlyEntity } from '~codeyam/types';

export default function isRemixRoute(
  file: File,
  entity: ReadonlyEntity,
  framework: ProjectFramework,
) {
  return (
    [ProjectFramework.CodeYam, ProjectFramework.Remix].includes(framework) &&
    file.path.indexOf('/routes/') > -1 &&
    !entity.metadata?.namedExport &&
    !entity.metadata?.notExported
  );
}
