import { File, ProjectFramework, ReadonlyEntity } from '~codeyam/types';

export default function isNextRoute(
  file: File,
  entity: ReadonlyEntity,
  framework: ProjectFramework,
  isRootFile = false,
) {
  // Layouts can not be used as direct routes in Next.js.
  if (isRootFile && file.path.endsWith('layout.tsx')) {
    return false;
  }

  return (
    [ProjectFramework.Next].includes(framework) &&
    (file.path.endsWith('page.tsx') || file.path.endsWith('layout.tsx')) &&
    !entity.metadata?.namedExport &&
    !entity.metadata?.notExported
  );
}
