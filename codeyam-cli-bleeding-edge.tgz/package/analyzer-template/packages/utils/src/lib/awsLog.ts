export default function awsLog(...messages: unknown[]) {
  if (!process.env['CODEYAM_ECS_TASK_ARN']) {
    console.log(messages);
    return;
  }
  console.log(
    messages
      .map((m) => {
        if (!m) return;

        if (typeof m === 'string') {
          return m;
        }

        if (m instanceof Error) {
          return `${m.name}: ${m.message}\n${m.stack}`;
        }

        if (typeof m === 'object') {
          return JSON.stringify(m, null, 2);
        }

        return String(m);
      })
      .filter(Boolean)
      .join('\n\n')
      .replace(/\n/g, '\r'), // Replace newlines with carriage returns for AWS CloudWatch compatibility
  );
}
