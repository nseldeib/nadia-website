export default function normalizeKey(key: string): string {
  return key.replace(/,/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
}
