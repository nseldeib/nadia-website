import { GitHubFile } from './GithubFile';

export interface GithubBranch {
  name: string;
  sha: string;
  files?: GitHubFile[];
}
