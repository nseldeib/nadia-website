import { TypeStructures } from './TypeStructures';

export interface FileProp {
  name: string;
  type: string;
  typeStructures?: TypeStructures;
  required: boolean;
}
