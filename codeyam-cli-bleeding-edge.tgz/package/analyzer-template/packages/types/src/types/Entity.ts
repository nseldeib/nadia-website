import { EntityType } from './EntityType';
import { Branch } from './Branch';
import { File } from './File';
import { Commit } from './Commit';
import { Analysis } from './Analysis';
import { DeepReadonly } from './DeepReadonly';
import { DataStructure } from './ScenariosDataStructure';

export interface Entity {
  sha: string;
  projectId: string;
  fileId?: string;
  localFilePath?: string;
  filePath?: string;
  resolvedFilePath?: string;
  commitId?: string;
  name: string;
  resolvedName?: string;
  resolvedIsDefault?: boolean;
  entityType: EntityType;
  code?: string;
  description?: string;
  documentation?: string;
  metadata?: {
    changeDescription?: string;
    notExported?: boolean;
    namedExport?: boolean;
    exportAlias?: string;
    importedExports?: (Pick<
      Entity,
      | 'filePath'
      | 'name'
      | 'entityType'
      | 'resolvedFilePath'
      | 'resolvedName'
      | 'resolvedIsDefault'
      | 'code'
    > & {
      isDefault: boolean;
      isImplicitDependency?: boolean;
      isMocked?: boolean;
      calls?: string[];
    })[];
    nodeModuleImports?: {
      [key: string]: {
        name: string;
        isDefault: boolean;
        isMocked?: boolean;
        calls?: string[];
      }[];
    };
    importedBy?: {
      // Should this be on Analysis?
      [key: string]: {
        [key: string]: {
          shas: string[];
        };
      };
    };
    isolatedDataStructure?: DataStructure;
    hasCircularDependency?: boolean;
    defaultWidth?: string;
  };
  file?: File;
  commit?: Commit;
  analyses?: Analysis[];
  branchIds?: string[];
  branches?: Branch[];
  createdAt?: string;
  updatedAt?: string;
}

export type ReadonlyEntity = DeepReadonly<Entity>;
