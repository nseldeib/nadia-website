import { Analysis, ReadonlyAnalysis } from './Analysis';

export interface AnalysisMap {
  [key: string]: { [key: string]: Analysis };
}

export interface ReadonlyAnalysisMap {
  [key: string]: { [key: string]: ReadonlyAnalysis };
}
