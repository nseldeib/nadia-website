import { DependencyTreeNode } from './DependencyTreeNode';
import { Entity } from './Entity';
import { PropsWithTypes } from './PropsWithTypes';
import type { File } from './File';
import type { Commit } from './Commit';
import type { Project } from './Project';
import { Scenario } from './Scenario';
import {
  DataStructure,
  ScenariosDataStructure,
} from './ScenariosDataStructure';
import { LlmCall } from './LlmCall';
import { Branch } from './Branch';
import { AnalysisBranch } from './AnalysisBranch';
import { DeepReadonly } from './DeepReadonly';

// used for e.g. analyzedTreeSha for analyses that have no meaningful content to hash
export const EMPTY_SHA_MARKER = '0000000000000000000000000000000000000000';

export interface AnalysisError {
  message: string;
  stack: string;
  timestamp: string;
  phase: 'capture' | 'analyze';
}

export interface Analysis {
  id?: string;
  projectId: string;
  commitId: string;
  fileId: string;
  filePath: string;
  entitySha: string;
  entityType: string;
  entityName: string;
  previousAnalysisId?: string;
  indirect?: boolean;
  branchCommitSha?: string;
  dependencyAnalyzedTreeSha?: string;
  analyzedTreeSha?: string;
  metadata?: {
    dataShaList?: string[][];
    approved?: boolean;
    pendingCommentCount?: number;
    propsWithTypes?: PropsWithTypes;
    nodeModuleMocks?: {
      mockId?: string;
      filePath: string;
      importName: string;
      importAlias: string;
      importIsDefault: boolean;
      mockingRequired: boolean;
      reason: string;
    }[];
    mergedDataStructure?: Omit<DataStructure, 'equivalentSignatureVariables'>;
    scenariosDataStructure?: ScenariosDataStructure;
    keyAttributes?: {
      dependentEntityName?: string;
      internalPath: string;
      externalPath: string;
      description: string;
      validValueOptions: string[];
      errorValueOptions: string[];
    }[];
    dependencyTree?: DependencyTreeNode;
    dependentAnalyses?: string[];
    dependencyAnalyzedTreeShas?: {
      [filePath: string]: { [entityName: string]: string };
    };
    llmCalls?: LlmCall[];
    defaultWidth?: number;
    scenarioChangesOverview?: string;
    scenarioErrorChangesOverview?: string;
  };
  status?: {
    startedAt: string;
    readyToBeCaptured?: boolean;
    processingForCaptureAt?: string;
    finishedAt?: string;
    retryAttempts?: number;
    steps: {
      name: string;
      startedAt: string;
      finishedAt?: string;
      error?: string;
      errorStack?: string;
    }[];
    scenarios?: {
      name: string;
      attempts?: number;
      screenshotStartedAt?: string;
      screenshotFinishedAt?: string;
      interactiveStartedAt?: string;
      interactiveFinishedAt?: string;
      startedAt: string;
      finishedAt?: string;
      error?: string;
      errorStack?: string;
    }[];
    errors: AnalysisError[];
  };
  entity?: Entity;
  file?: File;
  commit?: Commit;
  project?: Project;
  scenarios?: Scenario[];
  branches?: Branch[];
  analysisBranches?: AnalysisBranch[];
  selectedAnalysisBranch?: AnalysisBranch;
  originalContent?: string;
  originalFileContent?: string;
  committedAt?: string;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type AnalysisStatus = Analysis['status'];
export type AnalysisMetadata = Analysis['metadata'];
export type ReadonlyAnalysis = DeepReadonly<Analysis>;
