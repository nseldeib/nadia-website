export interface Mock {
  id?: string;
  projectId: string;
  fileId?: string;
  filePath: string;
  resolvedFilePath?: string;
  entityName: string;
  resolvedEntityName?: string;
  resolvedIsDefault?: boolean;
  importName?: string;
  importAlias?: string;
  importIsDefault?: boolean;
  entitySha?: string;
  nodeModule: boolean;
  mockingRequired?: boolean;
  metadata: {
    defaultExport: boolean;
    notExported: boolean;
    requiredByAnalyses?: { [key: string]: { [key: string]: string[] } };
    reason?: string;
    llmCalls: { [key: string]: string };
  };
  content?: string;
  sha?: string;
  createdAt?: string;
}
