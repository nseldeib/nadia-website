import { BackgroundJob } from './BackgroundJob';
import { Branch } from './Branch';
import { Analysis } from './Analysis';
import { Project } from './Project';
import { Entity } from './Entity';
import { CommitBranch } from './CommitBranch';

export type CommitRunStatus = {
  id: string;
  createdAt?: string; // timestamp when the run was initiated
  lastUpdatedAt?: string; // timestamp of the last progress update
  fileCount?: number; // number of source files involved in the run
  filesCompleted?: number; // number of files processed
  entityCount?: number; // number of entities to analyze
  analysesCompleted?: number; // number of entities analyzed
  readyToBeCaptured?: number; // number of analyses ready to be captured
  capturesAttempted?: number; // number of analyses captures attempted
  capturesCompleted?: number; // number of entity analyses captured
  analysisCompletedAt?: string; // timestamp when all analysis was completed
  firstCaptureAt?: string; // timestamp when the first capture was initiated
  lastCaptureAt?: string; // timestamp when the last capture was initiated

  analyzeTaskArns?: string[];
  captureTaskArns?: string[];

  archivedAt?: string; // timestamp when moved to commit.metadata.historicalRuns
};

export interface Commit {
  id?: string;
  projectId?: string;
  branchId?: string;
  branch?: Branch;
  parents?: string[];
  url: string;
  sha: string;
  htmlUrl: string;
  author?: {
    username?: string;
    avatarUrl?: string;
  };
  title?: string;
  message: string;
  aiMessage?: string;
  mergedBranchId?: string;
  mergedBranch?: Branch;
  metadata?: {
    coAuthors?: {
      username: string;
      avatarUrl: string;
    }[];
    skippedFiles?: string[];
    prNumber?: string;
    entitiesAnalyzedAt?: string;
    receivedAt?: string;
    startedAnalyzingAt?: string;
    baseline?: boolean;
    currentRun?: CommitRunStatus;
    historicalRuns?: CommitRunStatus[];
  };
  analyzedAt?: string;
  committedAt?: string;
  backgroundJob?: BackgroundJob;
  files: {
    fileName: string;
    status: string;
    patch?: string;
    previousFileName?: string;
    aiMessage?: string;
  }[];
  entities?: Entity[];
  analyses?: Analysis[];
  commitBranches?: CommitBranch[];
  project?: Pick<Project, 'id' | 'slug' | 'path' | 'metadata'>;
}

export type CommitMetadata = Commit['metadata'];

export interface CommitOverview {
  title: string;
  message: string;
  aiMessage: string;
}
