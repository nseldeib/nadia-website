import { Entity } from './Entity';

export interface EntityMap {
  [key: string]: { [key: string]: Entity };
}
