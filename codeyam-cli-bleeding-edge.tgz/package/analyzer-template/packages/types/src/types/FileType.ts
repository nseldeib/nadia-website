export type FileType =
  | 'visual'
  | 'library'
  | 'index'
  | 'documentation'
  | 'configuration'
  | 'asset'
  | 'test'
  | 'stylesheet'
  | 'type'
  | 'data'
  | 'other';
