export type CodeExplanation = {
  [key: string]: string;
};
