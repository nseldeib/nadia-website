export interface DependencyTreeNode {
  children: { [path: string]: { [entityName: string]: DependencyTreeNode } };
}
