export interface BackgroundJob {
  projectId: string;
  commitId: string;
  progress: {
    initiated?: string;
    steps: {
      name: string;
      initiated: string;
      details?: string[];
      error?: string;
      completed?: string;
    }[];
    completed?: string;
  };
  success?: boolean;
  createdAt: string;
  updatedAt?: string;
}
