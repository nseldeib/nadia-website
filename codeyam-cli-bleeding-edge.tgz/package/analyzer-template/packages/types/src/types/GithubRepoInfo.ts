export interface GithubRepoInfo {
  owner: string;
  name: string;
}

export interface GithubTreeInfo extends GithubRepoInfo {
  treeSha?: string;
  treeName?: string;
}

export interface GithubBranchesInfo extends GithubRepoInfo {
  branches: {
    name: string;
    sha: string;
  }[];
}
