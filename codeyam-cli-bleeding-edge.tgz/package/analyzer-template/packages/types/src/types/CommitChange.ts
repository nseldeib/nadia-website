import { Commit } from './Commit';

export interface CommitChange {
  eventType: 'INSERT' | 'UPDATE' | 'DELETE';
  new: Commit;
  old: {
    id: string;
  };
}
