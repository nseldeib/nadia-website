import { Analysis } from './Analysis';

import { Entity } from './Entity';
import { Branch } from './Branch';

export interface AnalysisBranch {
  id?: string;
  analysisId: string;
  entitySha: string;
  branchId: string;
  active: boolean;
  branch?: Branch;
  analysis?: Analysis;
  entity?: Entity;
  createdAt?: string;
}
