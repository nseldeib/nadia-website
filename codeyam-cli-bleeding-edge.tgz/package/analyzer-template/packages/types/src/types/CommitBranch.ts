import { Branch } from './Branch';
import { Commit } from './Commit';

export interface CommitBranch {
  id?: string;
  commitId: string;
  branchId: string;
  active: boolean;
  commit?: Commit;
  branch?: Branch;
}
