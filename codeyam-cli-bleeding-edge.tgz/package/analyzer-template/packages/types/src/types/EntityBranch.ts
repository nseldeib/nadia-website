import { Entity } from './Entity';

export interface EntityBranch {
  entitySha: string;
  branchId: string;
  active: boolean;
  entity?: Entity;
}
