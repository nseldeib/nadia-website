export interface JsonTypeDefinition {
  [key: string]: string | string[] | JsonTypeDefinition | JsonTypeDefinition[];
}
