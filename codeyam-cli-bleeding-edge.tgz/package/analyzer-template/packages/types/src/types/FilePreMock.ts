export type FilePreMock = {
  path: string;
  content: string;
  // types are a concating of recursive dependencies not defined in the raw file content itself
  types: string;
  mockingRequired?: boolean;
};
