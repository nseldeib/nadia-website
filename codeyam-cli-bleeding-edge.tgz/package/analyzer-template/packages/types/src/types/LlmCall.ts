export type LlmCall = { id: string; name?: string };
