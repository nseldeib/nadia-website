import { Analysis } from './Analysis';
import { BackgroundJob } from './BackgroundJob';
import { Commit } from './Commit';
import { File } from './File';
import { TimelineItem } from './TimelineItem';

export interface Branch {
  id?: string;
  projectId: string;
  name: string;
  primary: boolean;
  ref?: string;
  sha?: string;
  files?: File[];
  analysis?: BackgroundJob | BackgroundJob[];
  metadata?: {
    name?: string;
    description?: string;
    contributors?: {
      username: string;
      avatarUrl: string;
    }[];
    commits?: {
      total: number;
      last7Days: string[];
    };
    pullRequest?: {
      number: number;
      commentId?: number;
    };
    timeline?: TimelineItem[];
    permanent?: {
      nickname?: string;
      order: number;
    };
  };
  contentChangedAt?: string;
  activeAt?: string | null;
  createdAt?: string;
  updatedAt?: string;
  commits?: Commit[];
  analyses?: Analysis[];
}
