import { GithubBranch } from './GithubBranch';

export interface GithubRepoData {
  name: string;
  description: string;
  path: string;
  primaryBranch: string;
  trees: GithubBranch[];
}
