import { Entity } from '~codeyam/types';

export interface File {
  id: string;
  projectId?: string;
  name: string;
  path: string;
  deleted?: boolean;
  content?: string;
  metadata?: {
    previousFilePath?: string;
    nextFilePath?: string;
  };
  entities?: Entity[];
  createdAt?: string;
  updatedAt?: string;
}

export type UnsavedFile = Pick<File, 'path' | 'content'>;
