export type EntityType =
  | 'visual'
  | 'library'
  | 'functionCall'
  | 'index'
  | 'type'
  | 'data'
  | 'other';
