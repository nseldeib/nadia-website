import type { Config } from '@jest/types';

const config: Config.InitialOptions = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  moduleNameMapper: {
    '~codeyam/(.*)': '<rootDir>/../packages/$1',
  },
};

export default config;
