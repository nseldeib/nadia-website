export default function deepMerge(defaultData, changes, seen = new WeakSet()) {
  if (!changes) return defaultData;
  if (!defaultData) return changes;

  try {
    if (typeof changes === 'object' && changes !== null) {
      if (seen.has(changes)) {
        throw new Error('Circular reference detected during deep merge');
      }
      seen.add(changes);
    }

    const merge = { ...defaultData };
    for (const key in changes) {
      if (changes[key] === null) {
        delete merge[key];
      } else if (Array.isArray(changes[key])) {
        merge[key] = [];
        for (let i = 0; i < changes[key].length; i++) {
          const item = changes[key][i];
          if (typeof item === 'object' && item !== null) {
            merge[key][i] = deepMerge(merge?.[key]?.[i], item, seen);
          } else {
            merge[key][i] = item;
          }
        }
      } else if (typeof changes[key] === 'object' && changes[key] !== null) {
        merge[key] = deepMerge(merge[key] ?? {}, changes[key], seen);
      } else {
        merge[key] = changes[key];
      }
    }
    return merge;
  } catch (e) {
    console.log('CodeYam: Error merging data', defaultData, changes);
    throw e;
  }
}
