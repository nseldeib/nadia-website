import { Analysis } from '~codeyam/types';
import { handleCmdk } from './handleCmdk';
import handleRadix from './handleRadix';

export default function handleWrappers(
  componentContent: string,
  analysis: Analysis,
): string {
  const wrapperNodeModules = ['radix-ui', 'cmdk'];

  const frameworks: string[] = [];
  for (const nodeModulePath in analysis.entity.metadata.nodeModuleImports ??
    {}) {
    for (const wrapperNodeModule of wrapperNodeModules) {
      if (nodeModulePath.includes(wrapperNodeModule)) {
        frameworks.push(wrapperNodeModule);
      }
    }
  }

  for (const framework of frameworks) {
    if (framework === 'radix-ui') {
      componentContent = handleRadix(componentContent);
    } else if (framework === 'cmdk') {
      componentContent = handleCmdk(componentContent);
    }
  }

  return componentContent;
}
