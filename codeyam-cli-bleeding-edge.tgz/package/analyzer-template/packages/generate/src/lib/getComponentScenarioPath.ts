import { Entity, File, Scenario } from '~codeyam/types';
import { safeFileName } from '~codeyam/utils';
import getRelativePath from './getRelativePath';
import safeFolder from './safeFolder';

export const CODEYAM_DEMO_PAGES_DIRNAME = '__codeyamDemoPages__';

export default function getComponentScenarioPath(
  file: File,
  entity: Entity,
  currentPath: string,
  appPath: string,
  scenario: Scenario,
  primary: boolean,
) {
  const { name: entityName } = entity;
  const isLibraryDemoPage = entity.entityType === 'library' && primary;
  const filePath = isLibraryDemoPage
    ? `${appPath}/${CODEYAM_DEMO_PAGES_DIRNAME}/${file.name}`
    : file.path;

  const relativePath = safeFolder(
    getRelativePath(currentPath, filePath).split('/').slice(0, -1).join('/'),
  );

  if (scenario) {
    const importPath = isLibraryDemoPage
      ? `${relativePath}/${entity.sha}_${safeFileName(entityName)}`
      : `${relativePath}/${entity.sha}_${safeFileName(entityName)}`;
    return `${importPath}`;
  }

  return `${relativePath}_${entity.sha}_${safeFileName(entityName)}`;
}
