import { createAliases } from './handleRadix';

/**
 * Minimal wrapper map for the ⌘ k / cmdk primitives.
 *
 * – Keys are cmdk component names (dot notation).
 * – Values are functions that receive the raw JSX snippet (children)
 *   and return a string wrapped in the fewest providers necessary
 *   to avoid context/runtime errors such as
 *   “Cannot read properties of undefined (reading 'subscribe')”.
 *
 * The rules are:
 *   • Anything that lives under <Command.List> must get a Root + List.
 *   • Everything else just needs a Root (or Dialog for the modal variant).
 *
 * Sources:
 *   • Official examples that show the required nesting order :contentReference[oaicite:0]{index=0}
 *   • GitHub issue confirming the missing-provider error :contentReference[oaicite:1]{index=1}
 */
const baseCmdkWrapperMap: Record<string, (c: string) => string> = {
  // ── Core ──────────────────────────────────────────────
  'Command.Input': (c) => `<CYCommand>${c}</CYCommand>`,
  'Command.List': (c) => `<CYCommand>${c}</CYCommand>`,

  // ── List-level sub-parts ──────────────────────────────
  'Command.Item': (c) =>
    `<CYCommand><CYCommand.List>${c}</CYCommand.List></CYCommand>`,
  'Command.Group': (c) =>
    `<CYCommand><CYCommand.List>${c}</CYCommand.List></CYCommand>`,
  'Command.Separator': (c) =>
    `<CYCommand><CYCommand.List>${c}</CYCommand.List></CYCommand>`,
  'Command.Empty': (c) =>
    `<CYCommand><CYCommand.List>${c}</CYCommand.List></CYCommand>`,
  'Command.Loading': (c) =>
    `<CYCommand><CYCommand.List>${c}</CYCommand.List></CYCommand>`,

  // Needs a dummy item so <Shortcut> finds its parent context
  'Command.Shortcut': (c) =>
    `<CYCommand><CYCommand.List><CYCommand.Item value="x">${c}</CYCommand.Item></CYCommand.List></CYCommand>`,

  // ── Dialog variant ────────────────────────────────────
  'Command.Dialog': (c) => `<CYCommand.Dialog open>${c}</CYCommand.Dialog>`,
};

// Re-use your alias helper so <CommandItem> works too.
const cmdkWrapperMap = createAliases(baseCmdkWrapperMap);

/**
 * Wraps a cmdk primitive snippet with the providers it needs.
 *
 * @param componentContent JSX string of a *single* cmdk element.
 * @returns Wrapped JSX if we know the component, otherwise unchanged.
 */
export function handleCmdk(componentContent: string): string {
  const match = componentContent.match(/< *([A-Z][A-Za-z0-9\.]*)/);
  if (!match?.[1]) return componentContent;

  const name = match[1];
  const wrapper = cmdkWrapperMap[name];
  return wrapper ? wrapper(componentContent) : componentContent;
}
