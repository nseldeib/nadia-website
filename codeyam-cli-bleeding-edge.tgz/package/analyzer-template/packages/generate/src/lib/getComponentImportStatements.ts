import { Scenario, ProjectFramework } from '~codeyam/types';
import { safeFileName } from '~codeyam/utils';

interface GetComponentImportStatementsArgs {
  fileName: string;
  filePath: string;
  scenarios: Scenario[];
  framework: ProjectFramework;
}

export default function getComponentImportStatements({
  fileName,
  filePath,
  scenarios,
}: GetComponentImportStatementsArgs) {
  const componentName = fileName.split('.')[0];
  const pathParts = filePath.split('/').slice(0, -1);
  const relativePathStartIndex = pathParts.indexOf('app') + 1;
  const relativePath = pathParts.slice(relativePathStartIndex).join('/');

  const importStatements: string[] = [];

  if (scenarios && scenarios.length > 0) {
    scenarios.forEach((scenario) => {
      const scenarioSlug = safeFileName(scenario.name);
      const componentNameSafe = `${componentName}_${scenarioSlug}`;
      const importPath = `${relativePath}/${scenarioSlug}_${componentName}`;
      const importStatement = `import ${componentNameSafe} from "${importPath}";`;
      importStatements.push(importStatement);
    });
  } else {
    // If no examples had mocks, add the default import statement
    const defaultImportStatement = `import ${componentName} from "${relativePath}/${componentName}";`;
    importStatements.push(defaultImportStatement);
  }

  return importStatements.join('\n');
}
