/**
 * Creates aliases for component names by removing dots.
 * For example, an entry for 'Accordion.Trigger' will also create 'AccordionTrigger'.
 * This makes the map more robust to different naming conventions.
 * @param map The original map with dot-separated names.
 * @returns A new map including the original keys and the new aliases.
 */
export function createAliases(
  map: Record<string, (children: string) => string>,
): Record<string, (children: string) => string> {
  const aliasedMap = { ...map };
  for (const key in map) {
    if (key.includes('.')) {
      const alias = key.replace(/\./g, '');
      aliasedMap[alias] = map[key];
    }
  }
  return aliasedMap;
}

/**
 * A comprehensive map where the key is the name of a Radix UI component
 * and the value is a function that returns the minimal required JSX wrapper as a string.
 *
 * This map aims to cover all Radix Primitives that require a context provider
 * to prevent runtime errors when rendered in isolation.
 *
 * It provides the *minimal* set of wrappers. In some cases (like for Content areas),
 * you may need to add dummy triggers for the component to be visible, but these
 * wrappers are sufficient to prevent the app from crashing.
 */
const baseRadixWrapperMap: Record<string, (children: string) => string> = {
  // --- Accordion ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/accordion
  'Accordion.Item': (children) =>
    `<CYAccordion.Root type="single" collapsible>${children}</CYAccordion.Root>`,
  'Accordion.Header': (children) =>
    `<CYAccordion.Root type="single" collapsible><CYAccordion.Item value="item-1">${children}</CYAccordion.Item></CYAccordion.Root>`,
  'Accordion.Trigger': (children) =>
    `<CYAccordion.Root type="single" collapsible><CYAccordion.Item value="item-1"><CYAccordion.Header>${children}</CYAccordion.Header></CYAccordion.Item></CYAccordion.Root>`,
  'Accordion.Content': (children) =>
    `<CYAccordion.Root type="single" collapsible><CYAccordion.Item value="item-1">${children}</CYAccordion.Item></CYAccordion.Root>`,

  // --- Alert Dialog ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/alert-dialog
  'AlertDialog.Trigger': (children) =>
    `<CYAlertDialog.Root>${children}</CYAlertDialog.Root>`,
  'AlertDialog.Portal': (children) =>
    `<CYAlertDialog.Root>${children}</CYAlertDialog.Root>`,
  'AlertDialog.Overlay': (children) =>
    `<CYAlertDialog.Root><CYAlertDialog.Portal>${children}</CYAlertDialog.Portal></CYAlertDialog.Root>`,
  'AlertDialog.Content': (children) =>
    `<CYAlertDialog.Root><CYAlertDialog.Portal>${children}</CYAlertDialog.Portal></CYAlertDialog.Root>`,
  'AlertDialog.Title': (children) =>
    `<CYAlertDialog.Root><CYAlertDialog.Portal><CYAlertDialog.Content>${children}</CYAlertDialog.Content></CYAlertDialog.Portal></CYAlertDialog.Root>`,
  'AlertDialog.Description': (children) =>
    `<CYAlertDialog.Root><CYAlertDialog.Portal><CYAlertDialog.Content>${children}</CYAlertDialog.Content></CYAlertDialog.Portal></CYAlertDialog.Root>`,
  'AlertDialog.Action': (children) =>
    `<CYAlertDialog.Root><CYAlertDialog.Portal><CYAlertDialog.Content>${children}</CYAlertDialog.Content></CYAlertDialog.Portal></CYAlertDialog.Root>`,
  'AlertDialog.Cancel': (children) =>
    `<CYAlertDialog.Root><CYAlertDialog.Portal><CYAlertDialog.Content>${children}</CYAlertDialog.Content></CYAlertDialog.Portal></CYAlertDialog.Root>`,

  // --- Avatar ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/avatar
  'Avatar.Image': (children) => `<CYAvatar.Root>${children}</CYAvatar.Root>`,
  'Avatar.Fallback': (children) => `<CYAvatar.Root>${children}</CYAvatar.Root>`,

  // --- Checkbox ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/checkbox
  'Checkbox.Indicator': (children) =>
    `<CYCheckbox.Root>${children}</CYCheckbox.Root>`,

  // --- Collapsible ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/collapsible
  'Collapsible.Trigger': (children) =>
    `<CYCollapsible.Root>${children}</CYCollapsible.Root>`,
  'Collapsible.Content': (children) =>
    `<CYCollapsible.Root>${children}</CYCollapsible.Root>`,

  // --- Context Menu ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/context-menu
  'ContextMenu.Trigger': (children) =>
    `<CYContextMenu.Root>${children}</CYContextMenu.Root>`,
  'ContextMenu.Portal': (children) =>
    `<CYContextMenu.Root>${children}</CYContextMenu.Root>`,
  'ContextMenu.Content': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Portal>${children}</CYContextMenu.Portal></CYContextMenu.Root>`,
  'ContextMenu.Item': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content>${children}</CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.CheckboxItem': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content>${children}</CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.RadioGroup': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content>${children}</CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.RadioItem': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content><CYContextMenu.RadioGroup value="item-1">${children}</CYContextMenu.RadioGroup></CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.ItemIndicator': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content><CYContextMenu.CheckboxItem checked>${children}</CYContextMenu.CheckboxItem></CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.Label': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content>${children}</CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.Separator': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content>${children}</CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.Sub': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content>${children}</CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.SubTrigger': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content><CYContextMenu.Sub>${children}</CYContextMenu.Sub></CYContextMenu.Content></CYContextMenu.Root>`,
  'ContextMenu.SubContent': (children) =>
    `<CYContextMenu.Root><CYContextMenu.Content><CYContextMenu.Sub>${children}</CYContextMenu.Sub></CYContextMenu.Content></CYContextMenu.Root>`,

  // --- Dialog ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/dialog
  'Dialog.Trigger': (children) => `<CYDialog.Root>${children}</CYDialog.Root>`,
  'Dialog.Portal': (children) => `<CYDialog.Root>${children}</CYDialog.Root>`,
  'Dialog.Overlay': (children) =>
    `<CYDialog.Root><CYDialog.Portal>${children}</CYDialog.Portal></CYDialog.Root>`,
  'Dialog.Content': (children) =>
    `<CYDialog.Root><CYDialog.Portal>${children}</CYDialog.Portal></CYDialog.Root>`,
  'Dialog.Title': (children) =>
    `<CYDialog.Root><CYDialog.Portal><CYDialog.Content>${children}</CYDialog.Content></CYDialog.Portal></CYDialog.Root>`,
  'Dialog.Description': (children) =>
    `<CYDialog.Root><CYDialog.Portal><CYDialog.Content>${children}</CYDialog.Content></CYDialog.Portal></CYDialog.Root>`,
  'Dialog.Close': (children) =>
    `<CYDialog.Root><CYDialog.Portal><CYDialog.Content>${children}</CYDialog.Content></CYDialog.Portal></CYDialog.Root>`,

  // --- Dropdown Menu ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/dropdown-menu
  // Note: Dropdown has the same structure as Context Menu
  'DropdownMenu.Trigger': (children) =>
    `<CYDropdownMenu.Root>${children}</CYDropdownMenu.Root>`,
  'DropdownMenu.Portal': (children) =>
    `<CYDropdownMenu.Root>${children}</CYDropdownMenu.Root>`,
  'DropdownMenu.Content': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Portal>${children}</CYDropdownMenu.Portal></CYDropdownMenu.Root>`,
  'DropdownMenu.Item': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content>${children}</CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.CheckboxItem': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content>${children}</CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.RadioGroup': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content>${children}</CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.RadioItem': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content><CYDropdownMenu.RadioGroup value="item-1">${children}</CYDropdownMenu.RadioGroup></CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.ItemIndicator': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content><CYDropdownMenu.CheckboxItem checked>${children}</CYDropdownMenu.CheckboxItem></CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.Label': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content>${children}</CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.Separator': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content>${children}</CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.Sub': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content>${children}</CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.SubTrigger': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content><CYDropdownMenu.Sub>${children}</CYDropdownMenu.Sub></CYDropdownMenu.Content></CYDropdownMenu.Root>`,
  'DropdownMenu.SubContent': (children) =>
    `<CYDropdownMenu.Root><CYDropdownMenu.Content><CYDropdownMenu.Sub>${children}</CYDropdownMenu.Sub></CYDropdownMenu.Content></CYDropdownMenu.Root>`,

  // --- Form ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/form
  'Form.Field': (children) => `<CYForm.Root>${children}</CYForm.Root>`,
  'Form.Label': (children) =>
    `<CYForm.Root><CYForm.Field name="test-field">${children}</CYForm.Field></CYForm.Root>`,
  'Form.Control': (children) =>
    `<CYForm.Root><CYForm.Field name="test-field">${children}</CYForm.Field></CYForm.Root>`,
  'Form.Message': (children) =>
    `<CYForm.Root><CYForm.Field name="test-field">${children}</CYForm.Field></CYForm.Root>`,
  'Form.ValidityState': (children) =>
    `<CYForm.Root><CYForm.Field name="test-field">${children}</CYForm.Field></CYForm.Root>`,
  'Form.Submit': (children) => `<CYForm.Root>${children}</CYForm.Root>`,

  // --- Hover Card ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/hover-card
  'HoverCard.Trigger': (children) =>
    `<CYHoverCard.Root>${children}</CYHoverCard.Root>`,
  'HoverCard.Portal': (children) =>
    `<CYHoverCard.Root>${children}</CYHoverCard.Root>`,
  'HoverCard.Content': (children) =>
    `<CYHoverCard.Root><CYHoverCard.Portal>${children}</CYHoverCard.Portal></CYHoverCard.Root>`,

  // --- Menubar ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/menubar
  'Menubar.Menu': (children) => `<CYMenubar.Root>${children}</CYMenubar.Root>`,
  'Menubar.Trigger': (children) =>
    `<CYMenubar.Root><CYMenubar.Menu>${children}</CYMenubar.Menu></CYMenubar.Root>`,
  'Menubar.Portal': (children) =>
    `<CYMenubar.Root><CYMenubar.Menu>${children}</CYMenubar.Menu></CYMenubar.Root>`,
  'Menubar.Content': (children) =>
    `<CYMenubar.Root><CYMenubar.Menu>${children}</CYMenubar.Menu></CYMenubar.Root>`,
  'Menubar.Item': (children) =>
    `<CYMenubar.Root><CYMenubar.Menu><CYMenubar.Content>${children}</CYMenubar.Content></CYMenubar.Menu></CYMenubar.Root>`,
  // Other Menubar items follow the same pattern as Dropdown/Context Menu...

  // --- Navigation Menu ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/navigation-menu
  'NavigationMenu.List': (children) =>
    `<CYNavigationMenu.Root>${children}</CYNavigationMenu.Root>`,
  'NavigationMenu.Item': (children) =>
    `<CYNavigationMenu.Root><CYNavigationMenu.List>${children}</CYNavigationMenu.List></CYNavigationMenu.Root>`,
  'NavigationMenu.Trigger': (children) =>
    `<CYNavigationMenu.Root><CYNavigationMenu.List><CYNavigationMenu.Item>${children}</CYNavigationMenu.Item></CYNavigationMenu.List></CYNavigationMenu.Root>`,
  'NavigationMenu.Content': (children) =>
    `<CYNavigationMenu.Root><CYNavigationMenu.List><CYNavigationMenu.Item><CYNavigationMenu.Trigger />{/* Dummy trigger for context */}${children}</CYNavigationMenu.Item></CYNavigationMenu.List></CYNavigationMenu.Root>`,
  'NavigationMenu.Link': (children) =>
    `<CYNavigationMenu.Root><CYNavigationMenu.List><CYNavigationMenu.Item>${children}</CYNavigationMenu.Item></CYNavigationMenu.List></CYNavigationMenu.Root>`,
  'NavigationMenu.Indicator': (children) =>
    `<CYNavigationMenu.Root><CYNavigationMenu.List><CYNavigationMenu.Item><CYNavigationMenu.Trigger />{/* Dummy trigger for context */}</CYNavigationMenu.Item>${children}</CYNavigationMenu.List></CYNavigationMenu.Root>`,
  'NavigationMenu.Viewport': (children) =>
    `<CYNavigationMenu.Root>${children}</CYNavigationMenu.Root>`,

  // --- Popover ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/popover
  'Popover.Trigger': (children) =>
    `<CYPopover.Root>${children}</CYPopover.Root>`,
  'Popover.Portal': (children) =>
    `<CYPopover.Root>${children}</CYPopover.Root>`,
  'Popover.Content': (children) =>
    `<CYPopover.Root><CYPopover.Portal>${children}</CYPopover.Portal></CYPopover.Root>`,
  'Popover.Close': (children) =>
    `<CYPopover.Root><CYPopover.Content>${children}</CYPopover.Content></CYPopover.Root>`,
  'Popover.Anchor': (children) =>
    `<CYPopover.Root>${children}</CYPopover.Root>`,

  // --- Progress ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/progress
  'Progress.Indicator': (children) =>
    `<CYProgress.Root value={50}>${children}</CYProgress.Root>`,

  // --- Radio Group ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/radio-group
  'RadioGroup.Item': (children) =>
    `<CYRadioGroup.Root>${children}</CYRadioGroup.Root>`,
  'RadioGroup.Indicator': (children) =>
    `<CYRadioGroup.Root><CYRadioGroup.Item value="item-1">${children}</CYRadioGroup.Item></CYRadioGroup.Root>`,

  // --- Scroll Area ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/scroll-area
  'ScrollArea.Viewport': (children) =>
    `<CYScrollArea.Root>${children}</CYScrollArea.Root>`,
  'ScrollArea.Scrollbar': (children) =>
    `<CYScrollArea.Root>${children}</CYScrollArea.Root>`,
  'ScrollArea.Thumb': (children) =>
    `<CYScrollArea.Root><CYScrollArea.Scrollbar orientation="vertical">${children}</CYScrollArea.Scrollbar></CYScrollArea.Root>`,
  'ScrollArea.Corner': (children) =>
    `<CYScrollArea.Root>${children}</CYScrollArea.Root>`,

  // --- Select ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/select
  'Select.Trigger': (children) => `<CYSelect.Root>${children}</CYSelect.Root>`,
  'Select.Value': (children) =>
    `<CYSelect.Root><CYSelect.Trigger>${children}</CYSelect.Trigger></CYSelect.Root>`,
  'Select.Icon': (children) =>
    `<CYSelect.Root><CYSelect.Trigger>${children}</CYSelect.Trigger></CYSelect.Root>`,
  'Select.Portal': (children) => `<CYSelect.Root>${children}</CYSelect.Root>`,
  'Select.Content': (children) =>
    `<CYSelect.Root><CYSelect.Portal>${children}</CYSelect.Portal></CYSelect.Root>`,
  'Select.Viewport': (children) =>
    `<CYSelect.Root><CYSelect.Content>${children}</CYSelect.Content></CYSelect.Root>`,
  'Select.Item': (children) =>
    `<CYSelect.Root><CYSelect.Content>${children}</CYSelect.Content></CYSelect.Root>`,
  'Select.ItemText': (children) =>
    `<CYSelect.Root><CYSelect.Content><CYSelect.Item value="item-1">${children}</CYSelect.Item></CYSelect.Content></CYSelect.Root>`,
  'Select.ItemIndicator': (children) =>
    `<CYSelect.Root><CYSelect.Content><CYSelect.Item value="item-1">${children}</CYSelect.Item></CYSelect.Content></CYSelect.Root>`,
  'Select.Group': (children) =>
    `<CYSelect.Root><CYSelect.Content>${children}</CYSelect.Content></CYSelect.Root>`,
  'Select.Label': (children) =>
    `<CYSelect.Root><CYSelect.Content><CYSelect.Group>${children}</CYSelect.Group></CYSelect.Content></CYSelect.Root>`,
  'Select.Separator': (children) =>
    `<CYSelect.Root><CYSelect.Content>${children}</CYSelect.Content></CYSelect.Root>`,

  // --- Slider ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/slider
  'Slider.Track': (children) => `<CYSlider.Root>${children}</CYSlider.Root>`,
  'Slider.Range': (children) =>
    `<CYSlider.Root><CYSlider.Track>${children}</CYSlider.Track></CYSlider.Root>`,
  'Slider.Thumb': (children) => `<CYSlider.Root>${children}</CYSlider.Root>`,

  // --- Switch ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/switch
  'Switch.Thumb': (children) => `<CYSwitch.Root>${children}</CYSwitch.Root>`,

  // --- Tabs ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/tabs
  'Tabs.List': (children) =>
    `<CYTabs.Root defaultValue="tab1">${children}</CYTabs.Root>`,
  'Tabs.Trigger': (children) =>
    `<CYTabs.Root defaultValue="tab1"><CYTabs.List>${children}</CYTabs.List></CYTabs.Root>`,
  'Tabs.Content': (children) =>
    `<CYTabs.Root defaultValue="tab1">${children}</CYTabs.Root>`,

  // --- Toast ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/toast
  'Toast.Root': (children) =>
    `<CYToast.Provider>${children}</CYToast.Provider>`,
  'Toast.Title': (children) =>
    `<CYToast.Provider><CYToast.Root>${children}</CYToast.Root></CYToast.Provider>`,
  'Toast.Description': (children) =>
    `<CYToast.Provider><CYToast.Root>${children}</CYToast.Root></CYToast.Provider>`,
  'Toast.Action': (children) =>
    `<CYToast.Provider><CYToast.Root>${children}</CYToast.Root></CYToast.Provider>`,
  'Toast.Close': (children) =>
    `<CYToast.Provider><CYToast.Root>${children}</CYToast.Root></CYToast.Provider>`,
  'Toast.Viewport': (children) =>
    `<CYToast.Provider>${children}</CYToast.Provider>`,

  // --- Toggle Group ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/toggle-group
  'ToggleGroup.Item': (children) =>
    `<CYToggleGroup.Root type="single">${children}</CYToggleGroup.Root>`,

  // --- Toolbar ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/toolbar
  'Toolbar.Button': (children) =>
    `<CYToolbar.Root>${children}</CYToolbar.Root>`,
  'Toolbar.Link': (children) => `<CYToolbar.Root>${children}</CYToolbar.Root>`,
  'Toolbar.Separator': (children) =>
    `<CYToolbar.Root>${children}</CYToolbar.Root>`,
  'Toolbar.ToggleGroup': (children) =>
    `<CYToolbar.Root>${children}</CYToolbar.Root>`,
  'Toolbar.ToggleItem': (children) =>
    `<CYToolbar.Root><CYToolbar.ToggleGroup type="single">${children}</CYToolbar.ToggleGroup></CYToolbar.Root>`,

  // --- Tooltip ---
  // Docs: https://www.radix-ui.com/primitives/docs/components/tooltip
  // Tooltip requires a Provider at the app root level.
  'Tooltip.Root': (children) =>
    `<CYTooltip.Provider>${children}</CYTooltip.Provider>`,
  'Tooltip.Trigger': (children) =>
    `<CYTooltip.Provider><CYTooltip.Root>${children}</CYTooltip.Root></CYTooltip.Provider>`,
  'Tooltip.Portal': (children) =>
    `<CYTooltip.Provider><CYTooltip.Root>${children}</CYTooltip.Root></CYTooltip.Provider>`,
  'Tooltip.Content': (children) =>
    `<CYTooltip.Provider><CYTooltip.Root><CYTooltip.Portal>${children}</CYTooltip.Portal></CYTooltip.Root></CYTooltip.Provider>`,
  'Tooltip.Arrow': (children) =>
    `<CYTooltip.Provider><CYTooltip.Root><CYTooltip.Content>${children}</CYTooltip.Content></CYTooltip.Root></CYTooltip.Provider>`,
};

// Create the final map with aliases
const radixWrapperMap = createAliases(baseRadixWrapperMap);

/**
 * Identifies a Radix UI component from a JSX string and wraps it with
 * its necessary parent providers to prevent context errors.
 *
 * @param componentContent - A string containing the JSX of a single component.
 * @returns The original JSX string wrapped in its required Radix providers,
 * or the original string if no specific wrapper is defined.
 */
export default function handleRadix(componentContent: string): string {
  // This regex finds the component name, e.g., "NavigationMenuTrigger" or "DropdownMenu.Item"
  const componentNameMatch = componentContent.match(/< *([A-Z][A-Za-z0-9\.]*)/);

  if (!componentNameMatch || !componentNameMatch[1]) {
    return componentContent;
  }

  const componentName = componentNameMatch[1];

  const wrapperFn = radixWrapperMap[componentName];

  if (wrapperFn) {
    return wrapperFn(componentContent);
  }

  return componentContent;
}
