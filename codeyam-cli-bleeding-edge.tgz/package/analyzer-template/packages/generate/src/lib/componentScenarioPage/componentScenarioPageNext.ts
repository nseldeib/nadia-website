import { Entity, Analysis, type File, type Scenario } from '~codeyam/types';
import getComponentImportStatement from '../getComponentImportStatement';
import scenarioComponent from '../scenarioComponent';
import escapeQuotes from '../escapeQuotes';
import getIFrameMessageListenerCode from './getIFrameMessageListenerCode';
import getImageReplacementCode from './getImageReplacementCode';
import getNextJsErrorClosingCode from './getNextJsErrorClosingCode';

const VERSION = '0.5.1';

export default function componentScenarioPageNext({
  file,
  entity,
  analysis,
  currentPath,
  appPath,
  scenario,
  relativeMocksDir,
}: {
  file: File;
  entity: Entity;
  analysis: Analysis;
  currentPath: string;
  appPath: string;
  scenario: Scenario;
  relativeMocksDir: string;
}) {
  const fileName = file.name.split('.')[0];

  return `/* eslint-disable */
  "use client";
  import { 
  useCallback, 
  useEffect,
  useMemo, 
  useState,
  useRef,
  type ReactNode,
  type ChangeEvent
} from 'react';
import Head from 'next/head';
${analysis.scenarios?.length > 0 && `import { scenarios } from "${relativeMocksDir}/MockData";`}
${getComponentImportStatement({
  file,
  entity,
  analysis,
  currentPath,
  appPath,
  scenario,
  primary: true,
  namedExport:
    entity.name !== 'default' &&
    (entity.metadata.notExported || entity.metadata?.namedExport) &&
    entity.entityType !== 'library',
})}


const NextHead = () => {
  return (
    <Head>
      <title>${fileName}: ${escapeQuotes(scenario.name)} CodeYam Demo v${VERSION}</title>
      <meta name="description" content="This is a demo of the ${fileName} component" />
    </Head>
  )
};

function Scenario({ name, width, children }: { name: string, width: string, children: ReactNode }) {
  
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const calculateHeight = () => {
      const bodyHeight = document.body.offsetHeight;
      const htmlHeight = document.documentElement.offsetHeight;
      const scrollHeight = Math.max(
        document.body.scrollHeight,
        document.documentElement.scrollHeight,
        document.body.offsetHeight,
        document.documentElement.offsetHeight,
        document.body.clientHeight,
        document.documentElement.clientHeight
      );

      // TODO: consider a better fallback height
      return Math.max(100, bodyHeight, htmlHeight, scrollHeight);
    }

    const height = calculateHeight();
    parent.postMessage({ type: 'codeyam-resize', name, height }, '*');

    const eventListener = (event) => {
      if (event.data.name === name) {
        if (event.data.type === 'codeyam-respond') {
          const height = calculateHeight();
          parent.postMessage({ type: 'codeyam-resize', name, height }, '*');
        }
      }
    };

    window.addEventListener('message', eventListener)
    return () => window.removeEventListener('message', eventListener);
  }, [name])

  return (
    <div className='w-full flex items-center justify-center'>
      <div id='component' style={{ width: width }}>
        {children}
      </div>
    </div>
  );
}

export default function Index() {
  ${getIFrameMessageListenerCode({ scenarioName: scenario.name })}
  ${getImageReplacementCode()}
  ${getNextJsErrorClosingCode()}

  return (
    <div className='flex flex-col justify-center items-center h-screen' data-version={version}>
      <NextHead />
      ${scenarioComponent(entity, analysis, scenario)}
    </div>
  );
}`;
}
