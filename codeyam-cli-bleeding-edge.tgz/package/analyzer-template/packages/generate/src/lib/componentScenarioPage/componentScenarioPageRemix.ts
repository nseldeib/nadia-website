import { Analysis, Entity, type File, type Scenario } from '~codeyam/types';
import scenarioComponent from '../scenarioComponent';
import getComponentImportStatement from '../getComponentImportStatement';
import escapeQuotes from '../escapeQuotes';
import getIFrameMessageListenerCode from './getIFrameMessageListenerCode';
import getImageReplacementCode from './getImageReplacementCode';

const VERSION = '0.5.1';

export default function componentScenarioPageRemix(
  file: File,
  entity: Entity,
  analysis: Analysis,
  currentPath: string,
  appPath: string,
  scenario: Scenario,
  mocksDir: string,
) {
  return `import { ReactNode, useEffect, useCallback, useState } from 'react';
import type { MetaFunction } from "@remix-run/node";
${analysis.scenarios?.length > 0 && `import { scenarios } from "${mocksDir}/MockData";`}
${getComponentImportStatement({
  file,
  entity,
  analysis,
  scenario,
  currentPath,
  appPath,
  primary: true,
  namedExport:
    entity.name !== 'default' &&
    (entity.metadata.notExported || entity.metadata?.namedExport) &&
    entity.entityType !== 'library',
})}

export const meta: MetaFunction = () => {
  return [
    { title: "${file.name}: ${escapeQuotes(scenario.name)} CodeYam Demo v${VERSION}" },
    { name: "description", content: "This is a demo of the ${file.name} component under the scenario: ${escapeQuotes(scenario.description)}" },
  ];
};

function Scenario({ name, width, children }: { name: string, width: string, children: ReactNode }) {
  
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const calculateHeight = () => {
      const bodyHeight = document.body.offsetHeight;
      const htmlHeight = document.documentElement.offsetHeight;
      const scrollHeight = Math.max(
        document.body.scrollHeight,
        document.documentElement.scrollHeight,
        document.body.offsetHeight,
        document.documentElement.offsetHeight,
        document.body.clientHeight,
        document.documentElement.clientHeight
      );

      // TODO: consider a better fallback height
      return Math.max(100, bodyHeight, htmlHeight, scrollHeight);
    }

    const height = calculateHeight();
    parent.postMessage({ type: 'codeyam-resize', name, height }, '*');

    const eventListener = (event) => {
      if (event.data.name === name) {
        if (event.data.type === 'codeyam-respond') {
          const height = calculateHeight();
          parent.postMessage({ type: 'codeyam-resize', name, height }, '*');
        }
      }
    };

    window.addEventListener('message', eventListener)
    return () => window.removeEventListener('message', eventListener);
  }, [name])

  return (
    <div className='w-full flex items-center justify-center'>
      <div id='component' style={{ width: width }}>
        {children}
      </div>
    </div>
  );
}

export default function Index() {
  ${getIFrameMessageListenerCode({ scenarioName: scenario.name })}
  ${getImageReplacementCode()}

  return (
    <div className='flex flex-col justify-center items-center h-screen' data-version={version}>
      ${scenarioComponent(entity, analysis, scenario)}
    </div>
  );
}`;
}
