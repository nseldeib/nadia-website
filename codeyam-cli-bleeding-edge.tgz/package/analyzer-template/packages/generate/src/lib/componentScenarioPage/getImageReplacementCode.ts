import { PLACEHOLDER_IMAGE_SRC } from '../constants';

export default function getImageReplacementCode() {
  return `useEffect(() => {
  if (typeof window === 'undefined' || !document.body) return;

  const checkImageSrc = async (src) => {
    try {
      const response = await fetch(src, { method: 'HEAD' });
      return response.ok;
    } catch {
      return false;
    }
  };

  const updateImageSrc = async (img) => {
    const originalSrc = img.src;
    
    // Don't check if it's already the placeholder
    if (originalSrc === "${PLACEHOLDER_IMAGE_SRC}") return;

    // Check if original source exists
    const exists = await checkImageSrc(originalSrc);
    if (!exists) {
      img.src = "${PLACEHOLDER_IMAGE_SRC}";
      return;
    }
  };

  const protectImage = (img) => {
    if (img.dataset.protected) return;
      
    img.dataset.protected = 'true';

    const handleError = () => {
      if (img.src !== "${PLACEHOLDER_IMAGE_SRC}") {
        img.src = "${PLACEHOLDER_IMAGE_SRC}";
      }
    };

    img.removeEventListener('error', handleError);    
    img.addEventListener('error', handleError);

    if (!img.complete || img.naturalHeight === 0) {
      handleError();
    }

    const descriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    if (descriptor && !img.dataset.srcProtected) {
      img.dataset.srcProtected = 'true';
      Object.defineProperty(img, 'src', {
        ...descriptor,
        set(value) {
          if (value !== "${PLACEHOLDER_IMAGE_SRC}") {
            const img = new Image();
            img.onload = () => descriptor.set.call(this, value);
            img.onerror = () => descriptor.set.call(this, "${PLACEHOLDER_IMAGE_SRC}");
            img.src = value;
          } else {
            descriptor.set.call(this, value);
          }
        }
      });
    }

    updateImageSrc(img);
  };

  const checkExistingImages = () => {
    const images = document.querySelectorAll("img");
    images.forEach(img => protectImage(img));
  };

  checkExistingImages();

  const safetyCheckInterval = setInterval(checkExistingImages, 1000);
  
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
        mutation.addedNodes.forEach(node => {
          if ("tagName" in node && node.tagName === 'IMG') {
            protectImage(node);
          } else if ("querySelectorAll" in node && node.querySelectorAll && typeof node.querySelectorAll === 'function') {
            const nestedImages = node.querySelectorAll('img');
            nestedImages.forEach(nestedImg => {
              protectImage(nestedImg);
            });
          }
        });
      }

      if (
        mutation.type === "attributes" && 
        mutation.attributeName === "src" && 
        mutation.target instanceof HTMLImageElement
      ) {
        protectImage(mutation.target);
      }
    });
  });

  observer.observe(document.body, { 
    attributes: true, 
    attributeFilter: ['src'],  // Only watch src changes
    childList: true, 
    subtree: true 
  });

  return () => {
    observer.disconnect();
    clearInterval(safetyCheckInterval);
  };
}, []);
  `;
}
