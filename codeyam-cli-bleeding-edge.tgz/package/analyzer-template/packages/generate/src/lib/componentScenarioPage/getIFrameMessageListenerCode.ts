export default function getIFrameMessageListenerCode({
  scenarioName,
}: {
  scenarioName: string;
}): string {
  return `const [version, setVersion] = useState(1);

  function _getScenarioProps({ argumentIndex, propName }: { argumentIndex: number, propName?: string }) {
    const argument = scenarios().data()['arguments'][argumentIndex];
    return propName ? argument[propName] : argument;
  }

  const respond = useCallback((message) => {
    try {
      window.parent.postMessage({ 
        type: 'codeyam-update', 
        name: '${scenarioName}',
        message,
      }, '*');
    } catch (e) {
      console.warn('Error posting message to parent', message, e);
    }
  }, [])

  useEffect(() => {
    const eventListener = (event) => {
      if (event.data.type === 'codeyam-override-data') {
        const parsedData = JSON.parse(event.data.data);
        console.log("Override data received");
        respond("Set override data to " + JSON.stringify(parsedData, null, 2));
        scenarios().updateData('${scenarioName}', parsedData);
        setVersion(prev => prev + 1);
      }
    }
    window.addEventListener('message', eventListener)

    return () => window.removeEventListener('message', eventListener)
  }, [respond])
  
  useEffect(() => {
    const oldConsoleLog = console.log;
    console.log = function(...args) {
      oldConsoleLog(...args);
      try {
        window.parent.postMessage({
          type: 'codeyam-log',
          name: '${scenarioName}',
          data: {
            log: {
              name: "console.log",
              args 
            } 
          }
        }, '*');
      } catch (e) {
        oldConsoleLog('Error posting message to parent', e);
      }      
    }

    const oldConsoleError = console.error;
    console.error = function(...args) {
      oldConsoleError(...args);
      window.parent.postMessage({
        type: 'codeyam-log',
        name: '${scenarioName}',
        data: {
          log: {
            name: "console.log",
            args 
          } 
        }
      }, '*');
    }

    return () => {
      console.log = oldConsoleLog;
      console.error = oldConsoleError;
    }
  }, []);
`;
}
