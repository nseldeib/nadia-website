export default function getNextJsErrorClosingCode() {
  return `useEffect(() => {
  const closeNextJsError = () => {
    const safeQuerySelector = (parent, selector) => {
      try {
        return parent.querySelector(selector);
      } catch (e) {
        return null;
      }
    };

    const safeClick = (element) => {
      if (!element) return false;
      try {
        element.click();
        return true;
      } catch (e) {
        return false;
      }
    };

    const closeButtonSelectors = [
      '[data-nextjs-errors-dialog-left-right-close-button]',
      '[data-nextjs-dialog-close-button]',
      'button[aria-label="Close"]',
      '[role="button"][aria-label="Close"]',
      '.nextjs-toast-errors-parent [aria-label="Close"]'
    ];

    const portals = document.querySelectorAll('nextjs-portal');
    for (const portal of portals) {
      if (typeof window !== 'undefined' && window.location.search.includes('screenshot')) {
        portal.setAttribute('style', 'display: none !important');
      }
      const shadow = portal.shadowRoot;
      if (shadow) {
        for (const selector of closeButtonSelectors) {
          if (safeClick(safeQuerySelector(shadow, selector))) {
            return true;
          }
        }
      }
    }

    for (const selector of closeButtonSelectors) {
      if (safeClick(document.querySelector(selector))) {
        return true;
      }
    }

    return false;
  };

  let attempts = 0;
  const interval = setInterval(() => {
    closeNextJsError();
    ++attempts;
    if (attempts >= 10) {
      clearInterval(interval);
    }
  }, 500);

  return () => clearInterval(interval);
}, []);
`;
}
