export default function escapeQuotes(s: string | null | undefined): string {
  return s ? s.replace(/"/g, '&quot;').replace(/'/g, '&#39;') : '';
}
