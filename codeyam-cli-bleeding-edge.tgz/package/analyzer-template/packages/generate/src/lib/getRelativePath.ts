import { PROJECT_RELATIVE_PATH } from '~codeyam/utils';

function normalizeToProjectRoot(pathString: string) {
  const projectPrefix = PROJECT_RELATIVE_PATH + '/'; // '../project/'

  if (pathString.startsWith(projectPrefix)) {
    return pathString.slice(projectPrefix.length);
  }

  return pathString; // Return unchanged if no project prefix
}

export default function getRelativePath(filePath: string, importPath: string) {
  // Normalize both paths to project root reference
  const normalizedFilePath = normalizeToProjectRoot(filePath);
  const normalizedImportPath = normalizeToProjectRoot(importPath);

  const filePathParts = normalizedFilePath.split('/');
  const importPathParts = normalizedImportPath.split('/');

  const filePathFolders = filePathParts.slice(0, -1);
  const importPathFolders = importPathParts.slice(0, -1);

  let i = 0;
  while (i < filePathFolders.length && i < importPathFolders.length) {
    if (filePathFolders[i] !== importPathFolders[i]) {
      break;
    }
    i++;
  }

  const backSteps = filePathFolders.slice(i);
  const forwardSteps = importPathParts.slice(i);

  const relativePath = backSteps.map(() => '..').concat(forwardSteps);

  if (relativePath[0] !== '..') {
    relativePath.splice(0, 0, '.');
  }

  return relativePath.join('/').replace(/\/$/, '');
}
