import { Analysis, Entity, File, Scenario } from '~codeyam/types';
import getComponentScenarioPath from './getComponentScenarioPath';
import { safeFileName } from '~codeyam/utils';
import requiredNodeModuleImports from './requiredNodeModuleImports';

export interface GetComponentImportStatementsArgs {
  file: File;
  entity: Entity;
  analysis: Analysis;
  currentPath: string;
  appPath: string;
  scenario?: Scenario;
  primary?: boolean;
  namedExport?: boolean;
}

export default function getComponentImportStatement({
  file,
  entity,
  analysis,
  currentPath,
  appPath,
  scenario,
  primary,
  namedExport,
}: GetComponentImportStatementsArgs) {
  const importStatements: string[] = [];

  let entityName =
    primary && entity.entityType === 'library'
      ? safeFileName(entity.name)
      : entity.name;

  const componentScenarioPath = getComponentScenarioPath(
    file,
    entity,
    currentPath,
    appPath,
    scenario,
    primary,
  );

  if (namedExport) {
    importStatements.push(
      `import { ${entityName} } from "${componentScenarioPath}";`,
    );
  } else {
    if (entityName === 'default') {
      entityName =
        entity.entityType === 'library' ? 'defaultExport' : 'DefaultExport';
    }
    importStatements.push(
      `import ${entityName} from "${componentScenarioPath}";`,
    );
  }

  importStatements.push(...requiredNodeModuleImports(analysis));

  return importStatements.join('\n');
}
