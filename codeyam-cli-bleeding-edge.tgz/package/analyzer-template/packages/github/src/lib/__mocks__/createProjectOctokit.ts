import { Octokit } from '@octokit/rest';
import { Project } from '~codeyam/types';

export const createProjectOctokit = jest.fn().mockImplementation((project: Project): Octokit => {
  return new Octokit({
    auth: 'mock-token',
  });
});

export const getProjectGitToken = jest.fn().mockResolvedValue('mock-token');