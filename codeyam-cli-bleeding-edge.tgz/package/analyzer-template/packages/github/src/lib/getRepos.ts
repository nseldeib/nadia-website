import { GH_API_VERSION_HEADER } from './constants';
import { createProjectOctokit } from './createProjectOctokit';
import { Project } from '~codeyam/types';

export interface RepoInfo {
  owner: string;
  repo: string;
  treeSha: string;
}

export interface RepoData {
  name: string;
  owner: {
    login: string;
  };
}

export interface GetRepoProps {
  project: Project;
}

export default async function getRepos({
  project,
}: GetRepoProps): Promise<RepoData[]> {
  const octokit = createProjectOctokit(project);

  const { data: repos } = await octokit.request(`GET /user/repos`, {
    per_page: 100,
    // uncomment to get repos where the user is a collaborator
    // affiliation: 'collaborator',
    headers: GH_API_VERSION_HEADER,
  });

  return repos;
}
