import { Octokit } from '@octokit/rest';

export default async function getFirstCommitShaAfterTimestamp(
  path: string,
  token: string,
  timestamp: string,
): Promise<string | null> {
  const octokit = new Octokit({ auth: token });

  try {
    const response = await octokit.request(`GET /repos/${path}/commits`, {
      since: timestamp,
    });

    if (response.data.length > 0) {
      // The last commit in the array should be the earliest after the specified timestamp
      const lastCommitIndex = response.data.length - 1;
      return response.data[lastCommitIndex].sha;
    } else {
      return null; // No commits found after the given timestamp
    }
  } catch (error) {
    console.log('Error fetching commits: ', error);
    return null;
  }
}
