import { Project } from '~codeyam/types';
import { createProjectOctokit } from './createProjectOctokit';

export default async function getPullRequestsForCommit({
  project,
  commitSha,
}: {
  project: Project;
  commitSha: string;
}) {
  const octokit = createProjectOctokit(project);

  const [owner, repo] = project.path.split('/');

  try {
    const { data } =
      await octokit.rest.repos.listPullRequestsAssociatedWithCommit({
        owner,
        repo,
        commit_sha: commitSha,
      });
    return data;
  } catch (e) {
    console.error('Error getting pull requests for commit', {
      commitSha,
      e,
    });
    return [];
  }
}
