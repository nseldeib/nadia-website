import { GitHubFile, GithubTreeInfo, Project } from '~codeyam/types';
import { GH_API_VERSION_HEADER } from './constants';
import { createProjectOctokit } from './createProjectOctokit';

export interface GetTreeProps extends GithubTreeInfo {
  project: Project;
}

export default async function getTree({
  project,
  owner,
  name,
  treeSha,
}: GetTreeProps): Promise<GitHubFile[]> {
  const octokit = createProjectOctokit(project);

  const response = await octokit.request(
    `GET /repos/${owner}/${name}/git/trees/${treeSha}`,
    {
      owner,
      repo: name,
      tree_sha: treeSha,
      recursive: 'true',
      headers: GH_API_VERSION_HEADER,
    },
  );

  return response.data.tree as GitHubFile[];
}
