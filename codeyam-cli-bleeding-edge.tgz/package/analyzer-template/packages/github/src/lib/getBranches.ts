import { GithubBranch, GithubRepoInfo, Project } from '~codeyam/types';
import { GH_API_VERSION_HEADER } from './constants';
import { createProjectOctokit } from './createProjectOctokit';

export interface GetBranchesProps extends GithubRepoInfo {
  project: Project;
}

export default async function getBranches({
  project,
  owner,
  name,
}: GetBranchesProps): Promise<GithubBranch[]> {
  const octokit = createProjectOctokit(project);

  const { data } = await octokit.request(
    `GET /repos/${owner}/${name}/branches`,
    {
      per_page: 100,
      headers: GH_API_VERSION_HEADER,
    },
  );

  return data.map((branch: { name: string; commit: { sha: string } }) => ({
    name: branch.name,
    sha: branch.commit.sha,
  }));
}
