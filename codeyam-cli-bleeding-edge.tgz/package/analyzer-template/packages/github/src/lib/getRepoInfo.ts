import { Project } from '~codeyam/types';
import { createProjectOctokit } from './createProjectOctokit';

export interface RepoInfo {
  name: string;
  fullName: string;
  description: string;
  htmlUrl: string;
  cloneUrl: string;
  sshUrl: string;
  defaultBranch: string;
  private: boolean;
  fork: boolean;
  createdAt: string;
  updatedAt: string;
  pushedAt: string;
  owner: string;
}

export default async function getRepoInfo({
  project,
}: {
  project: Project;
}): Promise<RepoInfo | null> {
  const octokit = createProjectOctokit(project);
  const [owner, repo] = project.path.split('/');

  try {
    const { data } = await octokit.rest.repos.get({
      owner,
      repo,
    });
    return {
      name: data.name,
      fullName: data.full_name,
      description: data.description,
      htmlUrl: data.html_url,
      cloneUrl: data.clone_url,
      sshUrl: data.ssh_url,
      defaultBranch: data.default_branch,
      private: data.private,
      fork: data.fork,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
      pushedAt: data.pushed_at,
      owner: data.owner.login,
    };
  } catch (e) {
    console.error('Error retrieving repo info', {
      slug: project.slug,
      owner,
      repo,
    });
    return null;
  }
}
