import { RestEndpointMethodTypes } from '@octokit/rest';
import { Commit } from '~codeyam/types';

export type CommitData =
  RestEndpointMethodTypes['repos']['getCommit']['response']['data'];

export default function githubToCommit(commitData: CommitData): Commit {
  return {
    url: commitData.url,
    sha: commitData.sha,
    htmlUrl: commitData.html_url,
    parents: (commitData.parents ?? []).map((parent) => parent.sha),
    author: {
      username: commitData.author?.login ?? undefined,
      avatarUrl: commitData.author?.avatar_url,
    },
    message: commitData.commit.message,
    committedAt: commitData.commit.author?.date ?? undefined,
    files: (commitData.files ?? []).map((file) => ({
      fileName: file.filename,
      status: file.status,
      patch: file.patch,
    })),
  };
}
