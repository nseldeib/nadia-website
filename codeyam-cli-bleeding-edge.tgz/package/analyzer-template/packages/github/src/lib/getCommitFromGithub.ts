import { PLACEHOLDER_IMAGE_SRC } from '~codeyam/generate';
import { Commit, Project } from '~codeyam/types';
import syncHeadBranches from './syncHeadBranches';
import { createProjectOctokit } from './createProjectOctokit';

export default async function getCommitFromGithub(
  project: Project,
  commitSha: string,
): Promise<{ commit: Commit; branchName: string }> {
  const octokit = createProjectOctokit(project);

  const [owner, repo] = project.path.split('/');

  let commitData;
  try {
    const { data } = await octokit.rest.repos.getCommit({
      owner,
      repo,
      ref: commitSha,
    });
    commitData = data;
  } catch (error) {
    console.log('Error getting commit data', error);
    return { commit: null, branchName: null };
  }

  let author = {
    username: commitData.author?.login,
    avatarUrl: commitData.author?.avatar_url,
  };

  if (!author?.username) {
    const { data: commitData2 } = await octokit.rest.git.getCommit({
      owner,
      repo,
      commit_sha: commitSha,
    });
    author = {
      username: `${commitData2.author.name} ${commitData2.author.email}`,
      avatarUrl: PLACEHOLDER_IMAGE_SRC,
    };
  }

  const newBranches = await syncHeadBranches({ project, commitSha });
  project.branches = [...(project.branches ?? []), ...newBranches];
  const branch = newBranches[0];

  const commit: Commit = {
    url: commitData.url,
    sha: commitData.sha,
    htmlUrl: commitData.html_url,
    branchId: branch?.id,
    branch,
    parents: (commitData.parents ?? []).map((parent) => parent.sha),
    author,
    message: commitData.commit.message,
    committedAt: commitData.commit.author?.date ?? undefined,
    files: (commitData.files ?? []).map((file) => ({
      fileName: file.filename,
      status: file.status,
      patch: file.patch,
      previousFileName: file.previous_filename,
    })),
  };

  return { commit, branchName: branch?.name };
}
