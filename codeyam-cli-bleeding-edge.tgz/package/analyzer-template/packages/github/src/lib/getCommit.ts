import { Octokit } from '@octokit/rest';
import { GH_API_VERSION_HEADER } from './constants';
import type { Commit } from '~codeyam/types';
import githubToCommit from './githubToCommit';

export default async function getCommit({
  octokit,
  owner,
  repo,
  commitSha,
}: {
  octokit: Octokit;
  owner: string;
  repo: string;
  commitSha: string;
}): Promise<Commit> {
  const { data: commitData } = await octokit.rest.repos.getCommit({
    owner,
    repo,
    ref: commitSha,
    headers: GH_API_VERSION_HEADER,
  });

  return githubToCommit(commitData);
}
