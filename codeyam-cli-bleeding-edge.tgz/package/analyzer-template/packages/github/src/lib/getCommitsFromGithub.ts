import { getSupabase } from '~codeyam/supabase';
import { Project } from '~codeyam/types';
import { createProjectOctokit } from './createProjectOctokit';

export interface GitHubCommitInfo {
  sha: string;
  branchName: string;
  committedAt: string;
}

export default async function getCommitsFromGithub({
  project,
  sinceCommitSha,
  branchNames,
  removeSinceCommit = true,
}: {
  project: Project;
  sinceCommitSha?: string;
  branchNames?: string[];
  removeSinceCommit?: boolean;
}) {
  const octokit = createProjectOctokit(project);

  const [owner, repo] = project.path.split('/');

  let sinceCommitDate: string | undefined;
  if (sinceCommitSha) {
    const { data: latestCommit, error } = await getSupabase()
      .from('commits')
      .select('committed_at')
      .eq('project_id', project.id)
      .eq('sha', sinceCommitSha)
      .limit(1)
      .maybeSingle();

    if (error) {
      console.log('Error getting latest commit', error);
      throw new Error(error.message);
    }

    sinceCommitDate = latestCommit?.committed_at;
  }

  const branchesSpecified = !!branchNames;
  if (!branchNames || branchNames.length === 0) {
    branchNames ||= [];
    let branchesRetrieved = false;
    let branchesPage = 1;
    while (!branchesRetrieved) {
      const { data: branches } = await octokit.rest.repos.listBranches({
        owner,
        repo,
        per_page: 100,
        page: branchesPage,
      });

      if (branches.length < 100) {
        branchesRetrieved = true;
      } else {
        branchesPage++;
      }

      console.log('Retrieving Branches', branchesPage, branches.length);
      branchNames.push(...branches.map((branch) => branch.name));
    }
  }

  const commits: GitHubCommitInfo[] = [];
  for (const branchName of branchNames) {
    let commitsPage = 1;
    while (commitsPage > 0) {
      const { data: branchCommits } = await octokit.rest.repos.listCommits({
        owner,
        repo,
        sha: branchName,
        since: sinceCommitDate,
        per_page: 100,
        page: commitsPage,
      });

      let branchCommitInfos = branchCommits.map((commit) => ({
        sha: commit.sha,
        branchName: branchName,
        committedAt: commit.commit.author.date,
      }));

      if (sinceCommitSha && removeSinceCommit) {
        branchCommitInfos = branchCommitInfos.filter(
          (commit) => commit.sha !== sinceCommitSha,
        );
      }

      commits.push(...branchCommitInfos);

      console.log(
        'Retrieving Branch Commits',
        commitsPage,
        branchName,
        branchCommitInfos.length,
        commits.length,
      );
      if (branchCommits.length < 100) {
        commitsPage = -1;
      } else {
        commitsPage++;
      }
    }
  }

  if (branchesSpecified) {
    const orderedCommits = commits.sort((a, b) => {
      return (
        new Date(a.committedAt).getTime() - new Date(b.committedAt).getTime()
      );
    });

    return orderedCommits;
  }

  const pullRequestNumbers: { number: number; name: string }[] = [];
  const missingBranchNames =
    project.branches
      ?.filter((b) => !!b.name && !branchNames.includes(b.name))
      ?.map((b) => b.name) ?? [];

  for (const missingBranchName of missingBranchNames) {
    const { data: commits, error } = await getSupabase()
      .from('commits')
      .select('metadata, branch:branches!commits_branch_id_fkey!inner ( name )')
      .eq('project_id', project.id)
      .eq('branch.name', missingBranchName)
      .not('metadata->prNumber', 'is', null);

    if (!commits || error) {
      console.log(
        'Failed to retrieve commits for branch',
        missingBranchName,
        error,
      );
      throw new Error(
        `Error retrieving commits from database: ${error?.message}`,
      );
    }

    for (const commit of commits ?? []) {
      const prNumber = commit.metadata.prNumber;
      if (
        prNumber &&
        !pullRequestNumbers.find(
          (p) => p.number === parseInt(commit.metadata.prNumber),
        )
      ) {
        pullRequestNumbers.push({
          number: parseInt(commit.metadata.prNumber),
          name: missingBranchName,
        });
      }
    }
  }

  let pullRequestsRetrieved = false;
  let pullRequestsPage = 1;
  while (!pullRequestsRetrieved) {
    const { data: pullRequests } = await octokit.rest.pulls.list({
      owner,
      repo,
      per_page: 100,
      page: pullRequestsPage,
    });

    if (pullRequests.length < 100) {
      pullRequestsRetrieved = true;
    } else {
      pullRequestsPage++;
    }

    for (const pullRequest of pullRequests) {
      const branchName = pullRequest.head.ref;
      const prNumber = pullRequest.number;
      if (
        !branchNames.includes(branchName) &&
        !pullRequestNumbers.find((p) => p.number === prNumber)
      ) {
        pullRequestNumbers.push({ number: prNumber, name: branchName });
      }
    }
  }

  for (const pullRequestNumber of pullRequestNumbers) {
    let page = 1;
    while (page > 0) {
      const { data: pullRequestCommits } = await octokit.rest.pulls.listCommits(
        {
          owner,
          repo,
          pull_number: pullRequestNumber.number,
          since: sinceCommitDate,
          per_page: 100,
          page,
        },
      );

      let branchCommitInfos = pullRequestCommits.map((commit) => ({
        sha: commit.sha,
        branchName: pullRequestNumber.name,
        committedAt: commit.commit.author.date,
      }));

      if (sinceCommitSha && removeSinceCommit) {
        branchCommitInfos = branchCommitInfos.filter(
          (commit) => commit.sha !== sinceCommitSha,
        );
      }

      commits.push(...branchCommitInfos);

      console.log(
        'Retrieving Pull Request Commits',
        page,
        pullRequestNumber,
        branchCommitInfos.length,
        commits.length,
      );
      if (pullRequestCommits.length < 100) {
        page = -1;
      } else {
        page++;
      }
    }
  }

  const orderedCommits = commits.sort((a, b) => {
    return (
      new Date(a.committedAt).getTime() - new Date(b.committedAt).getTime()
    );
  });

  return orderedCommits;
}
