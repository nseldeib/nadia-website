import { Branch, Commit, Project } from '~codeyam/types';
import githubToCommit from './githubToCommit';
import { createProjectOctokit } from './createProjectOctokit';

export interface FileContentInfo {
  owner: string;
  repo: string;
  branch: Branch;
  primaryBranch: Branch;
}

export interface GetBranchCommitsProps extends FileContentInfo {
  project: Project;
}

export default async function getBranchCommits({
  project,
  owner,
  repo,
  branch,
  primaryBranch,
}: GetBranchCommitsProps): Promise<Commit[]> {
  const octokit = createProjectOctokit(project);

  const branchResponse = await octokit.repos.compareCommits({
    owner,
    repo,
    base: primaryBranch.name,
    head: branch.name,
  });

  const branchCommits = [];
  for (const commitInfo of branchResponse.data.commits) {
    if (commitInfo.parents.length > 1) continue;
    const { data: commit } = await octokit.repos.getCommit({
      owner,
      repo,
      ref: commitInfo.sha,
    });
    branchCommits.push(githubToCommit(commit));
  }

  return branchCommits;
}
