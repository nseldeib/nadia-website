import { Project } from '~codeyam/types';
import { createProjectOctokit } from './createProjectOctokit';

export default async function getDiffBetweenCommits(
  project: Project,
  path: string,
  baseSha: string,
  headSha: string,
): Promise<string | null> {
  const octokit = createProjectOctokit(project);

  try {
    const response = await octokit.request(
      `GET /repos/${path}/compare/{basehead}`,
      {
        basehead: `${baseSha}...${headSha}`,
      },
    );

    if (response.data && response.data.files) {
      // Constructing the diff as a string
      let diff = '';
      response.data.files.forEach(
        (file: { filename: string; patch: string }) => {
          diff += `--- a/${file.filename}\n+++ b/${file.filename}\n`;
          diff += file.patch + '\n';
        },
      );
      return diff;
    } else {
      return null; // No diff found between the given SHAs
    }
  } catch (error) {
    console.log('Error fetching diff: ', error);
    return null;
  }
}
