import { GH_API_VERSION_HEADER } from './constants';
import { RepoData } from './getRepos';
import { createProjectOctokit } from './createProjectOctokit';

export default async function getPublicReposWithQuery({
  project,
  query,
}): Promise<RepoData[]> {
  const octokit = createProjectOctokit(project);

  const { data } = await octokit.request(`GET /search/repositories`, {
    q: query, // The search query
    per_page: 100,
    headers: GH_API_VERSION_HEADER,
  });

  return data.items;
}
