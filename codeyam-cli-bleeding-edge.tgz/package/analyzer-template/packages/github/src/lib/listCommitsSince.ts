import { Octokit } from '@octokit/rest';
import githubToCommit from './githubToCommit';

/**
 * The `since` param should be a timestamp. `owner` and `repo` can be retrieved from `project.path`.
 */
export default async function listCommitsSince({
  octokit,
  owner,
  repo,
  since,
}: {
  octokit: Octokit;
  owner: string;
  repo: string;
  since: string;
}) {
  const res = await octokit.rest.repos.listCommits({ owner, repo, since });
  const commits = res.data.map(githubToCommit);
  return commits;
}
