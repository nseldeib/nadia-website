import { Project } from '~codeyam/types';
import { PullRequest } from './syncPullRequest';
import { createProjectOctokit } from './createProjectOctokit';

export default async function getOpenPullRequests({
  project,
}: {
  project: Project;
}): Promise<{ pullRequest: PullRequest; commitShas: string[] }[]> {
  const octokit = createProjectOctokit(project);

  const [owner, repo] = project.path.split('/');

  const openPullRequests = await octokit.rest.pulls.list({
    owner,
    repo,
    state: 'open',
  });

  const openPullRequestsData = [];
  for (const openPullRequest of openPullRequests.data) {
    const pullRequestInfo = {
      pullRequest: openPullRequest,
      commitShas: [],
    };
    const commits = await octokit.rest.pulls.listCommits({
      owner,
      repo,
      pull_number: openPullRequest.number,
    });

    for (const commit of commits.data) {
      pullRequestInfo.commitShas.push(commit.sha);
    }
    openPullRequestsData.push(pullRequestInfo);
  }

  return openPullRequestsData;
}
