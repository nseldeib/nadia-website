import { Project } from '~codeyam/types';
import { createProjectOctokit } from './createProjectOctokit';

export interface FileContentInfo {
  owner: string;
  repo: string;
  ref?: string;
  path: string;
}

export interface GetFileContentProps extends FileContentInfo {
  project: Project;
}

export default async function getFileContent({
  project,
  owner,
  repo,
  ref,
  path,
}: GetFileContentProps): Promise<string> {
  const octokit = createProjectOctokit(project);

  const response = await octokit.repos.getContent({ owner, repo, path, ref });

  if ('content' in response.data) {
    const content = Buffer.from(response.data.content, 'base64').toString(
      'utf-8',
    );
    return content;
  } else {
    console.log(
      'Error fetching file content',
      owner,
      repo,
      path,
      ref,
      response,
    );
    throw new Error('File content not found.');
  }
}
