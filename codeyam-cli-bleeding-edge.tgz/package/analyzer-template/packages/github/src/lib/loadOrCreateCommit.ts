import {
  loadBranch,
  loadCommit,
  upsertBranches,
  upsertCommits,
  upsertGithubUser,
} from '~codeyam/supabase';
import { Project } from '~codeyam/types';
import { safeStringify } from '~codeyam/analyze';
import {
  createProjectOctokit,
  getCommitFromGithub,
  updateCommitBranchesInDb,
  updateFilesInDb,
} from '~codeyam/github';

const CO_AUTHOR_RE = /^co-authored-by:\s*(.+?)\s*<([^>]+)>/i;

interface Contributor {
  name: string;
  email: string;
  username?: string;
  avatarUrl?: string;
}

export async function extractAndUpsertCoAuthors(
  message: string,
  project: Project,
): Promise<Contributor[]> {
  const contributors: Contributor[] = [];

  if (!message || !message.toLowerCase().includes('co-authored-by:')) {
    return contributors; // No co-authors found
  }

  for (const line of message.split('\n')) {
    const trimmed = line.trim();
    const match = CO_AUTHOR_RE.exec(trimmed);
    if (!match) continue;

    // Positional captures: 1 = name, 2 = email
    const name = match[1];
    const email = match[2];

    const contributor: Contributor = { name, email };

    /* ---------- fast path for noreply pattern ---------- */
    const noreply = email.match(/^\d+\+([^@]+)@users\.noreply\.github\.com$/i);
    if (noreply) {
      contributor.username = noreply[1];
    } else {
      /* ---------- fallback: search API ---------- */
      try {
        const octokit = createProjectOctokit(project);

        const { data } = await octokit.search.users({
          q: `${email} in:email`,
          per_page: 1,
        });

        if (data.total_count > 0) {
          const user = data.items[0];
          contributor.username = user.login;
          contributor.avatarUrl = user.avatar_url;
        }
      } catch (err) {
        console.error('GitHub search API failed', err);
      }
    }

    /* ---------- persist in Supabase ---------- */
    if (contributor.username) {
      await upsertGithubUser(contributor.username, contributor.avatarUrl);
    }

    contributors.push(contributor);
  }

  return contributors;
}

export default async function loadOrCreateCommit(
  project: Project,
  commitSha: string,
  baseline?: boolean,
) {
  const existingCommit = await loadCommit({
    projectId: project.id,
    sha: commitSha,
  });

  if (existingCommit) {
    return { commit: existingCommit, branchName: existingCommit.branch?.name };
  }

  let { commit, branchName } = await getCommitFromGithub(project, commitSha);

  if (!commit?.sha) {
    throw new Error(`Commit not found for sha: ${commitSha}`);
  }

  if (baseline) {
    commit.metadata ||= {};
    commit.metadata.baseline = true;
  }

  let branchFromDb = branchName
    ? await loadBranch({
        projectId: project.id,
        name: branchName,
      })
    : null;

  if (!branchFromDb) {
    const newBranches = await upsertBranches([
      {
        projectId: project.id,
        name: branchName,
        primary: false,
        activeAt: commit.committedAt,
        contentChangedAt: commit.committedAt,
      },
    ]);
    branchFromDb = newBranches[0];
  }

  commit.branch = branchFromDb;
  branchName = branchFromDb.name;

  if (!commit.author?.username) {
    console.log(
      'CodeYam Error: Commit author username not found',
      safeStringify(commit),
    );
    throw new Error(`Commit author not found for sha: ${commitSha}`);
  }

  const githubUser = await upsertGithubUser(
    commit.author.username,
    commit.author.avatarUrl,
  );

  if (!githubUser) {
    throw new Error(
      `Github user not found for username: ${commit.author.username}`,
    );
  }

  const { author, branch, message } = commit;

  const coAuthors = await extractAndUpsertCoAuthors(message, project);

  // Optionally save them on the commit metadata
  if (coAuthors?.length > 0) {
    commit.metadata ||= {};
    const coAuthorsWithUsernames = coAuthors.filter((c) => c.username);
    if (coAuthorsWithUsernames.length > 0) {
      commit.metadata.coAuthors = coAuthors.map((c) => ({
        username: c.username,
        avatarUrl: c.avatarUrl,
      }));
    }
  }

  const upsertedCommits = await upsertCommits({
    projectId: project.id,
    commits: [commit],
  });
  if (!upsertedCommits || !upsertedCommits.length) {
    throw new Error(`Error upserting commit: ${commitSha}`);
  }
  commit = upsertedCommits[0];

  commit.author = author;
  commit.branch = branch;

  await updateFilesInDb({
    project,
    added: commit.files
      .filter((f) => f.status === 'added')
      .map((f) => f.fileName),
    removed: commit.files
      .filter((f) => f.status === 'removed')
      .map((f) => f.fileName),
    renamed: commit.files
      .filter((f) => f.status === 'renamed')
      .map((f) => ({
        fromFilePath: f.previousFileName,
        toFilePath: f.fileName,
      })),
  });

  await updateCommitBranchesInDb({
    projectId: project.id,
    commit,
    branch,
  });

  return { commit, branchName };
}
