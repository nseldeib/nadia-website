import { GithubBranch, GithubRepoInfo, Project } from '~codeyam/types';
import { GH_API_VERSION_HEADER } from './constants';
import { createProjectOctokit } from './createProjectOctokit';

export interface GetBranchProps extends GithubRepoInfo {
  project: Project;
  branchName: string;
  token: string;
}

export default async function getBranch({
  project,
  owner,
  name,
  branchName,
}: GetBranchProps): Promise<GithubBranch | null> {
  const octokit = createProjectOctokit(project);

  const { data } = await octokit.request(
    `GET /repos/${owner}/${name}/branches/${branchName}`,
    {
      headers: GH_API_VERSION_HEADER,
    },
  );

  console.log('branch', data);

  return null;
}
