import { Commit, Project } from '~codeyam/types';
import githubToCommit from './githubToCommit';
import { createProjectOctokit } from './createProjectOctokit';

export default async function getLatestCommit({
  project,
  repoPath,
  branchName,
  filePath,
}: {
  project: Project;
  repoPath: string;
  branchName?: string;
  filePath?: string;
}): Promise<Commit | null> {
  const octokit = createProjectOctokit(project);

  try {
    const response = await octokit.request(`GET /repos/${repoPath}/commits`, {
      path: filePath,
      sha: branchName,
      per_page: 1, // Fetching only the latest commit
    });

    if (response.data.length > 0) {
      return githubToCommit(response.data[0]);
    } else {
      return null; // No commits found in the repo
    }
  } catch (error: any) {
    if (error.status !== 404) {
      console.log('Error fetching the latest commit: ', error);
    }
    return null;
  }
}
