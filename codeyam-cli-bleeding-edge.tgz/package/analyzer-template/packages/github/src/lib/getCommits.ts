import { Commit } from '~codeyam/types';
import { Octokit } from '@octokit/rest';
import githubToCommit from './githubToCommit';

export default async function getCommits({
  repoPath,
  sha,
  filePath,
  perPage,
  page,
  pageCount,
  octokit,
}: {
  repoPath: string;
  sha?: string;
  filePath?: string;
  page?: number;
  perPage?: number;
  pageCount?: number;
  octokit: Octokit;
}): Promise<Commit[] | null> {
  try {
    const response = await octokit.request(`GET /repos/${repoPath}/commits`, {
      path: filePath,
      sha,
      per_page: perPage,
      page,
    });

    // console.log("response", response.headers.link)

    // for (const d of response.data.slice(0, 20)) {
    //   console.log("commit", d.sha, d.commit.tree.url, d.parents.map((p: { sha: string; }) => p.sha))
    // }

    if (response.data.length === 0) return [];

    let commits = response.data.map(githubToCommit);
    if (pageCount && pageCount > 1) {
      for (let i = 2; i <= pageCount; i++) {
        const pageCommits = await getCommits({
          repoPath,
          sha,
          filePath,
          perPage,
          page: (page ?? 0) + i,
          octokit,
        });
        commits = [...commits, ...(pageCommits ?? [])];
      }
    }
    return commits;
  } catch (error) {
    console.log('Error fetching commits: ', error);
    return null;
  }
}
