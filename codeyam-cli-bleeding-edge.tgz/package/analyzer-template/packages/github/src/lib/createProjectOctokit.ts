import { createAppAuth } from '@octokit/auth-app';
import { Octokit } from '@octokit/rest';
import { Project } from '~codeyam/types';
import { awsLog } from '~codeyam/utils';

export function createProjectOctokit(project: Project): Octokit {
  const { appId, installationId, privateKey } = requirePrivateKey(project);

  return new Octokit({
    authStrategy: createAppAuth,
    auth: {
      appId,
      privateKey,
      installationId,
    },
  });
}

export async function getProjectGitToken(project: Project): Promise<string> {
  const { appId, installationId, privateKey } = requirePrivateKey(project);

  const authStrategy = createAppAuth({
    appId: appId,
    privateKey,
    installationId: installationId,
  });

  const authResult = await authStrategy({
    type: 'installation',
  });

  awsLog(
    `Codeyam: Authenticated as GitHub App '${appId}' for project: ${project.slug}`,
  );

  const { token } = authResult;
  return token;
}

function requirePrivateKey(project: Project) {
  const appId = project.metadata?.githubAppId;
  const installationId = project.metadata?.installationId;
  if (!appId) {
    throw new Error(`Project metadata missing githubAppId: ${project.id}`);
  }
  if (!installationId) {
    throw new Error(`Project metadata missing installationId: ${project.id}`);
  }
  const key = process.env[`GH_PRIVATE_KEY_${appId}`];
  if (!key) {
    throw new Error(`GH_PRIVATE_KEY_${appId} environment variable is not set.`);
  }
  return {
    appId,
    installationId,
    privateKey: key,
  };
}
