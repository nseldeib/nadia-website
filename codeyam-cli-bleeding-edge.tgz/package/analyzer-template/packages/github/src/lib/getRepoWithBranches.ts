import { GithubBranch, GithubBranchesInfo, Project } from '~codeyam/types';
import getTree from './getTree';
import { GH_API_VERSION_HEADER } from './constants';
import { GithubRepoData } from '~codeyam/types';
import { createProjectOctokit } from './createProjectOctokit';

export interface GetRepoWithBranchesProps extends GithubBranchesInfo {
  project: Project;
}

export default async function getRepoWithBranches({
  project,
  owner,
  name,
  branches,
}: GetRepoWithBranchesProps): Promise<GithubRepoData> {
  const octokit = createProjectOctokit(project);

  const repoResponse = await octokit.request(`GET /repos/${owner}/${name}`, {
    owner,
    repo: name,
    headers: GH_API_VERSION_HEADER,
  });

  const repoData = repoResponse.data;

  const shaMap: { [key: string]: string } = {};
  const trees: GithubBranch[] = [];

  const defaultBranch = repoData.default_branch;
  const sortedBranches = branches.sort((a, b) => {
    if (a.name === defaultBranch) {
      return -1;
    }
    if (b.name === defaultBranch) {
      return 1;
    }
    return 0;
  });

  for (const branch of sortedBranches) {
    const tree = await getTree({
      project,
      owner,
      name,
      treeSha: branch.sha,
    });

    const files: GithubBranch['files'] = [];
    for (const file of tree) {
      if (!shaMap[`${file.path}-${file.sha}`]) {
        if (branch.name === defaultBranch) {
          shaMap[file.sha] = file.path;
        }

        files.push(file);
      }
    }

    trees.push({
      ...branch,
      files,
    });
  }

  return {
    name: repoData.name,
    description: repoData.description,
    path: repoData.full_name,
    primaryBranch: repoData.default_branch,
    trees,
  };
}
