export const createAppAuth = jest.fn().mockImplementation(() => {
  return jest.fn().mockResolvedValue({ token: 'mock-token' });
});

