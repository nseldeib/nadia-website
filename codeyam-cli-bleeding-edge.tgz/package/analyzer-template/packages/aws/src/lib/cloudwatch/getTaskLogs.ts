import {
  CloudWatchLogsClient,
  GetLogEventsCommand,
} from '@aws-sdk/client-cloudwatch-logs';

export type TaskType = 'playwright' | 'pnpm-monorepo';

export interface GetTaskLogsParams {
  taskArn: string;
  type: TaskType;
}

const logsClient = new CloudWatchLogsClient({});

export async function fetchTaskLogs(type: TaskType, taskArn: string) {
  const cluster = process.env.ECS_CLUSTER_NAME;
  if (!cluster) {
    throw new Error('ECS_CLUSTER_NAME environment variable is not set');
  }

  const projectName = process.env.CODE_BUILD_PROJECT_NAME;
  if (!projectName) {
    throw new Error('CODE_BUILD_PROJECT_NAME environment variable is not set');
  }

  const taskId = taskArn.split('/').pop();
  if (!taskId) {
    throw new Error('Invalid task ARN format');
  }

  // 1. there are other prefixes in use – figure out how to specify them?
  // 2. in any case hard-coding of strings like /aws/codebuild should maybe be centralised
  const logGroupName = `/aws/codebuild/${projectName}`;
  const logStreamName = `${cluster}/${cluster}-${type}/${taskId}`;

  const command = new GetLogEventsCommand({
    logGroupName,
    logStreamName,
    startFromHead: true,
  });

  const response = await logsClient.send(command);

  return (
    response.events?.map((event) => ({
      timestamp: event.timestamp ? new Date(event.timestamp) : new Date(),
      message: event.message || '',
    })) || []
  );
}
