/** The data we send to ecsRunTask to instantiate a task as concrete execution on an AWS box*/
export type EcsStartConfig = {
  taskDefinition: string;
  containerEnvironmentVariables: Array<[string, Record<string, string>]>;
};

/**
 * Prepare to run an ECS task for the classical analysis-then-capture flow
 * which uses a 'project' image for analysis and a 'playwright' image for capture.
 */
export function getEcsStartConfigForAnalysisThenCapture(
  projectEnvironmentVariables: Record<string, string>,
  playwrightEnvironmentVariables: Record<string, string>,
): EcsStartConfig {
  return {
    taskDefinition: getEcsTaskDefinitionName(
      EcsTaskDefinitionUse.AnalyzeThenCapture,
    ),
    containerEnvironmentVariables: [
      [
        getEcsImageNameForType(EcsImageType.Project),
        projectEnvironmentVariables,
      ],
      [
        getEcsImageNameForType(EcsImageType.Playwright),
        playwrightEnvironmentVariables,
      ],
    ],
  };
}

/**
 * Prepare to run an ECS task for the new analysis flow with distributed capture
 * tasks orchestrated from only a 'project' image.
 */
export function getEcsStartConfigFoAnalysisWithOrchestration(
  environmentVariables: Record<string, string>,
): EcsStartConfig {
  return {
    taskDefinition: getEcsTaskDefinitionName(
      EcsTaskDefinitionUse.AnalyzeWithOrchestration,
    ),
    containerEnvironmentVariables: [
      [getEcsImageNameForType(EcsImageType.Project), environmentVariables],
    ],
  };
}

/**
 * Prepare to run an ECS worker task that implements the capture portion of the
 * distributed orchestration, which uses a 'combo' image. This task is launched
 * from a task created with `getEcsStartConfigFoAnalysisWithOrchestration()`
 */
export function getEcsStartConfigForOrchestrationTask(
  environmentVariables: Record<string, string>,
): EcsStartConfig {
  return {
    taskDefinition: getEcsTaskDefinitionName(
      EcsTaskDefinitionUse.OrchestrationTask,
    ),
    containerEnvironmentVariables: [
      [getEcsImageNameForType(EcsImageType.Combo), environmentVariables],
    ],
  };
}

export enum EcsTaskDefinitionUse {
  /* A 'project' image runs analysis while a 'playwright' image captures the entities. */
  AnalyzeThenCapture = 'analyze-then-capture',
  /* A 'project' image runs analysis while firing up distributed capture orchestration. */
  AnalyzeWithOrchestration = 'analyze-with-orchestration',
  /* A worker task that combines 'project' and 'playwright' code, launched by orchestration. */
  OrchestrationTask = 'orchestration-task',
}

export function getEcsTaskDefinitionName(forUse: EcsTaskDefinitionUse): string {
  switch (forUse) {
    case EcsTaskDefinitionUse.AnalyzeThenCapture:
      return `${process.env.ECR_REPOSITORY_NAME}-project-and-playwright`;
    case EcsTaskDefinitionUse.AnalyzeWithOrchestration:
      return `${process.env.ECR_REPOSITORY_NAME}-project`;
    case EcsTaskDefinitionUse.OrchestrationTask:
      return `${process.env.ECR_REPOSITORY_NAME}-combo`;
    default:
      throw new Error(`Unknown task definition use: ${forUse}`);
  }
}

export enum EcsImageType {
  /* The virtualized server that runs the project code. */
  Project = 'project',
  /* The playwright capture process which waits for the project to be ready. */
  Playwright = 'playwright',
  /* A combo image that combines both project and playwright code, used by orchestration. */
  Combo = 'combo',
}

export function getEcsImageNameForType(type: EcsImageType): string {
  switch (type) {
    case EcsImageType.Project:
      return `${process.env.ECR_REPOSITORY_NAME}-project`;
    case EcsImageType.Playwright:
      return `${process.env.ECR_REPOSITORY_NAME}-playwright`;
    case EcsImageType.Combo:
      return `${process.env.ECR_REPOSITORY_NAME}-combo`;
    default:
      throw new Error(`Unknown image type: ${type}`);
  }
}
