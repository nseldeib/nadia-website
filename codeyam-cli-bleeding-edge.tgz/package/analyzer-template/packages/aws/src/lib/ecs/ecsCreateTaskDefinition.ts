import {
  ECSClient,
  RegisterTaskDefinitionCommand,
  ListTaskDefinitionsCommand,
  ContainerDefinition,
  DeregisterTaskDefinitionCommand,
  DescribeTaskDefinitionCommand,
  TaskDefinition,
  NetworkMode,
  Compatibility,
} from '@aws-sdk/client-ecs';

interface TaskDefConfig {
  cpu: string;
  memory: string;
  networkMode: NetworkMode;
  requiresCompatibilities: Compatibility[];
  executionRoleArn: string;
}

const DEFAULT_CONFIG: TaskDefConfig = {
  cpu: '512',
  memory: '4096',
  networkMode: 'awsvpc',
  requiresCompatibilities: ['FARGATE'],
  executionRoleArn: 'arn:aws:iam::486237165972:role/ecsTaskExecutionRole',
};

type EcsCreateTaskDefinitionArgs = {
  family: string;
  containerDefinitions: ContainerDefinition[];
  cpu?: string;
  memory?: string;
  imageRebuilt?: boolean;
};

export default async function ecsCreateTaskDefinition({
  family,
  containerDefinitions,
  cpu,
  memory,
  imageRebuilt = true,
}: EcsCreateTaskDefinitionArgs): Promise<string> {
  memory ??= DEFAULT_CONFIG.memory;
  cpu ??= DEFAULT_CONFIG.cpu;

  const ecsClient = new ECSClient({});

  const listTaskDefCommand = new ListTaskDefinitionsCommand({
    familyPrefix: family,
    sort: 'DESC',
    maxResults: 1,
  });

  const listTaskDefResponse = await ecsClient.send(listTaskDefCommand);

  // If there's an existing task definition, check if we need to create a new one
  if (listTaskDefResponse.taskDefinitionArns?.length > 0) {
    const latestTaskDefArn = listTaskDefResponse.taskDefinitionArns[0];

    // Get details of the latest task definition
    const describeTaskDefCommand = new DescribeTaskDefinitionCommand({
      taskDefinition: latestTaskDefArn,
    });

    const describeResponse = await ecsClient.send(describeTaskDefCommand);
    const existingTaskDef = describeResponse.taskDefinition;

    if (existingTaskDef) {
      const configChanged = hasConfigChanged({
        existingTaskDef,
        newMemory: memory,
        newCpu: cpu,
      });
      if (configChanged.changed) {
        console.log('Task configuration changed:', configChanged.reasons);
      } else {
        // Compare container definitions
        const existingContainers = existingTaskDef.containerDefinitions;

        // First check if container counts match
        if (existingContainers.length !== containerDefinitions.length) {
          console.log(
            'Container definition count changed, creating new task definition',
            {
              existing: existingContainers.length,
              new: containerDefinitions.length,
            },
          );
        } else {
          // Compare container definitions for env var changes
          const containerChanges = getContainerChanges(
            containerDefinitions,
            existingContainers,
          );

          if (!containerChanges.length && !imageRebuilt) {
            console.log(
              'Task definition unchanged, reusing:',
              existingTaskDef.taskDefinitionArn,
            );
            return existingTaskDef.taskDefinitionArn;
          }

          if (imageRebuilt) {
            console.log('Image was rebuilt, creating new task definition');
          }
          if (containerChanges.length) {
            console.log('Container changes detected:', containerChanges);
          }
        }
      }

      // Deregister old task definition if we need to create a new one
      console.log('Deregistering old task definition:', latestTaskDefArn);
      const deregisterTaskDefCommand = new DeregisterTaskDefinitionCommand({
        taskDefinition: latestTaskDefArn,
      });
      await ecsClient.send(deregisterTaskDefCommand);
    }
  }

  console.log('Creating new task definition');
  const taskDefCommand = new RegisterTaskDefinitionCommand({
    family,
    ...DEFAULT_CONFIG,
    cpu,
    memory,
    containerDefinitions,
  });

  try {
    const response = await ecsClient.send(taskDefCommand);
    console.log(
      'Task definition registered:',
      response.taskDefinition.taskDefinitionArn,
    );
    return response.taskDefinition.taskDefinitionArn;
  } catch (error) {
    console.log('Error registering task definition:', error);
    throw error;
  }
}

function hasConfigChanged({
  existingTaskDef,
  newMemory,
  newCpu,
}: {
  existingTaskDef: TaskDefinition;
  newMemory?: string;
  newCpu?: string;
}): { changed: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const config = {
    ...DEFAULT_CONFIG,
    cpu: newCpu ?? DEFAULT_CONFIG.cpu,
    memory: newMemory ?? DEFAULT_CONFIG.memory,
  };

  if (existingTaskDef.cpu !== config.cpu) {
    reasons.push(`CPU changed: ${existingTaskDef.cpu} -> ${config.cpu}`);
  }
  if (existingTaskDef.memory !== config.memory) {
    reasons.push(
      `Memory changed: ${existingTaskDef.memory} -> ${config.memory}`,
    );
  }
  if (existingTaskDef.networkMode !== config.networkMode) {
    reasons.push(
      `Network mode changed: ${existingTaskDef.networkMode} -> ${config.networkMode}`,
    );
  }
  if (existingTaskDef.executionRoleArn !== config.executionRoleArn) {
    reasons.push('Execution role ARN changed');
  }
  if (
    !arraysEqual(
      existingTaskDef.requiresCompatibilities,
      config.requiresCompatibilities,
    )
  ) {
    reasons.push('Compatibility requirements changed');
  }

  return {
    changed: reasons.length > 0,
    reasons,
  };
}

function getContainerChanges(
  newContainers: ContainerDefinition[],
  existingContainers: ContainerDefinition[],
): string[] {
  const changes: string[] = [];

  newContainers.forEach((newContainer, index) => {
    const existingContainer = existingContainers[index];

    // Compare environment variables, handling undefined/null cases
    const normalizeEnvVars = (env: any[] = []) => {
      return JSON.stringify(env.sort((a, b) => (a.name > b.name ? 1 : -1)));
    };

    const envVarsChanged =
      normalizeEnvVars(newContainer.environment) !==
      normalizeEnvVars(existingContainer.environment);

    if (envVarsChanged) {
      changes.push(`Environment variables changed for ${newContainer.name}`);
    }
  });

  return changes;
}

function arraysEqual<T>(a: T[] = [], b: T[] = []): boolean {
  if (a.length !== b.length) return false;
  const sortedA = [...a].sort();
  const sortedB = [...b].sort();
  return sortedA.every((val, idx) => val === sortedB[idx]);
}
