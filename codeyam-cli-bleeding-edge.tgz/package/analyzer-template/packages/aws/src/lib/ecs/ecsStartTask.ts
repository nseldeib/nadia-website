import {
  ECSClient,
  RunTaskCommand,
  RunTaskCommandInput,
} from '@aws-sdk/client-ecs';
import { EcsStartConfig } from './ecsTaskFactory';

export default async function ecsStartTask({
  taskDefinition,
  containerEnvironmentVariables,
}: EcsStartConfig): Promise<string> {
  if (!taskDefinition) {
    throw new Error('Task definition is required to start an ECS task');
  }
  containerEnvironmentVariables ??= [];

  const ecsClient = new ECSClient({});

  const networkConfiguration: RunTaskCommandInput['networkConfiguration'] = {
    awsvpcConfiguration: {
      subnets: [
        'subnet-0d76742bbfb486aea',
        'subnet-05f0009e23767418c',
        'subnet-0160d7357d08302d2',
        'subnet-080d6444150130211',
        'subnet-057f34afad34678d3',
        'subnet-00982bc40ee6a9bec',
      ],
      securityGroups: ['sg-05e9aea4062a45c6d'],
      assignPublicIp: 'ENABLED',
    },
  };

  const containerOverrides = containerEnvironmentVariables.map(
    ([containerName, environmentVariables]) => ({
      name: containerName,
      environment: Object.entries(environmentVariables).map(
        ([name, value]) => ({
          name,
          value,
        }),
      ),
    }),
  );

  const runTaskCommand = new RunTaskCommand({
    cluster: process.env.ECS_CLUSTER_NAME ?? '',
    taskDefinition,
    launchType: 'FARGATE',
    networkConfiguration,
    overrides:
      containerOverrides.length > 0 ? { containerOverrides } : undefined,
  });

  try {
    const response = await ecsClient.send(runTaskCommand);

    // Assuming the task runs successfully, grab the first task's ARN from the response
    const taskArn = response.tasks && response.tasks[0]?.taskArn;
    if (!taskArn) {
      throw new Error(
        `Failed to start ECS task: ${JSON.stringify(response.failures)}`,
      );
    }

    console.log(`ECS Task started with ARN: ${taskArn}`);
    return taskArn;
  } catch (error) {
    console.log('Error starting ECS task:', error);
    throw error;
  }
}
