import { ContainerDefinition } from '@aws-sdk/client-ecs';

export default function ecsDefineContainer({
  containerName,
  containerImage,
  environmentVariables = {},
  openPort,
  dependsOn,
}: {
  containerName: string;
  containerImage: string;
  environmentVariables?: { [key: string]: string };
  openPort?: number;
  dependsOn?: ContainerDefinition['dependsOn'];
}): ContainerDefinition {
  return {
    name: containerName,
    image: containerImage,
    essential: true,
    environment: Object.entries(environmentVariables).map(([name, value]) => ({
      name,
      value,
    })),
    portMappings: openPort
      ? [
          {
            containerPort: openPort,
            hostPort: openPort,
          },
        ]
      : undefined,
    logConfiguration: {
      logDriver: 'awslogs',
      options: {
        'awslogs-create-group': 'true',
        'awslogs-group': `/aws/codebuild/${process.env.CODE_BUILD_PROJECT_NAME}`,
        'awslogs-region': 'us-east-1',
        'awslogs-stream-prefix': `${process.env.ECS_CLUSTER_NAME}`,
      },
    },
    dependsOn,
  };
}
