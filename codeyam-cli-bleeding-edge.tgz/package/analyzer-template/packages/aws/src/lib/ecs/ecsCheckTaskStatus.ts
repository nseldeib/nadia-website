import { ECSClient, DescribeTasksCommand } from '@aws-sdk/client-ecs';

export default async function ecsCheckTaskStatus(
  taskArn: string,
  noProgressReports: boolean = false,
): Promise<string | undefined> {
  const ecsClient = new ECSClient({});

  // Create a new DescribeTasksCommand with necessary parameters
  const describeTasksCommand = new DescribeTasksCommand({
    cluster: process.env.ECS_CLUSTER_NAME ?? '',
    tasks: [taskArn], // Array of task ARNs, we are checking a single task here
  });

  try {
    const response = await ecsClient.send(describeTasksCommand);

    if (!noProgressReports) {
      console.log('ECS task status:', response.tasks?.[0]?.lastStatus);
    }
    // Check the status of the task
    const task = response.tasks && response.tasks[0];
    if (!task) {
      if (!noProgressReports) {
        console.log(`ECS task ${taskArn} not found.`);
      }
      return;
    }

    if (task.lastStatus === 'STOPPED') {
      if (!noProgressReports) {
        console.log(`ECS task ${taskArn} stopped: ${task.stoppedReason}`);
      }
      return;
    }

    // Return true if the task is in RUNNING state
    return task.lastStatus;
  } catch (error) {
    console.log('Error checking ECS task status:', error);
    return;
  }
}
