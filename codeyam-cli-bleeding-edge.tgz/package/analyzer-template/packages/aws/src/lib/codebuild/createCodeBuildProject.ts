import {
  ArtifactsType,
  CodeBuildClient,
  ComputeType,
  CreateProjectCommand,
  EnvironmentType,
  LogsConfigStatusType,
  SourceType,
} from '@aws-sdk/client-codebuild';

export default async function createCodeBuildProject(name: string) {
  const codeBuildClient = new CodeBuildClient({});

  const projectParams = {
    name,
    source: {
      type: SourceType.S3,
      location: `${process.env.S3_BUCKET_NAME}/builds/${name}.zip`,
    },
    artifacts: {
      // Define your build artifacts' settings (e.g., S3 bucket)
      type: ArtifactsType.NO_ARTIFACTS,
    },
    environment: {
      // Define the environment in which build will run
      type: EnvironmentType.LINUX_CONTAINER,
      image: 'aws/codebuild/standard:4.0',
      computeType: ComputeType.BUILD_GENERAL1_SMALL,
    },
    logsConfig: {
      cloudWatchLogs: {
        status: LogsConfigStatusType.ENABLED,
        groupName: name,
        // streamName: "YourStreamName" // Optional
      },
      // If you're not using S3 logs, you can omit the s3Logs configuration
    },
    serviceRole:
      'arn:aws:iam::486237165972:role/service-role/codeyam-codebuild-dev',
    // Add other project configuration as needed
  };

  const command = new CreateProjectCommand(projectParams);

  try {
    const response = await codeBuildClient.send(command);
    console.log('Project created successfully:', response.project);
  } catch (error) {
    console.log('Error creating project:', error);
  }
}
