import {
  CodeBuildClient,
  BatchGetBuildsCommand,
  ListBuildsForProjectCommand,
} from '@aws-sdk/client-codebuild';

export default async function checkForCodeBuild(
  projectName: string,
  buildId?: string,
): Promise<boolean> {
  const codeBuildClient = new CodeBuildClient({});

  try {
    if (!buildId) {
      // Get most recent build
      const listCommand = new ListBuildsForProjectCommand({
        projectName,
      });
      const listResult = await codeBuildClient.send(listCommand);
      if (!listResult.ids?.length) {
        return false;
      }
      buildId = listResult.ids[0];
    }

    const getCommand = new BatchGetBuildsCommand({
      ids: [buildId],
    });

    const result = await codeBuildClient.send(getCommand);
    const build = result.builds?.[0];

    if (!build) {
      return false;
    }

    // Return true if build is in progress
    return build.buildStatus === 'IN_PROGRESS';
  } catch (error) {
    console.log('Error checking CodeBuild status:', error);
    return false;
  }
}
