import {
  CodeBuildClient,
  BatchGetProjectsCommand,
} from '@aws-sdk/client-codebuild';

export default async function checkForCodeBuildProject(projectName: string) {
  const codeBuildClient = new CodeBuildClient({});

  try {
    // Attempt to retrieve the project details
    const command = new BatchGetProjectsCommand({ names: [projectName] });
    const response = await codeBuildClient.send(command);

    if (response.projects && response.projects.length > 0) {
      console.log(`Project ${projectName} exists.`);
      return true;
    } else {
      console.log(`Project ${projectName} does not exist.`);
      return false;
    }
  } catch (error) {
    if (error.name === 'ResourceNotFoundException') {
      console.log(`Project ${projectName} does not exist.`);
      return false;
    } else {
      console.log('Error occurred while checking project existence:', error);
      throw error;
    }
  }
}
