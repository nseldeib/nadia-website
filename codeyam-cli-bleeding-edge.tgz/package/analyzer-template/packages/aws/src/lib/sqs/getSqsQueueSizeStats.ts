import { SQSClient, GetQueueAttributesCommand } from '@aws-sdk/client-sqs';

export interface QueueSizeStats {
  unreceived: number;
  inflight: number;
}

export default async function getSqsQueueSizeStats(
  sqs: SQSClient,
  queueUrl: string,
): Promise<QueueSizeStats> {
  const result = await sqs.send(
    new GetQueueAttributesCommand({
      QueueUrl: queueUrl,
      AttributeNames: [
        'ApproximateNumberOfMessages',
        'ApproximateNumberOfMessagesNotVisible',
      ],
    }),
  );

  return {
    unreceived: Number(result.Attributes?.ApproximateNumberOfMessages || 0),
    inflight: Number(
      result.Attributes?.ApproximateNumberOfMessagesNotVisible || 0,
    ),
  };
}
