import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { ScanCommand } from '@aws-sdk/client-dynamodb';
import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';
import { getLlmCallsTableName } from './tableNames';
import { LoadLlmCallsOptions, LoadLlmCallsResult, LlmCall } from './types';

const dynamodb = new DynamoDBClient({});

export default async function loadLlmCalls(
  options: LoadLlmCallsOptions = {},
): Promise<LoadLlmCallsResult> {
  const tableName = getLlmCallsTableName();
  if (!tableName) {
    throw new Error('DynamoDB for LLM calls is not configured.');
  }

  const { limit = 50, lastEvaluatedKey } = options;

  try {
    const result = await dynamodb.send(
      new ScanCommand({
        TableName: tableName,
        Limit: limit,
        ExclusiveStartKey: lastEvaluatedKey
          ? marshall(lastEvaluatedKey)
          : undefined,
      }),
    );

    const llmCalls = (result.Items || [])
      .map((item) => unmarshall(item) as LlmCall)
      .sort((a, b) => b.created_at - a.created_at); // Sort by created_at descending

    return {
      llmCalls,
      lastEvaluatedKey: result.LastEvaluatedKey
        ? unmarshall(result.LastEvaluatedKey)
        : undefined,
    };
  } catch (error) {
    console.log('Error loading llm calls', error);
    return { llmCalls: [] };
  }
}
