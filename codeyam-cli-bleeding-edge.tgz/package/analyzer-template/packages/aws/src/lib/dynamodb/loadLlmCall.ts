import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { GetItemCommand } from '@aws-sdk/client-dynamodb';
import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';
import { getLlmCallsTableName } from './tableNames';
import { LlmCall } from './types';

const dynamodb = new DynamoDBClient({});

export default async function loadLlmCall(id: string): Promise<LlmCall | null> {
  const tableName = getLlmCallsTableName();
  if (!tableName) {
    throw new Error('DynamoDB for LLM calls is not configured.');
  }
  try {
    const result = await dynamodb.send(
      new GetItemCommand({
        TableName: tableName,
        Key: marshall({ id }),
      }),
    );

    if (!result.Item) {
      return null;
    }

    return unmarshall(result.Item) as LlmCall;
  } catch (error) {
    console.log('Error loading llm call', error);
    return null;
  }
}
