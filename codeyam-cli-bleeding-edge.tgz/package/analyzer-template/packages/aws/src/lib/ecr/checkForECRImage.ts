import { ECRClient, DescribeImagesCommand } from '@aws-sdk/client-ecr';
import { ImageInfo } from '../../../types';

export interface ECRImageCheckOptions {
  imageName: string;
  tag?: string;
  pollUntilReady?: boolean;
  retryCount?: number;
}

export default async function checkForECRImage({
  imageName,
  tag = 'latest',
  pollUntilReady = false,
  retryCount = 0,
}: ECRImageCheckOptions): Promise<ImageInfo | undefined> {
  const ecr = new ECRClient({});
  const region = await ecr.config.region();

  const command = new DescribeImagesCommand({
    repositoryName: imageName,
    imageIds: [{ imageTag: tag }],
  });

  try {
    const data = await ecr.send(command);
    if (data.imageDetails && data.imageDetails.length > 0) {
      const { imagePushedAt, registryId } = data.imageDetails[0];

      const imageUri = `${registryId}.dkr.ecr.${region}.amazonaws.com/${imageName}:${tag}`;
      console.log(`Image ${imageName}:${tag} exists with URI: ${imageUri}`);

      return {
        name: imageName,
        uri: imageUri,
        pushedAt: imagePushedAt,
      };
    }
  } catch (error) {
    if (pollUntilReady && retryCount < 200) {
      console.log(
        `Waiting for image ${imageName}:${tag} to be ready... (attempt ${retryCount + 1})`,
      );
      await new Promise((resolve) => setTimeout(resolve, 5000));
      return checkForECRImage({
        imageName,
        tag,
        pollUntilReady,
        retryCount: retryCount + 1,
      });
    }
  }

  return undefined;
}
