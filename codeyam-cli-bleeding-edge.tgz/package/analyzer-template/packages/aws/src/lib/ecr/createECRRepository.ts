import {
  ECRClient,
  CreateRepositoryCommand,
  PutLifecyclePolicyCommand,
  DescribeRepositoriesCommand,
} from '@aws-sdk/client-ecr';

export default async function createECRRepository(repositoryName: string) {
  const ecrClient = new ECRClient({});

  // Check if repository already exists
  const describeCommand = new DescribeRepositoriesCommand({});
  const response = await ecrClient.send(describeCommand);

  const repositoryExists = response.repositories?.some(
    (repo) => repo.repositoryName === repositoryName,
  );

  if (repositoryExists) {
    return;
  }

  // Create repository
  try {
    const createCommand = new CreateRepositoryCommand({ repositoryName });
    const data = await ecrClient.send(createCommand);
    console.log('Repository Created:', data.repository?.repositoryUri);
  } catch (error) {
    // Handle race condition where repository was created between check and creation
    if (error.toString().indexOf('RepositoryAlreadyExistsException') > -1) {
      console.log(
        'Repository already exists (race condition):',
        repositoryName,
      );
    } else {
      throw error;
    }
  }

  // Set lifecycle policy
  const lifecyclePolicyCommand = new PutLifecyclePolicyCommand({
    repositoryName,
    lifecyclePolicyText: JSON.stringify({
      rules: [
        {
          rulePriority: 1,
          description: 'Keep only 2 most recent images',
          selection: {
            tagStatus: 'any',
            countType: 'imageCountMoreThan',
            countNumber: 2,
          },
          action: {
            type: 'expire',
          },
        },
      ],
    }),
  });

  await ecrClient.send(lifecyclePolicyCommand);
  console.log('Lifecycle policy added to repository:', repositoryName);
}
