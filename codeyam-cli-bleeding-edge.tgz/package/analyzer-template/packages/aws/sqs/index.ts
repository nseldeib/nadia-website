// Direct export for sqs functions only
export { default as sqsGetQueueSizeStats } from '../src/lib/sqs/getSqsQueueSizeStats';
export { default as sqsSendMessage } from '../src/lib/sqs/sendSqsMessage';
