/**
 * The `lib.projects` namespace is for functionality that depends on
 * `Project`s.
 */

import path from 'path';
import { Project } from '~codeyam/types';

/**
 * This function returns a relative path from the project root to the tsConfig.
 */
export function getTsConfigPath(project: Project, dirPath: string): string {
  const tsConfigPath = path.join(dirPath, 'tsconfig.json');

  return tsConfigPath;
}
