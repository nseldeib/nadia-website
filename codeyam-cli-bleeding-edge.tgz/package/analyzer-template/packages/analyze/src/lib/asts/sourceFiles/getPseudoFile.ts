import * as lib from '../../../lib';

export type FileFunctionsAnalysis = {
  [functionName: string]: FunctionDependenciesMap;
};

export type ExportInfo = {
  exportName: string;
  isExportDefault: boolean;
  importName: string;
  importAlias: string;
  isImportDefault: boolean;
  resolvedPath?: string;
};

export type FunctionDependenciesMap = {
  [importedFilePath: string]: {
    externalLibrary: boolean;
    exportInfos: ExportInfo[];
    resolvedPath?: string;
  };
};

export function getPseudoFile({
  fileAnalyzer,
}: {
  fileAnalyzer: lib.FileAnalyzer;
}): FileFunctionsAnalysis {
  const exportedFunctions = fileAnalyzer.getAllExports();
  const exportedFunctionNames = Object.keys(exportedFunctions);

  const entries = exportedFunctionNames.map((exportedFunctionName) => {
    const importedDependenciesMap =
      fileAnalyzer.getImportsRelevantToFunctionName(exportedFunctionName);

    return [exportedFunctionName, importedDependenciesMap];
  });

  return Object.fromEntries(entries);
}
