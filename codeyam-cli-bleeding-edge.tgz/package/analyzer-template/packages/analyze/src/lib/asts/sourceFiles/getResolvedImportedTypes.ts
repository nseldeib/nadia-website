import ts from 'typescript';

function getTypeStructure(type: ts.Type, checker: ts.TypeChecker): string {
  let typeStructure = '';

  // Check if the type is a complex type (object, class, or interface)
  if (type.isClassOrInterface() || type.getFlags() & ts.TypeFlags.Object) {
    const properties = checker.getPropertiesOfType(type);
    const props = properties.map((prop) => {
      if (!prop.declarations) {
        return;
      }
      const propType = checker.getTypeOfSymbolAtLocation(
        prop,
        prop.valueDeclaration || prop.declarations[0],
      );
      return `${prop.name}: ${checker.typeToString(propType)}`;
    });
    typeStructure = `{ ${props.join(', ')} }`;
  } else {
    typeStructure = checker.typeToString(type);
  }

  return typeStructure;
}

export function getResolvedImportedTypes(
  sourceFile: ts.SourceFile,
  checker: ts.TypeChecker,
): { [key: string]: string } {
  const importedTypes: { [key: string]: string } = {};

  ts.forEachChild(sourceFile, (node) => {
    if (ts.isImportDeclaration(node) && node.importClause) {
      // Handling named imports
      if (
        node.importClause.namedBindings &&
        ts.isNamedImports(node.importClause.namedBindings)
      ) {
        node.importClause.namedBindings.elements.forEach((specifier) => {
          const symbol = checker.getSymbolAtLocation(specifier.name);
          if (symbol) {
            const type = checker.getDeclaredTypeOfSymbol(symbol);
            importedTypes[specifier.name.text] = getTypeStructure(
              type,
              checker,
            );
          }
        });
      }

      // Handling default imports
      if (node.importClause.name) {
        const symbol = checker.getSymbolAtLocation(node.importClause.name);
        if (symbol) {
          const type = checker.getDeclaredTypeOfSymbol(symbol);
          importedTypes[node.importClause.name.text] = getTypeStructure(
            type,
            checker,
          );
        }
      }

      // Handle namespace imports (import * as name from 'module')
      if (
        node.importClause.namedBindings &&
        ts.isNamespaceImport(node.importClause.namedBindings)
      ) {
        const symbol = checker.getSymbolAtLocation(
          node.importClause.namedBindings.name,
        );
        if (symbol) {
          const exports = checker.getExportsOfModule(symbol);
          exports.forEach((exp) => {
            const type = checker.getDeclaredTypeOfSymbol(exp);
            importedTypes[exp.getName()] = getTypeStructure(type, checker);
          });
        }
      }
    }
  });

  return importedTypes;
}
