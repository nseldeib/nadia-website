import ts from 'typescript';

function findVariableName(node: ts.Node, sourceFile: ts.SourceFile) {
  if (ts.isVariableDeclaration(node)) {
    return node.name.getText(sourceFile);
  }

  for (const child of node.getChildren(sourceFile)) {
    const name = findVariableName(child, sourceFile);

    if (name) {
      return name;
    }
  }
}

function findExportNode(
  node: ts.Node,
  sourceFile: ts.SourceFile,
  variableName: string,
) {
  if (ts.isExportDeclaration(node)) {
    const analyzeChildren = (exportNode: ts.Node) => {
      for (const child of exportNode.getChildren(sourceFile)) {
        if (child.getText(sourceFile) === variableName) {
          return node;
        }
        const relevantNode = analyzeChildren(child);
        if (relevantNode) {
          return relevantNode;
        }
      }
    };
    return analyzeChildren(node);
  } else if (ts.isExportAssignment(node)) {
    if (node.expression?.getText(sourceFile) === variableName) {
      return node;
    }
  }

  for (const child of node.getChildren(sourceFile)) {
    const exportNode = findExportNode(child, sourceFile, variableName);

    if (exportNode) {
      return exportNode;
    }
  }
}

export function isDefaultExport(node: ts.Node, sourceFile: ts.SourceFile) {
  const modifiers =
    'modifiers' in node && Array.isArray(node.modifiers) ? node.modifiers : [];
  if (
    modifiers.find((mod) => mod.kind === ts.SyntaxKind.ExportKeyword) ||
    ts.isExportAssignment(node) ||
    ts.isExportDeclaration(node)
  ) {
    const isDefault =
      modifiers.some((mod) => mod.kind === ts.SyntaxKind.DefaultKeyword) ||
      node
        .getChildren(sourceFile)
        .some((n) => n.kind === ts.SyntaxKind.DefaultKeyword);

    return !!isDefault;
  } else {
    const variableName = findVariableName(node, sourceFile);
    if (variableName) {
      const exportNode = findExportNode(sourceFile, sourceFile, variableName);
      if (!exportNode) return false;

      return isDefaultExport(exportNode, sourceFile);
    }

    return false;
  }
}
