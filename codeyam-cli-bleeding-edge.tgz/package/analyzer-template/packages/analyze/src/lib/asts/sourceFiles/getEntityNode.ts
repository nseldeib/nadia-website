import ts from 'typescript';
import * as lib from '../../index';

export function getEntityNode({
  entityName,
  sourceFile,
}: {
  entityName: string;
  sourceFile: ts.SourceFile;
}) {
  const entityNodes = lib.asts.sourceFiles.getAllEntityNodes({ sourceFile });
  const entityNode = entityNodes[entityName];

  if (!entityNode) {
    // console.log(
    //   `CodeYam Error: getEntityNode: Entity not found: ${entityName}`,
    //   {
    //     sourceFile: sourceFile.fileName,
    //     names: Object.keys(entityNodes),
    //   },
    // );
    throw new Error('getEntityNode: Entity not found');
  }

  return entityNode;
}
