import ts from 'typescript';
import * as path from 'path';
import { getResolvedModule } from './getResolvedModule';

export function getImportMappings(
  sourceFile: ts.SourceFile,
  program: ts.Program,
): Map<string, string> {
  const importMappings = new Map<string, string>();

  function visit(node: ts.Node) {
    if (
      (ts.isImportDeclaration(node) ||
        (ts.isExportDeclaration(node) && node.moduleSpecifier)) &&
      ts.isStringLiteral(node.moduleSpecifier)
    ) {
      const moduleName = node.moduleSpecifier.text;
      const resolvedModule = getResolvedModule(moduleName, sourceFile, program);
      if (resolvedModule?.resolvedFileName) {
        importMappings.set(resolvedModule.resolvedFileName, moduleName);
      } else {
        // If TypeScript can't resolve it (e.g., CSS files), manually resolve relative paths
        if (moduleName.startsWith('./') || moduleName.startsWith('../')) {
          const sourceDir = path.dirname(sourceFile.fileName);
          const resolvedPath = path.resolve(sourceDir, moduleName);
          importMappings.set(resolvedPath, moduleName);
        } else {
          // For absolute imports that TypeScript can't resolve (like node modules), keep the original mapping
          importMappings.set(moduleName, moduleName);
        }
      }
    }

    ts.forEachChild(node, visit);
  }

  visit(sourceFile);

  return importMappings;
}
