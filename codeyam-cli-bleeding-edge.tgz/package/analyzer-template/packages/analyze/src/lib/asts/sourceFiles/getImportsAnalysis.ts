import ts from 'typescript';
import { ExportInfo } from './getPseudoFile';

// the `ExportInfo` is the name of every imported entity and whether it is default or not
type ImportsAnalysis = {
  [importedFilePath: string]: ExportInfo[];
};

export function getImportsAnalysis(sourceFile: ts.SourceFile): ImportsAnalysis {
  const importsMapEntries = [];

  const importsVisitor = (node: ts.Node) => {
    if (ts.isImportDeclaration(node)) {
      importsMapEntries.push(handleImportDeclaration(node));
    } else if (ts.isExportDeclaration(node) && node.moduleSpecifier) {
      importsMapEntries.push(handleExportDeclaration(node));
    } else {
      node.forEachChild(importsVisitor);
    }
  };

  sourceFile.forEachChild(importsVisitor);

  const consolidatedImportsMapEntries = importsMapEntries.reduce(
    (
      acc: ImportsAnalysis,
      [moduleSpecifier, namedImports]: [string, ExportInfo[]],
    ) => {
      if (!acc[moduleSpecifier]) {
        acc[moduleSpecifier] = [];
      }
      acc[moduleSpecifier].push(...namedImports);
      return acc;
    },
    {} as ImportsAnalysis,
  );

  return consolidatedImportsMapEntries;
}

function handleImportDeclaration(
  node: ts.ImportDeclaration,
): [string, ExportInfo[]] {
  const moduleSpecifier = (node.moduleSpecifier as ts.StringLiteral).text;
  const namedImports: ExportInfo[] = [];

  if (node.importClause) {
    // Handle default import
    if (node.importClause.name) {
      namedImports.push({
        exportName: 'default',
        isExportDefault: true,
        importName: node.importClause.name.text,
        importAlias: node.importClause.name.text,
        isImportDefault: true,
      });
    }

    // Handle named import
    if (node.importClause.namedBindings) {
      if (ts.isNamedImports(node.importClause.namedBindings)) {
        node.importClause.namedBindings.elements.forEach((element) => {
          namedImports.push({
            exportName: element.propertyName?.text ?? element.name.text,
            isExportDefault: element.propertyName?.text === 'default',
            importName: element.propertyName?.text ?? element.name.text,
            importAlias: element.name.text,
            isImportDefault: element.name.text === 'default',
          });
        });
      } else if (ts.isNamespaceImport(node.importClause.namedBindings)) {
        namedImports.push({
          exportName: '*',
          isExportDefault: false,
          importName: '*',
          importAlias: node.importClause.namedBindings.name.text,
          isImportDefault: false,
        });
      }
    }
  }

  return [moduleSpecifier, namedImports];
}

function handleExportDeclaration(
  node: ts.ExportDeclaration,
): [string, ExportInfo[]] {
  const moduleSpecifier = (node.moduleSpecifier as ts.StringLiteral).text;
  const namedImports: ExportInfo[] = [];

  if (node.exportClause) {
    if (!ts.isNamedExports(node.exportClause)) {
      if (ts.isNamespaceExport(node.exportClause)) {
        namedImports.push({
          exportName: '*',
          isExportDefault: false,
          importName: '*',
          importAlias: node.exportClause.name.text,
          isImportDefault: false,
        });
      } else {
        namedImports.push({
          exportName: 'default',
          isExportDefault: true,
          importName: 'default',
          importAlias: 'default',
          isImportDefault: true,
        });
      }
    }

    if (ts.isNamedExports(node.exportClause)) {
      node.exportClause.elements.forEach((element) => {
        namedImports.push({
          exportName: element.propertyName?.text ?? element.name.text,
          isExportDefault: element.propertyName?.text === 'default',
          importName: element.propertyName?.text ?? element.name.text,
          importAlias: element.name.text,
          isImportDefault: element.name.text === 'default',
        });
      });
    }
  }

  return [moduleSpecifier, namedImports];
}
