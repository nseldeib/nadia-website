import ts from 'typescript';
import { getSourceFilesForImports } from './getSourceFilesForImports';

export function getSourceFilesForAllImports(
  sourceFile: ts.SourceFile,
  program: ts.Program,
): ts.SourceFile[] {
  const moduleNames: string[] = [];

  // Helper function to visit nodes recursively
  function visit(node: ts.Node) {
    if (
      ts.isImportDeclaration(node) ||
      (ts.isExportDeclaration(node) && node.moduleSpecifier)
    ) {
      moduleNames.push((node.moduleSpecifier as ts.StringLiteral).text);
    }

    ts.forEachChild(node, visit); // Recursively visit all children of the current node
  }

  visit(sourceFile); // Start visiting nodes from the root source file

  return getSourceFilesForImports(moduleNames, sourceFile, program);
}
