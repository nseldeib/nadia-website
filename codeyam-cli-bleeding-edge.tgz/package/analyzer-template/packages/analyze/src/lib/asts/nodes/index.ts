import ts from 'typescript';
import * as lib from '../../../lib/index';

export { propsNodeToPropsData } from './propsNodeToPropsData';
export { getReactComponentType } from './getReactComponentType';
export { getCallExpressionNames } from './getCallExpressionNames';
export { getNodeType } from './getNodeType';
export { getFunctionNodeType } from './getFunctionNodeType';
export { isDefaultExport } from './isDefaultExport';

interface ImportInfo {
  packageName: string;
  importedName?: string; // The name as it's exported from the package (e.g., 'original' in 'import { original as alias }')
  isDefault?: boolean;
  isNamespace?: boolean;
}

type ImportMap = Map<string, ImportInfo>;

function extractFunctionCallInfo(node: ts.Node) {
  const importMap: ImportMap = new Map();

  const sourceFile = node.getSourceFile();

  sourceFile.statements.forEach((statement) => {
    if (ts.isImportDeclaration(statement)) {
      const moduleSpecifier = (statement.moduleSpecifier as ts.StringLiteral)
        .text;

      if (statement.importClause) {
        const { name, namedBindings } = statement.importClause;

        // Default import: import MyDefault from 'my-module';
        if (name) {
          importMap.set(name.text, {
            packageName: moduleSpecifier,
            importedName: 'default', // Or name.text if you prefer to track the original name for default
            isDefault: true,
          });
        }

        // Named imports: import { a, b as c } from 'my-module';
        if (namedBindings && ts.isNamedImports(namedBindings)) {
          namedBindings.elements.forEach((specifier) => {
            const localName = specifier.name.text;
            const importedName = specifier.propertyName
              ? specifier.propertyName.text
              : localName;
            importMap.set(localName, {
              packageName: moduleSpecifier,
              importedName: importedName,
            });
          });
        }

        // Namespace import: import * as MyNamespace from 'my-module';
        if (namedBindings && ts.isNamespaceImport(namedBindings)) {
          importMap.set(namedBindings.name.text, {
            packageName: moduleSpecifier,
            isNamespace: true,
            importedName: '*', // Indicate it's a namespace
          });
        }
      }
    }
  });

  let callingVar: string | undefined;
  let functionName: string | undefined;

  if (ts.isCallExpression(node)) {
    if (ts.isPropertyAccessExpression(node.expression)) {
      const propAccess = node.expression;

      if (ts.isIdentifier(propAccess.expression)) {
        callingVar = propAccess.expression.text;
      }
      if (ts.isIdentifier(propAccess.name)) {
        functionName = propAccess.name.text;
      }
    }
  }

  return {
    callingVar,
    functionName,
    packageName: callingVar
      ? importMap.get(callingVar)?.packageName
      : undefined,
  };
}

export function isReactComponent(node: ts.Node) {
  const isJsx = (node: ts.Node) =>
    node.kind === ts.SyntaxKind.JsxElement ||
    node.kind === ts.SyntaxKind.JsxFragment ||
    node.kind === ts.SyntaxKind.JsxSelfClosingElement ||
    node.kind === ts.SyntaxKind.JsxOpeningElement ||
    node.kind === ts.SyntaxKind.JsxClosingElement;

  return hasChild(node, isJsx);
}

export function isType(node: ts.Node) {
  const info = extractFunctionCallInfo(node);

  if (info.packageName === 'zod' && info.functionName === 'object') {
    return true;
  }
  return false;
}

export function isExported(node: ts.Node): boolean {
  let res = false;

  function visit(node: ts.Node) {
    if (node.kind === ts.SyntaxKind.ExportKeyword) {
      res = true;
    }
  }

  ts.forEachChild(node, visit);

  return res;
}

/**
 * Recursively checks each child node of `node` with `test`. If **any**
 * node passes the test, returns `true`, otherwise `false`.
 */
function hasChild(node: ts.Node, test: (node: ts.Node) => boolean): boolean {
  let bool = false;

  function visit(node: ts.Node) {
    if (test(node)) {
      bool = true;
    }

    ts.forEachChild(node, visit);
  }

  ts.forEachChild(node, visit);
  return bool;
}

/**
 * Detects if an AST node is a "function node", and type coerces it if so.
 */
export function isFunction(
  node: ts.Node,
): node is ts.FunctionDeclaration | ts.FunctionExpression | ts.ArrowFunction {
  return (
    ts.isFunctionDeclaration(node) ||
    ts.isFunctionExpression(node) ||
    ts.isArrowFunction(node) ||
    ts.isCallExpression(node)
  );
}

export function getFirstParameter(
  fnode: lib.types.FunctionNode,
): ts.ParameterDeclaration | undefined {
  const parameters = this.getAllParameters(fnode);
  if (parameters.length < 1) return;
  return parameters[0];
}

export function getAllParameters(
  fnode: lib.types.FunctionNode,
): ts.ParameterDeclaration[] | undefined {
  return fnode.parameters.flatMap((p) => p);
}
