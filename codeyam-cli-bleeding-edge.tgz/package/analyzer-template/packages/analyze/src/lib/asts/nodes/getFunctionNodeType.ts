import ts from 'typescript';
import { EntityType } from '~codeyam/types';
import * as lib from '../..';

/**
 * Returns the node type of the given node
 */
export function getFunctionNodeType(node: ts.Node): EntityType | null {
  if (lib.asts.nodes.isFunction(node)) {
    if (lib.asts.nodes.isReactComponent(node)) {
      return 'visual';
    }

    if (lib.asts.nodes.isType(node)) {
      return 'type';
    }

    return 'library';
  }

  return null;
}
