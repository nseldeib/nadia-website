import ts from 'typescript';

/**
 * Returns all `callExpression` names in child nodes
 */
export function getCallExpressionNames(node: ts.Node) {
  const callExpressionNames = [];

  const visitor = (node: ts.Node) => {
    if (ts.isCallExpression(node)) {
      callExpressionNames.push(handleCallExpression(node));
    } else {
      node.forEachChild(visitor);
    }
  };

  node.forEachChild(visitor);

  return callExpressionNames;
}

function handleCallExpression(node: ts.Node): string | null {
  let name = null;

  const visitor = (node: ts.Node) => {
    if (name !== null) return;
    if (ts.isIdentifier(node)) {
      name = node.escapedText;
    } else {
      node.forEachChild(visitor);
    }
  };

  node.forEachChild(visitor);

  return name;
}
