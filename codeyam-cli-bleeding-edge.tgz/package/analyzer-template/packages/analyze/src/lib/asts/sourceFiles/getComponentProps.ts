import ts from 'typescript';
import * as lib from '../../index';
import { PropsWithTypes } from '~codeyam/types';

export function getComponentProps({
  sourceFile,
  typeChecker,
}: {
  sourceFile: ts.SourceFile;
  typeChecker: ts.TypeChecker;
}): PropsWithTypes {
  const componentType = lib.asts.sourceFiles.getComponentType(sourceFile);

  switch (componentType) {
    case lib.types.ComponentType.Class:
      console.log('CodeYam Error: Class components are not yet supported');
      break;
    case lib.types.ComponentType.Functional:
      return lib.asts.sourceFiles.getPropsFromFunctionalComponent({
        sourceFile: sourceFile,
        checker: typeChecker,
      });
    case lib.types.ComponentType.Provider:
      console.log('CodeYam Error: Provider components are not yet supported');
      break;
    case lib.types.ComponentType.Unknown:
      console.log('CodeYam Error: Unknown component type');
      break;
    default:
      break;
  }
  return { props: [] };
}
