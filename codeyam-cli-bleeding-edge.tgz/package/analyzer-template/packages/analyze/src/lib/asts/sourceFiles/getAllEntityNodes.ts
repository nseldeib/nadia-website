import ts from 'typescript';

interface GetAllEntityNodesArgs {
  sourceFile: ts.SourceFile;
  possibleIdentifierNode?: ts.Node;
  entityNode?: ts.Node;
  entities?: { [key: string]: ts.Node };
}

export function getAllEntityNodes({
  sourceFile,
  possibleIdentifierNode,
  entityNode,
  entities = {},
}: GetAllEntityNodesArgs) {
  try {
    if (!possibleIdentifierNode) {
      possibleIdentifierNode = sourceFile;
    }

    if (ts.isBindingElement(possibleIdentifierNode)) {
      const lastChild = possibleIdentifierNode.getChildAt(
        possibleIdentifierNode.getChildCount(sourceFile) - 1,
      );

      if (ts.isIdentifier(lastChild)) {
        entities[lastChild.text] = entityNode;
      } else if (
        ts.isObjectBindingPattern(lastChild) ||
        ts.isArrayBindingPattern(lastChild)
      ) {
        entities = {
          ...entities,
          ...getAllEntityNodes({
            sourceFile,
            possibleIdentifierNode: lastChild,
            entityNode,
            entities,
          }),
        };
      }
      return entities;
    }

    possibleIdentifierNode.forEachChild((child) => {
      try {
        // console.log('child', ts.SyntaxKind[child.kind], child.getText(sourceFile));
        // console.log(
        //   'child children',
        //   child.getChildren(sourceFile).map((c) => ({
        //     kind: ts.SyntaxKind[c.kind],
        //     text: c.getText(sourceFile),
        //   })),
        // );

        const safeEntityNode = entityNode ?? child;

        if (ts.isIdentifier(child)) {
          if (!entities[child.text]) {
            entities[child.text] = safeEntityNode;
          }
        }

        if (
          ts.isVariableDeclaration(child) ||
          ts.isBindingElement(child) ||
          ts.isModuleDeclaration(child) ||
          ts.isNamedExports(child)
        ) {
          entities = {
            ...getAllEntityNodes({
              sourceFile,
              possibleIdentifierNode: child,
              entityNode: safeEntityNode,
              entities,
            }),
            ...entities,
          };
        }

        if (ts.isVariableDeclarationList(child)) {
          child.declarations.forEach((declaration) => {
            entities = {
              ...getAllEntityNodes({
                sourceFile,
                possibleIdentifierNode: declaration.name,
                entityNode: safeEntityNode,
                entities,
              }),
              ...entities,
            };
          });
        }

        if (ts.isVariableStatement(child)) {
          entities = {
            ...getAllEntityNodes({
              sourceFile,
              possibleIdentifierNode: child.declarationList,
              entityNode: safeEntityNode,
              entities,
            }),
            ...entities,
          };
        }

        if (ts.isObjectBindingPattern(child)) {
          const entityNodes = child.elements.reduce((acc, element) => {
            return {
              ...getAllEntityNodes({
                sourceFile,
                possibleIdentifierNode: element,
                entityNode: safeEntityNode,
                entities,
              }),
              ...acc,
            };
          }, {});

          for (const key in entityNodes) {
            entities[key] = safeEntityNode;
          }
        }

        if (ts.isArrayBindingPattern(child)) {
          entities = {
            ...entities,
            ...child.elements.reduce((acc, element) => {
              return {
                ...getAllEntityNodes({
                  sourceFile,
                  possibleIdentifierNode: element,
                  entityNode: safeEntityNode,
                  entities,
                }),
                ...acc,
              };
            }, {}),
          };
        }

        if (
          ts.isFunctionDeclaration(child) ||
          ts.isTypeAliasDeclaration(child) ||
          ts.isInterfaceDeclaration(child) ||
          ts.isClassDeclaration(child) ||
          ts.isEnumDeclaration(child)
        ) {
          if (!entities[child.name?.text ?? 'default']) {
            entities[child.name?.text ?? 'default'] = safeEntityNode;

            if (ts.isFunctionDeclaration(child) && child.modifiers) {
              const isDefaultExport =
                child.modifiers.some(
                  (modifier) => modifier.kind === ts.SyntaxKind.DefaultKeyword,
                ) &&
                child.modifiers.some(
                  (modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword,
                );

              if (isDefaultExport) {
                entities['default'] = safeEntityNode;
              }
            }
          }
        }

        if (ts.isExportDeclaration(child)) {
          if (child.exportClause) {
            entities = {
              ...getAllEntityNodes({
                sourceFile,
                possibleIdentifierNode: child.exportClause,
                entityNode: safeEntityNode,
                entities,
              }),
              ...entities,
            };
          }
        }

        if (ts.isExportAssignment(child)) {
          if (ts.isObjectLiteralExpression(child.expression)) {
            entities['default'] = safeEntityNode;
          } else {
            if (!child.isExportEquals) {
              const exportedNodeName = child.expression.getText(sourceFile);
              entities['default'] =
                entities[exportedNodeName] ?? child.expression;
            }
            entities = {
              ...getAllEntityNodes({
                sourceFile,
                possibleIdentifierNode: child.expression,
                entityNode: child.expression,
                entities,
              }),
              ...entities,
            };
          }
        }

        if (ts.isExportSpecifier(child)) {
          const nameText = child.name.getText(sourceFile);
          if (child.propertyName) {
            const propertyNameText = child.propertyName.getText(sourceFile);
            entities[nameText] = entities[propertyNameText] ?? safeEntityNode;
            if (propertyNameText !== 'default' && !entities[propertyNameText]) {
              entities[propertyNameText] = safeEntityNode;
            }
          } else {
            entities[nameText] = entities[nameText] ?? safeEntityNode;
          }
        }
      } catch (e) {
        console.log(
          'CodeYam Error: Error Getting All Entity Nodes Child',
          ts.SyntaxKind[child.kind],
          child.getText(sourceFile),
          e,
        );
        throw e;
      }
    });

    return entities;
  } catch (e) {
    console.log(
      'CodeYam Error: Error Getting All Entity Nodes',
      ts.SyntaxKind[possibleIdentifierNode.kind],
      possibleIdentifierNode.getText(sourceFile),
      e,
    );
    throw e;
  }
}
