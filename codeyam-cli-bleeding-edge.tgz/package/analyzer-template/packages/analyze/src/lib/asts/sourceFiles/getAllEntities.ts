import ts from 'typescript';
import { getAllEntityNodes } from './getAllEntityNodes';

export function getAllEntities(sourceFile: ts.SourceFile) {
  return Object.keys(getAllEntityNodes({ sourceFile }));
}
