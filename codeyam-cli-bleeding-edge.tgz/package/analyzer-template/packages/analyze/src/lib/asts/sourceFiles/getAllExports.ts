import ts from 'typescript';
import * as lib from '../../index';

export interface ExportedFunction {
  code: string;
  isDefaultExport: boolean;
  isNamespaceExport: boolean;
  directImportPath?: string;
  directImportName?: string;
}

export function getAllExports(
  sourceFile: ts.SourceFile,
): Record<string, ExportedFunction> {
  const exportsCodeMap: Record<string, ExportedFunction> = {};

  function addExport(
    name: string,
    node: ts.Node,
    isDefault: boolean,
    directImportPath?: string,
    directImportName?: string,
  ) {
    if (exportsCodeMap[name]) return;

    const code = node.getFullText(sourceFile).trim();
    exportsCodeMap[name] = {
      code,
      isDefaultExport: isDefault,
      isNamespaceExport: isNamespaceExport(node),
      directImportPath,
      directImportName,
    };
  }

  function isNamespaceExport(node: ts.Node): boolean {
    if (ts.isExportDeclaration(node) && node.exportClause) {
      return ts.isNamespaceExport(node.exportClause);
    }
    return false;
  }

  function handleExportedNode(node: ts.Node, isDefaultExport: boolean) {
    let name = 'default';

    if (ts.isFunctionDeclaration(node) && node.name) {
      name = node.name.text;
    } else if (ts.isVariableStatement(node)) {
      const [declaration] = node.declarationList.declarations;
      if (ts.isIdentifier(declaration.name)) {
        name = declaration.name.text;
      }
    }

    addExport(name, node, isDefaultExport);
  }

  function processExportAssignment(node: ts.ExportAssignment) {
    if (ts.isIdentifier(node.expression)) {
      const name = node.expression.text;
      sourceFile.forEachChild((child) => {
        if (ts.isExportAssignment(child)) {
          let directImportPath: string | undefined;
          let directImportName = child.expression.getText(sourceFile);
          const importsAnalysis =
            lib.asts.sourceFiles.getImportsAnalysis(sourceFile);
          Object.entries(importsAnalysis).forEach(([path, exportInfos]) => {
            for (const exportInfo of exportInfos) {
              if (exportInfo.importAlias === name) {
                directImportPath = path.replace(/['"]/g, '');
                directImportName = exportInfo.exportName;
              }
            }
          });

          addExport(name, child, true, directImportPath, directImportName);
        } else if (
          (ts.isFunctionDeclaration(child) || ts.isVariableStatement(child)) &&
          ((ts.isFunctionDeclaration(child) && child.name?.text === name) ||
            (ts.isVariableStatement(child) &&
              child.declarationList.declarations.some(
                (dec) => ts.isIdentifier(dec.name) && dec.name.text === name,
              )))
        ) {
          addExport(name, child, true);
        }
      });
    } else {
      const callExpressionNames = lib.asts.nodes.getCallExpressionNames(node);
      const code = node.getFullText(sourceFile).trim();
      exportsCodeMap[callExpressionNames[0] ?? 'default'] = {
        code,
        isDefaultExport: true,
        isNamespaceExport: false,
      };
    }
  }

  function processNamedExports(node: ts.NamedExports) {
    node.elements.forEach((element) => {
      const name = element.name.text;
      const propertyName = element.propertyName
        ? element.propertyName.text
        : name;
      const importedSource = node.parent.moduleSpecifier
        ? node.parent.moduleSpecifier.getText(sourceFile)
        : undefined;

      if (importedSource) {
        const directImportPath = importedSource?.replace(/['"]/g, '');
        const directImport = (
          node.parent.exportClause as ts.NamedExports
        )?.elements?.find(
          (e) => (e.propertyName || e.name).text === propertyName,
        );
        const directImportName = (
          directImport?.propertyName ?? directImport?.name
        )?.text;
        const importStatement = `export ${node.getText()} from ${importedSource}`;

        exportsCodeMap[name] = {
          code: importStatement,
          isDefaultExport: name === 'default',
          isNamespaceExport: false,
          directImportPath,
          directImportName,
        };
      } else {
        const declarations = sourceFile.statements.filter(
          (
            stmt,
          ): stmt is
            | ts.ImportDeclaration
            | ts.FunctionDeclaration
            | ts.VariableStatement =>
            (ts.isImportDeclaration(stmt) ||
              ts.isFunctionDeclaration(stmt) ||
              ts.isVariableStatement(stmt)) &&
            ((ts.isFunctionDeclaration(stmt) &&
              stmt.name?.text === propertyName) ||
              (ts.isVariableStatement(stmt) &&
                stmt.declarationList.declarations.some(
                  (dec) =>
                    ts.isIdentifier(dec.name) && dec.name.text === propertyName,
                )) ||
              (ts.isImportDeclaration(stmt) &&
                (stmt.importClause?.getText(sourceFile) === propertyName ||
                  (stmt.importClause?.namedBindings &&
                    ts.isNamedImports(stmt.importClause?.namedBindings) &&
                    stmt.importClause?.namedBindings.elements.some(
                      (e) => e.name.text === propertyName,
                    ))))),
        );

        declarations.forEach((decl) => {
          let directImportPath: string | undefined;
          if (ts.isImportDeclaration(decl)) {
            directImportPath = decl.moduleSpecifier
              ?.getText(sourceFile)
              .replace(/['"]/g, '');
          }
          addExport(name, decl, false, directImportPath);
        });
      }
    });
  }

  sourceFile.forEachChild((node) => {
    if (ts.isFunctionDeclaration(node) || ts.isVariableStatement(node)) {
      if (
        node.modifiers?.some((mod) => mod.kind === ts.SyntaxKind.ExportKeyword)
      ) {
        const isDefaultExport = node.modifiers?.some(
          (mod) => mod.kind === ts.SyntaxKind.DefaultKeyword,
        );
        handleExportedNode(node, isDefaultExport);
      }
    } else if (ts.isExportAssignment(node) && !node.isExportEquals) {
      processExportAssignment(node);
    } else if (ts.isExportDeclaration(node) && node.exportClause) {
      if (ts.isNamedExports(node.exportClause)) {
        processNamedExports(node.exportClause);
      } else if (ts.isNamespaceExport(node.exportClause)) {
        const name = node.exportClause.name.text;
        addExport(name, node, false);
      }
    }
  });

  return exportsCodeMap;
}
