import ts from 'typescript';

export function getResolvedModule(
  moduleName: string,
  sourceFile: ts.SourceFile,
  program: ts.Program,
) {
  return ts.resolveModuleName(
    moduleName,
    sourceFile.fileName,
    program.getCompilerOptions(),
    ts.sys,
  ).resolvedModule;
}
