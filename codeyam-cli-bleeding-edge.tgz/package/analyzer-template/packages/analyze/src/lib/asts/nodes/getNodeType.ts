import ts from 'typescript';

/**
 * Returns the node type of the given node
 */
export function getNodeType(node: ts.Node, sourceFile: ts.SourceFile) {
  const syntaxKind = ts.SyntaxKind[node.kind];

  let nodeType: string | undefined;
  switch (syntaxKind) {
    case 'CallExpression':
      nodeType = 'functionCall';
      break;
    case 'FunctionDeclaration':
    case 'FunctionExpression':
    case 'ArrowFunction':
      nodeType = 'function';
      break;
    case 'ExportDeclaration':
    case 'ExportAssignment':
      const exportedNode = handleExport(node, sourceFile);

      if (exportedNode.kind === ts.SyntaxKind.ExportDeclaration) {
        nodeType = 'index';
      } else {
        return getNodeType(exportedNode, sourceFile);
      }
      break;
    case 'FirstStatement':
      const relevantNode = handleFirstStatement(node, sourceFile);
      return getNodeType(relevantNode, sourceFile);
    case 'ExportSpecifier':
      nodeType = 'index';
      break;
    case 'FirstLiteralToken':
    case 'StringLiteral':
    case 'NumericLiteral':
    case 'ObjectLiteralExpression':
      nodeType = 'data';
      break;
    case 'TypeAliasDeclaration':
    case 'InterfaceDeclaration':
      nodeType = 'type';
      break;
    default:
      // console.log('Unknown node type:', syntaxKind, node.getText(sourceFile));
      nodeType = 'other';
  }

  return {
    nodeType,
    relevantNode: node,
  };
}

function handleExport(node: ts.Node, sourceFile: ts.SourceFile) {
  const variable = node
    .getChildren(sourceFile)
    .find((child) => child.kind === ts.SyntaxKind.Identifier);

  if (!variable) {
    const variableDeclarationList = node
      .getChildren(sourceFile)
      .find((child) => child.kind === ts.SyntaxKind.VariableDeclarationList);

    if (!variableDeclarationList) {
      if (ts.isExportAssignment(node)) {
        return node.expression;
      }

      return node;
    }

    return handleExport(variableDeclarationList, sourceFile);
  }

  const findVariableDeclaration = (
    node: ts.Node,
    name: string,
  ): ts.Node | undefined => {
    if (node.kind === ts.SyntaxKind.VariableDeclaration) {
      const variableName = node
        .getChildren(sourceFile)
        .find((child) => child.kind === ts.SyntaxKind.Identifier);
      if (variableName?.getText(sourceFile) === name) {
        const variableAssignment = node
          .getChildren(sourceFile)
          .findIndex((child) => child.kind === ts.SyntaxKind.FirstAssignment);
        return node.getChildren(sourceFile)[variableAssignment + 1];
      }
    }

    return node.forEachChild((child) => findVariableDeclaration(child, name));
  };

  return findVariableDeclaration(sourceFile, variable.getText(sourceFile));
}

function handleFirstStatement(node: ts.Node, sourceFile: ts.SourceFile) {
  const findAssignmentContent = (
    possibleAssignmentNode: ts.Node,
    nextNode?: ts.Node,
  ): ts.Node | undefined => {
    if (
      nextNode &&
      possibleAssignmentNode.kind === ts.SyntaxKind.FirstAssignment
    ) {
      return nextNode;
    }

    const children = possibleAssignmentNode.getChildren(sourceFile);
    for (let i = 0; i < children.length; ++i) {
      const content = findAssignmentContent(children[i], children[i + 1]);
      if (content) {
        return content;
      }
    }
  };

  const firstAssignment = findAssignmentContent(node);
  if (!firstAssignment) {
    const children = node.getChildren(sourceFile);
    return children[1] ?? children[0];
  }

  return firstAssignment;
}
