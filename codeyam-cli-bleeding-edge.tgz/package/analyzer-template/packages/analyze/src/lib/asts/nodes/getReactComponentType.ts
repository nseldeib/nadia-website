import ts from 'typescript';
import * as lib from '../../../lib/index';

export function getReactComponentType(node: ts.Node): lib.types.ComponentType {
  let hasClassComponent = false;
  let hasFunctionalComponent = false;
  let isProvider = false;

  const checkNode = (node: ts.Node): void => {
    if (ts.isClassDeclaration(node)) {
      hasClassComponent = true;
    } else if (
      ts.isFunctionDeclaration(node) ||
      ts.isArrowFunction(node) ||
      ts.isVariableDeclaration(node)
    ) {
      hasFunctionalComponent = true;
    }

    ts.forEachChild(node, checkNode);
  };

  checkNode(node);

  // TODO: super lazy, this needs to be improved
  if (node.getText().includes('.Provider')) {
    isProvider = true;
  }

  if (isProvider) {
    return lib.types.ComponentType.Provider;
  } else if (hasClassComponent) {
    return lib.types.ComponentType.Class;
  } else if (hasFunctionalComponent) {
    return lib.types.ComponentType.Functional;
  } else {
    return lib.types.ComponentType.Unknown;
  }
}
