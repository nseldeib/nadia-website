import ts from 'typescript';
import * as lib from '../../../lib/index';

export { getComponentProps } from './getComponentProps';
export { getComponentType } from './getComponentType';
export { getDefaultExportedFunctionNode } from './getDefaultExportedFunctionNode';
export { getPropsFromFunctionalComponent } from './getPropsFromFunctionalComponent';
export { getResolvedImportedTypes } from './getResolvedImportedTypes';
export { getSourceFilesForImports } from './getSourceFilesForImports';
export { getSourceFilesForAllImports } from './getSourceFilesForAllImports';
export { getImportMappings } from './getImportMappings';
export { getAllEntities } from './getAllEntities';
export { getAllEntityNodes } from './getAllEntityNodes';
export { getEntityNode } from './getEntityNode';
export { getAllExports } from './getAllExports';
export { getAllExportedNodes } from './getAllExportedNodes';
export { getImportsAnalysis } from './getImportsAnalysis';
export { getPseudoFile } from './getPseudoFile';
export { getResolvedModule } from './getResolvedModule';
export { getSourceFile } from './getSourceFile';

export function getDefaultExportFunctionNodeOrFirstFunctionNode(
  sourceFile: ts.SourceFile,
): lib.types.FunctionNode | undefined {
  const node = lib.asts.sourceFiles.getDefaultExportedFunctionNode(sourceFile);
  if (node && lib.asts.nodes.isFunction(node)) {
    return node;
  } else {
    return lib.asts.getFirstFunctionNode(sourceFile);
  }
}

/**
 * This will return the absolute path of imported files from the given file
 * e.g. /Users/yourMacUser/path/to/simulated/project/within/codeyam/file.ts
 */
export function getAbsolutePathsForInternalImports(
  sourceFile: ts.SourceFile,
  program: ts.Program,
): string[] {
  return lib.asts.sourceFiles
    .getSourceFilesForAllImports(sourceFile, program)
    .map((sourceFile) => sourceFile.fileName);
}

export function getRootRelativePathsForInternalImports(
  sourceFile: ts.SourceFile,
  program: ts.Program,
  dirPath: string,
): string[] {
  return lib.asts.sourceFiles
    .getAbsolutePathsForInternalImports(sourceFile, program)
    .map((sourceFile) => sourceFile.replace(dirPath, ''));
}
