import ts from 'typescript';

export function getSourceFilesForImports(
  moduleNames: string[],
  sourceFile: ts.SourceFile,
  program: ts.Program,
): ts.SourceFile[] {
  return moduleNames
    .map((moduleName) => {
      const resolvedModule = ts.resolveModuleName(
        moduleName,
        sourceFile.fileName,
        program.getCompilerOptions(),
        ts.sys,
      ).resolvedModule;
      if (resolvedModule) {
        return program.getSourceFile(resolvedModule.resolvedFileName);
      }
    })
    .filter(Boolean) as ts.SourceFile[];
}
