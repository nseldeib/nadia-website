import ts from 'typescript';

export function getDefaultExportedFunctionNode(
  sourceFile: ts.SourceFile,
): ts.FunctionDeclaration | ts.ArrowFunction | undefined {
  let defaultExportNode: ts.Node | undefined;

  // Inspect each node to find the default export
  function findDefaultExportNode(node: ts.Node) {
    // Direct default export of a function declaration or an arrow function
    if (
      (ts.isFunctionDeclaration(node) || ts.isVariableStatement(node)) &&
      node.modifiers?.some((mod) => mod.kind === ts.SyntaxKind.DefaultKeyword)
    ) {
      defaultExportNode = node;
      return;
    }

    // Export assignment (export default)
    if (ts.isExportAssignment(node) && !node.isExportEquals) {
      defaultExportNode = node.expression;
      return;
    }

    // Continue searching through the child nodes if not found
    node.forEachChild(findDefaultExportNode);
  }

  sourceFile.forEachChild(findDefaultExportNode);

  // If the default export is an identifier (variable name), find the corresponding variable statement
  if (defaultExportNode && ts.isIdentifier(defaultExportNode)) {
    const identifierName = defaultExportNode.text;
    sourceFile.forEachChild((node) => {
      if (ts.isVariableStatement(node)) {
        const [declaration] = node.declarationList.declarations;
        if (
          declaration.name &&
          ts.isIdentifier(declaration.name) &&
          declaration.name.text === identifierName
        ) {
          defaultExportNode = declaration.initializer;
        }
      }
    });
  }

  // At this point, defaultExportNode could be a FunctionDeclaration, ArrowFunction, or undefined
  return defaultExportNode as
    | ts.FunctionDeclaration
    | ts.ArrowFunction
    | undefined;
}
