import ts from 'typescript';

export function getAllExportedNodes(
  sourceFile: ts.SourceFile,
): Record<string, ts.Node> {
  const exportsCodeMap: Record<string, ts.Node> = {};

  function handleExportedNode(node: ts.Node) {
    let name = 'default';

    if (ts.isFunctionDeclaration(node) && node.name) {
      name = node.name.text;
    } else if (ts.isVariableStatement(node)) {
      const [declaration] = node.declarationList.declarations;
      if (ts.isIdentifier(declaration.name)) {
        name = declaration.name.text;
      }
    } else if (
      ts.isTypeAliasDeclaration(node) ||
      ts.isInterfaceDeclaration(node)
    ) {
      name = node.name.text;
    }

    exportsCodeMap[name] = node;
  }

  function processExportAssignment(node: ts.ExportAssignment) {
    if (ts.isIdentifier(node.expression)) {
      const name = node.expression.text;
      sourceFile.forEachChild((child) => {
        if (
          (ts.isFunctionDeclaration(child) || ts.isVariableStatement(child)) &&
          ((ts.isFunctionDeclaration(child) && child.name?.text === name) ||
            (ts.isVariableStatement(child) &&
              child.declarationList.declarations.some(
                (dec) => ts.isIdentifier(dec.name) && dec.name.text === name,
              )))
        ) {
          exportsCodeMap[name] = child;
        } else if (
          ts.isExportAssignment(child) &&
          child.expression.getText(sourceFile) === name
        ) {
          exportsCodeMap[name] = child;
        }
      });
    } else if (ts.isCallExpression(node.expression)) {
      const name = node.expression.expression.getText(sourceFile);
      exportsCodeMap[name] = node;
    } else {
      exportsCodeMap['default'] = node;
    }
  }

  function processNamedExports(node: ts.NamedExports) {
    node.elements.forEach((element) => {
      const name = element.name.text;
      const propertyName = element.propertyName
        ? element.propertyName.text
        : name;
      const importedSource = node.parent.moduleSpecifier
        ? node.parent.moduleSpecifier.getText(sourceFile)
        : undefined;

      if (importedSource) {
        exportsCodeMap[name] = element;
      } else {
        const declarations = sourceFile.statements.filter(
          (
            stmt,
          ): stmt is
            | ts.ImportDeclaration
            | ts.FunctionDeclaration
            | ts.VariableStatement =>
            (ts.isImportDeclaration(stmt) ||
              ts.isFunctionDeclaration(stmt) ||
              ts.isVariableStatement(stmt)) &&
            ((ts.isFunctionDeclaration(stmt) &&
              stmt.name?.text === propertyName) ||
              (ts.isVariableStatement(stmt) &&
                stmt.declarationList.declarations.some(
                  (dec) =>
                    ts.isIdentifier(dec.name) && dec.name.text === propertyName,
                )) ||
              (ts.isImportDeclaration(stmt) &&
                (stmt.importClause?.getText(sourceFile) === propertyName ||
                  (stmt.importClause?.namedBindings &&
                    ts.isNamedImports(stmt.importClause?.namedBindings) &&
                    stmt.importClause?.namedBindings.elements.some(
                      (e) => e.name.text === propertyName,
                    ))))),
        );

        declarations.forEach((decl) => {
          exportsCodeMap[name] = decl;
        });
      }
    });
  }

  sourceFile.forEachChild((node) => {
    if (ts.isFunctionDeclaration(node) || ts.isVariableStatement(node)) {
      if (
        node.modifiers?.some((mod) => mod.kind === ts.SyntaxKind.ExportKeyword)
      ) {
        handleExportedNode(node);
      }
    } else if (
      ts.isTypeAliasDeclaration(node) ||
      ts.isInterfaceDeclaration(node)
    ) {
      if (
        node.modifiers?.some((mod) => mod.kind === ts.SyntaxKind.ExportKeyword)
      ) {
        handleExportedNode(node);
      }
    } else if (ts.isExportAssignment(node) && !node.isExportEquals) {
      processExportAssignment(node);
    } else if (ts.isExportDeclaration(node) && node.exportClause) {
      if (ts.isNamedExports(node.exportClause)) {
        processNamedExports(node.exportClause);
      } else if (ts.isNamespaceExport(node.exportClause)) {
        const name = node.exportClause.name.text;
        exportsCodeMap[name] = node;
      }
    }
  });

  return exportsCodeMap;
}
