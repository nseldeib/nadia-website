import ts from 'typescript';

export function getSourceFile(
  content: string,
  fileName: string = 'example.ts',
): ts.SourceFile {
  return ts.createSourceFile(
    fileName,
    content,
    ts.ScriptTarget.Latest,
    /*setParentNodes*/ true,
  );
}
