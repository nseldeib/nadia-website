/**
 * `lib.asts` is the namespace for functions related to AST manipulation.
 * Ideally this will wrap most of the TS Compiler API calls. These will be
 * simple functions that are composed in higher order functions, such as those
 * that exist within `FileAnalyzer`.
 */

import ts from 'typescript';
import * as lib from '../index';

export * as nodes from './nodes/index';
export * as sourceFiles from './sourceFiles/index';

/**
 * ## Notes
 *
 * The high level flow of the implementation is as follows:
 *
 * - get type reference nodes
 * - map those into type object
 * - map type objects into symbols (which are import AST constructs)
 * - map symbols to their declarations
 * - declarations of symbols of types are, in essence, the type definitions.
 */
export function getTypeDependenciesString({
  sourceFile,
  program,
}: {
  sourceFile: ts.SourceFile;
  program: ts.Program;
}) {
  const typeChecker = program.getTypeChecker();
  const typeReferenceNodes = getTypeReferenceNodes(sourceFile);
  const types = typeReferenceNodes.map((trn) =>
    typeChecker.getTypeAtLocation(trn),
  );
  const isSymbol = (x: ts.Symbol | undefined): x is ts.Symbol => !!x;
  const symbols = types.map((t) => t.aliasSymbol).filter(isSymbol);
  const isDeclaration = (x: ts.Declaration | undefined): x is ts.Declaration =>
    !!x;
  const declarations = symbols
    .map((s) => s.getDeclarations())
    .flat()
    .filter(isDeclaration);
  const strings = declarations.map((d) => d.getText());
  const string = strings.join('\n');
  return string;
}

/**
 * This function collects all `TypeReferenceNodes` from the `SourceFile`
 * (instead of, for example, just the `TypeReferenceNodes` within a particular
 * `FunctionDeclaration`).
 */
export function getTypeReferenceNodes(
  sourceFile: ts.SourceFile,
): ts.TypeReferenceNode[] {
  const typeReferenceNodes: ts.TypeReferenceNode[] = [];

  function visit(node: ts.Node) {
    if (ts.isTypeReferenceNode(node)) {
      typeReferenceNodes.push(node);
    }

    ts.forEachChild(node, visit);
  }

  visit(sourceFile);

  return typeReferenceNodes;
}

/**
 * This function generates the full TS AST from the `tsConfigPath`. In TS
 * parlance the full AST is called a `Program`. A program consists of individual
 * source files of type `SourceFile` which contain nodes.
 */
export function createProgramFromTsConfigPath(
  tsConfigPath: string,
): ts.Program {
  const parsedCommandLine = ts.getParsedCommandLineOfConfigFile(
    tsConfigPath,
    {},
    {
      ...ts.sys,
      onUnRecoverableConfigFileDiagnostic: () => {},
    },
  );

  if (!parsedCommandLine) {
    throw new Error('Could not parse tsconfig.json');
  }

  return ts.createProgram({
    rootNames: parsedCommandLine.fileNames,
    options: parsedCommandLine.options,
  });
}

export function getAllFunctionNodes(
  sourceFile: ts.SourceFile,
): lib.types.FunctionNode[] {
  const functionNodes: lib.types.FunctionNode[] = [];

  function visit(node: ts.Node) {
    if (lib.asts.nodes.isFunction(node)) {
      functionNodes.push(node);
    }

    ts.forEachChild(node, visit);
  }

  ts.forEachChild(sourceFile, visit);

  return functionNodes;
}

export function getFirstFunctionsFirstParameterNode(
  sourceFile: ts.SourceFile,
): ts.ParameterDeclaration | undefined {
  const functionNode = lib.asts.getFirstFunctionNode(sourceFile);
  if (!functionNode) throw 'no functions defined in source file';

  const parameterNode = lib.asts.nodes.getFirstParameter(functionNode);
  return parameterNode;
}

/**
 * Turns an arbitrary string into a `ts.SourceFile` object.
 *
 * Example use case is turning the contents of a single file into a
 * `ts.SourceFile` for analysis.  (In general you should prefer creating a
 * `ts.Program` so imports can resolve appropriately, but for quick and dirty
 * single-file analysis, this can suffice.)
 */
export function stringToSourceFile(s: string): ts.SourceFile {
  return ts.createSourceFile(
    // A dummy file name, as the actual file name is not relevant here
    'file.ts',
    s,
    // You can adjust the script target as necessary
    // e.g., ts.ScriptTarget.ES2022
    ts.ScriptTarget.Latest,
    // setParentNodes: A boolean flag that indicates whether parent references
    // should be included in the AST nodes
    true,
  );
}

export function getFirstFunctionNode(
  sf: ts.SourceFile,
): lib.types.FunctionNode | undefined {
  let fnode: lib.types.FunctionNode | undefined = undefined;

  function visit(node: ts.Node) {
    switch (node.kind) {
      case ts.SyntaxKind.FunctionDeclaration:
      case ts.SyntaxKind.FunctionExpression:
      case ts.SyntaxKind.ArrowFunction:
        if (!lib.asts.nodes.isFunction(node)) {
          throw 'unsupported function syntax';
        }

        fnode = node;
        return;
      default:
        if (fnode) return;
        ts.forEachChild(node, visit);
    }
  }

  ts.forEachChild(sf, visit);

  return fnode;
}

export function getImportDeclarationNodes(
  sf: ts.SourceFile,
): ts.ImportDeclaration[] {
  const imports: ts.ImportDeclaration[] = [];

  function visit(node: ts.Node) {
    if (ts.isImportDeclaration(node)) {
      imports.push(node);
    }

    ts.forEachChild(node, visit);
  }

  ts.forEachChild(sf, visit);

  return imports;
}
