import ts from 'typescript';
import { PropsWithTypes } from '~codeyam/types';
import * as lib from '../../index';
import { FunctionNode } from '../../types';

type GetPropsFromFunctionalComponentProps = {
  functionNode?: FunctionNode;
  sourceFile: ts.SourceFile;
  checker: ts.TypeChecker;
  properties?: string[];
};

export function getPropsFromFunctionalComponent({
  functionNode,
  sourceFile,
  checker,
  properties,
}: GetPropsFromFunctionalComponentProps): PropsWithTypes {
  // console.log("CODEYAM DEBUG: getPropsFromFunctionalComponent", functionNode?.getText(sourceFile), sourceFile.getText())
  if (!functionNode) {
    functionNode =
      lib.asts.sourceFiles.getDefaultExportFunctionNodeOrFirstFunctionNode(
        sourceFile,
      );
    if (!functionNode) throw 'no function defined in this file';
  }

  if (ts.SyntaxKind[functionNode.kind] === 'CallExpression') {
    return { props: [] };
  }

  const paramNodes = lib.asts.nodes.getAllParameters(functionNode);

  // function with no parameters
  if (!paramNodes) {
    return { props: [] };
  }

  if (paramNodes[0]?.name?.getText()?.startsWith('{')) {
    const destructuredProps = lib.asts.nodes.propsNodeToPropsData({
      propsNode: paramNodes[0],
      checker,
      properties,
    });

    const destructuredTypeInfo = destructuredProps.reduce((acc, prop) => {
      if (prop.typeStructures) {
        acc = { ...acc, ...prop.typeStructures };
      }
      return acc;
    }, {});

    const destructured = destructuredProps.map((prop) => {
      delete prop.typeStructures;
      return prop;
    });

    const typeStructures = {
      destructured,
      ...destructuredTypeInfo,
    };

    return {
      props: [{ name: 'destructured', type: 'destructured', required: true }],
      typeStructures,
    };
  } else {
    const metaPropsNode = paramNodes.reduce((acc, pn) => {
      acc[pn.name.getText()] = pn;
      return acc;
    }, {});

    const propInfo = lib.asts.nodes.propsNodeToPropsData({
      metaPropsNode,
      checker,
      properties,
    });

    const typeStructures = propInfo.reduce((acc, prop) => {
      if (prop.typeStructures) {
        acc = { ...acc, ...prop.typeStructures };
      }
      return acc;
    }, {});

    const props = propInfo.map((prop) => {
      delete prop.typeStructures;
      return prop;
    });

    return {
      props,
      typeStructures,
    };
  }
}
