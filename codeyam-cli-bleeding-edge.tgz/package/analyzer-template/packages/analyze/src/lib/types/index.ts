/**
 * All types that remain internal to lib should go here
 */

import ts from 'typescript';

export type FunctionNode =
  | ts.ArrowFunction
  | ts.FunctionExpression
  | ts.FunctionDeclaration;

export enum ComponentType {
  Unknown,
  Class,
  Functional,
  Provider,
}
