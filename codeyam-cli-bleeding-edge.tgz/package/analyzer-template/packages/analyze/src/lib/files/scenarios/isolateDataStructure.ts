export default function isolateDataStructure({
  rawDataStructure,
  dependencyNames,
}: {
  rawDataStructure: {
    structure: Record<string, string>;
    equivalentVariables: Record<string, string>;
    functionDataStructure: Record<string, string>;
    functionFinalDataStructure: Record<string, string>;
  };
  dependencyNames: string[];
}) {
  const mocksDataEquivalencies = Object.entries(
    rawDataStructure.functionDataStructure,
  ).reduce(
    (acc, [key, value]) => {
      for (const name of dependencyNames) {
        if (key.startsWith(name)) {
          acc[key] = value;
          break;
        }
      }
      return acc;
    },
    {} as Record<string, string>,
  );

  const mocksDataStructure = Object.entries(
    rawDataStructure.functionFinalDataStructure,
  ).reduce(
    (acc, [key, value]) => {
      for (const name of dependencyNames) {
        if (key.startsWith(name)) {
          acc[key] = value;
          break;
        }
      }
      return acc;
    },
    {} as Record<string, string>,
  );

  const structure = Object.keys(rawDataStructure.structure).reduce(
    (acc, key) => {
      if (key.startsWith('signature') || key.startsWith('returnValue')) {
        acc[key] = rawDataStructure.structure[key];
      }
      return acc;
    },
    {} as Record<string, string>,
  );

  const equivalentSignatureVariables = Object.keys(
    rawDataStructure.equivalentVariables,
  ).reduce(
    (acc, key) => {
      if (rawDataStructure.equivalentVariables[key].startsWith('signature')) {
        acc[rawDataStructure.equivalentVariables[key]] = key;
      }
      return acc;
    },
    {} as Record<string, string>,
  );

  return {
    structure,
    equivalentSignatureVariables,
    mocksDataEquivalencies,
    mocksDataStructure,
  };
}
