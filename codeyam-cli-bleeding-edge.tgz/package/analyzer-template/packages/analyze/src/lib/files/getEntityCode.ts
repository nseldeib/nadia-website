import ts from 'typescript';
import * as lib from '../index';

interface GetEntityCodeArgs {
  entityName: string;
  sourceFile: ts.SourceFile;
  removeComments?: boolean;
}

export default function getEntityCode({
  entityName,
  sourceFile,
  removeComments,
}: GetEntityCodeArgs) {
  const entityNode = lib.asts.sourceFiles.getEntityNode({
    entityName,
    sourceFile,
  });

  if (removeComments) {
    const printer = ts.createPrinter({ removeComments: true });
    return printer.printNode(ts.EmitHint.Unspecified, entityNode, sourceFile);
  }

  return entityNode.getText(sourceFile);
}
