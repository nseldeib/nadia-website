import { Entity } from '~codeyam/types';
import { ImmutableAnalysisContext } from '../../analysisContext';
import { awsLog } from '~codeyam/utils';

export default function findImportedEntity(
  importedExport: Pick<
    Entity,
    | 'resolvedFilePath'
    | 'filePath'
    | 'resolvedIsDefault'
    | 'resolvedName'
    | 'name'
  >,
  context: ImmutableAnalysisContext,
) {
  const dependentEntityPath =
    importedExport.resolvedFilePath ?? importedExport.filePath;
  const dependentEntityName = importedExport.resolvedIsDefault
    ? 'default'
    : (importedExport.resolvedName ?? importedExport.name);
  const dependentEntity = context.getEntity(
    dependentEntityPath,
    dependentEntityName,
  );

  if (!dependentEntity) {
    awsLog('CodeYam Error: Dependent entity not found!', {
      filePath: dependentEntityPath,
      entityName: dependentEntityName,
      importedExport,
    });
    throw new Error('findImportedEntity: Dependent entity not found!');
  }

  return dependentEntity;
}
