import { Mock } from '~codeyam/types';
import { FunctionDependenciesMap } from '../..';

export default function findRelevantExportInfo(
  mock: Mock,
  resolvedImports: FunctionDependenciesMap,
) {
  const mockFilePath = mock.resolvedFilePath ?? mock.filePath;
  const mockEntityName = mock.resolvedEntityName ?? mock.entityName;
  const mockIsDefault =
    mock.resolvedIsDefault ?? mock.metadata?.defaultExport ?? false;

  for (const importInfo of Object.values(resolvedImports)) {
    const exportInfoWithMatchingPath = importInfo.exportInfos.find(
      (exportInfo) => exportInfo.resolvedPath === mockFilePath,
    );

    if (exportInfoWithMatchingPath) {
      if (
        exportInfoWithMatchingPath.exportName === mockEntityName ||
        exportInfoWithMatchingPath.importName === mockEntityName ||
        exportInfoWithMatchingPath.importAlias === mockEntityName ||
        (exportInfoWithMatchingPath.isExportDefault &&
          (mockEntityName === 'default' || mockIsDefault))
      ) {
        return exportInfoWithMatchingPath;
      }
    }
  }

  const relevantImport = Object.values(resolvedImports).find(
    (importInfo) =>
      importInfo.resolvedPath === mockFilePath ||
      Object.keys(resolvedImports).some(
        (key) =>
          key.includes(mockEntityName) && resolvedImports[key] === importInfo,
      ),
  );

  if (!relevantImport) {
    return undefined;
  }

  return relevantImport.exportInfos.find(
    (exportInfo) =>
      exportInfo.exportName === mockEntityName ||
      exportInfo.importName === mockEntityName ||
      exportInfo.importAlias === mockEntityName ||
      (exportInfo.isExportDefault &&
        (mockEntityName === 'default' || mockIsDefault)),
  );
}
