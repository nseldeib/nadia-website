import { Entity, File, Project } from '~codeyam/types';
import { FileAnalyzer } from '../FileAnalyzer';
import { ProjectAnalyzer } from '../ProjectAnalyzer';
// import { generateSha } from '~codeyam/supabase';

export default function getImportedExports(
  file: File,
  functionName: string,
  fileAnalyzer: FileAnalyzer,
  projectAnalyzer: ProjectAnalyzer,
  project: Project,
): Entity['metadata']['importedExports'] {
  const relevantLocalEntities = fileAnalyzer
    .getLocalEntitiesUsedInFunction(functionName)
    .map((entity) => {
      const name = entity.name;
      const code = entity.code;
      const filePath = file.path;
      const entityType = fileAnalyzer.getEntityType(name);
      const isDefault = fileAnalyzer.isDefaultExport(name);
      return {
        filePath,
        name,
        code,
        entityType,
        isDefault,
      };
    })
    .filter(
      (entity) => entity.filePath !== file.path || entity.name !== functionName,
    );

  const imports =
    fileAnalyzer.getResolvedImportsRelevantToFunctionName(functionName);

  const importedExports = Object.keys(imports)
    .map((filePath) => {
      if (imports[filePath].externalLibrary) return;

      const importedExportInfos = imports[filePath].exportInfos;

      return importedExportInfos.map((importedExportInfo) => {
        const importedExportFile = project.files.find(
          (f) =>
            f.path ===
            (importedExportInfo.resolvedPath ??
              imports[filePath].resolvedPath ??
              filePath),
        );

        if (!importedExportFile) {
          console.log(
            'CodeYam Error: File not found for imported export',
            file.path,
            filePath,
            importedExportInfo,
            imports[filePath],
          );
          return;
        }

        try {
          const importedExportFileAnalyzer =
            projectAnalyzer.getFileAnalyzer(importedExportFile);
          const exportName = importedExportInfo.isExportDefault
            ? 'default'
            : importedExportInfo.exportName;
          const code = importedExportFileAnalyzer.getEntityCode(exportName);
          // const sha = generateSha(importedExportFile.path, exportName, code);
          const entityType =
            importedExportFileAnalyzer.getEntityType(exportName);
          const name =
            importedExportInfo.importName ?? importedExportInfo.importAlias;

          const resolvedFilePath = importedExportInfo.resolvedPath;
          const resolvedName = importedExportInfo.exportName;

          return {
            fileId: importedExportFile.id,
            filePath: imports[filePath].resolvedPath,
            isDefault: importedExportInfo.isImportDefault,
            resolvedFilePath:
              resolvedFilePath === imports[filePath].resolvedPath
                ? undefined
                : resolvedFilePath,
            resolvedName: resolvedName === name ? undefined : resolvedName,
            resolvedIsDefault: importedExportInfo.isExportDefault,
            entityType,
            name,
            code,
          };
        } catch (e) {
          if (e.message.includes('getEntityNode: Entity not found')) {
            console.log(
              'CodeYam Warning: Entity not found in getImportedExports',
              {
                filePath: file.path,
                importFilePath: filePath,
                // importedFileContent: importedExportFile.content,
                importedExportInfo,
              },
            );
            return;
          }

          console.log(
            'CodeYam Error: Error getting imported exports',
            JSON.stringify(
              {
                filePath: file.path,
                importFilePath: filePath,
                importedFileContent: importedExportFile.content,
                importedExportInfo,
              },
              null,
              2,
            ),
            e,
          );
          throw e;
        }
      });
    })
    .flat()
    .filter(Boolean);

  return [...relevantLocalEntities, ...importedExports];
}
