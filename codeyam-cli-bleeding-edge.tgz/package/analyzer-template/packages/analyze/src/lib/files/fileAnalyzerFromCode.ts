import ts from 'typescript';
import { File } from '~codeyam/types';
import { FileAnalyzer, ProjectAnalyzer } from '~codeyam/analyze';

export default function fileAnalyzerFromCode(
  path: string,
  code: string,
): FileAnalyzer {
  const compilerOptions = {
    target: ts.ScriptTarget.Latest,
    jsx: ts.JsxEmit.React,
    module: ts.ModuleKind.ESNext,
    strict: true,
    esModuleInterop: true,
    skipLibCheck: true,
  };

  const host = ts.createCompilerHost(compilerOptions);

  const originalGetSourceFile = host.getSourceFile;
  host.getSourceFile = (name: string, languageVersion: ts.ScriptTarget) => {
    if (name === path) {
      return ts.createSourceFile(
        name,
        code,
        languageVersion,
        true,
        ts.ScriptKind.TSX,
      );
    }
    return originalGetSourceFile.call(host, name, languageVersion);
  };

  const program = ts.createProgram([path], compilerOptions, host);

  const simpleProjectAnalyzer = {
    dirPath: '/project/root',
    typeChecker: program.getTypeChecker(),
    getSourceFile: program.getSourceFile,
    getResolvedModule: () => ({
      isExternalLibraryImport: false,
      resolvedFileName: '/project/root/src/module.ts',
    }),
    getRelativePath: () => './src/module.ts',
    getFileAnalyzerByPath: () => {},
  } as unknown as ProjectAnalyzer;

  const simpleFile = {
    path: path,
    content: code,
  } as unknown as File;

  return new FileAnalyzer({
    projectAnalyzer: simpleProjectAnalyzer,
    file: simpleFile,
  });
}
