import { FileAnalyzer } from '../FileAnalyzer';

export default function getNodeModuleImports(
  functionName: string,
  fileAnalyzer: FileAnalyzer,
): { [key: string]: { name: string; isDefault: boolean }[] } {
  const imports =
    fileAnalyzer.getResolvedImportsRelevantToFunctionName(functionName);

  const nodeModuleImports = Object.keys(imports).reduce(
    (acc, path) => {
      if (!imports[path].externalLibrary) return acc;

      acc[path] = imports[path].exportInfos.map((info) => ({
        name: info.exportName,
        isDefault: info.isExportDefault,
      }));
      return acc;
    },
    {} as { [key: string]: { name: string; isDefault: boolean }[] },
  );

  const code = fileAnalyzer.getEntityCode(functionName);
  if (code.match('fetch\\s*\\(')) {
    nodeModuleImports['fetch'] = [{ name: 'fetch', isDefault: true }];
  }

  return nodeModuleImports;
}
