import crypto from 'crypto';
import type { Entity } from '~codeyam/types';
import { ImmutableAnalysisContext } from '../../analysisContext';

/**
 * Generate an analysis tree SHA considering all entity dependencies and their analyses
 * Uses AnalysisContext to access entities and analyses
 */
export default function generateAnalysisTreeSha(
  entity: Entity,
  context: ImmutableAnalysisContext,
) {
  try {
    const dependencies = entity.metadata.importedExports ?? [];
    const sortedDependencies = dependencies.sort((a, b) =>
      `${a.filePath}-${a.name}`.localeCompare(`${b.filePath}-${b.name}`),
    );

    const dataShaList: string[][] = [];
    const hash = crypto.createHash('sha256');
    for (const dependency of sortedDependencies) {
      const dependencyFilePath =
        dependency.resolvedFilePath ?? dependency.filePath;
      const dependencyName = dependency.resolvedName ?? dependency.name;

      const dependentEntity = context.getEntity(
        dependencyFilePath,
        dependencyName,
      );
      if (
        !dependentEntity ||
        !['library', 'visual'].includes(dependentEntity.entityType)
      )
        continue;

      const entityDataStructure =
        dependentEntity.metadata.isolatedDataStructure;

      const dependencySchemas = entityDataStructure?.dependencySchemas ?? {};

      const sortedKeys = (obj: Record<string, unknown> | undefined) => {
        return Object.keys(obj ?? {}).sort();
      };
      const values = (
        keys: string[],
        obj: Record<string, unknown> | undefined,
      ) => {
        return keys.map((key) => [key, obj?.[key]]);
      };
      const normalizedDependencySchemas = sortedKeys(dependencySchemas).reduce(
        (acc, filePath) => {
          sortedKeys(dependencySchemas[filePath])
            .sort()
            .forEach((entityName) => {
              const { signatureSchema, returnValueSchema } =
                dependencySchemas[filePath][entityName];
              acc.push([
                filePath,
                entityName,
                'signatureSchema',
                values(sortedKeys(signatureSchema), signatureSchema),
                'returnValueSchema',
                values(sortedKeys(returnValueSchema), returnValueSchema),
              ]);
            });
          return acc;
        },
        [],
      );

      // Generate SHA of dependency schemas
      const dependencySchemasSha = crypto.createHash('sha256');
      dependencySchemasSha.update(JSON.stringify(normalizedDependencySchemas));
      const dependencySchemasHash = dependencySchemasSha.digest('hex');

      dataShaList.push([
        dependencyFilePath,
        dependencyName,
        dependencySchemasHash,
      ]);
      hash.update(dependencySchemasHash);
    }
    hash.update(entity.sha);
    return { dataShaList, analysisTreeSha: hash.digest('hex') };
  } catch (e) {
    console.log('CodeYam Error: Error generating analysis tree sha', e, {
      filePath: entity.filePath,
      name: entity.name,
      sha: entity.sha,
      circular: entity.metadata?.hasCircularDependency,
    });
    throw e;
  }
}
