import { loadAnalysis } from '~codeyam/supabase';
import { Analysis, Project } from '~codeyam/types';

export interface FindValidExistingAnalysisArgs {
  project: Project;
  dependencyAnalyzedTreeSha: string;
  analyzedBefore?: number;
}

export default async function findValidExistingAnalysis({
  project,
  dependencyAnalyzedTreeSha,
}: FindValidExistingAnalysisArgs): Promise<Analysis | null> {
  const existingAnalysis = (await loadAnalysis({
    projectId: project.id,
    dependencyAnalyzedTreeSha,
    includeScenarios: true,
  })) as Analysis;

  if (!existingAnalysis) {
    return null;
  }

  return existingAnalysis;
}
