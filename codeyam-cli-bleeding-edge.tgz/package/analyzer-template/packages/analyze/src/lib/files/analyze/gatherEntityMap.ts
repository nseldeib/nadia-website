import { Entity } from '~codeyam/types';
import findOrCreateEntity from './findOrCreateEntity';
import { ProjectAnalyzer } from '../../ProjectAnalyzer';
import { AnalysisContext } from '../../analysisContext';

interface EntityWithGatheredDependencies extends Entity {
  dependenciesGathered?: boolean;
}

interface GatherEntityMapArgs {
  entity: EntityWithGatheredDependencies;
  commitId?: string;
  branchId: string;
  context: AnalysisContext;
  projectAnalyzer: ProjectAnalyzer;
  isMocked?: boolean;
}

export default async function gatherEntityMap({
  entity,
  commitId,
  branchId,
  context,
  projectAnalyzer,
  isMocked,
}: GatherEntityMapArgs): Promise<void> {
  // Check if entity already has dependencies gathered
  const existingEntity = context.getEntity(
    entity.filePath,
    entity.name,
  ) as EntityWithGatheredDependencies;
  if (existingEntity?.dependenciesGathered) {
    return;
  }

  // Mark entity as having dependencies gathered and add to context
  entity.dependenciesGathered = true;
  context.addEntity(entity);

  // Handle default exports
  if (
    entity.metadata &&
    !entity.metadata.notExported &&
    !entity.metadata.namedExport
  ) {
    // The same entity is also exported under name 'default'
    context.addEntity(entity, 'default');
  }

  // If no imported exports, we're done
  if (isMocked || !entity.metadata?.importedExports) {
    return;
  }

  // console.log(
  //   `🔍 Gathering imported exports for ${entity.filePath}:${entity.name}`,
  // );

  // Process imported exports
  const { project } = projectAnalyzer;
  for (const importedExport of entity.metadata.importedExports) {
    const importedExportFilePath =
      importedExport.resolvedFilePath ?? importedExport.filePath;
    const importedExportName =
      importedExport.resolvedName ?? importedExport.name;

    // console.log(
    //   `  → imported export ${importedExportFilePath}:${importedExportName}`,
    // );

    const importedFile = project.files.find(
      (file) => file.path === importedExportFilePath,
    );

    if (!importedFile) {
      console.log(
        `CodeYam Error: File not found while gathering entity map: ${importedExportFilePath}`,
        entity.filePath,
        entity.name,
      );
      throw new Error(
        `File not found while gathering entity map: ${importedExportFilePath}`,
      );
    }

    let importedEntity = context.getEntity(
      importedFile.path,
      importedExportName,
    ) as EntityWithGatheredDependencies;
    if (!importedEntity) {
      const fileAnalyzer = projectAnalyzer.getFileAnalyzer(importedFile);

      importedEntity = await findOrCreateEntity({
        file: importedFile,
        commitId,
        branchId,
        entityName: importedExportName,
        fileAnalyzer,
        projectAnalyzer,
        context,
      });

      if (!importedEntity) {
        console.log(
          `CodeYam Error: Entity not found while gathering entity map: ${importedFile.path}: ${importedExportName}`,
          {
            entityName: entity.name,
            entityFilePath: entity.filePath,
            importedFilePath: importedFile.path,
            importedExportName: importedExportName,
          },
        );
        throw new Error(
          `Entity not found while gathering entity map: ${importedFile.path}: ${importedExport.name}`,
        );
      }

      // Add newly created entity to context
      context.addEntity(importedEntity);
    }

    // Recursively gather dependencies for imported entity
    await gatherEntityMap({
      entity: importedEntity,
      commitId,
      branchId,
      context,
      projectAnalyzer,
    });
  }
}
