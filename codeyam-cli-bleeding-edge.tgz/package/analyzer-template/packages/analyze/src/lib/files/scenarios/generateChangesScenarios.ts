import {
  Analysis,
  ReadonlyAnalysisMap,
  Commit,
  Entity,
  DEFAULT_SCENARIO_NAME,
} from '~codeyam/types';
import deepEqual from '../../utils/deepEqual';
import measureAndReportExecutionTime from '../../utils/measureAndReportExecutionTime';
import {
  AI,
  generateChangesEntityScenarios,
  generateChangesEntityKeyAttributes,
} from '~codeyam/ai';
import { awsLog } from '~codeyam/utils';

export interface GenerateChangesScenariosArgs {
  previousAnalysis: Analysis;
  commit: Commit;
  entity: Entity;
  analysis: Analysis;
  dependentAnalyses: ReadonlyAnalysisMap;
  error?: boolean;
  model: AI.Model;
  updateProgress?: (detail: string) => void;
}

export default async function generateChangesScenarios({
  previousAnalysis,
  commit,
  entity,
  analysis,
  dependentAnalyses,
  error,
  model,
  updateProgress,
}: GenerateChangesScenariosArgs): Promise<void> {
  if (!['visual', 'library'].includes(entity.entityType)) return;

  const existingScenarios = (previousAnalysis.scenarios ?? []).filter(
    (s) =>
      (error ? s.metadata.error : !s.metadata.error) &&
      !s.metadata.sameAsDefault,
  );
  const commitDiff = commit.files.find(
    (f) => f.fileName === entity.filePath,
  )?.patch;

  const structure = { ...analysis.metadata.scenariosDataStructure };

  awsLog(`CodeYam: Generating ${error ? 'error ' : ''}changes scenarios`, {
    filePath: entity.filePath,
    entityName: entity.name,
    previousAnalysisId: previousAnalysis.id,
    structure: JSON.stringify(structure, null, 2),
    existingScenarios: existingScenarios.map((s) => ({
      id: s.id,
      name: s.name,
      error: s.metadata?.error,
    })),
  });

  const dependentScenarios = {};

  for (const [path, entities] of Object.entries(dependentAnalyses)) {
    dependentScenarios[path] = {};
    for (const [entityName, data] of Object.entries(entities)) {
      dependentScenarios[path][entityName] = data.scenarios;
    }
  }

  if (
    (!structure ||
      (Object.keys(structure.dataForMocks ?? {}).length === 0 &&
        Object.keys(structure.arguments ?? {}).length === 0)) &&
    (!dependentScenarios || Object.keys(dependentScenarios).length === 0)
  ) {
    awsLog(
      `CodeYam Error: No arguments or dataForMocks for ${entity.filePath} ${entity.name}`,
    );
    if (!error) {
      analysis.scenarios = [
        {
          projectId: analysis.projectId,
          analysisId: analysis.id,
          name: DEFAULT_SCENARIO_NAME,
          description: 'The only external state the component can be in.',
          metadata: {
            dataMapping: {},
            keyAttributeInstructions: {},
          },
        },
      ];
    }
    return;
  }

  // if (!analysis.metadata.keyAttributes) {
  const existingKeyAttributes = (
    previousAnalysis.metadata?.keyAttributes ?? []
  ).filter(
    (keyAttribute, index, self) =>
      self.findIndex((ka) => ka.internalPath === keyAttribute.internalPath) ===
      index,
  );

  const {
    result: { keyAttributes, llmCall: keyAttributesLLMCall },
  } = await measureAndReportExecutionTime(
    () =>
      generateChangesEntityKeyAttributes({
        entity,
        existingKeyAttributes,
        analysis,
        commitDiff,
        model,
      }),
    `Generating changes entity key attributes`,
    updateProgress,
  );

  analysis.metadata.keyAttributes = keyAttributes;

  if (keyAttributesLLMCall) {
    analysis.metadata.llmCalls ||= [];
    analysis.metadata.llmCalls.push({
      name: `generateChangesEntityKeyAttributes`,
      id: keyAttributesLLMCall.id,
    });
  }
  // }

  const addedKeyAttributes = analysis.metadata.keyAttributes?.filter(
    (ka) =>
      !previousAnalysis.metadata.keyAttributes?.find(
        (ka2) => ka.internalPath === ka2.internalPath,
      ),
  );
  const removedKeyAttributes = previousAnalysis.metadata.keyAttributes?.filter(
    (ka) =>
      !analysis.metadata.keyAttributes.find(
        (ka2) => ka.internalPath === ka2.internalPath,
      ),
  );
  const {
    result: { overview, scenarios, llmCall },
  } = await measureAndReportExecutionTime(
    () =>
      generateChangesEntityScenarios({
        entity,
        keyAttributes: analysis.metadata.keyAttributes,
        addedKeyAttributes,
        removedKeyAttributes,
        dependentAnalyses,
        existingScenarios,
        commitDiff,
        analysis,
        error,
        model,
      }),
    `Generating changes ${error ? 'error ' : ''}entity scenarios`,
    updateProgress,
  );

  const dataStructureChanged = !deepEqual(
    analysis.metadata?.scenariosDataStructure?.arguments,
    previousAnalysis?.metadata?.scenariosDataStructure?.dataForMocks,
  );
  for (const scenario of scenarios) {
    if (
      scenario.previousVersionId &&
      !scenario.metadata.revisedFromPreviousVersion
    ) {
      if (dataStructureChanged) {
        scenario.metadata.revisedFromPreviousVersion = true;
        continue;
      }

      const existingScenarioStatus = previousAnalysis.status?.scenarios?.find(
        (s) => s.name === scenario.name,
      );
      if (!existingScenarioStatus || existingScenarioStatus.error) {
        scenario.metadata.revisedFromPreviousVersion = true;
      }
    }
  }

  if (llmCall) {
    analysis.metadata.llmCalls ||= [];
    analysis.metadata.llmCalls.push({
      name: `generateChanges${error ? 'Error' : ''}EntityScenarios`,
      id: llmCall.id,
    });
  }

  if (scenarios) {
    if (error) {
      for (const scenario of scenarios) {
        if (!scenario.name.startsWith('Error: ')) {
          scenario.name = `Error: ${scenario.name}`;
        }
      }
    }

    if (analysis.scenarios) {
      for (const existingScenario of analysis.scenarios.filter((s) =>
        error ? !!s.metadata.error : !s.metadata.error,
      )) {
        const scenarioIndex = scenarios.findIndex(
          (s) => s.name === existingScenario.name,
        );
        if (scenarioIndex > -1 && !scenarios[scenarioIndex].id) {
          scenarios[scenarioIndex].id = existingScenario.id;
        } else {
          analysis.scenarios.splice(
            analysis.scenarios.findIndex((s) => s.id === existingScenario.id),
            1,
          );
        }
      }
    }

    awsLog(
      `CodeYam: Generated changes ${error ? 'error ' : ''}scenarios for ${entity.filePath} ${entity.name}`,
      {
        overview: overview?.toString() ?? 'No overview',
        previousAnalysisId: previousAnalysis.id,
        scenarios: scenarios.map((s) => ({
          id: s.id ?? 'New',
          analysisId: s.analysisId,
          name: s.name,
        })),
      },
    );

    analysis.metadata ||= {};
    if (error) {
      analysis.metadata.scenarioErrorChangesOverview =
        overview?.toString() ?? 'No overview provided';
    } else {
      analysis.metadata.scenarioChangesOverview =
        overview?.toString() ?? 'No overview provided';
    }

    if (!analysis.scenarios) {
      analysis.scenarios = scenarios;
    } else {
      for (const scenario of scenarios) {
        const existingIndex = analysis.scenarios.findIndex(
          (s) => s.id === scenario.id || s.name === scenario.name,
        );
        if (scenario.id && existingIndex > -1) {
          analysis.scenarios[existingIndex] = scenario;
        } else {
          analysis.scenarios.push(scenario);
        }
      }
    }
  }
}
