import { Analysis, Commit, Entity, File, Project } from '~codeyam/types';

interface NewAnalysisArgs {
  entity: Entity;
  file: File;
  project: Project;
  commit: Commit;
  branchCommitSha?: string;
  indirect?: boolean;
}

export default function newAnalysis({
  entity,
  file,
  project,
  commit,
  branchCommitSha,
  indirect,
}: NewAnalysisArgs): Analysis {
  return {
    projectId: project.id,
    fileId: file.id,
    entitySha: entity.sha,
    commitId: branchCommitSha ? undefined : commit?.id,
    filePath: entity.filePath,
    entityType: entity.entityType,
    entityName: entity.name,
    branchCommitSha,
    metadata: {
      llmCalls: [],
    },
    status: {
      startedAt: new Date().toISOString(),
      steps: [],
      errors: [],
    },
    indirect,
    committedAt: commit?.committedAt,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}
