import crypto from 'crypto';
import { Analysis } from '~codeyam/types';

export default function generateAnalyzedTreeSha(analysis: Analysis) {
  const hash = crypto.createHash('sha256');

  hash.update(JSON.stringify(analysis.metadata?.scenariosDataStructure ?? {}));

  return hash.digest('hex');
}
