export default function guessDefaultWidth(
  entityName: string,
  filePath: string,
  isDefault: boolean,
): string {
  if (entityName !== 'default' && !isDefault) return;

  const pageFolders = ['pages', 'views', 'routes', 'layouts'];
  const pageNames = ['page'];

  if (
    pageFolders.some((f) => filePath.includes(`/${f}/`)) ||
    pageNames.some((n) => filePath.includes(`/${n}.`))
  ) {
    return '100%';
  }
}
