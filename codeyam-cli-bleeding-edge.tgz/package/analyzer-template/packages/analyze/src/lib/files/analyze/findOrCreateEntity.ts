import { File, ProjectFramework } from '~codeyam/types';
import { FileAnalyzer, ProjectAnalyzer } from '../..';
import {
  loadEntities,
  loadEntity,
  loadEntityBranches,
  updateEntityBranch,
  upsertEntities,
} from '~codeyam/supabase';
import getImportedExports from '../getImportedExports';
import getNodeModuleImports from '../getNodeModuleImports';
import { upsertEntityBranches, generateSha } from '~codeyam/supabase';
import { AnalysisContext } from '../../analysisContext';
import guessDefaultWidth from './guessDefaultWidth';
import { isFrameworkRoute } from '~codeyam/utils';
import analyzeFrameworkRoute from '../analyzeFrameworkRoute';

interface FindOrCreateEntityArgs {
  file: File;
  commitId?: string;
  branchId: string;
  entityName: string;
  fileAnalyzer: FileAnalyzer;
  projectAnalyzer: ProjectAnalyzer;
  context: AnalysisContext;
}

export default async function findOrCreateEntity({
  file,
  commitId,
  branchId,
  entityName,
  fileAnalyzer,
  projectAnalyzer,
  context,
}: FindOrCreateEntityArgs) {
  const localEntityName = entityName;
  if (entityName === 'default') {
    const allEntityNodes = fileAnalyzer.getAllEntityNodes();
    entityName = Object.keys(allEntityNodes).find(
      (exportName) =>
        exportName !== 'default' &&
        allEntityNodes[exportName] === allEntityNodes.default,
    );

    if (!entityName || entityName === 'default') {
      const exportInfos = fileAnalyzer.getAllExports();
      const defaultExportInfo = Object.entries(exportInfos).find(
        ([exportKey]) => exportInfos[exportKey].isDefaultExport,
      )[1];
      const importInfo =
        fileAnalyzer.getResolvedImportsRelevantToFunctionName('default');
      const resolvedPath =
        importInfo[defaultExportInfo.directImportPath]?.resolvedPath;

      if (resolvedPath && file.path !== resolvedPath) {
        const resolvedFileAnalyzer =
          projectAnalyzer.getFileAnalyzerByPath(resolvedPath);
        if (resolvedFileAnalyzer) {
          const resolvedExportInfos = resolvedFileAnalyzer.getAllExports();

          for (const exportKey in resolvedExportInfos) {
            const resolvedExportInfo = resolvedExportInfos[exportKey];
            if (
              defaultExportInfo.directImportName === exportKey ||
              (defaultExportInfo.directImportName === 'default' &&
                resolvedExportInfo.isDefaultExport)
            ) {
              entityName = exportKey;
              break;
            }
          }
        }
      } else if (defaultExportInfo?.directImportName) {
        entityName = defaultExportInfo.directImportName;
        entityName = defaultExportInfo.directImportName;
      }
    }

    if (!entityName) {
      entityName = 'default';
    }
  }

  let entity = context.getMutableEntity(file.path, entityName);
  if (entity) {
    return entity;
  }

  const { project } = projectAnalyzer;

  let code = '';
  try {
    code = fileAnalyzer.getEntityCode(localEntityName);
  } catch (e) {
    console.log('CodeYam Error: could not get entity code', {
      filePath: file.path,
      localEntityName,
      entityName,
      error: e,
    });
    return null;
  }
  const sha = generateSha(file.path, entityName, code);

  if (!context.isBaselineMode()) {
    entity = await loadEntity({
      projectId: project.id,
      sha,
    });
  }

  if (!entity) {
    let defaultWidth = guessDefaultWidth(
      entityName,
      file.path,
      fileAnalyzer.isDefaultExport(entityName),
    );

    let previousEntities = undefined;
    if (!context.isBaselineMode()) {
      previousEntities = await loadEntities({
        projectId: project.id,
        filePaths: [file.path],
        names: [entityName],
      });
    }

    if (previousEntities && previousEntities.length > 0) {
      const sortedPreviousEntities = previousEntities.sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
      for (const previousEntity of sortedPreviousEntities) {
        if (previousEntity.metadata?.defaultWidth) {
          defaultWidth = previousEntity.metadata.defaultWidth;
          break;
        }
      }
    }

    entity = {
      sha,
      name: entityName,
      commitId,
      fileId: file.id,
      filePath: file.path,
      projectId: project.id,
      entityType: fileAnalyzer.getEntityType(localEntityName),
      metadata: {
        defaultWidth,
      },
    };
  }
  entity.metadata ||= {};

  entity.metadata.notExported =
    entity.name !== 'default' && !fileAnalyzer.isExported(entity.name);

  const defaultExport = fileAnalyzer.isDefaultExport(entity.name);
  entity.metadata.namedExport = !defaultExport;

  if (defaultExport) {
    const allEntityNodes = fileAnalyzer.getAllEntityNodes();
    entity.metadata.exportAlias = Object.keys(allEntityNodes).find(
      (exportName) =>
        exportName !== 'default' &&
        allEntityNodes[exportName] === allEntityNodes.default,
    );
  }

  if (!entity.metadata.importedExports) {
    entity.metadata.importedExports = getImportedExports(
      file,
      localEntityName,
      fileAnalyzer,
      projectAnalyzer,
      project,
    );
  }

  if (!entity.metadata.nodeModuleImports) {
    entity.metadata.nodeModuleImports = getNodeModuleImports(
      localEntityName,
      fileAnalyzer,
    );
  }

  if (
    isFrameworkRoute(
      file,
      entity,
      project.metadata?.framework as ProjectFramework,
    )
  ) {
    entity = analyzeFrameworkRoute(
      file,
      projectAnalyzer,
      entity,
      project.metadata?.framework as ProjectFramework,
    );
  }

  const branchIds = entity.branchIds || [];

  if (!context.isBaselineMode()) {
    const entities = await upsertEntities([entity]);
    entity = entities[0];
  }

  entity.filePath = file.path;
  entity.code = code;
  entity.file = file;

  let previousEntityOnBranches = [];
  if (!context.isBaselineMode()) {
    previousEntityOnBranches = await loadEntityBranches({
      filePath: entity.filePath,
      entityName: entity.name,
      branchId,
      active: true,
    });
  }

  if (previousEntityOnBranches && previousEntityOnBranches.length > 0) {
    const thisEntityBranch = previousEntityOnBranches.find(
      (eb) => eb.entitySha === entity.sha,
    );

    if (thisEntityBranch?.entity?.commit) {
      const olderEntityBranches = thisEntityBranch
        ? previousEntityOnBranches.filter(
            (eb) =>
              !eb.entity.commit ||
              new Date(eb.entity.commit.committedAt) <
                new Date(thisEntityBranch.entity.commit.committedAt),
          )
        : previousEntityOnBranches;

      for (const olderEntityBranch of olderEntityBranches) {
        olderEntityBranch.active = false;
        await updateEntityBranch(olderEntityBranch);
      }
    }
  }

  if (branchId && !branchIds.includes(branchId)) {
    branchIds.push(branchId);

    if (!context.isBaselineMode()) {
      await upsertEntityBranches([
        {
          entitySha: entity.sha,
          branchId,
          active: true,
        },
      ]);
    }
    entity.branchIds = branchIds;
  }

  return entity;
}
