import { AI, describeCodeChange } from '~codeyam/ai';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import { Commit, Entity } from '~codeyam/types';
import measureAndReportExecutionTime from '../utils/measureAndReportExecutionTime';

export interface AnalyzeCodeExplanationArgs {
  entity: Entity;
  commit: Commit;
  diff: string;
  model: AI.Model;
  updateProgress?: (detail: string) => void;
}

export default async function analyzeCodeChange({
  entity,
  commit,
  diff,
  model,
  updateProgress,
}: AnalyzeCodeExplanationArgs) {
  if (!['visual', 'library'].includes(entity.entityType)) return entity;

  console.log(
    'Analyzing code change for entity',
    entity.filePath,
    entity.name,
    entity.sha,
  );

  const { result } = await measureAndReportExecutionTime(
    () =>
      describeCodeChange({
        entityCode: entity.code,
        diff,
        title: commit.title,
        commitMessage: commit.message,
        aiCommitMessage: commit.aiMessage,
        model,
      }),
    'Code Change Description',
    updateProgress,
  );

  const { completion, stats } = result;

  const llmCall = await saveLlmCall({
    object_type: 'entity',
    object_id: entity.sha,
    propsJson: {
      entity: {
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      model,
    },
    ...stats,
  });

  if (!completion) return entity;

  console.log(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} (${entity.name}): change description :>> `,
  );
  console.log(completion);
  entity.metadata ||= {};
  entity.metadata.changeDescription = completion;

  return entity;
}
