import {
  convertDotNotation,
  fillInDirectSchemaGapsAndUnknowns,
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from '~codeyam/ai';
import { DataStructure, JsonTypeDefinition } from '~codeyam/types';

export default function gatherDataForMocks(
  importedExports: { filePath?: string; name: string; calls?: string[] }[],
  dependencySchemas: DataStructure['dependencySchemas'],
) {
  // console.info(
  //   'CODEYAM DEBUG: gatherDataForMocks',
  //   JSON.stringify(
  //     {
  //       importedExports: importedExports.map((ie) => ({
  //         filePath: ie.filePath,
  //         name: ie.name,
  //       })),
  //       dependencySchemas,
  //     },
  //     null,
  //     2,
  //   ),
  // );

  return importedExports.reduce(
    (acc, importedExport) => {
      const functionNames: string[] = [];

      const isFunctionNameWithoutFunction = (
        path: string,
        functionName: string,
      ) => {
        return (
          path.startsWith(functionName) && !path.startsWith(functionName + '(')
        );
      };

      const relevantMergedDependencySchema = Object.keys(
        dependencySchemas?.[importedExport.filePath]?.[importedExport.name]
          ?.returnValueSchema ?? {},
      ).reduce(
        (acc, path) => {
          if (path.endsWith(')')) {
            const pathParts = splitOutsideParenthesesAndArrays(path);
            const functionName = joinParenthesesAndArrays([
              ...pathParts.slice(0, -1),
              pathParts[pathParts.length - 1].split('(')[0],
            ]);
            functionNames.push(functionName);
            for (const existingPath in acc) {
              if (isFunctionNameWithoutFunction(existingPath, functionName)) {
                delete acc[existingPath];
              }
            }
          }

          if (
            functionNames.some((fn) => isFunctionNameWithoutFunction(path, fn))
          ) {
            return acc;
          }

          acc[path] =
            dependencySchemas?.[importedExport.filePath]?.[
              importedExport.name
            ]?.returnValueSchema?.[path];
          return acc;
        },
        {} as Record<string, string>,
      );

      const schema = convertDotNotation(
        fillInDirectSchemaGapsAndUnknowns({
          scopeName: importedExport.name,
          schema: relevantMergedDependencySchema,
        }),
      );

      const returnValue = schema['returnValue'];

      if (!returnValue) {
        return acc;
      }

      acc[importedExport.calls[0] ?? importedExport.name] =
        returnValue as JsonTypeDefinition;

      return acc;
    },
    {} as { [importAlias: string]: JsonTypeDefinition },
  );
}
