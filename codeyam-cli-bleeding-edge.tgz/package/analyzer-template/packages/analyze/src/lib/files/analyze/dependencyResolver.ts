import { Analysis, ReadonlyAnalysis } from '~codeyam/types';
import { ImmutableAnalysisContext } from '../../analysisContext';

/**
 * Discovers all direct mock dependencies for a single analysis
 */
export function discoverDirectDependencies(
  analysis: ReadonlyAnalysis,
): Set<string> {
  const dependencies = new Set<string>();

  for (const importedExport of analysis.entity?.metadata?.importedExports ??
    []) {
    if (
      importedExport.isMocked ||
      !importedExport.calls ||
      importedExport.calls.length === 0
    )
      continue;

    // Add the primary mock entity
    dependencies.add(`${importedExport.filePath}:${importedExport.name}`);

    // Add resolved path entity if different (for index.ts resolution)
    if (
      importedExport.resolvedFilePath &&
      importedExport.resolvedFilePath !== importedExport.filePath
    ) {
      dependencies.add(
        `${importedExport.resolvedFilePath}:${importedExport.name}`,
      );

      // Also try resolved entity name if it exists
      if (
        importedExport.resolvedName &&
        importedExport.resolvedName !== importedExport.name
      ) {
        dependencies.add(
          `${importedExport.resolvedFilePath}:${importedExport.resolvedName}`,
        );
      }

      // Also ensure we have the default export for resolved path (used as fallback)
      dependencies.add(`${importedExport.resolvedFilePath}:default`);
    }
  }

  return dependencies;
}

/**
 * Computes transitive closure of dependencies using provided lookup function
 */
export function getTransitiveDependencies(
  rootKeys: Set<string>,
  analysisLookup: (key: string) => ReadonlyAnalysis | null,
): {
  allDependencies: Set<string>;
  missingDependencies: Set<string>;
} {
  const allDependencies = new Set<string>();
  const missingDependencies = new Set<string>();
  const stillNeeded = new Set(rootKeys);

  let foundNewDependencies = true;
  while (foundNewDependencies && stillNeeded.size > 0) {
    foundNewDependencies = false;
    const currentBatch = Array.from(stillNeeded);

    for (const key of currentBatch) {
      stillNeeded.delete(key);

      const analysis = analysisLookup(key);
      if (!analysis) {
        missingDependencies.add(key);
        continue;
      }

      allDependencies.add(key);

      // Discover new dependencies
      const newDeps = discoverDirectDependencies(analysis);
      for (const dep of newDeps) {
        if (!allDependencies.has(dep) && !stillNeeded.has(dep)) {
          stillNeeded.add(dep);
          foundNewDependencies = true;
        }
      }
    }
  }

  return { allDependencies, missingDependencies };
}

/**
 * Checks which analyses are ready for capture (all dependencies complete)
 */
export function getCandidatesReadyForCapture(
  candidateAnalyses: Analysis[],
  context: ImmutableAnalysisContext,
): Analysis[] {
  const readyAnalyses: Analysis[] = [];

  for (const candidate of candidateAnalyses) {
    // Check if this analysis should be capturable
    if (!['visual', 'library', 'index'].includes(candidate.entityType)) {
      continue;
    }

    if (!candidate.scenarios?.length) {
      continue;
    }

    // Get all transitive dependencies
    const candidateKey = `${candidate.filePath}:${candidate.entityName}`;
    const { missingDependencies } = getTransitiveDependencies(
      new Set([candidateKey]),
      (key) => {
        const [filePath, entityName] = key.split(':');
        return context.getAnalysis(filePath, entityName);
      },
    );

    // If no missing dependencies, this candidate is ready
    if (missingDependencies.size === 0) {
      readyAnalyses.push(candidate);
    }
  }

  return readyAnalyses;
}
