import { Entity, File, ProjectFramework } from '~codeyam/types';
import { ProjectAnalyzer } from '../ProjectAnalyzer';
import { isNextRoute, isRemixRoute } from '~codeyam/utils';
import analyzeRemixRoute from './analyzeRemixRoute';
import analyzeNextRoute from './analyzeNextRoute';

export default function analyzeFrameworkRoute(
  file: File,
  projectAnalyzer: ProjectAnalyzer,
  entity: Entity,
  framework: ProjectFramework,
) {
  if (isRemixRoute(file, entity, framework)) {
    return analyzeRemixRoute(file, projectAnalyzer, entity, framework);
  } else if (isNextRoute(file, entity, framework)) {
    return analyzeNextRoute(file, projectAnalyzer, entity, framework);
  }
  return entity;
}
