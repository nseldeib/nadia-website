import {
  Analysis,
  Entity,
  DEFAULT_SCENARIO_NAME,
  ReadonlyAnalysisMap,
} from '~codeyam/types';
import measureAndReportExecutionTime from '../../utils/measureAndReportExecutionTime';
import { AI, generateEntityScenarios } from '~codeyam/ai';
import { awsLog } from '~codeyam/utils';

export interface GenerateScenariosArgs {
  entity: Entity;
  analysis: Analysis;
  dependentAnalyses: ReadonlyAnalysisMap;
  error?: boolean;
  model: AI.Model;
  updateProgress?: (detail: string) => void;
}

export default async function generateScenarios({
  entity,
  analysis,
  dependentAnalyses,
  error,
  model,
  updateProgress,
}: GenerateScenariosArgs): Promise<void> {
  if (!['visual', 'library'].includes(entity.entityType)) return;

  const structure = { ...analysis.metadata.scenariosDataStructure };

  awsLog(`🔮 Generating ${error ? 'error ' : ''}scenarios for`, {
    filePath: entity.filePath,
    entityName: entity.name,
    structure,
  });

  if (
    !structure ||
    (Object.keys(structure.dataForMocks ?? {}).length === 0 &&
      (structure.arguments ?? []).length === 0)
  ) {
    awsLog(
      `CodeYam Error: No arguments or dataForMocks for ${entity.filePath} ${entity.name}`,
    );
    if (!error) {
      analysis.scenarios = [
        {
          projectId: analysis.projectId,
          analysisId: analysis.id,
          name: DEFAULT_SCENARIO_NAME,
          description: 'The only external state the component can be in.',
          metadata: {
            testName: 'it("renders correctly")',
            keyAttributeInstructions: {},
          },
        },
      ];
    }

    return;
  }

  const {
    result: { scenarios, llmCall: scenariosLLMCall },
  } = await measureAndReportExecutionTime(
    () =>
      generateEntityScenarios({
        entity,
        keyAttributes: analysis.metadata.keyAttributes,
        dependentAnalyses,
        analysis,
        error,
        model,
      }),
    `Generating ${error ? 'error ' : ''}entity scenarios`,
    updateProgress,
  );

  if (scenariosLLMCall) {
    analysis.metadata.llmCalls ||= [];
    if (scenariosLLMCall) {
      analysis.metadata.llmCalls.push({
        name: `generate${error ? 'Error' : ''}EntityScenarios`,
        id: scenariosLLMCall.id,
      });
    }
  }

  if (scenarios) {
    if (error) {
      for (const scenario of scenarios) {
        if (!scenario.name.startsWith('Error: ')) {
          scenario.name = `Error: ${scenario.name}`;
        }
      }
    }

    if (analysis.scenarios) {
      for (const existingScenario of analysis.scenarios) {
        const scenarioIndex = scenarios.findIndex(
          (s) => s.name === existingScenario.name,
        );
        if (scenarioIndex > -1) {
          scenarios[scenarioIndex].id = existingScenario.id;
        }
      }
    }

    awsLog(`CodeYam: Generated ${error ? 'error ' : ''}scenarios`, {
      filePath: entity.filePath,
      entityName: entity.name,
      scenarios: scenarios.map((s) => ({ id: s.id ?? 'New', name: s.name })),
    });
    if (!analysis.scenarios) {
      analysis.scenarios = scenarios;
    } else {
      for (const scenario of scenarios) {
        const existingIndex = analysis.scenarios.findIndex(
          (s) => s.id === scenario.id,
        );
        if (scenario.id && existingIndex > -1) {
          analysis.scenarios[existingIndex] = scenario;
        } else {
          analysis.scenarios.push(scenario);
        }
      }
    }
  }
}
