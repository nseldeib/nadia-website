import { ScenarioData } from '~codeyam/types';

export default function findScenarioData(
  name: string,
  scenarioDatas: ScenarioData[],
) {
  const lowerCaseName = name.toLowerCase();
  return scenarioDatas.find((scenarioData) => {
    if (typeof scenarioData.scenarioName !== 'string') {
      console.warn(
        `CodeYam Warning: Surprising value in scenarioData.scenarioName: ${scenarioData.scenarioName}. Expected a string.`,
        {
          scenarioName: scenarioData.scenarioName,
          type: typeof scenarioData.scenarioName,
          scenarioData: JSON.stringify(scenarioData, null, 2),
        },
      );
      return false;
    }
    const lowerCaseScenarioName =
      scenarioData.scenarioName?.toLowerCase() ?? '';
    return (
      lowerCaseScenarioName === lowerCaseName ||
      lowerCaseScenarioName === name.replace(/ /g, '') ||
      lowerCaseScenarioName === name.replace(/ /g, '_') ||
      lowerCaseScenarioName === name.replace(/ /g, '-')
    );
  })?.data;
}
