import { Entity, EntityType, File, ProjectFramework } from '~codeyam/types';
import { ProjectAnalyzer } from '../ProjectAnalyzer';
import { generateSha } from '~codeyam/supabase';
import { isNextRoute } from '~codeyam/utils';

export default function analyzeNextRoute(
  file: File,
  projectAnalyzer: ProjectAnalyzer,
  entity: Entity,
  framework: ProjectFramework,
) {
  if (!isNextRoute(file, entity, framework)) return entity;
  entity.metadata ||= {};
  const importedExports = entity.metadata.importedExports ?? [];

  const fileAnalyzer = projectAnalyzer.getFileAnalyzer(file);
  const localExports = fileAnalyzer.getAllExports();
  const internalDependencies: Entity['metadata']['importedExports'] = [
    ...['loader']
      .map((entityName) => {
        const exportedFunction = localExports[entityName];
        if (!exportedFunction) return;
        return {
          code: exportedFunction.code,
          sha: generateSha(file.path, entityName, exportedFunction.code),
          name: entityName,
          filePath: file.path,
          projectId: entity.projectId,
          entityType: 'library' as EntityType,
          isDefault: false,
          isMocked: true,
        };
      })
      .filter(Boolean),
  ];

  const layouts = projectAnalyzer.project.files.filter((f) => {
    const parts = f.path.split('/');
    const fileName = parts.pop();
    const basePath = parts.join('/');
    if (fileName !== 'layout.tsx') return false;
    if (!file.path.startsWith(basePath)) return false;
    if (file.path === f.path) return false;
    return true;
  });

  const layoutDefaultExportEntities: Entity['metadata']['importedExports'] =
    layouts
      .map((layout) => {
        try {
          const layoutFileAnalyzer = projectAnalyzer.getFileAnalyzer(layout);
          const exports = layoutFileAnalyzer.getAllExports();
          const defaultExport = Object.values(exports).find(
            (e) => e.isDefaultExport,
          );
          const defaultEntity = layout.entities.find((e) =>
            layoutFileAnalyzer.isDefaultExport(e.name),
          );

          if (!defaultExport || !defaultEntity) return;

          const code = defaultExport.code;

          return {
            code: code,
            // sha: generateSha(layout.path, layout.name, code),
            name: defaultEntity.name,
            filePath: layout.path,
            projectId: entity.projectId,
            entityType: 'visual' as EntityType,
            isDefault: true,
            isImplicitDependency: true,
            isMocked: false,
          };
        } catch (e) {
          console.log(
            'CodeYam Warning: unable to find file for analysis',
            layout.path,
            e,
          );
        }
      })
      .filter(
        (layoutEntity) =>
          !!layoutEntity &&
          !importedExports.find(
            (e) => e.filePath && e.filePath === layoutEntity.filePath,
          ),
      );

  entity.metadata.importedExports = [
    ...internalDependencies,
    ...layoutDefaultExportEntities,
    ...importedExports,
  ].filter(
    (entity, index, self) =>
      self.findIndex(
        (e) => e.filePath === entity.filePath && e.name === entity.name,
      ) === index,
  );

  return entity;
}
