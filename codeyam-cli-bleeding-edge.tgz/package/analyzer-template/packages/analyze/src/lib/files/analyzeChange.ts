import type {
  Analysis,
  Commit,
  Entity,
  ReadonlyAnalysisMap,
} from '~codeyam/types';
import generateDataStructure from './scenarios/generateDataStructure';
import generateChangesScenarioData from './scenarios/generateChangesScenarioData';
import generateChangesScenarios from './scenarios/generateChangesScenarios';
import { upsertAnalysesWithScenarios } from '~codeyam/supabase';
import { Step } from './enums/steps';
import updateProps from './analyze/updateProps';
import recordStep from './recordStep';
import { FileAnalyzer } from '..';
import { AI } from '~codeyam/ai';
import extractDiffLines from './extractDiffLines';
import analyzeCodeChange from './analyzeCodeChange';
import relevantDiffPart from './relevantDiffPart';
import { awsLog, pushAnalysisError } from '~codeyam/utils';

export interface AnalyzeChangeArgs {
  previousAnalysis: Analysis;
  analysis: Analysis;
  fileAnalyzer: FileAnalyzer;
  entity: Entity;
  commit: Commit;
  dependentAnalyses: ReadonlyAnalysisMap;
  scenarioIds?: string[];
  steps?: string[];
  updateProgress?: (detail: string) => void;
  model: AI.Model;
}

export default async function analyzeChange({
  previousAnalysis,
  analysis,
  fileAnalyzer,
  entity,
  commit,
  dependentAnalyses,
  scenarioIds,
  steps,
  updateProgress,
  model,
}: AnalyzeChangeArgs) {
  awsLog('CodeYam: Analyzing change entity', {
    filePath: entity.filePath,
    entityName: entity.name,
    scenarios: analysis.scenarios?.length ?? 0,
    scenarioIds,
  });

  analysis.previousAnalysisId = previousAnalysis.id;

  const fileChanged = commit.files.find((f) => f.fileName === entity.filePath);

  let entityChanged = false;
  if (fileChanged) {
    const { start, end } = fileAnalyzer.getEntityStartAndEnd(entity.name);
    const diffLines = extractDiffLines(fileChanged.patch);
    entityChanged = diffLines.some((lineNumber) => {
      return lineNumber >= start && lineNumber <= end;
    });
  }

  try {
    if (entityChanged) {
      const diff = relevantDiffPart(entity, commit, fileAnalyzer);
      entity = await analyzeCodeChange({
        entity,
        commit,
        diff,
        model,
      });
    }

    if (!steps || steps.includes(Step.Structure)) {
      const { step: dataStructureStep } = await recordStep(
        'generateDataStructure',
        () =>
          generateDataStructure({
            entity,
            dependentAnalyses,
            analysis,
          }),
      );
      analysis.status.steps.push(dataStructureStep);

      await updateProps(entity, fileAnalyzer, analysis);
    }

    if (
      analysis.metadata.scenariosDataStructure ===
      previousAnalysis.metadata.scenariosDataStructure
    ) {
      analysis.scenarios = previousAnalysis.scenarios;
    } else {
      if (!steps || steps.includes(Step.Scenarios)) {
        const { step: scenariosStep } = await recordStep(
          'generateChangesScenarios',
          () =>
            generateChangesScenarios({
              previousAnalysis,
              commit,
              entity,
              analysis,
              dependentAnalyses,
              model,
              updateProgress,
            }),
        );
        analysis.status.steps.push(scenariosStep);
      }

      // if (!steps || steps.includes(Step.ErrorScenarios)) {
      //   const { step: errorScenarioStep } = await recordStep(
      //     'generateChangesErrorScenarios',
      //     () =>
      //       generateChangesScenarios({
      //         previousAnalysis,
      //         commit,
      //         entity,
      //         analysis,
      //         dependentAnalyses,
      //         error: true,
      //         model,
      //         updateProgress,
      //       }),
      //   );
      //   analysis.status.steps.push(errorScenarioStep);
      // }

      if (!steps || steps.includes(Step.Data)) {
        const { step: mockDataStep } = await recordStep(
          'generateChangesScenarioData',
          () =>
            generateChangesScenarioData({
              previousAnalysis,
              entity,
              analysis,
              scenarioIds,
              dependentAnalyses,
              model,
              updateProgress,
            }),
        );
        analysis.status.steps.push(mockDataStep);
      }
    }
  } catch (error) {
    console.log(error);
    pushAnalysisError({
      status: analysis.status,
      error,
      phase: 'analyze',
    });

    analysis = (
      await upsertAnalysesWithScenarios({
        analysesToUpsert: [analysis],
      })
    )[0];
  }

  return { analysis };
}
