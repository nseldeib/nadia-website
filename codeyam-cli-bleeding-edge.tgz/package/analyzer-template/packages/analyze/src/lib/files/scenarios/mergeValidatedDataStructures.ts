import { splitOutsideParenthesesAndArrays } from '~codeyam/ai';
import { JsonTypeDefinition, ReadonlyAnalysisMap } from '~codeyam/types';
import { awsLog } from '~codeyam/utils';

export function mergeInStructure(
  name: string | number,
  key: string | number,
  source: JsonTypeDefinition | JsonTypeDefinition[],
  target: JsonTypeDefinition | JsonTypeDefinition[],
) {
  try {
    const specificSource = source[key] as
      | JsonTypeDefinition
      | JsonTypeDefinition[];
    let specificTarget = target[name] as
      | JsonTypeDefinition
      | JsonTypeDefinition[];
    if (Array.isArray(specificSource)) {
      specificSource.map((_, index) => {
        if (!Array.isArray(specificTarget)) {
          specificTarget = [];
        }
        try {
          mergeInStructure(index, index, specificSource, specificTarget);
        } catch (error) {
          awsLog('Error merging structure1:', {
            name,
            key,
            source,
            target,
          });
          throw error;
        }
      });
    } else if (typeof specificSource === 'object') {
      if (typeof specificTarget !== 'object') {
        specificTarget = {};
      }
      for (const specificSourceKey in specificSource) {
        try {
          mergeInStructure(
            specificSourceKey,
            specificSourceKey,
            specificSource,
            specificTarget ?? {},
          );
        } catch (error) {
          awsLog('Error merging structure2:', {
            name,
            key,
            source,
            target,
          });
          throw error;
        }
      }
    } else if (specificSource) {
      specificTarget = specificSource;
    }

    if (specificTarget) {
      try {
        target[name] = specificTarget;
      } catch (error) {
        console.log(
          'CodeYam Error: Unable to set target',
          { name, key, source, target },
          error,
        );
      }
    }
  } catch (error) {
    awsLog('Error merging structure:', {
      name,
      key,
      source,
      target,
      error: error instanceof Error ? error.message : error,
    });
    throw error;
  }
}

export default function mergeValidatedDataStructures({
  validatedVariables,
  relevantDependencies = [],
  dependentAnalyses = {},
}: {
  validatedVariables: JsonTypeDefinition;
  relevantDependencies?: {
    filePath: string;
    entityName: string;
    importAlias: string;
  }[];
  dependentAnalyses?: ReadonlyAnalysisMap;
}) {
  // console.log("CODEYAM DEBUG: mergeValidatedDataStructures called with", JSON.stringify({
  //   validatedVariables,
  //   relevantDependencies: relevantDependencies.map(dep => ({
  //     filePath: dep.filePath,
  //     entityName: dep.entityName,
  //     importAlias: dep.importAlias,
  //   })),
  //   dependentAnalyses: Object.keys(dependentAnalyses).reduce(
  //     (acc, filePath) => {
  //       Object.keys(dependentAnalyses[filePath]).forEach(
  //         (entityName) => {
  //           acc[filePath] ||= {};
  //           acc[filePath][entityName] = {
  //             metadata: {
  //               scenariosDataStructure: {
  //                 dataForMocks: dependentAnalyses[filePath][entityName]?.metadata
  //                   ?.scenariosDataStructure?.dataForMocks || {},
  //               }
  //             },
  //           }
  //         }
  //       );
  //       return acc;
  //     }, {}
  //   ),
  // }, null, 2));

  let args = (validatedVariables['signature'] || []) as JsonTypeDefinition[];
  if (!Array.isArray(args)) args = [];

  let dataForMocks: JsonTypeDefinition = {};
  const addMockDataForEntity = (mockName: string) => {
    const mockNameParts = splitOutsideParenthesesAndArrays(mockName);

    const validatedData: JsonTypeDefinition = {};
    let activeValidatedParts: JsonTypeDefinition = validatedData;
    for (const part of mockNameParts) {
      if (!activeValidatedParts) continue;

      const rootPart = part.includes('(') ? `${part.split('(')[0]}(` : part;
      const fullName = rootPart.includes('(') ? rootPart + ')' : rootPart;
      const functionName = fullName.split('(')[0] + '(';
      const fullFunctionName = functionName + ')';

      let usedName = fullName;
      for (const key in validatedVariables) {
        if (key.startsWith(rootPart) || key.startsWith(functionName)) {
          if (key.startsWith(functionName)) {
            usedName = fullFunctionName;
          }

          mergeInStructure(
            usedName,
            key,
            validatedVariables as JsonTypeDefinition,
            activeValidatedParts as JsonTypeDefinition,
          );
        }
      }
      activeValidatedParts = validatedVariables[usedName] as JsonTypeDefinition;
    }
    dataForMocks = {
      ...dataForMocks,
      ...validatedData,
    };
  };

  for (const dependency of relevantDependencies) {
    addMockDataForEntity(dependency.importAlias);

    let dependentAnalysis =
      dependentAnalyses[dependency.filePath]?.[dependency.entityName];

    if (!dependentAnalysis) {
      if (
        dependentAnalyses[dependency.filePath]?.['default']?.entityName ===
        dependency.entityName
      ) {
        dependentAnalysis = dependentAnalyses[dependency.filePath]['default'];
      }
    }

    for (const mockName in dependentAnalysis?.metadata?.scenariosDataStructure
      ?.dataForMocks ?? {}) {
      addMockDataForEntity(mockName);
    }
  }

  return {
    args,
    dataForMocks,
  };
}
