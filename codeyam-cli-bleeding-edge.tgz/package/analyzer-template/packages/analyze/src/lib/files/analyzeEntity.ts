import {
  deleteScenarios,
  upsertAnalysesWithScenarios,
  upsertEntities,
} from '~codeyam/supabase';
import {
  AI,
  generateChangesEntityDocumentation,
  generateEntityDocumentation,
} from '~codeyam/ai';
import updateProps from './analyze/updateProps';
import { ProjectAnalyzer } from '../ProjectAnalyzer';
import findValidExistingAnalysis from './analyze/findValidExistingAnalysis';
import generateAnalysisTreeSha from './analyze/generateAnalysisTreeSha';
import findPreviousAnalysis from './analyze/findPreviousAnalysis';
import analyzeInitial from './analyzeInitial';
import analyzeChange from './analyzeChange';
import recordStep from './recordStep';
import newAnalysis from './newAnalysis';
import validateDependencyAnalyses from './analyze/validateDependencyAnalyses';
import type {
  Analysis,
  Commit,
  Entity,
  File,
  Project,
  ReadonlyAnalysisMap,
} from '~codeyam/types';
import { EMPTY_SHA_MARKER } from '~codeyam/types';
import setActiveAnalysisBranches from './analyze/setActiveAnalysisBranches';
import relevantDiffPart from './relevantDiffPart';
import { Step } from './enums/steps';
import { ImmutableAnalysisContext } from '../analysisContext';
import generateAnalyzedTreeSha from './analyze/generateAnalyzedTreeSha';
import { awsLog, pushAnalysisError } from '~codeyam/utils';

export interface AnalyzeEntityArgs {
  project: Project;
  projectAnalyzer: ProjectAnalyzer;
  commit?: Commit;
  file: File;
  entity: Entity;
  context: ImmutableAnalysisContext;
  analyzeAsDependency?: boolean;
  branchCommitSha?: string;
  indirect?: boolean;
  scenarioIds?: string[];
  steps?: string[];
  fresh?: boolean;
  force?: boolean;
  forceAll?: boolean;
  updateProgress?: (detail: string) => void;
  modelString?: string;
}

/**
 * Analyze an entity in a file, relative to the the provided context, which is a private
 * copy of the global context.
 *
 * This file is built to be called from analyzeEntities(), which performs the integration
 * of its return value and other constrained mutations into the global context.
 */

export default async function analyzeEntity({
  project,
  projectAnalyzer,
  commit,
  file,
  entity,
  context,
  analyzeAsDependency = false,
  branchCommitSha,
  indirect,
  scenarioIds,
  steps,
  fresh,
  force,
  forceAll,
  updateProgress,
  modelString,
}: AnalyzeEntityArgs): Promise<{
  analysis: Analysis;
  dependentAnalyses?: ReadonlyAnalysisMap;
}> {
  awsLog('CodeYam: Analyzing entity', {
    filePath: entity.filePath,
    entityName: entity.name,
    code: entity.code?.length,
    analyzeAsDependency,
    indirect,
    fresh,
    force,
    forceAll,
  });

  if (project.metadata?.unapprovedPaths) {
    for (const unapprovedPath of project.metadata.unapprovedPaths) {
      if (entity.filePath.includes(unapprovedPath)) {
        awsLog('CodeYam: Skipping unapproved path', {
          filePath: entity.filePath,
          unapprovedPath,
        });
        return {
          analysis: null,
        };
      }
    }
  }

  if (project.metadata?.approvedPaths) {
    for (const approvedPath of project.metadata.approvedPaths) {
      if (!entity.filePath.includes(approvedPath)) {
        awsLog('CodeYam: Skipping entity not on approved path', {
          filePath: entity.filePath,
          approvedPath,
        });
        return {
          analysis: null,
        };
      }
    }
  }

  const existingAnalysis = context.getAnalysis(
    entity.filePath,
    entity.name,
    true,
  );
  if (existingAnalysis) {
    awsLog(
      'Returning in-memory analysis',
      entity.filePath,
      entity.name,
      entity.sha,
      existingAnalysis?.analyzedTreeSha,
    );
    return {
      analysis: existingAnalysis as Analysis,
    };
  }

  const model = AI.Model[modelString as keyof typeof AI.Model];

  const fileAnalyzer = projectAnalyzer.getFileAnalyzer(file);

  if (commit && !indirect && !relevantDiffPart(entity, commit, fileAnalyzer)) {
    indirect = true;
  }

  let analysis: Analysis = newAnalysis({
    entity,
    file,
    project,
    commit,
    branchCommitSha,
    indirect,
  });

  // Store the initial analysis in the context
  context.setPrimaryAnalysis(analysis);

  let dependentAnalyses: ReadonlyAnalysisMap;
  try {
    const { result, step } = await recordStep('validateDependencies', () =>
      validateDependencyAnalyses({ analysis, entity, context }),
    );

    dependentAnalyses = result.dependentAnalyses;
    analysis.status.steps.push(step);

    awsLog('Continuing to analyze entity', {
      filePath: entity.filePath,
      entityName: entity.name,
      code: entity.code?.length,
    });

    const { dataShaList, analysisTreeSha: dependencyAnalyzedTreeSha } =
      generateAnalysisTreeSha(entity, context);

    analysis.dependencyAnalyzedTreeSha = dependencyAnalyzedTreeSha;
    analysis.metadata.dataShaList = dataShaList;

    awsLog('findValidExistingAnalysis', {
      filePath: file.path,
      entityName: analysis.entityName,
      dependencyAnalyzedTreeSha,
    });

    const existingAnalysis = await findValidExistingAnalysis({
      project,
      dependencyAnalyzedTreeSha,
    });

    if (existingAnalysis) {
      awsLog('CodeYam: existingAnalysis found', {
        fileId: file.id,
        filePath: file.path,
        entityName: existingAnalysis.entityName,
        entitySha: existingAnalysis.entitySha,
        analysisId: existingAnalysis.id,
        analysisFileId: existingAnalysis.fileId,
        analysisCommitId: existingAnalysis.commitId,
        analysisBranchCommitSha: existingAnalysis.branchCommitSha,
        analysisDependencyAnalyzedTreeSha:
          existingAnalysis.dependencyAnalyzedTreeSha,
        analysisAnalyzedTreesha: existingAnalysis.analyzedTreeSha,
        scenarios: existingAnalysis.scenarios?.map((scenario) => ({
          id: scenario.id ?? 'No ID',
          name: scenario.name,
        })),
      });

      if (existingAnalysis.commitId === commit?.id) {
        await setActiveAnalysisBranches(existingAnalysis, entity, commit);
      }

      if (existingAnalysis.metadata?.scenariosDataStructure?.arguments) {
        await updateProps(entity, fileAnalyzer, existingAnalysis);
      }

      if (
        commit &&
        new Date(existingAnalysis.committedAt).getTime() >
          new Date(commit.committedAt).getTime()
      ) {
        awsLog(
          'CodeYam: existingAnalysis commit is newer, updating commitId to potential original commitId',
          {
            existing: {
              id: existingAnalysis.id,
              entityName: existingAnalysis.entityName,
              commitId: existingAnalysis.commitId,
              committedAt: existingAnalysis.committedAt,
            },
            commit: {
              id: commit.id,
              committedAt: commit.committedAt,
            },
          },
        );
        existingAnalysis.commitId = commit.id;
        existingAnalysis.committedAt = commit.committedAt;
        await upsertAnalysesWithScenarios({
          analysesToUpsert: [existingAnalysis],
        });
      }

      if (
        !force &&
        !!existingAnalysis.analyzedTreeSha &&
        existingAnalysis.dependencyAnalyzedTreeSha === dependencyAnalyzedTreeSha //&&
        // (existingAnalysis.status?.finishedAt ||
        //   existingAnalysis.status?.readyToBeCaptured ||
        //   branchCommitSha)
      ) {
        awsLog('Returning existing analysis', {
          filePath: file.path,
          entityName: entity.name,
          existingAnalysisId: existingAnalysis.id,
        });

        // Update context with existingAnalysis
        context.setPrimaryAnalysis(existingAnalysis);
        context.updatePrimaryEntity(entity);

        return {
          analysis: existingAnalysis,
        };
      } else {
        // if (!force || forceAll) {
        //   awsLog("INAPPROPRIATE REANALYZING", JSON.stringify({
        //     analysisId: existingAnalysis.id,
        //     filePath: file.path,
        //     entityName: entity.name,
        //     shasDiff: Object.keys(dependentAnalyses).reduce((acc, filePath) => {
        //       Object.keys(dependentAnalyses[filePath]).forEach((entityName) => {
        //         const existingSha = existingAnalysis.metadata.dependencyAnalyzedTreeShas?.[filePath]?.[entityName];
        //         const newSha = dependentAnalyses[filePath][entityName].analyzedTreeSha;
        //         if (newSha !== existingSha) {
        //           acc[filePath] ||= {};
        //           acc[filePath][entityName] = {
        //             existingSha,
        //             newSha,
        //           };
        //         }
        //       });
        //       return acc;
        //     }, {}),
        //   }, null, 2))
        //   throw new Error("INAPPROPRIATE REANALYZING");
        // }
        awsLog(
          force || forceAll
            ? 'CodeYam: force re-analysis of existing analysis'
            : 'CodeYam: existingAnalysis requires further analysis',
          {
            analysisId: existingAnalysis.id,
            fileId: file.id,
            filePath: file.path,
            entityName: entity.name,
            existingDependencyAnalyzedTreeSha:
              existingAnalysis.dependencyAnalyzedTreeSha,
            dependencyAnalyzedTreeSha,
            existingFinishedAt: existingAnalysis.status?.finishedAt,
            existingReadyToBeCaptured:
              existingAnalysis.status?.readyToBeCaptured,
          },
        );

        if (!scenarioIds) {
          if (existingAnalysis.scenarios) {
            if (!steps || steps?.includes(Step.Scenarios)) {
              await deleteScenarios({
                ids: existingAnalysis.scenarios
                  .filter((s) => !s.metadata.error)
                  .map((s) => s.id),
              });
              existingAnalysis.scenarios = existingAnalysis.scenarios.filter(
                (s) => !!s.metadata.error,
              );
            }

            if (!steps || steps?.includes(Step.ErrorScenarios)) {
              await deleteScenarios({
                ids: existingAnalysis.scenarios
                  .filter((s) => !!s.metadata.error)
                  .map((s) => s.id),
              });
              existingAnalysis.scenarios = existingAnalysis.scenarios.filter(
                (s) => !s.metadata.error,
              );
            }
          }

          if (!steps) {
            delete existingAnalysis.metadata.llmCalls;

            existingAnalysis.status = {
              startedAt: new Date().toISOString(),
              steps: [],
              errors: [],
            };
          }
        }

        if (!steps || steps?.includes(Step.Structure)) {
          delete existingAnalysis.metadata.scenariosDataStructure;
        }

        if (!steps || steps?.includes(Step.Scenarios)) {
          delete existingAnalysis.metadata.keyAttributes;
        }

        if (!steps || steps?.includes(Step.Data)) {
          existingAnalysis.status.errors = [];
          existingAnalysis.status.scenarios?.forEach((scenario) => {
            delete scenario.error;
            delete scenario.errorStack;
          });
        }

        existingAnalysis.dependencyAnalyzedTreeSha = dependencyAnalyzedTreeSha;
        existingAnalysis.metadata.dependentAnalyses =
          analysis.metadata.dependentAnalyses;
      }

      if (!existingAnalysis.status) {
        existingAnalysis.status = analysis.status;
      }
    } else {
      awsLog('CodeYam: no existingAnalysis found', {
        fileId: file.id,
        filePath: file.path,
        entityName: entity.name,
        dependencyAnalyzedTreeSha,
      });
    }

    if (existingAnalysis) {
      analysis = existingAnalysis;
    } else {
      analysis.dependencyAnalyzedTreeSha = dependencyAnalyzedTreeSha;

      const updatedAnalysis = (
        await upsertAnalysesWithScenarios({
          analysesToUpsert: [analysis],
        })
      )[0];
      analysis = updatedAnalysis as Analysis;

      await setActiveAnalysisBranches(analysis, entity, commit);
    }

    // Update the analysis in the context
    context.setPrimaryAnalysis(analysis);

    if (!['visual', 'library', 'index'].includes(entity.entityType)) {
      analysis.analyzedTreeSha = EMPTY_SHA_MARKER;
      analysis.status.finishedAt = new Date().toISOString();
      analysis = (
        await upsertAnalysesWithScenarios({
          analysesToUpsert: [analysis],
        })
      )[0];

      awsLog('Returning analysis for non-functional entity', {
        filePath: entity.filePath,
        entityName: entity.name,
        entityType: entity.entityType,
        entitySha: entity.sha,
        analysisAnalyzedTreeSha: analysis.analyzedTreeSha,
      });
      return {
        analysis,
      };
    }

    const previousAnalysis = commit
      ? await findPreviousAnalysis({
          project,
          commit: commit.sha === branchCommitSha ? null : commit,
          file,
          entity,
          dependencyAnalyzedTreeSha,
        })
      : null;

    const [documentationResult, analysisResult] = await Promise.all([
      !entity.documentation
        ? previousAnalysis?.entity?.documentation
          ? generateChangesEntityDocumentation({
              entity,
              previousDocumentation: previousAnalysis?.entity?.documentation,
              model,
            })
          : generateEntityDocumentation({ entity, model })
        : Promise.resolve(null),

      previousAnalysis &&
      previousAnalysis.metadata?.mergedDataStructure &&
      !fresh
        ? await analyzeChange({
            previousAnalysis,
            analysis,
            entity,
            commit,
            fileAnalyzer,
            dependentAnalyses,
            scenarioIds,
            steps,
            updateProgress,
            model,
          })
        : await analyzeInitial({
            analysis,
            entity,
            fileAnalyzer,
            dependentAnalyses,
            analyzeAsDependency,
            steps,
            updateProgress,
            model,
          }),
    ]);

    if (documentationResult) {
      entity.documentation = documentationResult.documentation;
      // Update the entity in the context
      context.updatePrimaryEntity(entity);
      await upsertEntities([entity]);
    }

    analysis = analysisResult.analysis;

    analysis.completedAt = new Date().toISOString();
    analysis.analyzedTreeSha = generateAnalyzedTreeSha(analysis);
  } catch (error) {
    awsLog(error);
    pushAnalysisError({
      status: analysis.status,
      error,
      phase: 'analyze',
    });
  }

  analysis = (
    await upsertAnalysesWithScenarios({
      analysesToUpsert: [analysis],
    })
  )[0];

  context.setPrimaryAnalysis(analysis);

  awsLog('Returning completed analysis', {
    filePath: entity.filePath,
    entityName: entity.name,
    entitySha: entity.sha,
    analysisId: analysis.id,
    scenarioCount: analysis.scenarios?.length,
  });

  return {
    analysis,
    dependentAnalyses,
  };
}
