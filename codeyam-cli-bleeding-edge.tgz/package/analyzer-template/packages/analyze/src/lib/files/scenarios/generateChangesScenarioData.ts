import {
  Analysis,
  DEFAULT_SCENARIO_NAME,
  Entity,
  ReadonlyAnalysisMap,
} from '~codeyam/types';
import measureAndReportExecutionTime from '../../utils/measureAndReportExecutionTime';
import {
  AI,
  generateChangesEntityScenarioData,
  splitOutsideParenthesesAndArrays,
} from '~codeyam/ai';
import findScenarioData from '../findScenarioData';
import { awsLog } from '~codeyam/utils';
import { gatherDataForMocks } from './generateScenarioData';

export interface GenerateChangesMockDataArgs {
  previousAnalysis: Analysis;
  entity: Entity;
  analysis: Analysis;
  scenarioIds?: string[];
  dependentAnalyses: ReadonlyAnalysisMap;
  model: AI.Model;
  updateProgress?: (detail: string) => void;
}

export default async function generateChangesScenarioData({
  previousAnalysis,
  entity,
  analysis,
  scenarioIds,
  dependentAnalyses,
  model,
  updateProgress,
}: GenerateChangesMockDataArgs): Promise<void> {
  if (!['visual', 'library'].includes(entity.entityType)) return;

  const fullStructure = analysis.metadata.scenariosDataStructure;
  const structure: Analysis['metadata']['scenariosDataStructure'] = {
    arguments: fullStructure.arguments,
    dataForMocks: gatherDataForMocks(analysis, dependentAnalyses),
  };

  for (const key in fullStructure.dataForMocks) {
    const keyParts = splitOutsideParenthesesAndArrays(key);
    for (const importedExport of entity.metadata.importedExports) {
      if (!importedExport.isMocked) continue;

      const functionCallReturnValue =
        keyParts.some((part) => part === 'functionCallReturnValue') &&
        keyParts[keyParts.length - 1] !== 'functionCallReturnValue' &&
        !keyParts.some((part) => part.match(/signature\[\d+\]/)) &&
        fullStructure.dataForMocks[key] !== 'function';
      if (!functionCallReturnValue) continue;

      const name = importedExport.name;
      if (keyParts[0] === name || keyParts[0].startsWith(`${name}(`)) {
        structure.dataForMocks[key] = fullStructure.dataForMocks[key];
      }
    }
  }

  let scenarios = analysis.scenarios;
  if (scenarioIds) {
    scenarios = scenarios.filter((scenario) =>
      scenarioIds.includes(scenario.id),
    );
  }

  const newOrRevisedScenarios = scenarios.filter(
    (scenario) =>
      !scenario.previousVersionId ||
      scenario.metadata.revisedFromPreviousVersion,
  );

  const previousScenarios = previousAnalysis.scenarios ?? [];
  const existingScenarios = previousScenarios.filter((scenario) =>
    scenarios.find((s) => s.previousVersionId === scenario.id),
  );

  const defaultScenario = analysis.scenarios.find(
    (s) => s.name === DEFAULT_SCENARIO_NAME,
  );
  const existingDefaultScenario = previousScenarios.find(
    (s) => s.name === DEFAULT_SCENARIO_NAME,
  );
  defaultScenario.metadata.data = existingDefaultScenario?.metadata?.data;

  awsLog('CodeYam: Generating changes scenario data for', {
    filePath: entity.filePath,
    entityName: entity.name,
    scenarioNames: scenarios.map((s) => s.name),
  });

  if (
    !structure ||
    (Object.keys(structure.dataForMocks ?? {}).length === 0 &&
      Object.keys(structure.arguments ?? {}).length === 0)
  ) {
    awsLog(
      `CodeYam: No scenario data structure found for ${entity.filePath} ${entity.name}. Unable to generate changes scenario data.`,
    );
    return;
  }

  const {
    result: { scenarioDatas, llmCalls },
  } = await measureAndReportExecutionTime(
    () =>
      generateChangesEntityScenarioData({
        entity,
        structure,
        existingStructure: previousAnalysis.metadata.scenariosDataStructure,
        scenarios: newOrRevisedScenarios,
        defaultScenario,
        existingScenarios,
        analysisId: analysis.id,
        model,
      }),
    'Getting changes data for scenario',
    updateProgress,
  );

  if (llmCalls) {
    analysis.metadata.llmCalls ||= [];
    for (const llmCall of llmCalls) {
      analysis.metadata.llmCalls.push({
        name: `generateChangesEntityScenarioData: ${llmCall.name}`,
        id: llmCall.id,
      });
    }
  }

  if (scenarioDatas) {
    analysis.scenarios = analysis.scenarios.map((scenario) => {
      if (
        scenario.previousVersionId &&
        !scenario.metadata.revisedFromPreviousVersion
      ) {
        const existingScenario = existingScenarios.find(
          (s) => s.id === scenario.previousVersionId,
        );
        return {
          ...scenario,
          metadata: {
            ...scenario.metadata,
            data: existingScenario?.metadata?.data,
          },
        };
      }

      let data = findScenarioData(scenario.name, scenarioDatas);
      if (!data) {
        data = previousScenarios.find((s) => s.name === scenario.name)?.metadata
          ?.data;
      }

      return {
        ...scenario,
        metadata: {
          ...(scenario.metadata ?? {}),
          data,
        },
      };
    });

    awsLog(`CodeYam: Generated changes scenario data`, {
      filePath: entity.filePath,
      entityName: entity.name,
      scenarioNames: analysis.scenarios.map((s) => ({
        name: s.name,
        stringifiedDataLength: JSON.stringify(s.metadata?.data ?? {}).length,
      })),
    });
  }
}
