import {
  Analysis,
  Entity,
  ReadonlyAnalysis,
  ReadonlyAnalysisMap,
} from '~codeyam/types';
import measureAndReportExecutionTime from '../../utils/measureAndReportExecutionTime';
import {
  AI,
  generateEntityScenarioData,
  mergeJsonTypeDefinitions,
} from '~codeyam/ai';
import findScenarioData from '../findScenarioData';
import { awsLog } from '~codeyam/utils';

export interface GenerateScenarioDataArgs {
  entity: Entity;
  analysis: Analysis;
  dependentAnalyses: ReadonlyAnalysisMap;
  model: AI.Model;
  updateProgress?: (detail: string) => void;
}

export function gatherDataForMocks(
  analysis: ReadonlyAnalysis,
  dependentAnalyses: ReadonlyAnalysisMap,
): Analysis['metadata']['scenariosDataStructure']['dataForMocks'] {
  const dataForMocks = {};
  const analysesGathered = new Set<string>();

  // inner recursive function to gather data for mocks
  const gatherDataForMocksRecursive = (
    activeAnalysis: ReadonlyAnalysis,
  ): void => {
    const allImportedExports = [
      ...(activeAnalysis.entity?.metadata.importedExports ?? []),
      ...Object.keys(
        activeAnalysis.entity?.metadata.nodeModuleImports ?? {},
      ).flatMap((moduleName) =>
        (
          activeAnalysis.entity?.metadata.nodeModuleImports?.[moduleName] || []
        ).map((imported) => ({
          filePath: moduleName,
          ...imported,
        })),
      ),
    ];

    // console.info('CODEYAM DEBUG: gatherDataForMocksRecursive', {
    //   filePath: activeAnalysis.filePath,
    //   analysisEntityName: activeAnalysis.entityName,
    //   analysisId: activeAnalysis.id,
    //   entity: !!activeAnalysis.entity,
    //   entityName: activeAnalysis.entity?.name,
    //   allImportedExports,
    // });

    for (const importedExport of allImportedExports) {
      const localDataForMocks =
        activeAnalysis.metadata?.scenariosDataStructure?.dataForMocks ?? {};
      const relevantKey = Object.keys(localDataForMocks).find((key) =>
        key.startsWith(importedExport.name),
      );

      if (relevantKey) {
        const localDataForMock = localDataForMocks[relevantKey];

        // console.info(
        //   'CODEYAM DEBUG: gatherDataForMocksRecursive add data for mock',
        //   JSON.stringify(
        //     {
        //       filePath: analysis.filePath,
        //       entityName: analysis.entityName,
        //       importedExportFilePath: importedExport.filePath,
        //       importedExportEntityName: importedExport.name,
        //       importedExportIsMocked: importedExport.isMocked,
        //       localDataForMock,
        //     },
        //     null,
        //     2,
        //   ),
        // );

        if (Object.keys(localDataForMock).length > 0) {
          if (dataForMocks[relevantKey]) {
            dataForMocks[relevantKey] = mergeJsonTypeDefinitions(
              dataForMocks[relevantKey],
              localDataForMock,
            );
          } else {
            dataForMocks[relevantKey] = localDataForMock;
          }
        }

        // console.info(
        //   'CODEYAM DEBUG: gatherDataForMocksRecursive added data for mock',
        //   JSON.stringify(
        //     {
        //       filePath: analysis.filePath,
        //       entityName: analysis.entityName,
        //       importedExportFilePath: importedExport.filePath,
        //       importedExportEntityName: importedExport.name,
        //       importedExportIsMocked: importedExport.isMocked,
        //       localDataForMock,
        //       dataForMocksRelevantKey: dataForMocks[relevantKey],
        //     },
        //     null,
        //     2,
        //   ),
        // );
      } else {
        const dependentAnalysis =
          dependentAnalyses?.[importedExport.filePath]?.[importedExport.name];
        if (!dependentAnalysis || analysesGathered.has(dependentAnalysis.id)) {
          // if (!dependentAnalysis) {
          //   console.info(
          //     'CODEYAM DEBUG: gatherDataForMocks: No dependentAnalysis',
          //     {
          //       filePath: analysis.filePath,
          //       entityName: analysis.entityName,
          //       importedExportFilePath: importedExport.filePath,
          //       importedExportEntityName: importedExport.name,
          //       importedExportIsMocked: importedExport.isMocked,
          //       dependentAnalysisId: dependentAnalysis?.id,
          //       analysesGathered: Array.from(analysesGathered),
          //       dependentAnalyses: Object.keys(dependentAnalyses ?? {}).flatMap(
          //         (filePath) =>
          //           Object.keys(dependentAnalyses[filePath] || {}).flatMap(
          //             (entityName) => ({
          //               filePath,
          //               entityName,
          //               id: dependentAnalyses[filePath][entityName]?.id,
          //             }),
          //           ),
          //       ),
          //     },
          //   );
          // }
          continue;
        }
        analysesGathered.add(dependentAnalysis.id);
        gatherDataForMocksRecursive(dependentAnalysis);
      }
    }
  };

  gatherDataForMocksRecursive(analysis);

  // console.info(
  //   'CODEYAM DEBUG: gatherDataForMocks',
  //   JSON.stringify(
  //     {
  //       filePath: analysis.filePath,
  //       entityName: analysis.entityName,
  //       dataForMocks,
  //     },
  //     null,
  //     2,
  //   ),
  // );

  return dataForMocks;
}

export default async function generateScenarioData({
  entity,
  analysis,
  dependentAnalyses,
  model,
  updateProgress,
}: GenerateScenarioDataArgs): Promise<void> {
  if (!['visual', 'library'].includes(entity.entityType)) return;

  const structure: Analysis['metadata']['scenariosDataStructure'] = {
    arguments: analysis.metadata.scenariosDataStructure?.arguments ?? [],
    dataForMocks: gatherDataForMocks(analysis, dependentAnalyses),
  };

  const scenarios = analysis.scenarios;

  awsLog(
    'CodeYam: Generating scenario data for',
    JSON.stringify(
      {
        filePath: entity.filePath,
        entityName: entity.name,
        structure,
        ams: analysis.metadata.scenariosDataStructure,
      },
      null,
      2,
    ),
  );

  if (
    !structure ||
    (Object.keys(structure.dataForMocks ?? {}).length === 0 &&
      (!structure.arguments || structure.arguments.length === 0))
  ) {
    awsLog(
      `CodeYam: No scenario data structure found for ${entity.filePath} ${entity.name}. Unable to generate scenario data.`,
    );
    return;
  }

  const {
    result: { scenarioDatas, llmCalls },
  } = await measureAndReportExecutionTime(
    () =>
      generateEntityScenarioData({
        entity,
        structure,
        scenarios,
        analysis,
        model,
      }),
    'Getting data to scenario',
    updateProgress,
  );

  if (llmCalls) {
    analysis.metadata.llmCalls ||= [];
    for (const llmCall of llmCalls) {
      analysis.metadata.llmCalls.push({
        name: `generateEntityScenarioData: ${llmCall.name}`,
        id: llmCall.id,
      });
    }
  }

  if (scenarioDatas) {
    awsLog(
      `CodeYam: Generated scenario data for ${entity.filePath} ${entity.name}`,
    );
    // Merge scenarioDatas with scenarios
    analysis.scenarios = analysis.scenarios.map((scenario) => {
      return {
        ...scenario,
        metadata: {
          ...(scenario.metadata ?? {}),
          data: findScenarioData(scenario.name, scenarioDatas),
        },
      };
    });
  }
}
