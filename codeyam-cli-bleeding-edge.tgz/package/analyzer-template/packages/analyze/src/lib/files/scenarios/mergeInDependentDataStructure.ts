import {
  splitOutsideParenthesesAndArrays,
  joinParenthesesAndArrays,
} from '~codeyam/ai';
import { cleanKnownObjectFunctionsFromMapping } from '~codeyam/ai';
import { DataStructure, Entity, ReadonlyAnalysis } from '~codeyam/types';

export interface DataStructureInfo {
  signatureSchema: { [key: string]: string };
  returnValueSchema: { [key: string]: string };
  usageEquivalencies?: {
    [path: string]: { schemaPath: string; scopeNodeName: string }[];
  };
  sourceEquivalencies?: {
    [path: string]: { schemaPath: string; scopeNodeName: string }[];
  };
}

function cleanFunctionName(functionName: string) {
  return functionName?.split('<')[0];
}

function bestValueFromOptions(options: Array<string | undefined>) {
  options = options.filter(Boolean) as string[];

  const known = options.find((o) => !o.includes('unknown'));
  if (known) return known;

  const notUnknown = options.find((o) => o !== 'unknown');
  if (notUnknown) return notUnknown;

  return options[0] ?? 'unknown';
}

export default function mergeInDependentDataStructure({
  importedExports,
  dependentAnalyses,
  rootScopeName,
  dataStructure,
  dependencySchemas,
}: {
  importedExports: Pick<
    Entity['metadata']['importedExports'][0],
    'filePath' | 'name'
  >[];
  dependentAnalyses: {
    [filePath: string]: {
      [name: string]: {
        metadata?: {
          mergedDataStructure?: ReadonlyAnalysis['metadata']['mergedDataStructure'];
        };
      };
    };
  };
  rootScopeName: string;
  dataStructure: DataStructureInfo;
  dependencySchemas: {
    [filePath: string]: {
      [name: string]: DataStructureInfo;
    };
  };
}) {
  // console.info(
  //   'CODEYAM DEBUG: mergeInDependentDataStructure',
  //   JSON.stringify(
  //     {
  //       importedExports: importedExports.map((d) => ({
  //         filePath: d.filePath,
  //         name: d.name,
  //       })),
  //       dependentAnalyses: Object.keys(dependentAnalyses).reduce(
  //         (pathAcc, filePath) => {
  //           pathAcc[filePath] = Object.keys(dependentAnalyses[filePath]).reduce(
  //             (nameAcc, name) => {
  //               nameAcc[name] = {
  //                 metadata: {
  //                   mergedDataStructure:
  //                     dependentAnalyses[filePath][name].metadata
  //                       .mergedDataStructure,
  //                 },
  //               };
  //               return nameAcc;
  //             },
  //             {},
  //           );
  //           return pathAcc;
  //         },
  //         {},
  //       ),
  //       rootScopeName,
  //       dataStructure,
  //       dependencySchemas,
  //     },
  //     null,
  //     2,
  //   ),
  // );

  const mergedDataStructure: Omit<
    DataStructure,
    'equivalentSignatureVariables'
  > = {
    signatureSchema: { ...(dataStructure.signatureSchema ?? {}) },
    returnValueSchema: { ...(dataStructure.returnValueSchema ?? {}) },
    usageEquivalencies: { ...(dataStructure.usageEquivalencies ?? {}) },
    sourceEquivalencies: { ...(dataStructure.sourceEquivalencies ?? {}) },
    dependencySchemas: {},
  };

  let equivalentSchemaPaths: {
    equivalentRoots: {
      schemaRootPath: string;
      function?: { filePath?: string; name: string };
      postfix?: string;
    }[];
    equivalentPostfixes: Record<string, string>;
  }[] = [];

  const findRelevantDependency = (functionName) => {
    return importedExports.find(
      (d) => cleanFunctionName(d.name) === cleanFunctionName(functionName),
    );
  };

  const findRelevantDependentDataStructure = (functionName) => {
    const dependency = findRelevantDependency(functionName);
    if (!dependency) return;

    return dependencySchemas?.[dependency.filePath]?.[dependency.name];
  };

  const findRelevantDependentAnalysisDataStructure = (functionName) => {
    const dependency = findRelevantDependency(functionName);
    if (!dependency) return;

    const dependentAnalysis =
      dependentAnalyses[dependency.filePath]?.[dependency.name];
    if (!dependentAnalysis?.metadata?.mergedDataStructure) {
      return;
    }

    return dependentAnalysis.metadata.mergedDataStructure;
  };

  const findOrCreateDependentSchemas = (dependency: {
    filePath?: string;
    name: string;
  }) => {
    const { filePath, name } = dependency;
    mergedDataStructure.dependencySchemas[filePath] ||= {};
    mergedDataStructure.dependencySchemas[filePath][name] ||= {
      signatureSchema: {},
      returnValueSchema: {},
    };

    return mergedDataStructure.dependencySchemas[filePath][name];
  };

  const cleanSchema = (schema: { [key: string]: string }) => {
    cleanKnownObjectFunctionsFromMapping(schema);
  };

  const translatePath = (path: string, dependencyName: string) => {
    if (path.startsWith(dependencyName)) {
      const pathParts = splitOutsideParenthesesAndArrays(path);
      if (pathParts.length > 1) {
        if (pathParts[1].startsWith('functionCallReturnValue')) {
          return joinParenthesesAndArrays([
            'returnValue',
            ...pathParts.slice(2),
          ]);
        } else {
          return joinParenthesesAndArrays(pathParts.slice(1));
        }
      }
    }
    return path;
  };

  const gatherAllEquivalentSchemaPaths = (
    functionName: string,
    sourceAndUsageEquivalencies: Pick<
      DataStructure,
      'sourceEquivalencies' | 'usageEquivalencies'
    >,
    dataStructure?: Pick<
      DataStructure,
      'signatureSchema' | 'returnValueSchema'
    >,
  ) => {
    if (!sourceAndUsageEquivalencies) return;

    const findOrCreateEquivalentSchemaPathsEntry = (
      allPaths: { path: string; functionName?: string }[],
    ) => {
      const equivalentRoots = allPaths
        .filter(
          (p) =>
            p.functionName === rootScopeName ||
            !!findRelevantDependency(p.functionName),
        )
        .map((p) => ({
          schemaRootPath: p.path,
          function:
            p.functionName === rootScopeName
              ? undefined
              : findRelevantDependency(p.functionName),
        }));

      let equivalentSchemaPathsEntry:
        | (typeof equivalentSchemaPaths)[0]
        | undefined;
      for (const pathInfo of allPaths) {
        if (!equivalentSchemaPathsEntry) {
          equivalentSchemaPathsEntry = equivalentSchemaPaths.find((esp) =>
            esp.equivalentRoots.some(
              (er) =>
                er.schemaRootPath === pathInfo.path &&
                (er.function?.name ===
                  cleanFunctionName(pathInfo.functionName) ||
                  (!er.function &&
                    cleanFunctionName(pathInfo.functionName) ===
                      rootScopeName)),
            ),
          );
        }
      }

      if (!equivalentSchemaPathsEntry) {
        equivalentSchemaPathsEntry = {
          equivalentRoots,
          equivalentPostfixes: {},
        };
        equivalentSchemaPaths.push(equivalentSchemaPathsEntry);
      } else {
        equivalentSchemaPathsEntry.equivalentRoots.push(...equivalentRoots);
      }
      equivalentSchemaPathsEntry.equivalentRoots =
        equivalentSchemaPathsEntry.equivalentRoots.filter(
          (er, index, self) =>
            index ===
            self.findIndex(
              (e) =>
                e.schemaRootPath === er.schemaRootPath &&
                e.function?.name === er.function?.name,
            ),
        );

      return equivalentSchemaPathsEntry;
    };

    for (const equivalencies of [
      sourceAndUsageEquivalencies.usageEquivalencies,
      sourceAndUsageEquivalencies.sourceEquivalencies,
    ].filter(Boolean)) {
      for (const [schemaPath, usages] of Object.entries(equivalencies)) {
        const allPaths: { path: string; functionName?: string }[] = [
          { path: translatePath(schemaPath, functionName), functionName },
          ...usages.map((u) => ({
            path: translatePath(u.schemaPath, u.scopeNodeName),
            functionName: u.scopeNodeName,
          })),
        ].filter((pathInfo) => !pathInfo.path.includes('.map('));

        const entry = findOrCreateEquivalentSchemaPathsEntry(allPaths);
        for (const equivalentRoot of entry.equivalentRoots) {
          const dataStructures =
            equivalentRoot.function &&
            equivalentRoot.function.name !== rootScopeName
              ? [
                  findRelevantDependentDataStructure(
                    equivalentRoot.function.name,
                  ),
                  findRelevantDependentAnalysisDataStructure(
                    equivalentRoot.function.name,
                  ),
                ]
              : [dataStructure];

          const schemas = dataStructures.map((dataStructure) =>
            equivalentRoot.schemaRootPath.startsWith('signature[')
              ? dataStructure?.signatureSchema
              : dataStructure?.returnValueSchema,
          );

          const pathParts = splitOutsideParenthesesAndArrays(
            equivalentRoot.schemaRootPath,
          );

          for (const schema of schemas) {
            for (const schemaPath in schema) {
              let schemaPathParts =
                splitOutsideParenthesesAndArrays(schemaPath);

              if (schemaPathParts[0].startsWith(functionName)) {
                schemaPathParts =
                  schemaPathParts[1] === 'functionCallReturnValue'
                    ? ['returnValue', ...schemaPathParts.slice(2)]
                    : schemaPathParts.slice(1);
              }

              if (schemaPathParts.length < pathParts.length) continue;
              if (
                pathParts.every(
                  (part, index) => part === schemaPathParts[index],
                )
              ) {
                const postfix = joinParenthesesAndArrays(
                  schemaPathParts.slice(pathParts.length),
                );
                entry.equivalentPostfixes[postfix] = entry.equivalentPostfixes[
                  postfix
                ]
                  ? bestValueFromOptions([
                      entry.equivalentPostfixes[postfix],
                      schema[schemaPath],
                    ])
                  : schema[schemaPath];
              }
            }
          }
        }
      }
    }

    if (Object.keys(dataStructure?.returnValueSchema ?? {}).length > 0) {
      const basePath = Object.keys(dataStructure.returnValueSchema)
        .filter((p) => p.endsWith('functionCallReturnValue'))
        .sort((a, b) => a.length - b.length)[0];

      if (basePath) {
        const translatedBasePath = translatePath(basePath, functionName);
        const entry = findOrCreateEquivalentSchemaPathsEntry([
          { path: translatedBasePath },
        ]);
        entry.equivalentRoots.push({
          schemaRootPath: translatedBasePath,
          function: findRelevantDependency(functionName),
        });

        const basePathParts = splitOutsideParenthesesAndArrays(basePath);
        for (const schemaPath in dataStructure.returnValueSchema) {
          const schemaPathParts = splitOutsideParenthesesAndArrays(schemaPath);
          if (schemaPathParts.length < basePathParts.length) continue;
          const postfix = joinParenthesesAndArrays(
            schemaPathParts.slice(basePathParts.length),
          );
          entry.equivalentPostfixes[postfix] = entry.equivalentPostfixes[
            postfix
          ] = dataStructure.returnValueSchema[schemaPath];
        }
      }
    }
  };

  const mergeAllEquivalentSchemaPaths = () => {
    const mergedEquivalentSchemaPaths: typeof equivalentSchemaPaths = [];

    const findEquivalentSchemaPathEntry = (
      schemaSubPath: string,
      equivalentRootFunction: (typeof equivalentSchemaPaths)[0]['equivalentRoots'][0]['function'],
    ) => {
      let postfix: string | undefined;
      const equivalentEntry = mergedEquivalentSchemaPaths.find((esp) =>
        esp.equivalentRoots.some((er) => {
          if (
            (schemaSubPath.startsWith('returnValue') ||
              schemaSubPath.startsWith('signature[')) &&
            (er.function?.name !== equivalentRootFunction?.name ||
              er.function?.filePath !== equivalentRootFunction?.filePath)
          ) {
            return false;
          }

          if (schemaSubPath === er.schemaRootPath) {
            postfix = er.postfix;
            return true;
          }

          return false;
        }),
      );

      return { equivalentEntry, postfix };
    };

    const sortedEquivalentSchemaPaths = equivalentSchemaPaths.sort(
      (a, b) =>
        Math.max(
          ...a.equivalentRoots.map(
            (er) => splitOutsideParenthesesAndArrays(er.schemaRootPath).length,
          ),
        ) -
        Math.max(
          ...b.equivalentRoots.map(
            (er) => splitOutsideParenthesesAndArrays(er.schemaRootPath).length,
          ),
        ),
    );

    for (const esp of sortedEquivalentSchemaPaths) {
      if (esp.equivalentRoots.length === 0) continue;
      let bestCandidateLength: number | undefined;
      let bestCandidate: (typeof equivalentSchemaPaths)[0] | undefined;
      let postfix: string | undefined;
      for (const equivalentRoot of esp.equivalentRoots) {
        const rootSchemaPath = equivalentRoot.schemaRootPath;
        const schemaPathParts =
          splitOutsideParenthesesAndArrays(rootSchemaPath);

        for (let i = 0; i < schemaPathParts.length; i++) {
          const subPath = joinParenthesesAndArrays(
            schemaPathParts.slice(0, i + 1),
          );

          const { equivalentEntry, postfix: equivalentEntryPostfix } =
            findEquivalentSchemaPathEntry(subPath, equivalentRoot.function);
          if (
            equivalentEntry &&
            (!bestCandidateLength || bestCandidateLength > i + 1)
          ) {
            bestCandidate = equivalentEntry;
            bestCandidateLength = i + 1;
            postfix = joinParenthesesAndArrays(
              [equivalentEntryPostfix, ...schemaPathParts.slice(i + 1)].filter(
                Boolean,
              ),
            );
          }
        }
      }

      if (bestCandidate) {
        for (const root of esp.equivalentRoots) {
          if (postfix.length > 0) {
            root.postfix = postfix;
          }

          bestCandidate.equivalentRoots.push(root);
        }

        const postfixesToMerge =
          postfix.length > 0
            ? Object.keys(esp.equivalentPostfixes).reduce(
                (acc, postfixPath) => {
                  const fullPath = joinParenthesesAndArrays([
                    postfix,
                    postfixPath,
                  ]);
                  acc[fullPath] = esp.equivalentPostfixes[postfixPath];
                  return acc;
                },
                {} as Record<string, string>,
              )
            : esp.equivalentPostfixes;

        bestCandidate.equivalentPostfixes = {
          ...bestCandidate.equivalentPostfixes,
          ...postfixesToMerge,
        };
      } else {
        mergedEquivalentSchemaPaths.push(esp);
      }
    }

    return mergedEquivalentSchemaPaths;
  };

  gatherAllEquivalentSchemaPaths(rootScopeName, dataStructure);

  for (const dependency of importedExports) {
    const dependentDataStructure =
      dependencySchemas?.[dependency.filePath]?.[dependency.name];
    if (!dependentDataStructure) continue;
    gatherAllEquivalentSchemaPaths(
      dependency.name,
      dependentDataStructure,
      dependentDataStructure,
    );
  }

  for (const filePath in dependentAnalyses) {
    for (const name in dependentAnalyses[filePath]) {
      const mergedDataStructure =
        dependentAnalyses[filePath][name].metadata?.mergedDataStructure || {};
      gatherAllEquivalentSchemaPaths(name, mergedDataStructure);
    }
  }

  equivalentSchemaPaths = mergeAllEquivalentSchemaPaths();

  for (const esp of equivalentSchemaPaths) {
    for (const equivalentRoot of esp.equivalentRoots) {
      let merged:
        | {
            signatureSchema: { [key: string]: string };
            returnValueSchema: { [key: string]: string };
          }
        | undefined;

      if (equivalentRoot.function) {
        merged = findOrCreateDependentSchemas(equivalentRoot.function);
      } else {
        merged = mergedDataStructure;
      }

      if (!merged) continue;

      const schema = equivalentRoot.schemaRootPath.startsWith('signature[')
        ? merged.signatureSchema
        : merged.returnValueSchema;

      for (const [postfixPath, postfixValue] of Object.entries(
        esp.equivalentPostfixes,
      )) {
        let relevantPostfix = postfixPath;
        if (equivalentRoot.postfix) {
          if (!postfixPath.startsWith(equivalentRoot.postfix)) {
            continue;
          }

          const postFixPathParts =
            splitOutsideParenthesesAndArrays(postfixPath);
          const equivalentRootPostFixParts = splitOutsideParenthesesAndArrays(
            equivalentRoot.postfix,
          );
          relevantPostfix = joinParenthesesAndArrays(
            postFixPathParts.slice(equivalentRootPostFixParts.length),
          );
        }

        const newSchemaPath = joinParenthesesAndArrays([
          equivalentRoot.schemaRootPath,
          relevantPostfix,
        ]);
        schema[newSchemaPath] = postfixValue;
      }

      cleanSchema(schema);
    }
  }

  // console.info(
  //   'CODEYAM DEBUG: mergedDataStructure',
  //   rootScopeName,
  //   JSON.stringify(mergedDataStructure, null, 2),
  // );

  return mergedDataStructure;
}
