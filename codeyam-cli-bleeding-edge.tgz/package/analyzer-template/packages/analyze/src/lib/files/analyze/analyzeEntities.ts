import type { Analysis, Commit, Entity, Project } from '~codeyam/types';
import {
  AnalysisContext,
  analyzeEntity,
  FileAnalyzer,
  ProjectAnalyzer,
} from '~codeyam/analyze';
import trackEntityCircularDependencies from './trackEntityCircularDependencies';
import validateDependencyAnalyses from './validateDependencyAnalyses';
import {
  upsertAnalyses,
  updateFreshAnalysisStatus,
  updateFreshAnalysisMetadata,
  updateCommitMetadata,
} from '~codeyam/supabase';
import { getCandidatesReadyForCapture as getAnalysesReadyForCapture } from './dependencyResolver';
import { awsLog } from '~codeyam/utils';
import {
  fillInDirectSchemaGapsAndUnknowns,
  generateEntityDataStructure,
} from '~codeyam/ai';

const MAX_CONCURRENT_ANALYSES = 100; // fairly arbitrary, but more isn't necessarily better

type ConcurrencyStrategy =
  | 'sequential'
  | 'async-simple'
  | 'async-complex'
  | 'worker-threads';

/**
 * Options for entity analysis
 */
export interface AnalysisOptions {
  branchId?: string;
  branchCommitSha?: string;
  indirect?: boolean;
  scenarioIds?: string[];
  steps?: string[];
  fresh?: boolean;
  force?: boolean;
  forceAll?: boolean;
  updateProgress?: (detail: string) => void;
  modelString?: string;
}

interface AnalyzeEntitiesArgs {
  rootEntities: Entity[];
  context: AnalysisContext;
  project: Project;
  projectAnalyzer: ProjectAnalyzer;
  commit?: Commit;
  options?: AnalysisOptions;
  concurrecyStrategy?: ConcurrencyStrategy;
}

export default async function analyzeEntities({
  rootEntities,
  context,
  project,
  projectAnalyzer,
  commit,
  options = {},
  concurrecyStrategy = 'async-simple',
}: AnalyzeEntitiesArgs): Promise<Analysis[]> {
  awsLog(
    `CodeYam: analyzeEntities: Tracking dependencies for ${rootEntities.length} root entities`,
    rootEntities.map((e) => ({ filePath: e.filePath, name: e.name })),
  );

  const allEntities = trackEntityCircularDependencies(rootEntities, context);
  awsLog(
    `CodeYam: analyzeEntities: Starting analysis of ${allEntities.size} entities in total`,
  );

  /**
   * This is a simplified architecture that depends on single-shot analysis of a set of
   * leaf nodes in a single call (in strict sequence or through Promise.all()); we cannot
   * currently implement async-complex just by extending the switch statement.
   * More will need to change. TODO.
   */
  const completed = new Set<string>();
  const markedReady = new Set<string>(); // Analyses we've attempted to mark ready
  const analyses: Analysis[] = [];

  const analysesAlreadyCompletedAtStart =
    commit.metadata.currentRun?.analysesCompleted ?? 0;

  while (true) {
    // determine remaining work
    const incompleteRootEntities = rootEntities.filter(
      (entity) => !completed.has(getEntityKey(entity)),
    );

    // enumerate entities with complete dependencies for analysis
    const leafKeys = await accumulateLeaves(incompleteRootEntities);

    // check exit conditions
    if (leafKeys.size === 0) {
      if (incompleteRootEntities.length > 0) {
        console.error(
          `CodeYam: analyzeEntities: Incomplete root entities but no analysis candidates: ${Array.from(
            incompleteRootEntities,
          )
            .map(getEntityKey)
            .join(', ')}`,
        );
        throw new Error(
          `CodeYam: analyzeEntities: Incomplete root entities but no analysis candidates`,
        );
      }
      awsLog(
        `CodeYam: analyzeEntities: No more leaf entities to analyze. Exiting loop.`,
      );
      break;
    }

    awsLog(
      `CodeYam: analyzeEntities: ${leafKeys.size} leaf keys to analyze; ${completed.size} completed `,
    );

    const analyzeOneEntityKey = async (entityKey: string) => {
      const entity = getEntity(entityKey);
      try {
        const analysis = await analyzeOneEntity(entityKey, entity);
        if (analysis !== null) {
          analyses.push(analysis);

          // Upsert the completed analysis immediately
          await upsertAnalyses([analysis]);

          // After completing an analysis, check if any pending ones are now ready
          const newlyReady = await updateReadyAnalyses();
          if (!newlyReady.includes(analysis)) {
            awsLog(
              `CodeYam: analyzeEntities: Analysis ${getEntityKey(
                analysis.entity,
              )} is ready for capture, but pending other analyses`,
            );
          }
        }
        completed.add(entityKey);
      } catch (error) {
        console.error(
          `CodeYam: analyzeEntities: Error analyzing ${entityKey}:`,
          error,
        );
        completed.add(entityKey);
      }

      try {
        commit.metadata = await updateCommitMetadata({
          commitId: commit.id,
          runStatusUpdate: {
            analysesCompleted: analysesAlreadyCompletedAtStart + completed.size,
          },
        });
      } catch (error) {
        console.warn(
          `CodeYam: analyzeEntities: Error in updateCommitMetadata for ${entityKey} (but continuing):`,
          error,
        );
      }
    };

    switch (concurrecyStrategy) {
      case 'sequential': {
        for (const entityKey of leafKeys) {
          await analyzeOneEntityKey(entityKey);
        }
        break;
      }
      case 'async-simple': {
        const entityKeysToAnalyze = Array.from(leafKeys).slice(
          0,
          MAX_CONCURRENT_ANALYSES,
        );
        if (entityKeysToAnalyze.length < leafKeys.size) {
          awsLog(
            `CodeYam: analyzeEntities: Capping batch of ${entityKeysToAnalyze.length} entities out of ${leafKeys.size} total`,
          );
        }
        await Promise.all(
          entityKeysToAnalyze.map(
            async (entityKey) => await analyzeOneEntityKey(entityKey),
          ),
        );
        break;
      }
      default:
        throw new Error(
          `CodeYam: analyzeEntities: Unsupported concurrency strategy: ${concurrecyStrategy}`,
        );
    }
  }

  awsLog(`CodeYam: analyzeEntities: Running patch-up dependency validation`);
  for (const analysis of analyses) {
    if (!analysis.entity) {
      throw new Error(
        `CodeYam: analyzeEntities: Internal error: Analysis entity is missing for ${analysis.filePath}:${analysis.entityName}.`,
      );
    }

    // Validate dependencies, which modifies analysis.metadata.dependentAnalyses
    validateDependencyAnalyses({ analysis, entity: analysis.entity, context });

    // Carefully update only the metadata field
    if (analysis.id) {
      const updatedMetadata = await updateFreshAnalysisMetadata(
        analysis.id,
        (metadata) => {
          metadata.dependentAnalyses =
            analysis.metadata?.dependentAnalyses || [];
        },
      );

      if (updatedMetadata) {
        analysis.metadata = updatedMetadata;
      } else {
        console.warn(
          `CodeYam: analyzeEntities: Failed to update metadata for analysis ${analysis.id}`,
        );
      }
    } else {
      console.warn(
        `CodeYam: analyzeEntities: Analysis ${analysis.filePath}:${analysis.entityName} has no ID, skipping metadata update`,
      );
    }
  }

  const newlyReady = await updateReadyAnalyses();
  if (newlyReady.length > 0) {
    console.warn(
      `CodeYam: analyzeEntities: Unexpectedly found ${newlyReady.length} newly ready analyses at the end of entity analysis`,
    );
  }

  awsLog(
    `CodeYam: analyzeEntities: Analysis completed with ${analyses.length} analyses`,
  );
  return analyses;

  // Perform a depth-first traversal of the dependency graph rooted in `entity`,
  // either noting it as a "leaf" if all its dependencies are either complete or
  // part of a cycle, else continuing the traversal.
  //
  // this logic does *not* depend on the circular detection metadata in the entity
  async function accumulateLeaves(entities: Entity[]) {
    const leafKeys = new Set<string>();
    for (const entity of entities) {
      await visitEntity(entity);
    }
    return leafKeys;

    async function visitEntity(entity: Entity, path: string[] = []) {
      const entityKey = getEntityKey(entity);
      if (leafKeys.has(entityKey)) {
        // we already know this is a leaf
        return;
      }

      let isLeaf = true;

      const importedExports = entity.metadata.importedExports ?? [];

      let entityDataStructure = entity.metadata?.isolatedDataStructure;
      let functionCalls: Record<string, string[]> = {};
      if (!entityDataStructure) {
        const dataStructureInfo = await getEntityDataStructureAndFunctionCalls({
          entity,
          fileAnalyzer: projectAnalyzer.getFileAnalyzerByPath(
            entity.resolvedFilePath ?? entity.filePath,
          ),
        });

        entityDataStructure = dataStructureInfo?.isolatedDataStructure;
        functionCalls = dataStructureInfo?.functionCalls ?? {};

        entity.metadata ||= {};
        entity.metadata.isolatedDataStructure = entityDataStructure;
      }

      const mockedDependencies = determineMockedDependencies(entity);
      for (const importedExport of importedExports) {
        const calledDependency =
          !!entityDataStructure?.dependencySchemas?.[importedExport.filePath]?.[
            importedExport.name
          ];

        const relevantFunctionCalls = functionCalls[importedExport.name];
        if (relevantFunctionCalls) {
          importedExport.calls = relevantFunctionCalls;
        }

        if (
          !calledDependency &&
          !importedExport.isImplicitDependency &&
          !relevantFunctionCalls?.length
        ) {
          if (importedExport.isMocked === undefined) {
            importedExport.isMocked = false;
          }
          continue;
        }

        const dependentEntity = context.getMutableEntity(
          importedExport.resolvedFilePath ?? importedExport.filePath,
          importedExport.resolvedName ?? importedExport.name,
        );
        if (!dependentEntity) {
          awsLog(`CodeYam: analyzeEntities: Dependent entity not found`, {
            entityFilePath: entity.filePath,
            entityName: entity.name,
            dependentFilePath:
              importedExport.resolvedFilePath ?? importedExport.filePath,
            dependentEntityName:
              importedExport.resolvedName ?? importedExport.name,
          });
          throw new Error(
            `CodeYam: analyzeEntities: Dependent entity ${importedExport.filePath}:${importedExport.name} not found`,
          );
        }

        dependentEntity.resolvedFilePath = importedExport.resolvedFilePath;
        dependentEntity.resolvedName = importedExport.resolvedName;

        if (importedExport.isMocked === undefined) {
          const isMocked = mockedDependencies.some(
            (dependency) =>
              dependency.filePath === importedExport.filePath &&
              dependency.entityName === importedExport.name,
          );
          importedExport.isMocked = isMocked;
        }

        if (importedExport.isMocked) {
          continue;
        }

        const dependentEntityKey = getEntityKey(dependentEntity);
        if (!completed.has(dependentEntityKey)) {
          if (path.includes(dependentEntityKey)) {
            continue;
          }
          isLeaf = false;
          await visitEntity(dependentEntity, [...path, dependentEntityKey]);
        }
      }

      for (const [path, infos] of Object.entries(
        entity.metadata.nodeModuleImports ?? {},
      )) {
        for (const info of infos) {
          const calledDependency =
            !!entityDataStructure?.dependencySchemas?.[path]?.[info.name];

          const relevantFunctionCalls = functionCalls[info.name];
          if (relevantFunctionCalls) {
            info.calls = relevantFunctionCalls;
          }

          if (!calledDependency && !relevantFunctionCalls?.length) {
            info.isMocked = false;
            continue;
          }

          const isMocked = mockedDependencies.some(
            (dependency) =>
              dependency.filePath === path &&
              dependency.entityName === info.name,
          );
          info.isMocked = isMocked;
        }
      }

      if (!isLeaf) {
        return;
      }

      leafKeys.add(entityKey);
    }
  }

  // common function for running analyzeEntity() and merging its results into the shared context
  async function analyzeOneEntity(
    entityKey: string,
    entity: Entity,
  ): Promise<Analysis | null> {
    // Check if analysis already exists
    const existingAnalysis = context.getMutableAnalysis(
      entity.filePath,
      entity.name,
    );
    if (existingAnalysis) {
      awsLog(
        `CodeYam: analyzeEntities: Using existing analysis for ${entityKey}`,
      );
      existingAnalysis.entity = entity;
      return existingAnalysis as Analysis;
    }

    const file =
      entity.file || project.files.find((f) => f.path === entity.filePath);
    if (!file) {
      awsLog(
        `CodeYam: analyzeEntities: File not found for entity: ${entityKey}`,
      );
      return null;
    }

    // awsLog(
    //   `CodeYam: analyzeEntities: Traversing ${entityKey} for circular dependencies`,
    // );
    // trackEntityCircularDependencies(entity, context);

    // create a private context for each analysis
    const privateContext = context.forEntityAnalysis(entity);
    awsLog(`CodeYam: analyzeEntities: Calling analyzeEntity for ${entityKey}`);

    let force = options.force;
    if (force) {
      if (!rootEntities.find((rootEntity) => rootEntity.sha === entity.sha)) {
        force = false;
      }
    }

    const { analysis } = await analyzeEntity({
      project,
      projectAnalyzer,
      commit,
      file,
      entity,
      context: privateContext,
      analyzeAsDependency: !rootEntities.some(
        (e) => e.filePath === entity.filePath && e.name === entity.name,
      ),
      ...options,
      force,
    });

    /** DEBUG: while we're in development mode, expose writes outside the expected patterns **/
    for (const addedEntity of privateContext.entitiesAdded) {
      if (addedEntity !== entity) {
        const addedEntityKey = getEntityKey(addedEntity);
        console.warn(
          `CodeYam: analyzeEntities: Entity ${addedEntityKey} was added to private context during analysis of ${entityKey}`,
        );
      }
    }
    for (const addedAnalysis of privateContext.analysesAdded) {
      if (addedAnalysis !== analysis) {
        const addedEntityKey = getEntityKey(addedAnalysis.entity);
        console.warn(
          `CodeYam: analyzeEntities: Analysis ${addedEntityKey} was added to private context during analysis of ${entityKey}`,
        );
      }
    }

    // copy both the generated analysis & the updated entity to the main context
    context.addAnalysis(analysis, entity.filePath, entity.name);
    context.addEntity(entity);

    // the analysis flow generally does not populate the entity field, but it's harmless
    // and useful for our postprocessing below
    analysis.entity = entity;
    return analysis;
  }

  async function updateReadyAnalyses() {
    const readyCandidates = analyses.filter(
      (a) =>
        !markedReady.has(a.id!) &&
        ['visual', 'library', 'index'].includes(a.entityType) &&
        a.scenarios?.length > 0,
    );

    const newlyReady = getAnalysesReadyForCapture(readyCandidates, context);

    for (const analysis of newlyReady) {
      // mark these are ready *before* the async operation to avoid contention
      markedReady.add(analysis.id!);
    }

    const successfullyUpdated: Analysis[] = [];

    for (const analysis of newlyReady) {
      const updatedStatus = await updateFreshAnalysisStatus(
        analysis.id!,
        (status) => {
          status.readyToBeCaptured = true;
        },
        'analysis',
      );

      if (updatedStatus) {
        analysis.status = updatedStatus;
        successfullyUpdated.push(analysis);
      } else {
        console.warn(
          `CodeYam: updateReadyAnalyses: Failed to update status for analysis ${analysis.id}`,
        );
      }
    }

    return successfullyUpdated;
  }
}

// translation between entities and convenient string keys
const entityMap = new Map<string, Entity>();

async function getEntityDataStructureAndFunctionCalls({
  entity,
  fileAnalyzer,
}: {
  entity: Entity;
  fileAnalyzer: FileAnalyzer;
}) {
  const dataStructure = await generateEntityDataStructure({
    entity,
    fileAnalyzer,
  });

  if (!dataStructure) return;

  const allDependencies = [
    ...(entity.metadata?.importedExports ?? []),
    ...Object.keys(entity.metadata?.nodeModuleImports ?? {}).flatMap(
      (filePath) =>
        entity.metadata?.nodeModuleImports[filePath].map((nmi) => ({
          filePath,
          name: nmi.name,
        })) ?? [],
    ),
  ];

  const dependencySchemas = allDependencies.reduce(
    (acc, importedExport) => {
      const externalFunctionCall = dataStructure.getExternalFunctionCallInfo(
        importedExport.name,
      );

      if (!externalFunctionCall) {
        return acc;
      }

      acc[importedExport.filePath] ||= {};
      acc[importedExport.filePath][importedExport.name] = {
        signatureSchema: dataStructure.getFunctionSignature({
          functionName: importedExport.name,
        }),
        returnValueSchema: dataStructure.getReturnValue({
          functionName: importedExport.name,
        }),
        usageEquivalencies: dataStructure.getUsageEquivalencies(
          importedExport.name,
        ),
        sourceEquivalencies: dataStructure.getSourceEquivalencies(
          importedExport.name,
        ),
      };
      return acc;
    },
    {} as {
      [filePath: string]: {
        [entityName: string]: {
          signatureSchema: { [key: string]: string };
          returnValueSchema: { [key: string]: string };
          usageEquivalencies: Record<
            string,
            { scopeNodeName: string; schemaPath: string }[]
          >;
          sourceEquivalencies: Record<
            string,
            { scopeNodeName: string; schemaPath: string }[]
          >;
        };
      };
    },
  );

  const isolatedDataStructure = {
    signatureSchema: dataStructure.getFunctionSignature({
      fillInUnknowns: true,
    }),
    returnValueSchema: dataStructure.getReturnValue({
      fillInUnknowns: true,
    }),
    equivalentSignatureVariables:
      dataStructure.getEquivalentSignatureVariables(),
    dependencySchemas,
  };

  const functionCalls: Record<string, string[]> = {};
  for (const filePath in dependencySchemas) {
    for (const entityName in dependencySchemas[filePath]) {
      const calls = dataStructure.externalFunctionCalls
        .filter((efc) => efc.callSignature.startsWith(entityName))
        .map((efc) => efc.callSignature);

      functionCalls[entityName] = calls;
    }
  }

  return { isolatedDataStructure, functionCalls };
}

function determineMockedDependencies(entity: Entity) {
  const mockedEntities: { filePath: string; entityName: string }[] = [];
  const dependencySchemas =
    entity.metadata.isolatedDataStructure?.dependencySchemas ?? {};
  for (const filePath in dependencySchemas) {
    for (const entityName in dependencySchemas[filePath]) {
      const dataStructure = dependencySchemas[filePath][entityName];
      const entitySignatureSchema = dataStructure.signatureSchema;

      const emptySignature =
        Object.keys(entitySignatureSchema ?? {}).length === 0;

      const entityReturnValueSchema = fillInDirectSchemaGapsAndUnknowns({
        scopeName: entity.name,
        schema: dataStructure.returnValueSchema,
      });
      const hasReturnValue =
        Object.keys(entityReturnValueSchema ?? {}).length > 0;
      const complexReturnValue = Object.values(
        entityReturnValueSchema ?? {},
      ).some((value) => value === 'object' || value === 'array');

      const entityShouldBeMocked =
        (emptySignature && hasReturnValue) || complexReturnValue;

      if (entityShouldBeMocked) {
        mockedEntities.push({
          filePath,
          entityName,
        });
      }
    }
  }

  return mockedEntities;
}

function getEntityKey(entity: Entity): string {
  const key = `${entity.filePath}:${entity.name}`;
  if (!entityMap.has(key)) {
    entityMap.set(key, entity);
  }
  return key;
}

function getEntity(key: string): Entity {
  const entity = entityMap.get(key);
  if (!entity) {
    throw new Error(`Entity not found for key: ${key}`);
  }
  return entity;
}
