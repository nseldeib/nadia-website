import generateDataStructure from './scenarios/generateDataStructure';
import generateScenarioData from './scenarios/generateScenarioData';
import generateScenarios from './scenarios/generateScenarios';
import { AI } from '~codeyam/ai';
import { Step } from './enums/steps';
import updateProps from './analyze/updateProps';
import recordStep from './recordStep';

import {
  type Analysis,
  DEFAULT_SCENARIO_NAME,
  type Entity,
  type ReadonlyAnalysisMap,
} from '~codeyam/types';
import { FileAnalyzer } from '..';
import { upsertAnalysesWithScenarios } from '~codeyam/supabase';
import { awsLog, pushAnalysisError } from '~codeyam/utils';
import generateKeyAttributes from './scenarios/generateKeyAttributes';

export interface AnalyzeInitialArgs {
  analysis: Analysis;
  entity: Entity;
  fileAnalyzer: FileAnalyzer;
  dependentAnalyses: ReadonlyAnalysisMap;
  analyzeAsDependency?: boolean;
  steps?: string[];
  updateProgress?: (detail: string) => void;
  model: AI.Model;
}

export default async function analyzeInitial({
  analysis,
  entity,
  fileAnalyzer,
  analyzeAsDependency,
  dependentAnalyses,
  steps,
  updateProgress,
  model,
}: AnalyzeInitialArgs) {
  analysis.entity = entity;
  awsLog('CodeYam: Analyzing initial entity', {
    filePath: entity.filePath,
    entityName: entity.name,
    analyzeEntityExists: !!analysis.entity,
    analyzeAsDependency,
    scenarios:
      analysis.scenarios?.filter((s) => !s.metadata?.error)?.length ?? 0,
    errorScenarios:
      analysis.scenarios?.filter((s) => !!s.metadata?.error)?.length ?? 0,
  });

  try {
    if (!steps || steps.includes(Step.Structure)) {
      const { step: dataStructureStep } = await recordStep(
        'generateDataStructure',
        () =>
          generateDataStructure({
            entity,
            dependentAnalyses,
            analysis,
          }),
      );
      analysis.status.steps.push(dataStructureStep);

      await updateProps(entity, fileAnalyzer, analysis);
    }

    if (!steps || steps.includes(Step.KeyAttributes)) {
      const { step: dataStructureStep } = await recordStep(
        'generateKeyAttributes',
        () =>
          generateKeyAttributes({
            entity,
            analysis,
            dependentAnalyses,
            model,
            updateProgress,
          }),
      );
      analysis.status.steps.push(dataStructureStep);

      await updateProps(entity, fileAnalyzer, analysis);
    }

    if (analyzeAsDependency) {
      return { analysis };
    }

    if (!steps || steps.includes(Step.Scenarios)) {
      const { step: scenarioStep } = await recordStep('generateScenarios', () =>
        generateScenarios({
          entity,
          analysis,
          dependentAnalyses,
          model,
          updateProgress,
        }),
      );
      analysis.status.steps.push(scenarioStep);
    }

    // if (!steps || steps.includes(Step.ErrorScenarios)) {
    //   const { step: errorScenarioStep } = await recordStep(
    //     'generateErrorScenarios',
    //     () =>
    //       generateScenarios({
    //         file,
    //         entity,
    //         analysis,
    //         dependentAnalyses,
    //         error: true,
    //         model,
    //         updateProgress,
    //       }),
    //   );
    //   analysis.status.steps.push(errorScenarioStep);
    // }

    if (
      analysis.scenarios &&
      analysis.scenarios.length > 0 &&
      !analysis.scenarios?.find((s) => s.name === DEFAULT_SCENARIO_NAME)
    ) {
      console.log(
        'CodeYam Error: No Default Scenario',
        analysis.id,
        analysis.filePath,
        analysis.entityName,
      );
      throw new Error('No Default Scenario when other scenarios exist');
    }

    if (!steps || steps.includes(Step.Data)) {
      const { step: mockDataStep } = await recordStep(
        'generateScenarioData',
        () =>
          generateScenarioData({
            entity,
            analysis,
            dependentAnalyses,
            model,
            updateProgress,
          }),
      );
      analysis.status.steps.push(mockDataStep);
    }
  } catch (error) {
    console.log(error);
    pushAnalysisError({
      status: analysis.status,
      error,
      phase: 'analyze',
    });

    analysis = (
      await upsertAnalysesWithScenarios({
        analysesToUpsert: [analysis],
      })
    )[0];
  }

  return { analysis };
}
