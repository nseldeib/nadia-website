import { loadMostRecentPreviousAnalysis } from '~codeyam/supabase';
import { Commit, Entity, File, Project } from '~codeyam/types';

export interface FindValidExistingAnalysisArgs {
  project: Project;
  commit: Commit;
  file: File;
  entity: Entity;
  dependencyAnalyzedTreeSha: string;
}

export default async function findPreviousAnalysis({
  project,
  commit,
  file,
  entity,
  dependencyAnalyzedTreeSha,
}: FindValidExistingAnalysisArgs) {
  if (!commit?.branchId) return null;

  const previousAnalysis = await loadMostRecentPreviousAnalysis({
    projectId: project.id,
    branchId: commit.branchId,
    filePath: file.path,
    entityName: entity.name,
    dependencyAnalyzedTreeSha,
    beforeCommit: commit,
  });

  return previousAnalysis;
}
