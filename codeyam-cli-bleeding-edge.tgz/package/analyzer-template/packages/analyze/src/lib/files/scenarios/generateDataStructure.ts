import {
  Entity,
  Analysis,
  ReadonlyAnalysisMap,
  JsonTypeDefinition,
} from '~codeyam/types';
import {
  convertDotNotation,
  fillInDirectSchemaGapsAndUnknowns,
} from '~codeyam/ai';
import mergeInDependentDataStructure from './mergeInDependentDataStructure';
import { awsLog } from '~codeyam/utils';
import gatherDataForMocks from './gatherDataForMocks';

export interface GenerateDataStructureArgs {
  entity: Entity;
  dependentAnalyses: ReadonlyAnalysisMap;
  analysis: Analysis;
}

export default function generateDataStructure({
  entity,
  dependentAnalyses,
  analysis,
}: GenerateDataStructureArgs) {
  try {
    if (!['visual', 'library'].includes(entity.entityType)) return analysis;

    awsLog('CodeYam: Generating data structure for', {
      filePath: entity.filePath,
      entityName: entity.name,
      // dependentAnalyses: Object.keys(dependentAnalyses).flatMap((path) =>
      //   Object.keys(dependentAnalyses[path]).flatMap((entityName) => ({
      //     path,
      //     entityName,
      //   })),
      // ),
    });

    const allImportedExports = [
      ...(entity.metadata.importedExports ?? []),
      ...Object.keys(entity.metadata.nodeModuleImports ?? {}).flatMap(
        (moduleName) =>
          (entity.metadata.nodeModuleImports?.[moduleName] || []).map(
            (imported) => ({
              filePath: moduleName,
              ...imported,
            }),
          ),
      ),
    ];
    const nonMockedDependentAnalyses: ReadonlyAnalysisMap =
      allImportedExports.reduce((acc, importedExport) => {
        if (importedExport.isMocked) return acc;
        const relevantDependencyAnalysis =
          dependentAnalyses[importedExport.filePath]?.[importedExport.name];

        if (!relevantDependencyAnalysis) {
          // console.info(
          //   'CodeYam Warn: No relevant dependency analysis found for importedExport',
          //   {
          //     entityName: entity.name,
          //     filePath: entity.filePath,
          //     importedExportFilePath: importedExport.filePath,
          //     importedExportEntityName: importedExport.name,
          //     importedExportResolvedFilePath: importedExport.resolvedFilePath,
          //     importedExportResolvedName: importedExport.resolvedName,
          //     importedExports: entity.metadata.importedExports.map(
          //       (importedExport) => ({
          //         filePath: importedExport.filePath,
          //         entityName: importedExport.name,
          //         isMocked: importedExport.isMocked,
          //       }),
          //     ),
          //     dependentAnalyses: Object.keys(dependentAnalyses).reduce(
          //       (acc, filePath) => {
          //         acc[filePath] = Object.keys(dependentAnalyses[filePath]);
          //         return acc;
          //       },
          //       {},
          //     ),
          //   },
          // );
          return acc;
        }

        acc[importedExport.filePath] ||= {};
        acc[importedExport.filePath][importedExport.name] =
          relevantDependencyAnalysis;
        return acc;
      }, {});

    // console.info(
    //   'CODEYAM DEBUG: start merge',
    //   JSON.stringify(
    //     {
    //       filePath: entity.filePath,
    //       entityName: entity.name,
    //       rootScopeName: dataStructure.scopeTree.name,
    //       // relevantDependencies,
    //       // nonMockedDependentAnalyses,
    //       // dependencySchemas,
    //     },
    //     null,
    //     2,
    //   ),
    // );

    const { isolatedDataStructure } = entity.metadata;
    const mergedDataStructure = mergeInDependentDataStructure({
      importedExports: allImportedExports,
      dependentAnalyses: nonMockedDependentAnalyses,
      rootScopeName: entity.name,
      dataStructure: {
        signatureSchema: isolatedDataStructure.signatureSchema,
        returnValueSchema: isolatedDataStructure.returnValueSchema,
        usageEquivalencies: isolatedDataStructure.usageEquivalencies,
        sourceEquivalencies: isolatedDataStructure.sourceEquivalencies,
      },
      dependencySchemas: isolatedDataStructure?.dependencySchemas || {},
    });

    // console.info(
    //   'CODEYAM DEBUG: end merge',
    //   JSON.stringify(
    //     {
    //       filePath: entity.filePath,
    //       entityName: entity.name,
    //       dependencySchemas: Object.keys(
    //         mergedDataStructure.dependencySchemas,
    //       ).reduce((acc, filePath) => {
    //         acc[filePath] = Object.keys(
    //           mergedDataStructure.dependencySchemas[filePath],
    //         );
    //         return acc;
    //       }, {}),
    //     },
    //     null,
    //     2,
    //   ),
    // );

    analysis.metadata ||= {};
    analysis.metadata.mergedDataStructure = mergedDataStructure;

    const dataForMocks = gatherDataForMocks(
      allImportedExports,
      mergedDataStructure.dependencySchemas,
    );

    const argumentsSchema = convertDotNotation(
      fillInDirectSchemaGapsAndUnknowns({
        schema: mergedDataStructure.signatureSchema,
      }),
    ).signature as JsonTypeDefinition[];

    analysis.metadata.scenariosDataStructure = {
      arguments: argumentsSchema,
      dataForMocks,
    };

    return analysis;
  } catch (e) {
    awsLog('CodeYam Error: Error generating data structure', {
      entity: {
        name: entity.name,
        sha: entity.sha,
        filePath: entity.filePath,
      },
      error: e,
    });
    throw e;
  }
}
