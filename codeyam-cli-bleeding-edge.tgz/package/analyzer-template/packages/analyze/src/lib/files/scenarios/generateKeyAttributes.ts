import {
  Analysis,
  Entity,
  DEFAULT_SCENARIO_NAME,
  ReadonlyAnalysisMap,
} from '~codeyam/types';
import measureAndReportExecutionTime from '../../utils/measureAndReportExecutionTime';
import { AI, generateEntityKeyAttributes } from '~codeyam/ai';
import { awsLog } from '~codeyam/utils';
import { gatherRelevantDependentKeyAttributes } from '~codeyam/ai';

export interface GenerateEntityKeyAttributesArgs {
  entity: Entity;
  analysis: Analysis;
  dependentAnalyses: ReadonlyAnalysisMap;
  error?: boolean;
  model: AI.Model;
  updateProgress?: (detail: string) => void;
}

export default async function generateKeyAttributes({
  entity,
  analysis,
  dependentAnalyses,
  error,
  model,
  updateProgress,
}: GenerateEntityKeyAttributesArgs): Promise<void> {
  if (!['visual', 'library'].includes(entity.entityType)) return;

  const structure = { ...analysis.metadata.scenariosDataStructure };

  awsLog(`🔮 Generating ${error ? 'error ' : ''}scenarios for`, {
    filePath: entity.filePath,
    entityName: entity.name,
    structure,
  });

  if (
    !structure ||
    (Object.keys(structure.dataForMocks ?? {}).length === 0 &&
      (structure.arguments ?? []).length === 0)
  ) {
    awsLog(
      `CodeYam Error: No arguments or dataForMocks for ${entity.filePath} ${entity.name}`,
    );
    if (!error) {
      analysis.scenarios = [
        {
          projectId: analysis.projectId,
          analysisId: analysis.id,
          name: DEFAULT_SCENARIO_NAME,
          description: 'The only external state the component can be in.',
          metadata: {
            testName: 'it("renders correctly")',
            keyAttributeInstructions: {},
          },
        },
      ];
    }

    return;
  }

  if (!analysis.metadata.keyAttributes) {
    const {
      result: { keyAttributes, llmCall: keyAttributesLLMCall },
    } = await measureAndReportExecutionTime(
      () =>
        generateEntityKeyAttributes({
          entity,
          model,
        }),
      `Generating entity key attributes`,
      updateProgress,
    );

    const relevantDependentKeyAttributes = gatherRelevantDependentKeyAttributes(
      entity,
      dependentAnalyses,
    );

    analysis.metadata.keyAttributes = [
      ...keyAttributes,
      ...relevantDependentKeyAttributes.map((ka) => ({
        ...ka,
      })),
    ].filter(
      (ka, index, self) =>
        self.findIndex((k) => k.internalPath === ka.internalPath) === index,
    );

    if (keyAttributesLLMCall) {
      analysis.metadata.llmCalls ||= [];
      analysis.metadata.llmCalls.push({
        name: `generateEntityKeyAttributes`,
        id: keyAttributesLLMCall.id,
      });
    }
  }
}
