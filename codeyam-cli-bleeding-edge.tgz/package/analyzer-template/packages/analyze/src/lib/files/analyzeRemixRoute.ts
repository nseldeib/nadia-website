import { Entity, EntityType, File, ProjectFramework } from '~codeyam/types';
import { ProjectAnalyzer } from '../ProjectAnalyzer';
import { generateSha } from '~codeyam/supabase';
import { isRemixRoute } from '~codeyam/utils';

export default function analyzeRemixRoute(
  file: File,
  projectAnalyzer: ProjectAnalyzer,
  entity: Entity,
  framework: ProjectFramework,
) {
  if (!isRemixRoute(file, entity, framework)) return entity;
  entity.metadata ||= {};
  const importedExports = entity.metadata.importedExports ?? [];

  const fileAnalyzer = projectAnalyzer.getFileAnalyzer(file);
  const localExports = fileAnalyzer.getAllExports();
  const internalDependencies: Entity['metadata']['importedExports'] = [
    ...['loader']
      .map((entityName) => {
        const exportedFunction = localExports[entityName];
        if (!exportedFunction) return;
        return {
          code: exportedFunction.code,
          sha: generateSha(file.path, entityName, exportedFunction.code),
          name: entityName,
          filePath: file.path,
          projectId: entity.projectId,
          entityType: 'library' as EntityType,
          isDefault: false,
          isMocked: true,
        };
      })
      .filter(Boolean),
  ];

  const route = file.path.split('.').slice(0, -1).join('.');
  const implicitRoutes = projectAnalyzer.project.files.filter((f) => {
    if (f.path.indexOf('/routes/') === -1) return false;
    const fRoute = f.path.split('.').slice(0, -1).join('.');
    return route.startsWith(fRoute) && route !== fRoute;
  });

  const implicitRouteDefaultExportEntities: Entity['metadata']['importedExports'] =
    implicitRoutes
      .map((implicitRoute) => {
        try {
          const implicitRouteFileAnalyzer =
            projectAnalyzer.getFileAnalyzer(implicitRoute);
          const exports = implicitRouteFileAnalyzer.getAllExports();
          const defaultExport = Object.values(exports).find(
            (e) => e.isDefaultExport,
          );

          const defaultEntity = implicitRoute.entities.find((e) =>
            implicitRouteFileAnalyzer.isDefaultExport(e.name),
          );

          if (!defaultExport || !defaultEntity) return;

          const code = defaultExport.code;
          return {
            code: code,
            // sha: generateSha(implicitRoute.path, 'default', code),
            name: defaultEntity.name,
            filePath: implicitRoute.path,
            projectId: entity.projectId,
            entityType: 'visual' as EntityType,
            isDefault: true,
            isImplicitDependency: true,
            isMocked: false,
          };
        } catch (e) {
          console.log(
            'CodeYam Warning: unable to find file for analysis',
            implicitRoute.path,
            e,
          );
        }
      })
      .filter(
        (implicitRouteEntity) =>
          !!implicitRouteEntity &&
          !importedExports.find(
            (e) => e.filePath && e.filePath === implicitRouteEntity.filePath,
          ),
      );

  entity.metadata.importedExports = [
    ...internalDependencies,
    ...implicitRouteDefaultExportEntities,
    ...importedExports,
  ].filter(
    (entity, index, self) =>
      self.findIndex(
        (e) => e.filePath === entity.filePath && e.name === entity.name,
      ) === index,
  );
  return entity;
}
