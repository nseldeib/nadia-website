import { EntityType } from '~codeyam/types';
import * as lib from '../index';
import ts from 'typescript';

interface GetEntityTypeArgs {
  entityName: string;
  sourceFile: ts.SourceFile;
}

export default function getEntityType({
  entityName,
  sourceFile,
}: GetEntityTypeArgs): EntityType {
  const entityNode = lib.asts.sourceFiles.getEntityNode({
    entityName,
    sourceFile,
  });

  const { nodeType, relevantNode } = lib.asts.nodes.getNodeType(
    entityNode,
    sourceFile,
  );

  if (['function', 'functionCall'].includes(nodeType)) {
    return lib.asts.nodes.getFunctionNodeType(relevantNode);
  }

  return nodeType as EntityType;
}
