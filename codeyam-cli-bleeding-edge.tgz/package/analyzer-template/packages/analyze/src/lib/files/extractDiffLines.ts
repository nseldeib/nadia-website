export default function extractDiffLines(diff: string): number[] {
  const changedLines: number[] = [];
  const diffLines = diff.split('\n');
  let currentLine = 0;

  for (const line of diffLines) {
    if (line.startsWith('@@')) {
      const match = line.match(/@@ -(\d+),\d+ \+(\d+),\d+ @@/);
      if (match) {
        currentLine = parseInt(match[2], 10) - 1; // Adjust for 0-based index
      }
    } else if (line.startsWith('+') || line.startsWith('-')) {
      changedLines.push(currentLine);
      currentLine++;
    } else {
      currentLine++;
    }
  }

  return changedLines;
}
