import {
  Analysis,
  AnalysisMap,
  DeepReadonly,
  Entity,
  EntityMap,
  Mock,
  ReadonlyAnalysis,
  ReadonlyEntity,
} from '~codeyam/types';

export interface ImmutableAnalysisContext {
  getAnalysis(
    filePath: string,
    name: string,
    withEntity?: boolean,
  ): ReadonlyAnalysis | undefined;
  getAnalysesForFile(filePath: string): DeepReadonly<Analysis[]> | undefined;
  setPrimaryAnalysis(analysis: Analysis): void;
  getEntity(filePath: string, entityName: string): ReadonlyEntity | undefined;
  getEntityNamesForFile(filePath: string): DeepReadonly<string[]> | undefined;
  updatePrimaryEntity(entity: Entity): void;
  findMock(
    filePath: string,
    entityName: string,
  ): DeepReadonly<Mock> | undefined;
  getMocks(): DeepReadonly<Mock[]>;

  // TODO: Remove when we're confident there are no more spurious mutations
  entitiesAdded: Entity[];
  analysesAdded: Analysis[];
}

/**
 * AnalysisContext encapsulates the state of an analysis process, including
 * the entity map and analysis map. This class provides controlled access to
 * these maps, ensuring all modifications are explicit and traceable.
 *
 * Current implementation allows mutable patterns for easier migration from the
 * existing codebase. In the long run, it will be instantiated with immutable
 * maps and will only provide read-only access.
 */
export class AnalysisContext implements ImmutableAnalysisContext {
  private primaryEntity?: Entity;
  private entityMap: EntityMap;
  public entitiesAdded: Entity[]; // TODO: Remove this when we switch to immutable maps
  private analysisMap: AnalysisMap;
  public analysesAdded: Analysis[]; // TODO: Remove this when we switch to immutable maps
  private projectNodeModuleMocks: Mock[];
  private baselineMode: boolean = false;

  /**
   * Create a new AnalysisContext with optional initial maps and mocks
   */
  constructor({
    primaryEntity,
    initialEntityMap,
    initialAnalysisMap,
  }: {
    primaryEntity?: Entity;
    initialEntityMap?: EntityMap;
    initialAnalysisMap?: AnalysisMap;
  } = {}) {
    this.primaryEntity = primaryEntity;
    this.entityMap = initialEntityMap || {};
    this.entitiesAdded = []; // TODO: Remove this when we switch to immutable maps
    this.analysisMap = initialAnalysisMap || {};
    this.analysesAdded = []; // TODO: Remove this when we switch to immutable maps
  }
  setPrimaryAnalysis(analysis: Analysis): void {
    if (!this.primaryEntity) {
      throw new Error('primary entity not configured');
    }
    this.addAnalysis(
      analysis,
      this.primaryEntity.filePath,
      this.primaryEntity.name,
    );
  }
  updatePrimaryEntity(entity: Entity): void {
    if (!this.primaryEntity) {
      throw new Error('primary entity not configured');
    }
    if (
      this.primaryEntity.filePath !== entity.filePath ||
      this.primaryEntity.name !== entity.name
    ) {
      throw new Error(
        `primary entity mismatch: ${this.primaryEntity.filePath}:${this.primaryEntity.name} !== ${entity.filePath}:${entity.name}`,
      );
    }
    if (this.primaryEntity.sha !== entity.sha) {
      throw new Error(
        `primary entity sha mismatch: ${this.primaryEntity.sha} !== ${entity.sha}`,
      );
    }
    this.addEntity(entity);
  }

  forEntityAnalysis(entity: Entity): ImmutableAnalysisContext {
    return new AnalysisContext({
      primaryEntity: entity,
      initialEntityMap: { ...this.entityMap },
      initialAnalysisMap: { ...this.analysisMap },
    });
  }

  /**
   * Get a read-only view of an entity by file path and entity name
   * @returns The entity or undefined if not found
   */
  getEntity(filePath: string, entityName: string): ReadonlyEntity | undefined {
    return this.entityMap[filePath]?.[entityName];
  }

  /**
   * Get a mutable view of an entity by file path and entity name
   * @returns The entity or undefined if not found
   */
  getMutableEntity(filePath: string, entityName: string): Entity | undefined {
    return this.getEntity(filePath, entityName) as Entity;
  }

  getEntityNamesForFile(filePath: string): DeepReadonly<string[]> | undefined {
    return Object.keys(this.entityMap[filePath] ?? {});
  }

  /**
   * Get a read-only view of an analysis by file path and entity name
   * @returns The analysis or undefined if not found
   */
  getAnalysis(
    filePath: string,
    entityName: string,
    withEntity = false,
  ): ReadonlyAnalysis | undefined {
    const analysis = this.analysisMap[filePath]?.[entityName];
    if (withEntity && analysis) {
      analysis.entity ||= this.getMutableEntity(filePath, entityName);
    }
    return analysis;
  }

  /**
   * Get a mutable view of an analysis by file path and entity name
   * @returns The analysis or undefined if not found
   */
  getMutableAnalysis(
    filePath: string,
    entityName: string,
  ): Analysis | undefined {
    return this.getAnalysis(filePath, entityName) as Analysis;
  }

  getAnalysesForFile(filePath: string): DeepReadonly<Analysis[]> | undefined {
    return Object.values(this.analysisMap[filePath] ?? {});
  }

  /**
   * Add or update an entity in the entity map
   *
   * NOTE: All mutable patterns in this class are temporary and will be replaced with
   * immutable patterns in the future. This is a transitional step to facilitate migration.
   *
   * If the 'alias' parameter is provided, it will be used as the key in the entity map.
   * This weird pattern is preserved to satisfy one weird callsite in gatherEntityMap().
   */
  addEntity(entity: Entity, alias?: string): void {
    if (!this.entityMap[entity.filePath]) {
      this.entityMap[entity.filePath] = {};
    }
    this.entityMap[entity.filePath][alias ?? entity.name] = entity;
  }

  /**
   * Add or update an analysis in the analysis map
   *
   * NOTE: All mutable patterns in this class are temporary and will be replaced with
   * immutable patterns in the future. This is a transitional step to facilitate migration.
   */
  addAnalysis(analysis: Analysis, filePath: string, entityName: string): void {
    if (!this.analysisMap[filePath]) {
      this.analysisMap[filePath] = {};
    }
    this.analysisMap[filePath][entityName] = analysis;
  }

  /**
   * Get a read-only copy of the entity map
   */
  getEntityMap(): DeepReadonly<EntityMap> {
    return this.entityMap;
  }

  /**
   * Get a mutable copy of the entity map
   */
  getMutableEntityMap(): EntityMap {
    return this.entityMap;
  }

  /**
   * Get a read-only copy of the analysis map
   */
  getAnalysisMap(): DeepReadonly<AnalysisMap> {
    return this.analysisMap;
  }

  /**
   * Get a mutable copy of the analysis map
   */
  getMutableAnalysisMap(): AnalysisMap {
    return this.analysisMap;
  }

  /**
   * Merge an old-fashioned AnalysisMap into this context
   */
  mergeAnalysisMap(analysisMap: AnalysisMap): void {
    for (const [filePath, analyses] of Object.entries(analysisMap)) {
      if (!this.analysisMap[filePath]) {
        this.analysisMap[filePath] = {};
      }

      for (const [entityName, analysis] of Object.entries(analyses)) {
        this.analysisMap[filePath][entityName] = analysis;
      }
    }
  }

  /**
   * Merge an old-fashioned EntityMap into this context
   */
  mergeEntityMap(entityMap: EntityMap): void {
    for (const [filePath, entities] of Object.entries(entityMap)) {
      if (!this.entityMap[filePath]) {
        this.entityMap[filePath] = {};
      }
      for (const [entityName, entity] of Object.entries(entities)) {
        this.entityMap[filePath][entityName] = entity;
      }
    }
  }

  /**
   * Add a node module mock to the context
   * If a mock with the same filePath and entityName already exists, it will be replaced
   *
   * NOTE: All mutable patterns in this class are temporary and will be replaced with
   * immutable patterns in the future. This is a transitional step to facilitate migration.
   */
  addMock(mock: Mock): void {
    if (!mock.nodeModule) {
      // Currently we only track node module mocks in this collection
      return;
    }

    const existingIndex = this.projectNodeModuleMocks.findIndex(
      (m) => m.filePath === mock.filePath && m.entityName === mock.entityName,
    );

    if (existingIndex > -1) {
      // Replace the existing mock with the updated one
      console.log(
        `CodeYam: addMock: replacing existing mock ${mock.filePath} ${mock.entityName}`,
      );
      this.projectNodeModuleMocks.splice(existingIndex, 1, mock);
    } else {
      // Add the new mock
      this.projectNodeModuleMocks.push(mock);
    }
  }

  /**
   * Get a read-only view of the project node module mocks
   * @returns A deep copy of the project node module mocks array
   */
  getMocks(): DeepReadonly<Mock[]> {
    return this.projectNodeModuleMocks;
  }

  /**
   * Find a mock by filePath and entityName
   * @returns The mock or undefined if not found
   */
  findMock(
    filePath: string,
    entityName: string,
  ): DeepReadonly<Mock> | undefined {
    return this.projectNodeModuleMocks.find(
      (m) => m.filePath === filePath && m.entityName === entityName,
    );
  }

  /**
   * Check if baseline mode is enabled (skips DB reads for performance)
   */
  isBaselineMode(): boolean {
    return this.baselineMode;
  }

  /**
   * Enable or disable baseline mode
   */
  setBaselineMode(enabled: boolean): void {
    this.baselineMode = enabled;
  }
}
