import ts from 'typescript';
import { EntityType, File, Mock, PropsWithTypes } from '~codeyam/types';
import * as lib from './index';
import { FunctionDependenciesMap } from './asts/sourceFiles/getPseudoFile';
import {
  ExportedFunction,
  getAllExports,
} from './asts/sourceFiles/getAllExports';
import { FunctionNode } from './types';
import getEntityType from './files/getEntityType';
import getEntityCode from './files/getEntityCode';

export class FileAnalyzer {
  private projectAnalyzer: lib.ProjectAnalyzer;
  public file: File;
  public sourceFile: ts.SourceFile;
  public typeChecker: ts.TypeChecker;

  constructor({
    projectAnalyzer,
    file,
  }: {
    projectAnalyzer: lib.ProjectAnalyzer;
    file: File;
  }) {
    this.projectAnalyzer = projectAnalyzer;
    this.file = file;
    this.typeChecker = this.projectAnalyzer.typeChecker;
    const _sourceFile = this.projectAnalyzer.getSourceFile(file.path);
    if (!_sourceFile) {
      console.log(
        `CodeYam Error: Error getting source file in FileAnalyzer: File not found: ${file.path}`,
      );
      throw new Error(
        `Error getting source file in FileAnalyzer: File not found: ${file.path}`,
      );
    }
    this.sourceFile = _sourceFile;
  }

  getAllEntityNodes() {
    return lib.asts.sourceFiles.getAllEntityNodes({
      sourceFile: this.sourceFile,
    });
  }

  getAllEntityNodesOnlyAliases() {
    const allEntityNodes = lib.asts.sourceFiles.getAllEntityNodes({
      sourceFile: this.sourceFile,
    });
    if (allEntityNodes.default) {
      const namedDefault = Object.entries(allEntityNodes).find(
        ([otherEntityName, node]) =>
          otherEntityName !== 'default' && node === allEntityNodes.default,
      );
      if (namedDefault) delete allEntityNodes.default;
    }
    return allEntityNodes;
  }

  getNodeCode(node: ts.Node, removeComments = false) {
    if (removeComments) {
      const printer = ts.createPrinter({ removeComments: true });
      return printer.printNode(ts.EmitHint.Unspecified, node, this.sourceFile);
    }

    return node.getText(this.sourceFile);
  }

  getNodesInRange(startPosition: number, endPosition: number) {
    const nodesInRange: ts.Node[] = [];

    function visit(node: ts.Node) {
      // Check if node is within our range
      if (
        node.getStart(this.sourceFile) >= startPosition &&
        node.getEnd() <= endPosition
      ) {
        nodesInRange.push(node);
      }

      // Continue recursively visiting children
      ts.forEachChild(node, visit);
    }

    // Start the traversal from the source file
    visit(this.sourceFile);

    return nodesInRange;
  }

  getEntityCode(entityName: string, removeComments = false) {
    return getEntityCode({
      entityName,
      sourceFile: this.sourceFile,
      removeComments,
    });
  }

  getAllExports(): Record<string, ExportedFunction> {
    return lib.asts.sourceFiles.getAllExports(this.sourceFile);
  }

  getImportsAnalysis() {
    return lib.asts.sourceFiles.getImportsAnalysis(this.sourceFile);
  }

  getImportNodes() {
    const importNodes: ts.ImportDeclaration[] = [];

    const importsVisitor = (node: ts.Node) => {
      if (ts.isImportDeclaration(node)) {
        importNodes.push(node);
      } else {
        node.forEachChild(importsVisitor);
      }
    };

    this.sourceFile.forEachChild(importsVisitor);

    return importNodes;
  }

  getSourceFilesForAllImports() {
    return lib.asts.sourceFiles.getSourceFilesForAllImports(
      this.sourceFile,
      this.projectAnalyzer.program,
    );
  }

  getImportsCode() {
    const imports = this.getImportNodes();
    return imports.map((node) => this.getNodeCode(node, true));
  }

  getLocalEntitiesUsedInFunction(functionName: string) {
    const entityNodes = lib.asts.sourceFiles.getAllEntityNodes({
      sourceFile: this.sourceFile,
    });

    const identifiers = this.getIdentifiersInNode(entityNodes[functionName]);
    return identifiers
      .filter(
        (identifier, index, self) =>
          entityNodes[identifier] !== entityNodes[functionName] &&
          Object.keys(entityNodes).includes(identifier) &&
          self.indexOf(identifier) === index,
      )
      .map((identifier) => ({
        name: identifier,
        node: entityNodes[identifier],
        code: entityNodes[identifier].getText(this.sourceFile),
      }));
  }

  getImportsRelevantToFunctionName(
    functionName: string,
  ): FunctionDependenciesMap {
    const importsAnalysis = lib.asts.sourceFiles.getImportsAnalysis(
      this.sourceFile,
    );

    const relevantNode = lib.asts.sourceFiles.getEntityNode({
      entityName: this.isDefaultExport(functionName) ? 'default' : functionName,
      sourceFile: this.sourceFile,
    });
    const identifiersInRelevantNode = this.getIdentifiersInNode(relevantNode);

    const entries = Object.entries(importsAnalysis)
      .map(([importedFilePath, importedExpressions]) => {
        const relevantExpressions = importedExpressions.filter(
          (importedExpression) => {
            return identifiersInRelevantNode.includes(
              importedExpression.importAlias,
            );
          },
        );

        // Remove duplicate 'default' if present
        const uniqueRelevantExpressions = [...new Set(relevantExpressions)];
        const resolvedModule = this.getResolvedModule(importedFilePath);

        for (let i = 0; i < uniqueRelevantExpressions.length; i++) {
          const relevantExpression = uniqueRelevantExpressions[i];
          if (
            relevantExpression.exportName === '*' &&
            resolvedModule &&
            !resolvedModule.isExternalLibraryImport
          ) {
            uniqueRelevantExpressions.splice(i, 1);
            uniqueRelevantExpressions.push(
              ...this.resolveNamespaceImport(
                relevantNode,
                relevantExpression.importAlias,
                importedFilePath,
              ),
            );
          }
        }

        if (uniqueRelevantExpressions.length > 0) {
          return [
            importedFilePath,
            {
              externalLibrary: resolvedModule?.isExternalLibraryImport ?? true,
              resolvedPath: resolvedModule?.resolvedFileName,
              exportInfos: uniqueRelevantExpressions,
            },
          ];
        } else {
          return [];
        }
      })
      .filter((entry) => entry.length > 0);

    return Object.fromEntries(entries);
  }

  getResolvedImportsRelevantToFunctionName(
    functionName: string,
  ): FunctionDependenciesMap {
    const imports = this.getImportsRelevantToFunctionName(functionName);

    return Object.fromEntries(
      Object.entries(imports)
        .map(([importPath, { externalLibrary, exportInfos }]) => {
          const resolvedImport = this.getResolvedModule(importPath);

          if (!resolvedImport)
            return [importPath, { externalLibrary, exportInfos }];

          const relativePath = this.projectAnalyzer.getRelativePath(importPath);
          const projectPath = this.projectAnalyzer.getRelativePath(
            resolvedImport.resolvedFileName,
          );

          const importedFile = this.projectAnalyzer.project.files.find(
            (f) => f.path === projectPath,
          );

          if (!importedFile) {
            return [
              importPath,
              {
                externalLibrary,
                exportInfos,
              },
            ];
          }

          const importedFileAnalyer =
            this.projectAnalyzer.getFileAnalyzer(importedFile);
          const importedExports = importedFileAnalyer.getAllExports();

          for (const exportInfo of exportInfos) {
            if (exportInfo.isExportDefault) {
              Object.entries(importedExports).find(
                ([entityName, exportedFunction]) => {
                  if (exportedFunction.isDefaultExport) {
                    exportInfo.exportName = entityName;
                  }
                },
              );
            }

            const importedExport = importedExports[exportInfo.exportName];
            const directImportPath = importedExport?.directImportPath;

            if (directImportPath) {
              const directImportResolvedImports =
                importedFileAnalyer.getResolvedImportsRelevantToFunctionName(
                  exportInfo.exportName,
                );
              const directImportResolvedImport =
                directImportResolvedImports[directImportPath];

              if (directImportResolvedImport) {
                const directImportExportInfo =
                  directImportResolvedImport?.exportInfos?.find(
                    (info) => info.importAlias === exportInfo.exportName,
                  );
                exportInfo.resolvedPath =
                  directImportExportInfo.resolvedPath ??
                  directImportResolvedImport.resolvedPath;
                exportInfo.exportName = directImportExportInfo.exportName;
                exportInfo.isExportDefault =
                  directImportExportInfo.isExportDefault;
              } else {
                const importsAnalysis =
                  importedFileAnalyer.getImportsAnalysis();
                const [_, relevantImports] = Object.entries(
                  importsAnalysis,
                ).find(([path]) => path === directImportPath);
                if (relevantImports) {
                  const relevantImport = relevantImports.find(
                    (info) => info.importAlias === exportInfo.exportName,
                  );

                  exportInfo.isExportDefault = relevantImport.isExportDefault;
                  exportInfo.resolvedPath = directImportPath;
                  exportInfo.exportName = relevantImport.importName;
                }
              }
            }
          }

          return [
            relativePath,
            {
              exportInfos,
              externalLibrary,
              resolvedPath: projectPath,
            },
          ];
        })
        .filter(Boolean),
    );
  }

  getResolvedModule(importPath: string) {
    return this.projectAnalyzer.getResolvedModule(importPath, this.sourceFile);
  }

  getNamespaceIdentifiersInNode(node: ts.Node, namespaceIdentifier: string) {
    const identifiers: string[] = [];

    const identifierVisitor = (child: ts.Node) => {
      if (ts.isPropertyAccessExpression(child)) {
        if (child.expression.getText() === namespaceIdentifier) {
          identifiers.push(child.name.getText());
        }
      }
      ts.forEachChild(child, identifierVisitor);
    };

    ts.forEachChild(node, identifierVisitor);
    return identifiers.filter(
      (identifier, index, self) => self.indexOf(identifier) === index,
    );
  }

  getIdentifiersInNode(node: ts.Node): string[] {
    const identifiers: string[] = [];

    if (ts.isIdentifier(node)) {
      identifiers.push(node.getText());
    }

    const identifierVisitor = (child: ts.Node) => {
      if (ts.isIdentifier(child)) {
        if (child.getText() === 'default') return;
        identifiers.push(child.getText());
      } else if (ts.isExportDeclaration(child)) {
        if (child.exportClause && ts.isNamedExports(child.exportClause)) {
          child.exportClause.elements.forEach((element) => {
            identifiers.push(element.name.getText());
          });
        } else if (
          child.exportClause &&
          ts.isNamespaceExport(child.exportClause)
        ) {
          identifiers.push(child.exportClause.name.getText());
        }
      } else if (ts.isExportAssignment(child)) {
        if (ts.isIdentifier(child.expression)) {
          identifiers.push(child.expression.getText());
        }
      } else if (ts.isExportSpecifier(child)) {
        identifiers.push(child.name.getText());
        return;
      } else if (ts.isFunctionDeclaration(child) && child.name) {
        identifiers.push(child.name.getText());
      } else if (ts.isVariableStatement(child)) {
        child.declarationList.declarations.forEach((declaration) => {
          if (ts.isIdentifier(declaration.name)) {
            identifiers.push(declaration.name.getText());
          }
        });
      } else if (ts.isImportDeclaration(child)) {
        if (child.importClause && child.importClause.namedBindings) {
          if (ts.isNamespaceImport(child.importClause.namedBindings)) {
            identifiers.push(child.importClause.namedBindings.name.getText());
          } else if (ts.isNamedImports(child.importClause.namedBindings)) {
            child.importClause.namedBindings.elements.forEach((element) => {
              identifiers.push(element.name.getText());
            });
          }
        }
      } else if (ts.isImportSpecifier(child)) {
        identifiers.push(child.name.getText());
        return;
      }
      ts.forEachChild(child, identifierVisitor);
    };

    ts.forEachChild(node, identifierVisitor);
    return identifiers.filter(
      (identifier, index, self) => self.indexOf(identifier) === index,
    );
  }

  resolveNamespaceImport(
    entityNode: ts.Node,
    namespaceIdentifier: string,
    importedFilePath: string,
  ) {
    const exportInfos = [];
    const resolvedModule = this.getResolvedModule(importedFilePath);

    const identifiersForNamespace = this.getNamespaceIdentifiersInNode(
      entityNode,
      namespaceIdentifier,
    );

    const resolvedNamespaceFilePath = resolvedModule.resolvedFileName;
    const relativeNamespaceFilePath = this.projectAnalyzer.getRelativePath(
      resolvedNamespaceFilePath,
    );
    const namespaceFileAnalyzer = this.projectAnalyzer.getFileAnalyzerByPath(
      relativeNamespaceFilePath,
    );
    const imports = namespaceFileAnalyzer.getImportsAnalysis();
    const exports = namespaceFileAnalyzer.getAllExports();

    for (const identifierForNamespace of identifiersForNamespace) {
      const relevantExport = exports[identifierForNamespace];

      if (relevantExport) {
        if (relevantExport.isNamespaceExport) {
          const [relevantImportPath] = Object.entries(imports).find(
            ([_, infos]) =>
              infos.find((info) => info.importAlias === identifierForNamespace),
          );

          const resolvedPath =
            namespaceFileAnalyzer.getResolvedModule(
              relevantImportPath,
            ).resolvedFileName;

          exportInfos.push(
            {
              exportName: identifierForNamespace,
              importAlias: `${namespaceIdentifier}.${identifierForNamespace}`,
              isExportDefault: relevantExport.isDefaultExport,
              isImportDefault: relevantExport.isDefaultExport,
              resolvedPath: relativeNamespaceFilePath,
            },
            ...this.resolveNamespaceImport(
              entityNode,
              `${namespaceIdentifier}.${identifierForNamespace}`,
              resolvedPath,
            ),
          );
        } else {
          exportInfos.push({
            exportName: identifierForNamespace,
            importAlias: `${namespaceIdentifier}.${identifierForNamespace}`,
            isExportDefault: relevantExport.isDefaultExport,
            isImportDefault: relevantExport.isDefaultExport,
            resolvedPath: relativeNamespaceFilePath,
          });
        }
      }
    }

    return exportInfos;
  }

  /**
   * This will return the absolute path of imported files from the given file
   * e.g. /Users/yourMacUser/path/to/simulated/project/within/codeyam/file.ts
   */
  getAbsolutePathsForInternalImports(): string[] {
    return lib.asts.sourceFiles.getAbsolutePathsForInternalImports(
      this.sourceFile,
      this.projectAnalyzer.program,
    );
  }

  /**
   * This will return the import mappings for the given file
   * e.g. { '/Users/yourMacUser/path/to/simulated/project/within/codeyam/app/types/User.ts': '~/types/User' }
   */
  getAbsoluteImportMappings(): Record<string, string> {
    const importMappings = lib.asts.sourceFiles.getImportMappings(
      this.sourceFile,
      this.projectAnalyzer.program,
    );

    return Object.fromEntries(importMappings);
  }

  /**
   * This will return the import mappings for the given file
   * e.g. { 'app/types/User.ts': '~/types/User' }
   */
  getRelativeImportMappings(): Record<string, string> {
    const importMappings = lib.asts.sourceFiles.getImportMappings(
      this.sourceFile,
      this.projectAnalyzer.program,
    );

    return Object.entries(Object.fromEntries(importMappings)).reduce(
      (acc, [key, value]) => {
        acc[key.replace(this.projectAnalyzer.dirPath + '/', '')] = value;
        return acc;
      },
      {} as Record<string, string>,
    );
  }

  /**
   * This will return the path of imported files from the root of the simulated project
   * e.g. <root>/types/file.ts
   */
  getRootRelativePathsForInternalImports(): string[] {
    const fullPaths = this.getAbsolutePathsForInternalImports();
    const rootRelativePaths = fullPaths.map((fullPath) =>
      fullPath.replace(this.projectAnalyzer.dirPath, ''),
    );
    return rootRelativePaths;
  }

  /**
   * This function analyzes the first detected function declaration in the file
   * and so currently lacks the ability to detect if it is _actually_ a React
   * component. It would be more appropriate to think of it as
   * `getFirstFunctionDeclarationsFirstInputParameter`.
   */
  getComponentProps(): PropsWithTypes {
    return lib.asts.sourceFiles.getComponentProps({
      sourceFile: this.sourceFile,
      typeChecker: this.typeChecker,
    });
  }

  getEntityType(entityName: string): EntityType {
    return getEntityType({ entityName, sourceFile: this.sourceFile });
  }

  getEntityStartAndEnd(entityName: string): { start: number; end: number } {
    const node = this.getAllEntityNodes()[entityName];
    const start = this.sourceFile.getLineAndCharacterOfPosition(
      node.getStart(),
    ).line;
    const end = this.sourceFile.getLineAndCharacterOfPosition(
      node.getEnd(),
    ).line;
    return { start, end };
  }

  isExported(entityName: string): boolean {
    // if (entityName === 'default') {
    //   const exportNodes = lib.asts.sourceFiles.getAllExportedNodes(
    //     this.sourceFile,
    //   );
    //   const exports = lib.asts.sourceFiles.getAllExports(
    //     this.sourceFile,
    //   );
    //   const exportInfo = exports['default'];
    //   console.log("CODEYAM DEBUG: default isExported", Object.keys(exportNodes), JSON.stringify(exportInfo, null, 2), this.sourceFile.getText());
    // }

    if (entityName === 'default') return true;

    const exportNodes = lib.asts.sourceFiles.getAllExportedNodes(
      this.sourceFile,
    );

    const exportNode = exportNodes[entityName];

    if (exportNode) {
      return true;
    }

    return false;
  }

  isDefaultExport(entityName: string): boolean {
    if (entityName === 'default') return true;

    const exportNodes = lib.asts.sourceFiles.getAllExportedNodes(
      this.sourceFile,
    );
    const exportNode = exportNodes[entityName];

    if (!exportNode) {
      return false;
    }

    return lib.asts.nodes.isDefaultExport(exportNode, this.sourceFile);
  }

  getMockData(): Mock[] {
    const sourceFilesForImports =
      lib.asts.sourceFiles.getSourceFilesForAllImports(
        this.sourceFile,
        this.projectAnalyzer.program,
      );

    const localImportSourceFiles = sourceFilesForImports.filter(
      (sf) => !sf.fileName.includes('node_modules'),
    );

    const filePreMocks = localImportSourceFiles.map((sf) => {
      // the ts.SourceFile object has a fileName property that is the absolute path
      const filePath = sf.fileName.replace(
        this.projectAnalyzer.dirPath + '/',
        '',
      );

      return {
        projectId: '',
        fileId: '',
        filePath,
        entityName: '',
        entitySha: '',
        content: sf.getFullText(),
        types: lib.asts.sourceFiles.getResolvedImportedTypes(
          sf,
          this.typeChecker,
        ),
        nodeModule: false,
        metadata: {
          defaultExport: false,
          notExported: false,
          llmCalls: {},
        },
      };
    });

    return filePreMocks;
  }

  getPropTypesForFunctionEntity(
    entityName: string,
    properties?: string[],
  ): PropsWithTypes {
    const nodes = this.getAllEntityNodes();
    const node = nodes[entityName];

    const findFunctionNode = (node: ts.Node): FunctionNode | undefined => {
      if (lib.asts.nodes.isFunction(node)) {
        return node as FunctionNode;
      }

      let functionNode: FunctionNode | undefined;

      node.forEachChild((child) => {
        if (functionNode) return;
        functionNode = findFunctionNode(child);
      });

      return functionNode;
    };

    const functionNode = findFunctionNode(node);
    if (!functionNode) return { props: [] };

    return lib.asts.sourceFiles.getPropsFromFunctionalComponent({
      functionNode,
      sourceFile: this.sourceFile,
      checker: this.typeChecker,
      properties,
    });
  }

  getMockDataForExport(entityName: string): Mock[] {
    const relevantImports = this.getImportsRelevantToFunctionName(entityName);

    const sourceFilesForImports = lib.asts.sourceFiles.getSourceFilesForImports(
      Object.keys(relevantImports),
      this.sourceFile,
      this.projectAnalyzer.program,
    );

    const resolvedRelevantImports = Object.keys(relevantImports).reduce(
      (acc, importPath) => {
        const resolvedImport = lib.asts.sourceFiles.getResolvedModule(
          importPath,
          this.sourceFile,
          this.projectAnalyzer.program,
        );

        if (!resolvedImport) return acc;

        acc[resolvedImport.resolvedFileName] = relevantImports[importPath];
        return acc;
      },
      {},
    );

    const localImportSourceFiles = sourceFilesForImports.filter(
      (sf) => !sf.fileName.includes('node_modules'),
    );

    const filePreMocks = localImportSourceFiles
      .map((sf) => {
        // the ts.SourceFile object has a fileName property that is the absolute path
        const filePath = sf.fileName.replace(
          this.projectAnalyzer.dirPath + '/',
          '',
        );

        const exportsFromMock = getAllExports(sf);

        const relevantExports = Object.keys(exportsFromMock).filter(
          (entityNameFromMock) =>
            resolvedRelevantImports[sf.fileName].includes(entityNameFromMock) ||
            (exportsFromMock[entityNameFromMock].isDefaultExport &&
              resolvedRelevantImports[sf.fileName].includes('default')),
        );

        return relevantExports.map((entityName) => {
          return {
            projectId: '',
            fileId: '',
            filePath,
            entityName,
            entitySha: '',
            nodeModule: false,
            content: exportsFromMock[entityName].code,
            types: lib.asts.sourceFiles.getResolvedImportedTypes(
              sf,
              this.typeChecker,
            ),
            metadata: {
              defaultExport: exportsFromMock[entityName].isDefaultExport,
              notExported: false,
              llmCalls: {},
            },
          };
        });
      })
      .flat();

    return filePreMocks;
  }

  removeImports(
    importDeclaration: ts.ImportDeclaration,
    removeImportNames: string[],
  ) {
    const importClause = importDeclaration.importClause;

    if (!importClause)
      return ts
        .createPrinter({ removeComments: true })
        .printNode(ts.EmitHint.Unspecified, importDeclaration, this.sourceFile);

    const namedBindings = importClause.namedBindings;
    let newImportClause = importClause;

    let newNamedImports: ts.NamedImports | undefined;
    if (ts.isNamedImports(namedBindings)) {
      const updatedElements = namedBindings.elements.filter(
        (element) => !removeImportNames.includes(this.getNodeCode(element)),
      );

      if (updatedElements.length > 0) {
        newNamedImports = ts.factory.createNamedImports(updatedElements);

        newImportClause = ts.factory.createImportClause(
          importClause.isTypeOnly,
          importClause.name,
          newNamedImports,
        );
      } else {
        newImportClause = ts.factory.createImportClause(
          importClause.isTypeOnly,
          importClause.name,
          undefined,
        );
      }
    }

    if (removeImportNames.includes(importClause.name?.getText())) {
      newImportClause = ts.factory.createImportClause(
        importClause.isTypeOnly,
        undefined,
        newNamedImports,
      );
    }

    const newImportDeclaration = ts.factory.createImportDeclaration(
      undefined,
      newImportClause,
      importDeclaration.moduleSpecifier,
      undefined,
    );

    return ts
      .createPrinter({ removeComments: true })
      .printNode(
        ts.EmitHint.Unspecified,
        newImportDeclaration,
        this.sourceFile,
      );
  }
}
