import measureExecutionTime from './measureExecutionTime';

export default async function measureAndReportExecutionTime<T>(
  callback: () => T | Promise<T>,
  headline: string,
  report?: (message: string) => void,
): Promise<{ result: T }> {
  try {
    const { result, seconds, milliseconds } =
      await measureExecutionTime(callback);

    const message = `${headline}: ${seconds}.${milliseconds} seconds.`;
    console.log(`⏰ ${message}`);
    report?.(message);

    return { result };
  } catch (error) {
    console.error(`CodeYam Error: ❌ Error in ${headline}:`, error);
    report?.(`Error in ${headline}: ${error.message}`);
    throw error; // re-throw for the caller to handle
  }
}
