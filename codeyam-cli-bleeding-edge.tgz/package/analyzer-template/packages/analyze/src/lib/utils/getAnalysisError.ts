import { AnalysisStatus, AnalysisError } from '~codeyam/types';

interface GetAnalysisErrorArgs {
  status: AnalysisStatus;
  phase?: 'analyze' | 'capture';
}

export default function getAnalysisError({
  status,
  phase,
}: GetAnalysisErrorArgs): AnalysisError[] {
  return status.errors.filter((error) => !phase || error.phase === phase);
}
