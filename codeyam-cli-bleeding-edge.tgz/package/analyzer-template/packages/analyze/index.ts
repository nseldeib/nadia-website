/**
 * This is the external API of packages/analyze. Please be thoughtful when
 * adding exports to it.
 */

// If you don't export classes directly you run into issues where TS thinks you
// are exporting a namespace/object.
//
// e.g., (BAD) `export const SomeClass = lib.SomeClass;`
//
// TS thinks this is a namespace or object and so disallows using the class as
// both a class and a type declaration. The fix is a direct export of a class,
// as seen below.
export { FileAnalyzer } from './src/lib/FileAnalyzer';
export { ProjectAnalyzer } from './src/lib/ProjectAnalyzer';
export {
  default as analyzeEntity,
  AnalyzeEntityArgs,
} from './src/lib/files/analyzeEntity';
export {
  AnalysisContext,
  ImmutableAnalysisContext,
} from './src/lib/analysisContext';
export { default as findOrCreateEntity } from './src/lib/files/analyze/findOrCreateEntity';
export { default as gatherEntityMap } from './src/lib/files/analyze/gatherEntityMap';
export { default as setImportedExports } from './src/lib/files/setImportedExports';

// New exports for non-recursive analysis
export { default as validateDependencyAnalyses } from './src/lib/files/analyze/validateDependencyAnalyses';
export { default as analyzeEntities } from './src/lib/files/analyze/analyzeEntities';

export { default as getEntityType } from './src/lib/files/getEntityType';
export { default as getEntityCode } from './src/lib/files/getEntityCode';
export { getAllEntityNodes } from './src/lib/asts/sourceFiles/getAllEntityNodes';

export { default as safeStringify } from './src/lib/utils/safeStringify';
export { default as fileAnalyzerFromCode } from './src/lib/files/fileAnalyzerFromCode';

export { default as isolateDataStructure } from './src/lib/files/scenarios/isolateDataStructure';
export { default as mergeInDependentDataStructure } from './src/lib/files/scenarios/mergeInDependentDataStructure';
export { default as mergeValidatedDataStructures } from './src/lib/files/scenarios/mergeValidatedDataStructures';

export { discoverDirectDependencies } from './src/lib/files/analyze/dependencyResolver';

export { default as getAnalysisError } from './src/lib/utils/getAnalysisError';

// Rough mocks to help debug build failures.
//
// import { Entity, EntityMap, EntityType, Project } from '~codeyam/types';
// import { SourceFile, TypeChecker } from 'typescript';
//
// export class FileAnalyzer {
//   sourceFile = {} as unknown as SourceFile;
//   typeChecker = {} as unknown as TypeChecker;
//   getEntityCode = (a, b?) => '';
//   getRelativeImportMappings = () => ({});
//   getImportsCode = () => [];
//   isDefaultExport= (a) => false;
//   isExported = (a) => false;
//   getEntityType = (a) => 'visual' as EntityType;
//   getAllEntityNodesNoAliases = () => { return [] }
// }
// export class ProjectAnalyzer {
//   project = {} as unknown as Project;
//   getAllSourceFiles = () => [];
//   getFileAnalyzer = (a) => { return {} as unknown as FileAnalyzer };
//   static async from(a) { return {} as unknown as ProjectAnalyzer };
// }
// export interface AnalyzeEntityArgs {}
// export const analyzeEntity = (a) => {
//   return {
//     analysisMap: {},
//     entityMap: {} as unknown as EntityMap,
//     entity: {} as unknown as Entity,
//     file: {},
//     filePath: '',
//     analysis: {},
//     existingProjectNodeModuleMocks: [],
//   }
// };
// export const analyzeIndirectEntities = (a) => {
//   return {
//     entityMap: {} as unknown as EntityMap,
//     analysisMap: {},
//   }
// };
// export const findOrCreateEntity = (a) => {
//   return {} as unknown as Entity;
// };
// export const gatherEntityMap = (a) => {
//   return {} as unknown as EntityMap
// };
// export const analyzeProjectType = (a) => {
//   return {
//     packageManager: '',
//     monorepo: false,
//   }
// };
// export const isRemixRoute = (a, b, c) => {
//   return false
// };
// export const setImportedExports = (a) => {
//   return {
//     entities: [],
//     entityMap: {} as unknown as EntityMap,
//   }
// };
// export const getEntityType = () => {};
// export const getEntityCode = () => {};
// export const getAllEntityNodes = () => {};
// export const safeStringify = (x) => {};
