# TODOs

## Doing

## To Do

- Create a mother function / portfolio builder of a file inside FileAnalyzer that combines the functionality of getAllExportedFunctions and getPseudoFile.
- class components
- Reduce duplicated files: `background/integrationTests/lib/runShellCommand.ts`, `background/src/lib/local/execAsync.ts`, `background/src/lib/virtualized/common/execAsync.ts`
- File that has dependencies that do not need to be mocked are still classified as files that need to be mocked in getFilesRequiringMock.ts
- Add packageManager path to `Project`, eg, `project.packageManager = 'pnpm'`
- component that use providers
  - mock providers when generating examples
  - get it working with the Package and File Analyzer
- if a file gets deleted in one branch but exists on another branch, they all get deleted in the db
- In the FileExample type, id should not be optional. This will help a lot of undefined checking in `WebContainerProvider.tsx`
- Don't let the AI break the types because it's trying to find edge cases that actually cause rendering errors. For example it generated this:

```ts
{
      "id": "7a5f52eb-957b-4024-b8cf-400f7bd90da7",
      "info": {
        "props": [
          {
            "name": "name",
            "value": "NonBool",
            "required": true
          },
          {
            "name": "age",
            "value": "30",
            "required": true
          },
          {
            "name": "isActive",
            "value": "notABoolean",
            "required": true
          }
        ]
      },
      "name": "Edge Case: Non-Boolean isActive",
      "description": "Handles an edge case where isActive is not a boolean"
    }
```

which is incorrect because `isActive` is a boolean.
