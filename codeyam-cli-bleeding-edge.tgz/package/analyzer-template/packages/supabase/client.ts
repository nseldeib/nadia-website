/**
 * This index file re-exports modules which are safe to use in a browser
 * environment with our current set of polyfills. Two considerations:
 * - It must compile: it can't rely on node modules we don't polyfill
 * - It must use Supabase for its REST capabilities. None of the db.ts
 *   infrastructure must be invoked in this file or any of its imports.
 *
 *   Kysely itself is fine.
 */

export { getSupabase, getAdminSupabase } from './src/lib/supabase';

export type { SupabaseClient } from '@supabase/supabase-js';
export { default as upsertFiles_Client } from './src/lib/client/upsertFiles_Client';
export { default as loadAnalyses_Client } from './src/lib/client/loadAnalysesInClient';
export { default as loadBranches_Client } from './src/lib/client/loadBranches_Client';
export { default as loadAnalysis_Client } from './src/lib/client/loadAnalysis_Client';

export { default as listenForCommits_Client } from './src/lib/client/listenForCommits_Client';

export { default as dbToAnalysis } from './src/lib/dbToAnalysis';
export { default as dbToBranch } from './src/lib/dbToBranch';
export { default as dbToCommit } from './src/lib/dbToCommit';
export { default as dbToEntity } from './src/lib/dbToEntity';
export { default as dbToFile } from './src/lib/dbToFile';
export { default as dbToMock } from './src/lib/dbToMock';
export { default as dbToProject } from './src/lib/dbToProject';
export { default as dbToScenario } from './src/lib/dbToScenario';
export { default as dbToUserScenario } from './src/lib/dbToUserScenario';
export { default as dbToScenarioComment } from './src/lib/dbToScenarioComment';

export { default as userScenarioToDb } from './src/lib/userScenarioToDb';

export { default as generateSha } from './src/lib/generateSha';

export * from './src/lib/kysely/tableRelations';
