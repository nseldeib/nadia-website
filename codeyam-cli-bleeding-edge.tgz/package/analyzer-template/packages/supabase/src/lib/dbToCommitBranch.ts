import { CommitBranch } from '~codeyam/types';
import dbToBranch from './dbToBranch';
import dbToCommit from './dbToCommit';
import { DbCommitBranch } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToCommitBranch(
  dbCommitBranch: DbCommitBranch,
): CommitBranch {
  return nullsToUndefines({
    id: dbCommitBranch.id,
    commitId: dbCommitBranch.commit_id,
    branchId: dbCommitBranch.branch_id,
    active: !!dbCommitBranch.active,
    commit: dbCommitBranch.commit
      ? dbToCommit(dbCommitBranch.commit)
      : undefined,
    branch: dbCommitBranch.branch
      ? dbToBranch(dbCommitBranch.branch)
      : undefined,
  });
}
