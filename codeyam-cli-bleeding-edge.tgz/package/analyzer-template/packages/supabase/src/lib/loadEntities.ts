import { Entity } from '~codeyam/types';
import dbToEntity from './dbToEntity';
import { getDatabase } from './kysely/db';

export interface LoadEntitiesArgs {
  projectId?: string;
  branchId?: string;
  fileIds?: string[];
  filePaths?: string[];
  names?: string[];
  shas?: string[];
}

export default async function loadEntities({
  projectId,
  branchId,
  fileIds,
  filePaths,
  names,
  shas,
}: LoadEntitiesArgs): Promise<Entity[] | null> {
  if (
    (fileIds && fileIds.length == 0) ||
    (filePaths && filePaths.length == 0) ||
    (names && names.length == 0) ||
    (shas && shas.length == 0)
  ) {
    return [];
  }

  if (shas && shas.length > 50) {
    const allEntities: Entity[] = [];
    for (let i = 0; i < shas.length; i += 50) {
      const chunk = shas.slice(i, i + 50);
      const chunkEntities = await loadEntities({
        projectId,
        branchId,
        fileIds,
        filePaths,
        names,
        shas: chunk,
      });

      if (chunkEntities) {
        allEntities.push(...chunkEntities);
      }
    }
    return allEntities;
  }

  const db = getDatabase();

  try {
    let query = db
      .selectFrom('entities')
      .selectAll('entities')
      .$if(!!branchId, (qb) =>
        qb
          .innerJoin(
            'entity_branches',
            'entity_branches.entity_sha',
            'entities.sha',
          )
          .where('entity_branches.branch_id', '=', branchId),
      )
      .$if(!!projectId, (qb) => qb.where('entities.project_id', '=', projectId))
      .$if(!!shas, (qb) => qb.where('entities.sha', 'in', shas))
      .$if(!!filePaths, (qb) => qb.where('entities.file_path', 'in', filePaths))
      .$if(!!names, (qb) => qb.where('entities.name', 'in', names))
      .$if(!!fileIds, (qb) => qb.where('entities.file_id', 'in', fileIds));

    const entities = await query.execute();

    if (!entities || entities.length === 0) {
      console.log('Load Entities: No entities found', {
        projectId,
        fileIds,
        filePaths,
        shas,
      });
      return null;
    }

    return entities.map(dbToEntity);
  } catch (error) {
    console.log('Load Entities: Error occurred', error, {
      projectId,
      fileIds,
      filePaths,
      shas,
    });
    return null;
  }
}
