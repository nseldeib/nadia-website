import { BackgroundJob } from '~codeyam/types';
import { DbBackgroundJob } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToBackgroundJob(
  dbBackgroundJob: DbBackgroundJob,
): BackgroundJob {
  const {
    project_id,
    commit_id,
    created_at,
    updated_at,
    success,
    ...remaining
  } = dbBackgroundJob;

  return nullsToUndefines({
    ...remaining,
    projectId: project_id,
    commitId: commit_id,
    createdAt: created_at,
    updatedAt: updated_at,
    success: !!success,
  });
}
