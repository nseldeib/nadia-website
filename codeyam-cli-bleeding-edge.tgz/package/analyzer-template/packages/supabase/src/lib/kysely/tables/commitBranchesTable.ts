import { Kysely } from 'kysely';
import type { Generated } from 'kysely';

import { schemaField, defaultNow } from '../schemaHelpers';

const commitBranchesSchema = {
  active: schemaField<Generated<boolean | null>>(),
  branch_id: schemaField<string | null>(),
  commit_id: schemaField<string | null>(),
  created_at: schemaField<Generated<string>>(),
  id: schemaField<Generated<string>>(),
} as const;

// Derive the interface from the schema
export type CommitBranchesTable = {
  [K in keyof typeof commitBranchesSchema]: (typeof commitBranchesSchema)[K];
};

// Get columns at runtime
export const CommitBranchesTableColumns = Object.keys(
  commitBranchesSchema,
) as (keyof CommitBranchesTable)[];

export async function createCommitBranchesTable(
  db: Kysely<any>,
): Promise<void> {
  await db.schema
    .createTable('commit_branches')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('branch_id', 'uuid')
    .addColumn('commit_id', 'uuid')
    .addColumn('active', 'boolean')
    .addColumn('created_at', 'datetime', defaultNow(true))
    .ifNotExists()
    .execute();
}
