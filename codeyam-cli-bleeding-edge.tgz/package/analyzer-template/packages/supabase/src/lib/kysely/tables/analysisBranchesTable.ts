import { Kysely } from 'kysely';
import type { Generated } from 'kysely';

import { schemaField, defaultNow } from '../schemaHelpers';

const analysisBranchesSchema = {
  active: schemaField<Generated<boolean>>(),
  analysis_id: schemaField<string>(),
  branch_id: schemaField<string>(),
  created_at: schemaField<Generated<string | null>>(),
  entity_sha: schemaField<string>(),
  id: schemaField<Generated<string>>(),
} as const;

// Derive the interface from the schema
export type AnalysisBranchesTable = {
  [K in keyof typeof analysisBranchesSchema]: (typeof analysisBranchesSchema)[K];
};

// Get columns at runtime
export const AnalysisBranchesTableColumns = Object.keys(
  analysisBranchesSchema,
) as (keyof AnalysisBranchesTable)[];

export async function createAnalysisBranchesTable(
  db: Kysely<any>,
): Promise<void> {
  await db.schema
    .createTable('analysis_branches')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('analysis_id', 'uuid', (col) => col.notNull())
    .addColumn('branch_id', 'uuid', (col) => col.notNull())
    .addColumn('entity_sha', 'varchar', (col) => col.notNull())
    .addColumn('active', 'boolean', (col) => col.defaultTo(true))
    .addColumn('created_at', 'datetime', defaultNow())
    .ifNotExists()
    .execute();
}
