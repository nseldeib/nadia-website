import type { Generated, JSONColumnType } from 'kysely';
import { Kysely } from 'kysely';
import { Branch } from '~codeyam/types';

import { schemaField, defaultNow } from '../schemaHelpers';

const branchesSchema = {
  active_at: schemaField<string | null>(),
  content_changed_at: schemaField<Generated<string | null>>(),
  created_at: schemaField<Generated<string>>(),
  id: schemaField<Generated<string>>(),
  metadata: schemaField<JSONColumnType<Branch['metadata']> | null>(),
  name: schemaField<string | null>(),
  primary: schemaField<Generated<boolean>>(),
  project_id: schemaField<string | null>(),
  ref: schemaField<string | null>(),
  sha: schemaField<string | null>(),
  updated_at: schemaField<Generated<string | null>>(),
} as const;

// Derive the interface from the schema
export type BranchesTable = {
  [K in keyof typeof branchesSchema]: (typeof branchesSchema)[K];
};

// Get columns at runtime
export const BranchesTableColumns = Object.keys(
  branchesSchema,
) as (keyof BranchesTable)[];

export async function createBranchesTable(db: Kysely<any>): Promise<void> {
  await db.schema
    .createTable('branches')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('project_id', 'uuid')
    .addColumn('ref', 'text')
    .addColumn('name', 'text')
    .addColumn('sha', 'text')
    .addColumn('primary', 'boolean', (col) => col.notNull().defaultTo(false))
    .addColumn('metadata', 'text') // JSON stored as text in SQLite
    .addColumn('content_changed_at', 'datetime', defaultNow())
    .addColumn('active_at', 'datetime')
    .addColumn('created_at', 'datetime', defaultNow(true))
    .addColumn('updated_at', 'datetime', defaultNow())
    .ifNotExists()
    .execute();
}
