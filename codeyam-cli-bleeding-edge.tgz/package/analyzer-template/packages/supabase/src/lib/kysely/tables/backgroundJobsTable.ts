import { Kysely } from 'kysely';
import type { Generated, JSONColumnType } from 'kysely';
import { BackgroundJob } from '~codeyam/types';

import { schemaField, defaultNow } from '../schemaHelpers';

const backgroundJobsSchema = {
  commit_id: schemaField<string>(),
  created_at: schemaField<Generated<string>>(),
  progress: schemaField<JSONColumnType<BackgroundJob['progress']> | null>(),
  project_id: schemaField<string>(),
  success: schemaField<boolean | null>(),
  updated_at: schemaField<string | null>(),
} as const;

// Derive the interface from the schema
export type BackgroundJobsTable = {
  [K in keyof typeof backgroundJobsSchema]: (typeof backgroundJobsSchema)[K];
};

// Get columns at runtime
export const BackgroundJobsTableColumns = Object.keys(
  backgroundJobsSchema,
) as (keyof BackgroundJobsTable)[];

export async function createBackgroundJobsTable(
  db: Kysely<any>,
): Promise<void> {
  await db.schema
    .createTable('background_jobs')
    .addColumn('commit_id', 'uuid', (col) => col.notNull())
    .addColumn('project_id', 'uuid', (col) => col.notNull())
    .addColumn('progress', 'text')
    .addColumn('success', 'boolean')
    .addColumn('created_at', 'datetime', defaultNow(true))
    .addColumn('updated_at', 'datetime')
    .addPrimaryKeyConstraint('background_jobs_pkey', [
      'project_id',
      'commit_id',
    ])
    .ifNotExists()
    .execute();
}
