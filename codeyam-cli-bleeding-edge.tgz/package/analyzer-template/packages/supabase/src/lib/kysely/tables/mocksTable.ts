import { Kysely } from 'kysely';
import type { Generated, JSONColumnType } from 'kysely';
import { Mock } from '~codeyam/types';

import { schemaField, defaultNow } from '../schemaHelpers';

const mocksSchema = {
  content: schemaField<string | null>(),
  created_at: schemaField<Generated<string>>(),
  entity_name: schemaField<string | null>(),
  entity_sha: schemaField<string | null>(),
  file_id: schemaField<string | null>(),
  file_path: schemaField<string | null>(),
  id: schemaField<Generated<string>>(),
  metadata: schemaField<JSONColumnType<Mock['metadata']> | null>(),
  mocking_required: schemaField<Generated<boolean | null>>(),
  node_module: schemaField<boolean | null>(),
  project_id: schemaField<string | null>(),
  sha: schemaField<string | null>(),
} as const;

// Derive the interface from the schema
export type MocksTable = {
  [K in keyof typeof mocksSchema]: (typeof mocksSchema)[K];
};

// Get columns at runtime
export const MocksTableColumns = Object.keys(
  mocksSchema,
) as (keyof MocksTable)[];

export async function createMocksTable(db: Kysely<any>): Promise<void> {
  await db.schema
    .createTable('mocks')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('project_id', 'uuid')
    .addColumn('file_id', 'uuid')
    .addColumn('file_path', 'varchar')
    .addColumn('entity_sha', 'varchar')
    .addColumn('entity_name', 'varchar')
    .addColumn('mocking_required', 'boolean', (col) => col.defaultTo(false))
    .addColumn('content', 'text')
    .addColumn('node_module', 'boolean')
    .addColumn('metadata', 'text') // JSON stored as text in SQLite
    .addColumn('created_at', 'datetime', defaultNow(true))
    .addColumn('sha', 'varchar')
    .ifNotExists()
    .execute();
}
