import { Kysely } from 'kysely';
import type { Generated } from 'kysely';

import { schemaField } from '../schemaHelpers';

const entityBranchesSchema = {
  active: schemaField<Generated<boolean>>(),
  branch_id: schemaField<string>(),
  entity_sha: schemaField<string>(),
} as const;

// Derive the interface from the schema
export type EntityBranchesTable = {
  [K in keyof typeof entityBranchesSchema]: (typeof entityBranchesSchema)[K];
};

// Get columns at runtime
export const EntityBranchesTableColumns = Object.keys(
  entityBranchesSchema,
) as (keyof EntityBranchesTable)[];

export async function createEntityBranchesTable(
  db: Kysely<any>,
): Promise<void> {
  await db.schema
    .createTable('entity_branches')
    .addColumn('branch_id', 'uuid', (col) => col.notNull())
    .addColumn('entity_sha', 'varchar', (col) => col.notNull())
    .addColumn('active', 'boolean', (col) => col.defaultTo(true))
    .addPrimaryKeyConstraint('entity_branches_pkey', [
      'branch_id',
      'entity_sha',
    ])
    .ifNotExists()
    .execute();
}
