import SQLiteDatabase from 'better-sqlite3';
import { Pool, PoolClient } from 'pg';

import {
  Kysely,
  LogEvent,
  ParseJSONResultsPlugin,
  PostgresDialect,
  sql,
  SqliteDialect,
} from 'kysely';

import * as sqliteHelper from 'kysely/helpers/sqlite';
import * as pgHelper from 'kysely/helpers/postgres';

import { SqliteBooleanPlugin } from './sqliteBooleanPlugin';

import { createProjectsTable, ProjectsTable } from './tables/projectsTable';
import { AnalysesTable, createAnalysesTable } from './tables/analysesTable';
import {
  AnalysisBranchesTable,
  createAnalysisBranchesTable,
} from './tables/analysisBranchesTable';
import {
  BackgroundJobsTable,
  createBackgroundJobsTable,
} from './tables/backgroundJobsTable';
import { BranchesTable, createBranchesTable } from './tables/branchesTable';
import {
  CommitBranchesTable,
  createCommitBranchesTable,
} from './tables/commitBranchesTable';
import { CommitsTable, createCommitsTable } from './tables/commitsTable';
import { createEntitiesTable, EntitiesTable } from './tables/entitiesTable';
import {
  createEntityBranchesTable,
  EntityBranchesTable,
} from './tables/entityBranchesTable';
import {
  createEntityStatementsTable,
  EntityStatementsTable,
} from './tables/entityStatementsTable';
import { createFilesTable, FilesTable } from './tables/filesTable';
import {
  createGithubPayloadsTable,
  GithubPayloadsTable,
} from './tables/githubPayloadsTable';
import {
  createGithubUsersTable,
  GithubUsersTable,
} from './tables/githubUsersTable';
import { createMocksTable, MocksTable } from './tables/mocksTable';
import {
  createScenarioCommentsTable,
  ScenarioCommentsTable,
} from './tables/scenarioCommentsTable';
import { createScenariosTable, ScenariosTable } from './tables/scenariosTable';
import {
  createStatementsTable,
  StatementsTable,
} from './tables/statementsTable';
import { createTeamsTable, TeamsTable } from './tables/teamsTable';
import {
  createUserScenariosTable,
  UserScenariosTable,
} from './tables/userScenariosTable';
import { createUserTeamsTable, UserTeamsTable } from './tables/userTeamsTable';
import { createUsersTable, UsersTable } from './tables/usersTable';

import { schemaField } from './schemaHelpers';

import dotenv from 'dotenv';
import fs from 'fs';

dotenv.config();

const ENABLE_QUERY_LOGGING = !!getEnvVar('ENABLE_QUERY_LOGGING');
const ENABLE_QUERY_ERROR_LOGGING = !!getEnvVar('ENABLE_QUERY_ERROR_LOGGING');

// 🚨 WARNING: This will COMPLETELY WIPE your local PostgreSQL database!
// Only enable for testing against a dedicated test database on localhost.
// NEVER use this with production databases!
const USE_LOCAL_POSTGRESQL_FOR_TESTING =
  getEnvVar('USE_LOCAL_POSTGRESQL_FOR_TESTING') === 'true';

// define the Kysely database as an object instance so we can enumerate
// our tables in runtime, while still creating the Database type for Kysely
// using type inference flow (below).
const databaseSchema = {
  projects: schemaField<ProjectsTable>(),
  analyses: schemaField<AnalysesTable>(),
  analysis_branches: schemaField<AnalysisBranchesTable>(),
  background_jobs: schemaField<BackgroundJobsTable>(),
  branches: schemaField<BranchesTable>(),
  commit_branches: schemaField<CommitBranchesTable>(),
  commits: schemaField<CommitsTable>(),
  entities: schemaField<EntitiesTable>(),
  entity_branches: schemaField<EntityBranchesTable>(),
  entity_statements: schemaField<EntityStatementsTable>(),
  files: schemaField<FilesTable>(),
  github_payloads: schemaField<GithubPayloadsTable>(),
  github_users: schemaField<GithubUsersTable>(),
  mocks: schemaField<MocksTable>(),
  scenario_comments: schemaField<ScenarioCommentsTable>(),
  scenarios: schemaField<ScenariosTable>(),
  statements: schemaField<StatementsTable>(),
  teams: schemaField<TeamsTable>(),
  user_scenarios: schemaField<UserScenariosTable>(),
  user_teams: schemaField<UserTeamsTable>(),
  users: schemaField<UsersTable>(),
} as const;

// This is the core Database type used by Kysely everywhere
export type Database = {
  [K in keyof typeof databaseSchema]: (typeof databaseSchema)[K];
};

// Get columns at runtime
export const databaseTableNames = Object.keys(
  databaseSchema,
) as (keyof Database)[];

let db: Kysely<Database>;

export function getDatabase(): Kysely<Database> {
  if (!db) {
    const dbType = determineDatabaseType();

    if (dbType === 'sqlite') {
      db = getSqliteDatabase();
    } else if (dbType === 'postgresql') {
      db = getPostgreDatabase();
    } else {
      throw new Error(`Unknown database type: ${dbType}`);
    }
  }
  return db;
}

let warnedAboutTestDb = false;

export function getSqliteDatabase(sqlitePath?: string) {
  if (!sqlitePath) {
    sqlitePath = getEnvVar('SQLITE_PATH');
  }
  if (sqlitePath === ':memory:' || sqlitePath === 'memory') {
    throw new Error(
      'In-memory SQLite not supported in getDatabase(). Use getDatabaseForTesting() instead.',
    );
  }

  console.log(`CodeYam: Using SQLite database at path: ${sqlitePath}`);

  const sqlite = new SQLiteDatabase(sqlitePath);
  return new Kysely<Database>({
    dialect: new SqliteDialect({ database: sqlite }),
    plugins: [new ParseJSONResultsPlugin(), new SqliteBooleanPlugin()],
    log: onQueryLogEvent,
  });
}

export function getPostgreDatabase() {
  const connectionString = getPostgresConnectionString();
  console.log(`CodeYam: Using PostgreSQL database at: ${connectionString}`);
  const pool = new Pool({ connectionString });
  pool.on('error', (err: Error, _client: PoolClient) => {
    console.error('CodeYam: Unexpected error on idle PostgreSQL client', err);
  });
  return new Kysely<Database>({
    dialect: new PostgresDialect({ pool }),
    log: onQueryLogEvent,
  });
}
// Async database creation for testing only
export async function getDatabaseForTesting(
  dbPath = ':memory:',
): Promise<Kysely<Database>> {
  if (USE_LOCAL_POSTGRESQL_FOR_TESTING) {
    // 🚨 DANGER ZONE: PostgreSQL testing mode 🚨
    if (!warnedAboutTestDb) {
      console.warn(
        '⚠️  WARNING: Running tests against local PostgreSQL database!',
      );
      console.warn('⚠️  This will DELETE ALL DATA in your local database!');
      warnedAboutTestDb = true;
    }

    const connectionString = getPostgresConnectionString();
    validateLocalhostOnly(connectionString);

    const pool = new Pool({
      connectionString,
      max: 1, // Single connection for tests
    });
    pool.on('error', (err: Error, _client: PoolClient) => {
      console.error(
        'CodeYam: Unexpected error on idle PostgreSQL client in test pool',
        err,
      );
    });
    const kyselyDb = new Kysely<Database>({
      dialect: new PostgresDialect({ pool }),
      plugins: [new ParseJSONResultsPlugin()], // No SQLite boolean plugin for PostgreSQL
      log: onQueryLogEvent,
    });

    await clearPostgreSQLData(kyselyDb);
    return kyselyDb;
  } else {
    // Standard SQLite testing path
    const sqlite = new SQLiteDatabase(dbPath);
    const kyselyDb = new Kysely<Database>({
      dialect: new SqliteDialect({ database: sqlite }),
      plugins: [new ParseJSONResultsPlugin(), new SqliteBooleanPlugin()],
      log: onQueryLogEvent,
    });

    await createSqliteSchema(kyselyDb);
    return kyselyDb;
  }
}

let jsonHelper: ReturnType<typeof createJsonHelper> | null = null;

export function getJsonHelper() {
  if (!jsonHelper) {
    jsonHelper = createJsonHelper(determineDatabaseType());
  }
  return jsonHelper;
}

export function getJsonHelperForTesting() {
  return createJsonHelper(
    USE_LOCAL_POSTGRESQL_FOR_TESTING ? 'postgresql' : 'sqlite',
  );
}

function onQueryLogEvent(event: LogEvent) {
  if (event.level === 'error') {
    if (ENABLE_QUERY_ERROR_LOGGING) {
      console.error('Query failed : ', {
        durationMs: event.queryDurationMillis,
        error: event.error,
        sql: event.query.sql,
        params: event.query.parameters,
      });
    }
  } else if (ENABLE_QUERY_LOGGING) {
    // `'query'`
    console.log('Query executed : ', {
      durationMs: event.queryDurationMillis,
      sql: event.query.sql,
      params: event.query.parameters,
    });
  }
}

function createJsonHelper(dbType: 'postgresql' | 'sqlite') {
  if (dbType === 'sqlite') {
    return sqliteHelper;
  } else if (dbType === 'postgresql') {
    return pgHelper;
  } else {
    throw new Error(`Unknown database type: ${dbType}`);
  }
}

function determineDatabaseType(): 'postgresql' | 'sqlite' {
  const sqlitePath = getEnvVar('SQLITE_PATH');
  if (sqlitePath) {
    return 'sqlite';
  }

  // Check for PostgreSQL connection strings
  const postgresUrl = getEnvVar('POSTGRESQL_URL');
  if (postgresUrl) {
    return 'postgresql';
  }

  throw new Error(
    'No database configuration found. Set SQLITE_PATH for SQLite or POSTGRESQL_URL for PostgreSQL',
  );
}

export async function createSqliteSchema(db: Kysely<Database>): Promise<void> {
  // Create all tables needed for testing
  // TODO: If this takes non-trivial time, we can maybe do it concurrently?
  await createProjectsTable(db);
  await createAnalysesTable(db);
  await createAnalysisBranchesTable(db);
  await createBackgroundJobsTable(db);
  await createBranchesTable(db);
  await createCommitBranchesTable(db);
  await createCommitsTable(db);
  await createEntitiesTable(db);
  await createEntityBranchesTable(db);
  await createEntityStatementsTable(db);
  await createFilesTable(db);
  await createGithubPayloadsTable(db);
  await createGithubUsersTable(db);
  await createMocksTable(db);
  await createScenarioCommentsTable(db);
  await createScenariosTable(db);
  await createStatementsTable(db);
  await createTeamsTable(db);
  await createUserScenariosTable(db);
  await createUserTeamsTable(db);
  await createUsersTable(db);
}

let warnedAboutClear = false;

// 🚨 DANGER: This deletes ALL data from ALL tables in the database!
async function clearPostgreSQLData(db: Kysely<Database>): Promise<void> {
  if (!warnedAboutClear) {
    console.warn('🗑️  Clearing all data from PostgreSQL database...');
  }

  // Delete in reverse dependency order (child tables first)
  // Using the dynamically generated table names from schema
  const tablesToClear = [...databaseTableNames].reverse();

  // For testing, we can use TRUNCATE for better performance and to reset sequences
  // But fallback to DELETE if TRUNCATE fails due to foreign key constraints
  for (const tableName of tablesToClear) {
    try {
      // Try TRUNCATE first for better performance
      await sql`TRUNCATE TABLE ${sql.ref(tableName)} CASCADE`.execute(db);
    } catch (error) {
      console.warn(
        `TRUNCATE failed for ${tableName}, falling back to DELETE:`,
        error,
      );
      try {
        // Fallback to DELETE FROM if TRUNCATE fails
        await db.deleteFrom(tableName as any).execute();
      } catch (deleteError) {
        console.error(`Failed to clear table ${tableName}:`, deleteError);
        // Continue with other tables - don't fail the entire test setup
      }
    }
  }

  if (!warnedAboutClear) {
    console.warn('✅ PostgreSQL database cleared.');
    warnedAboutClear = true;
  }
}

// Safety check to ensure we're only wiping localhost databases
function validateLocalhostOnly(connectionString: string): void {
  try {
    const url = new URL(connectionString.replace('postgresql://', 'http://'));
    const allowedHosts = ['localhost', '127.0.0.1', '::1'];

    if (!allowedHosts.some((host) => url.hostname.includes(host))) {
      throw new Error(
        `🚨 SAFETY ERROR: PostgreSQL testing is only allowed on localhost!\n` +
          `Current host: ${url.hostname}\n` +
          `Set USE_LOCAL_POSTGRESQL_FOR_TESTING=false to disable PostgreSQL testing.\n` +
          `If you need to test against a remote database, please review the safety implications.`,
      );
    }

    // console.warn(`🔒 Validated localhost connection: ${url.hostname}`);
  } catch (error) {
    if (error instanceof Error && error.message.includes('SAFETY ERROR')) {
      throw error; // Re-throw our safety errors
    }

    // If URL parsing fails, be extra cautious and block
    throw new Error(
      `🚨 SAFETY ERROR: Could not validate connection string format.\n` +
        `For safety, PostgreSQL testing is blocked.\n` +
        `Connection string: ${connectionString}\n` +
        `Error: ${error}`,
    );
  }
}

function getPostgresConnectionString(): string {
  // Check for direct PostgreSQL connection strings first
  const postgresUrl = getEnvVar('POSTGRESQL_URL');
  if (!postgresUrl) {
    throw new Error(
      'No PostgreSQL connection string found. Set POSTGRESQL_URL environment variable.',
    );
  }
  return postgresUrl;
}

function getEnvVar(key: string): string | undefined {
  return typeof window !== 'undefined'
    ? (window as any).env?.[key]
    : process.env[key];
}
