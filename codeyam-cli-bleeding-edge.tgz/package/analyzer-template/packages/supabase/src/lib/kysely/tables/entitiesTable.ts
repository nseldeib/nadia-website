import { Kysely } from 'kysely';
import type { Generated, JSONColumnType } from 'kysely';
import { Entity } from '~codeyam/types';

import { schemaField, defaultNow } from '../schemaHelpers';

const entitiesSchema = {
  commit_id: schemaField<string | null>(),
  created_at: schemaField<Generated<string>>(),
  description: schemaField<string | null>(),
  documentation: schemaField<string | null>(),
  entity_type: schemaField<string | null>(),
  file_id: schemaField<string | null>(),
  file_path: schemaField<string | null>(),
  metadata: schemaField<JSONColumnType<Entity['metadata']> | null>(),
  name: schemaField<string | null>(),
  project_id: schemaField<string>(),
  quality: schemaField<string | null>(), // Numeric as string in SQLite
  sha: schemaField<string>(),
  updated_at: schemaField<string | null>(),
} as const;

// Derive the interface from the schema
export type EntitiesTable = {
  [K in keyof typeof entitiesSchema]: (typeof entitiesSchema)[K];
};

// Get columns at runtime
export const EntitiesTableColumns = Object.keys(
  entitiesSchema,
) as (keyof EntitiesTable)[];

export async function createEntitiesTable(db: Kysely<any>): Promise<void> {
  await db.schema
    .createTable('entities')
    .addColumn('project_id', 'uuid', (col) => col.notNull())
    .addColumn('file_id', 'uuid')
    .addColumn('commit_id', 'uuid')
    .addColumn('name', 'varchar')
    .addColumn('sha', 'varchar', (col) => col.primaryKey())
    .addColumn('entity_type', 'varchar')
    .addColumn('file_path', 'varchar')
    .addColumn('description', 'text')
    .addColumn('documentation', 'text')
    .addColumn('metadata', 'text') // JSON stored as text in SQLite
    .addColumn('quality', 'text') // Numeric as text in SQLite
    .addColumn('created_at', 'datetime', defaultNow(true))
    .addColumn('updated_at', 'datetime')
    .ifNotExists()
    .execute();
}
