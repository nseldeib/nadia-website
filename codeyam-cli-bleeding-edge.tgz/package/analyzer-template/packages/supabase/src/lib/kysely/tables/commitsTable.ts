import { Kysely } from 'kysely';
import type { Generated, JSONColumnType } from 'kysely';
import { Commit } from '~codeyam/types';

import { schemaField, defaultNow } from '../schemaHelpers';

const commitsSchema = {
  ai_message: schemaField<string | null>(),
  analyzed_at: schemaField<string | null>(),
  author_github_username: schemaField<string | null>(),
  branch_id: schemaField<string | null>(),
  committed_at: schemaField<string | null>(),
  created_at: schemaField<Generated<string>>(),
  files: schemaField<JSONColumnType<Commit['files']> | null>(),
  html_url: schemaField<string | null>(),
  id: schemaField<Generated<string>>(),
  merged_branch_id: schemaField<string | null>(),
  message: schemaField<string | null>(),
  metadata: schemaField<JSONColumnType<Commit['metadata']> | null>(),
  project_id: schemaField<string>(),
  sha: schemaField<string>(),
  title: schemaField<string | null>(),
  url: schemaField<string | null>(),
} as const;

// Derive the interface from the schema
export type CommitsTable = {
  [K in keyof typeof commitsSchema]: (typeof commitsSchema)[K];
};

// Get columns at runtime
export const CommitsTableColumns = Object.keys(
  commitsSchema,
) as (keyof CommitsTable)[];

export async function createCommitsTable(db: Kysely<any>): Promise<void> {
  await db.schema
    .createTable('commits')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('project_id', 'uuid', (col) => col.notNull())
    .addColumn('branch_id', 'uuid')
    .addColumn('merged_branch_id', 'uuid')
    .addColumn('message', 'text')
    .addColumn('ai_message', 'text')
    .addColumn('title', 'varchar')
    .addColumn('author_github_username', 'varchar')
    .addColumn('url', 'varchar')
    .addColumn('html_url', 'varchar')
    .addColumn('sha', 'varchar', (col) => col.notNull())
    .addColumn('files', 'text') // JSON stored as text in SQLite
    .addColumn('metadata', 'text') // JSON stored as text in SQLite
    .addColumn('committed_at', 'datetime')
    .addColumn('analyzed_at', 'datetime')
    .addColumn('created_at', 'datetime', defaultNow(true))
    .ifNotExists()
    .execute();
}
