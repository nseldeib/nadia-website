import { Kysely } from 'kysely';
import type { Generated } from 'kysely';

import { schemaField, defaultNow } from '../schemaHelpers';

const githubPayloadsSchema = {
  after: schemaField<string | null>(),
  commit_sha: schemaField<string | null>(),
  committed_at: schemaField<string | null>(),
  created_at: schemaField<Generated<string>>(),
  error: schemaField<string | null>(),
  id: schemaField<Generated<string>>(),
  payload: schemaField<string | null>(),
  payload_type: schemaField<string | null>(),
  project_id: schemaField<string>(),
  ref: schemaField<string | null>(),
} as const;

// Derive the interface from the schema
export type GithubPayloadsTable = {
  [K in keyof typeof githubPayloadsSchema]: (typeof githubPayloadsSchema)[K];
};

// Get columns at runtime
export const GithubPayloadsTableColumns = Object.keys(
  githubPayloadsSchema,
) as (keyof GithubPayloadsTable)[];

export async function createGithubPayloadsTable(
  db: Kysely<any>,
): Promise<void> {
  await db.schema
    .createTable('github_payloads')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('project_id', 'uuid', (col) => col.notNull())
    .addColumn('payload_type', 'varchar')
    .addColumn('payload', 'text')
    .addColumn('after', 'varchar')
    .addColumn('commit_sha', 'varchar')
    .addColumn('ref', 'varchar')
    .addColumn('committed_at', 'datetime')
    .addColumn('error', 'text')
    .addColumn('created_at', 'datetime', defaultNow(true))
    .ifNotExists()
    .execute();
}
