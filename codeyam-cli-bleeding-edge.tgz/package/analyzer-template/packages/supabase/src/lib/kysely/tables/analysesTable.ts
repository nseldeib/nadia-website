import { Kysely } from 'kysely';
import type { Generated, JSONColumnType } from 'kysely';
import { AnalysisMetadata, AnalysisStatus } from '~codeyam/types';

import { schemaField, defaultNow } from '../schemaHelpers';

const analysesSchema = {
  analyzed_tree_sha: schemaField<string | null>(),
  branch_commit_sha: schemaField<string | null>(),
  commit_id: schemaField<string | null>(),
  committed_at: schemaField<string | null>(),
  completed_at: schemaField<string | null>(),
  created_at: schemaField<Generated<string>>(),
  dependency_analyzed_tree_sha: schemaField<string | null>(),
  entity_name: schemaField<string | null>(),
  entity_sha: schemaField<string | null>(),
  entity_type: schemaField<string | null>(),
  file_id: schemaField<string | null>(),
  file_path: schemaField<string | null>(),
  id: schemaField<Generated<string>>(),
  indirect: schemaField<boolean | null>(),
  metadata: schemaField<JSONColumnType<AnalysisMetadata> | null>(),
  previous_analysis_id: schemaField<string | null>(),
  project_id: schemaField<string | null>(),
  status: schemaField<JSONColumnType<AnalysisStatus> | null>(),
  tree_sha: schemaField<string | null>(),
  updated_at: schemaField<Generated<string>>(),
} as const;

// Derive the interface from the schema
export type AnalysesTable = {
  [K in keyof typeof analysesSchema]: (typeof analysesSchema)[K];
};

// Get columns at runtime
export const AnalysesTableColumns = Object.keys(
  analysesSchema,
) as (keyof AnalysesTable)[];

export async function createAnalysesTable(db: Kysely<any>): Promise<void> {
  await db.schema
    .createTable('analyses')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('project_id', 'uuid')
    .addColumn('file_id', 'uuid')
    .addColumn('commit_id', 'uuid')
    .addColumn('entity_sha', 'varchar')
    .addColumn('entity_name', 'varchar')
    .addColumn('status', 'text') // JSON stored as text in SQLite
    .addColumn('metadata', 'text') // JSON stored as text in SQLite
    .addColumn('created_at', 'datetime', defaultNow(true))
    .addColumn('updated_at', 'datetime', defaultNow(true))
    .addColumn('tree_sha', 'text')
    .addColumn('analyzed_tree_sha', 'text')
    .addColumn('dependency_analyzed_tree_sha', 'text')
    .addColumn('previous_analysis_id', 'uuid')
    .addColumn('branch_commit_sha', 'varchar')
    .addColumn('indirect', 'boolean')
    .addColumn('committed_at', 'datetime')
    .addColumn('completed_at', 'datetime')
    .addColumn('file_path', 'varchar')
    .addColumn('entity_type', 'varchar')
    .ifNotExists()
    .execute();
}
