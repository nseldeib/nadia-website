import { Kysely } from 'kysely';
import type { Generated, JSONColumnType } from 'kysely';
import { File } from '~codeyam/types';

import { schemaField, defaultNow } from '../schemaHelpers';

const filesSchema = {
  created_at: schemaField<Generated<string>>(),
  deleted: schemaField<Generated<boolean | null>>(),
  id: schemaField<Generated<string>>(),
  metadata: schemaField<JSONColumnType<File['metadata']> | null>(),
  name: schemaField<string | null>(),
  path: schemaField<string>(),
  project_id: schemaField<string>(),
  updated_at: schemaField<Generated<string | null>>(),
} as const;

// Derive the interface from the schema
export type FilesTable = {
  [K in keyof typeof filesSchema]: (typeof filesSchema)[K];
};

// Get columns at runtime
export const FilesTableColumns = Object.keys(
  filesSchema,
) as (keyof FilesTable)[];

export async function createFilesTable(db: Kysely<any>): Promise<void> {
  await db.schema
    .createTable('files')
    .addColumn('id', 'uuid', (col) => col.primaryKey())
    .addColumn('project_id', 'uuid', (col) => col.notNull())
    .addColumn('name', 'varchar')
    .addColumn('path', 'varchar', (col) => col.notNull())
    .addColumn('deleted', 'boolean', (col) => col.defaultTo(false))
    .addColumn('created_at', 'datetime', defaultNow(true))
    .addColumn('updated_at', 'datetime', defaultNow())
    .addColumn('metadata', 'text') // JSON stored as text in SQLite
    .ifNotExists()
    .execute();
}
