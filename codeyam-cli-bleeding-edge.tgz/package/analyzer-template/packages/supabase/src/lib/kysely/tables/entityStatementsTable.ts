import { Kysely } from 'kysely';
import type { Generated } from 'kysely';

import { schemaField, defaultNow } from '../schemaHelpers';

const entityStatementsSchema = {
  created_at: schemaField<Generated<string>>(),
  entity_sha: schemaField<string>(),
  id: schemaField<Generated<bigint>>(),
  project_id: schemaField<string>(),
  statement_sha: schemaField<string>(),
} as const;

// Derive the interface from the schema
export type EntityStatementsTable = {
  [K in keyof typeof entityStatementsSchema]: (typeof entityStatementsSchema)[K];
};

// Get columns at runtime
export const EntityStatementsTableColumns = Object.keys(
  entityStatementsSchema,
) as (keyof EntityStatementsTable)[];

export async function createEntityStatementsTable(
  db: Kysely<any>,
): Promise<void> {
  await db.schema
    .createTable('entity_statements')
    .addColumn('id', 'integer', (col) => col.autoIncrement().primaryKey())
    .addColumn('project_id', 'uuid', (col) => col.notNull())
    .addColumn('entity_sha', 'varchar', (col) => col.notNull())
    .addColumn('statement_sha', 'varchar', (col) => col.notNull())
    .addColumn('created_at', 'datetime', defaultNow(true))
    .ifNotExists()
    .execute();
}
