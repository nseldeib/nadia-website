import { Kysely } from 'kysely';
import type { Generated } from 'kysely';

import { schemaField, defaultNow } from '../schemaHelpers';

const githubUsersSchema = {
  avatar_url: schemaField<string | null>(),
  created_at: schemaField<Generated<string>>(),
  preferred_username: schemaField<string | null>(),
  updated_at: schemaField<Generated<string | null>>(),
  username: schemaField<string>(),
} as const;

// Derive the interface from the schema
export type GithubUsersTable = {
  [K in keyof typeof githubUsersSchema]: (typeof githubUsersSchema)[K];
};

// Get columns at runtime
export const GithubUsersTableColumns = Object.keys(
  githubUsersSchema,
) as (keyof GithubUsersTable)[];

export async function createGithubUsersTable(db: Kysely<any>): Promise<void> {
  await db.schema
    .createTable('github_users')
    .addColumn('username', 'varchar', (col) => col.primaryKey())
    .addColumn('preferred_username', 'varchar')
    .addColumn('avatar_url', 'varchar')
    .addColumn('created_at', 'datetime', defaultNow(true))
    .addColumn('updated_at', 'datetime', defaultNow())
    .ifNotExists()
    .execute();
}
