import { sql, ExpressionBuilder, SelectQueryBuilder, SelectType } from 'kysely';
import { Database } from './db';

export function aliasedTableColumns<
  DT extends keyof Database,
  CT extends keyof Database[DT] & string,
>(table: DT, columns: ReadonlyArray<CT>) {
  return columns.map((c) => aliasedTableColumn(table, c));
}

export function aliasedTableColumn<
  DT extends keyof Database,
  CT extends keyof Database[DT] & string,
>(table: DT, column: CT) {
  return sql<
    SelectType<Database[DT][CT]>
  >` ${sql.ref(table)}.${sql.ref(column)}`.as(column);
}

/**
 * Crates an array of disambiguated column selections for a given table. This
 * is useful when we're joining related tables on a 1-to-1 basis, and want to
 * avoid column name collisions.
 *
 * For aggregating 1-to-many relationships into JSON arrays, see `getXAsJson`
 * helpers in the various loaders, as well as
 *
 * To be used in conjunction with `assembleDisambiguatedResult` to reassemble
 *
 * Example usage:
 * ```ts
 *     if (includeBranches) {
 *       query = query.select(
 *         disambiguateTableColumns('branches', BranchesTableColumns, 'branch'),
 *       );
 *     }
 * ```
 */
export function disambiguateTableColumns<
  DT extends keyof Database,
  CT extends keyof Database[DT] & string,
>(table: DT, columns: CT[], prefix: string) {
  return columns.map((c) => disambiguateTableColumn(table, c, prefix));
}

export function disambiguateTableColumn<
  DT extends keyof Database,
  CT extends keyof Database[DT] & string,
>(table: DT, column: CT, prefix: string) {
  return sql` ${sql.ref(table)}.${sql.ref(column)}`.as(
    `_cy_${prefix}:${column}`,
  );
}

/**
 * Takes a result set from Kysely and reassembles a structured output object
 * using the prefixes defined in `disambiguateTableColumns`.
 *
 * Example usage:
 * ```ts
 *    const dbCommitBranches = results.map(
 *       (result) =>
 *         assembleDisambiguatedResult(result, 'branch') as DbCommitBranch,
 *     );
 * ```
 */

export function assembleDisambiguatedResult(
  columns: Record<string, any>,
  ...prefixes: string[]
) {
  const result = {};

  for (const [key, value] of Object.entries(columns)) {
    const regexMatch = key.match(/^_cy_(.+?):(.+)$/);
    if (regexMatch) {
      const [, prefix, column] = regexMatch;
      if (prefixes.includes(prefix)) {
        if (!result[prefix]) {
          result[prefix] = {};
        }
        result[prefix][column] = value;
        continue;
      }
      console.warn(`CodeYam Warning: Unrecognized prefix in key '${key}'`);
      continue;
    }
    // If no prefix match, just add the key-value pair as is
    result[key] = value;
  }

  return result;
}

// There is probably a way to make these types more precise, with the kind
// of complex inference transformation Kysely does under the hood – but
// this is good enough for now. It means the system is very forgiving of
// what kind of 'eb' you can pass in, and the constraint method too is able
// to do things like reference tables that haven't been selected from.
//
// But it works, and I have a headache.

export type JsonSelectBuilder = ExpressionBuilder<Database, keyof Database>;

export type JsonSelectConstraint = <O>(
  eb: SelectQueryBuilder<Database, keyof Database, O>,
) => SelectQueryBuilder<Database, keyof Database, O>;
