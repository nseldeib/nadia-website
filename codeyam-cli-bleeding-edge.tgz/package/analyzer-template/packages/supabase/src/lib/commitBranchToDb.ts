import { CommitBranch } from '~codeyam/types';
import { type Insertable } from 'kysely';
import { randomUUID } from 'crypto';
import { CommitBranchesTable } from './kysely/tables/commitBranchesTable';

export default function commitBranchToDb(
  commitBranch: CommitBranch,
): Insertable<CommitBranchesTable> {
  const { id, commitId, branchId, ...remaining } = commitBranch;

  delete remaining.commit;
  delete remaining.branch;

  return {
    ...remaining,
    id: id ?? randomUUID(),
    commit_id: commitId,
    branch_id: branchId,
  };
}
