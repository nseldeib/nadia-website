import { BackgroundJob } from '~codeyam/types';
import { type Insertable } from 'kysely';
import { BackgroundJobsTable } from './kysely/tables/backgroundJobsTable';

export default function backgroundJobToDb(
  backgroundJob: Omit<BackgroundJob, 'createdAt'> & { createdAt?: string },
): Insertable<BackgroundJobsTable> {
  const { projectId, commitId, updatedAt, createdAt, progress, ...remaining } =
    backgroundJob;

  //  delete remaining.createdAt;

  return {
    ...remaining,
    progress: progress ? JSON.stringify(progress) : null,
    project_id: projectId.toString(),
    commit_id: commitId.toString(),
    updated_at: updatedAt,
    created_at: createdAt ?? new Date().toISOString(),
  };
}
