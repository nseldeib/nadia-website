import { Commit } from '~codeyam/types';
import dbToAnalysis from './dbToAnalysis';
import { getDatabase, getJsonHelper } from './kysely/db';
import { awsLog } from '~codeyam/utils';
import { aliasedTableColumns } from './kysely/aggregationHelpers';
import { DbAnalysis } from './kysely/tableRelations';
import { AnalysisBranchesTableColumns } from './kysely/tables/analysisBranchesTable';
import { BranchesTableColumns } from './kysely/tables/branchesTable';
import { EntitiesTableColumns } from './kysely/tables/entitiesTable';
import { ScenariosTableColumns } from './kysely/tables/scenariosTable';

export interface loadMostRecentPreviousAnalysisArgs {
  projectId: string;
  branchId: string;
  filePath: string;
  entityName: string;
  dependencyAnalyzedTreeSha: string;
  beforeCommit: Commit;
}

export default async function loadMostRecentPreviousAnalysis({
  projectId,
  branchId,
  filePath,
  entityName,
  dependencyAnalyzedTreeSha,
  beforeCommit,
}: loadMostRecentPreviousAnalysisArgs) {
  const db = getDatabase();
  const { jsonObjectFrom, jsonArrayFrom } = getJsonHelper();

  try {
    // Create CTE with all the joins and filtering
    const filteredAnalysisCTE = db
      .selectFrom('analyses')
      .innerJoin(
        'analysis_branches',
        'analyses.id',
        'analysis_branches.analysis_id',
      )
      .innerJoin('files', 'analyses.file_id', 'files.id')
      .selectAll('analyses') // Expose all analysis columns to the outer query
      .where('analyses.project_id', '=', projectId)
      .where('analysis_branches.branch_id', '=', branchId)
      .where('files.path', '=', filePath)
      .where('analyses.entity_name', '=', entityName)
      .where(
        'analyses.dependency_analyzed_tree_sha',
        '!=',
        dependencyAnalyzedTreeSha,
      )
      .where('analyses.committed_at', '<', beforeCommit.committedAt)
      .orderBy('analyses.committed_at', 'desc')
      .limit(1);

    // Main query with JSON aggregations referencing the CTE
    const analysisQuery = db
      .with('filtered_analysis', () => filteredAnalysisCTE)
      .selectFrom('filtered_analysis')
      .selectAll('filtered_analysis')
      .select((eb) => [
        jsonObjectFrom(
          eb
            .selectFrom('entities')
            .select(aliasedTableColumns('entities', EntitiesTableColumns))
            // .select(aliasedTableColumn('entities', 'metadata'))
            .whereRef('entities.sha', '=', 'filtered_analysis.entity_sha')
            .limit(1),
        ).as('entity'),

        jsonArrayFrom(
          eb
            .selectFrom('analysis_branches')
            .select(
              aliasedTableColumns(
                'analysis_branches',
                AnalysisBranchesTableColumns,
              ),
            )
            .select((seb) =>
              jsonObjectFrom(
                seb
                  .selectFrom('branches')
                  .select(aliasedTableColumns('branches', BranchesTableColumns))
                  .whereRef('branches.id', '=', 'analysis_branches.branch_id'),
              ).as('branch'),
            )
            .whereRef(
              'analysis_branches.analysis_id',
              '=',
              'filtered_analysis.id',
            ),
        ).as('analysis_branches'),

        jsonArrayFrom(
          eb
            .selectFrom('scenarios')
            .select(aliasedTableColumns('scenarios', ScenariosTableColumns))
            .whereRef('scenarios.analysis_id', '=', 'filtered_analysis.id'),
        ).as('scenarios'),
      ]);

    console.log(
      `CodeYam DEBUG: compiled SQL for loadMostRecentPreviousAnalysis`,
      analysisQuery.compile().sql,
    );

    const analysis = await analysisQuery.executeTakeFirst();

    if (!analysis) {
      awsLog('loadMostRecentPreviousAnalysis: no analysis found', null, {
        projectId,
        branchId,
        filePath,
        entityName,
        dependencyAnalyzedTreeSha,
        beforeCommitSha: beforeCommit.sha,
      });
      return null;
    }

    console.log(
      `CodeYam DEBUG: Analysis ${analysis.id} loaded from database`,
      JSON.stringify(analysis, null, 2),
    );

    // TODO: this cast shouldn't be needed, but there's some quirky thing with
    // the typeof of e.g. entity.metadata being a union with 'string'
    return dbToAnalysis(analysis as DbAnalysis);
  } catch (error) {
    awsLog('loadMostRecentPreviousAnalysis: database error', error, {
      projectId,
      branchId,
      filePath,
      entityName,
      dependencyAnalyzedTreeSha,
      beforeCommitSha: beforeCommit.sha,
    });
    return null;
  }
}
