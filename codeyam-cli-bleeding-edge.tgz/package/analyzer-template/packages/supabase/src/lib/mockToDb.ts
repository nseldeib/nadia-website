import { Mock } from '~codeyam/types';
import { type Insertable } from 'kysely';
import { MocksTable } from './kysely/tables/mocksTable';
import { randomUUID } from 'crypto';

export default function mockToDb(mock: Mock): Insertable<MocksTable> {
  if (!mock.projectId) {
    return {
      id: mock.id,
    };
  }

  const {
    id,
    projectId,
    fileId,
    filePath,
    entitySha,
    entityName,
    mockingRequired,
    nodeModule,
    metadata,
    createdAt,
    ...remaining
  } = mock;

  if ('importName' in remaining) delete remaining.importName;
  if ('importAlias' in remaining) delete remaining.importAlias;
  if ('importIsDefault' in remaining) delete remaining.importIsDefault;
  if ('resolvedFilePath' in remaining) delete remaining.resolvedFilePath;
  if ('resolvedEntityName' in remaining) delete remaining.resolvedEntityName;
  if ('resolvedIsDefault' in remaining) delete remaining.resolvedIsDefault;

  let reason;
  if ('reason' in remaining) {
    reason = remaining.reason;
    delete remaining.reason;
  }

  if ('createdAt' in remaining) delete remaining.createdAt;

  if (metadata) {
    metadata.reason ??= reason;
  }

  return {
    ...remaining,
    id: id ?? randomUUID(),
    project_id: projectId,
    file_id: fileId,
    file_path: filePath,
    entity_sha: entitySha,
    entity_name: entityName,
    mocking_required: mockingRequired,
    node_module: nodeModule,
    metadata: metadata ? JSON.stringify(metadata) : undefined,
  };
}
