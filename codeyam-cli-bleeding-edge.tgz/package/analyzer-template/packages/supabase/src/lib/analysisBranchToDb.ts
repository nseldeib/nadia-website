import { AnalysisBranch } from '~codeyam/types';
import { DbAnalysisBranch } from './kysely/tableRelations';
import { randomUUID } from 'crypto';
import { AnalysisBranchesTable } from './kysely/tables/analysisBranchesTable';
import { type Insertable } from 'kysely';

export default function analysisBranchToDb(
  analysisBranch: AnalysisBranch,
): Insertable<AnalysisBranchesTable> {
  const { id, analysisId, entitySha, branchId, ...remaining } = analysisBranch;

  delete remaining.analysis;
  delete remaining.entity;
  delete remaining.branch;

  if ('createdAt' in remaining) {
    (remaining as unknown as DbAnalysisBranch).created_at = remaining.createdAt;
    delete remaining.createdAt;
  }

  return {
    ...remaining,
    id: id ?? randomUUID(),
    analysis_id: analysisId,
    entity_sha: entitySha,
    branch_id: branchId,
  };
}
