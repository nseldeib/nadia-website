import { getDatabase } from './kysely/db';
import { awsLog } from '~codeyam/utils';

interface DeleteScenariosArgs {
  ids?: string[];
  analysisId?: string;
}

export default async function deleteScenarios({
  ids,
  analysisId,
}: DeleteScenariosArgs) {
  const db = getDatabase();

  try {
    let query = db.deleteFrom('scenarios');

    // Apply filters using fluent query composition
    if (ids) {
      if (ids.length === 0) return;
      query = query.where('id', 'in', ids);
    } else if (analysisId) {
      query = query.where('analysis_id', '=', analysisId);
    } else {
      // No valid criteria provided
      awsLog('CodeYam Error: No deletion criteria provided', null, {
        ids,
        analysisId,
      });
      throw new Error('No deletion criteria provided for scenarios');
    }

    await query.execute();
  } catch (error) {
    awsLog('CodeYam Error: Database error deleting scenarios', error, {
      ids,
      analysisId,
    });
    throw error;
  }
}
