// eslint-disable-next-line @typescript-eslint/no-unsafe-function-type
export type DeepUpdate<T> = T extends Function
  ? T
  : T extends Array<any>
    ? T
    : T extends object
      ? { [K in keyof T]?: DeepUpdate<T[K]> }
      : T;

/**
 * Deep merges two objects recursively.
 * Arrays are replaced, not merged.
 */
export function deepMerge<T extends Record<string, any>, U = DeepUpdate<T>>(
  target: T,
  source: U,
): T {
  const result = { ...target };

  for (const key in source) {
    const sourceValue = source[key];
    const targetValue = target[key];

    if (
      sourceValue !== undefined &&
      sourceValue !== null &&
      typeof sourceValue === 'object' &&
      !Array.isArray(sourceValue) &&
      targetValue !== undefined &&
      targetValue !== null &&
      typeof targetValue === 'object' &&
      !Array.isArray(targetValue)
    ) {
      // Both are objects (not arrays), merge recursively
      result[key] = deepMerge(targetValue, sourceValue);
    } else if (sourceValue !== undefined) {
      // Direct assignment for primitives, arrays, null, or undefined target
      result[key] = sourceValue as any;
    }
  }

  return result;
}
