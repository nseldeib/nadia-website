import { AnalysisBranch } from '~codeyam/types';
import dbToAnalysisBranch from './dbToAnalysisBranch';
import { DbAnalysisBranch } from './kysely/tableRelations';
import { getDatabase, getJsonHelper } from './kysely/db';
import {
  JsonSelectBuilder,
  JsonSelectConstraint,
} from './kysely/aggregationHelpers';
import { AnalysisBranchesTableColumns } from './kysely/tables/analysisBranchesTable';
import { BranchesTableColumns } from './kysely/tables/branchesTable';
import { awsLog } from '~codeyam/utils';
import { InferResult } from 'kysely';

interface LoadAnalysisBranchArgs {
  projectId: string;
  filePaths?: string[];
  entityName?: string;
  analysisIds?: string[];
  entitySha?: string;
  branchId?: string;
  active?: boolean;
  includeBranches?: boolean;
  perPage?: number;
  page?: number;
}

const MAX_FILEPATHS = 50;
const MAX_ANALYSIS_IDS = 50;
const PER_PAGE = 200;

export default async function loadAnalysisBranches({
  projectId,
  filePaths,
  entityName,
  analysisIds,
  entitySha,
  branchId,
  active,
  includeBranches,
  perPage = PER_PAGE,
  page,
}: LoadAnalysisBranchArgs): Promise<AnalysisBranch[] | null> {
  if (
    (filePaths && filePaths.length === 0) ||
    (analysisIds && analysisIds.length === 0)
  ) {
    return [];
  }

  if (filePaths && filePaths.length > MAX_FILEPATHS) {
    const allAnalysisBranches: AnalysisBranch[] = [];
    for (let i = 0; i < filePaths.length; i += MAX_FILEPATHS) {
      const chunk = filePaths.slice(i, i + MAX_FILEPATHS);
      const chunkAnalysisBranches = await loadAnalysisBranches({
        projectId,
        filePaths: chunk,
        entityName,
        analysisIds,
        entitySha,
        branchId,
        active,
        includeBranches,
        page,
      });

      if (chunkAnalysisBranches) {
        allAnalysisBranches.push(...chunkAnalysisBranches);
      }
    }
    return allAnalysisBranches;
  }

  if (analysisIds && analysisIds.length > MAX_ANALYSIS_IDS) {
    const allAnalysisBranches: AnalysisBranch[] = [];
    for (let i = 0; i < analysisIds.length; i += MAX_ANALYSIS_IDS) {
      const chunk = analysisIds.slice(i, i + MAX_ANALYSIS_IDS);
      const chunkAnalysisBranches = await loadAnalysisBranches({
        projectId,
        filePaths,
        entityName,
        analysisIds: chunk,
        entitySha,
        branchId,
        active,
        includeBranches,
        page,
      });

      if (chunkAnalysisBranches) {
        allAnalysisBranches.push(...chunkAnalysisBranches);
      }
    }
    return allAnalysisBranches;
  }

  const { jsonObjectFrom } = getJsonHelper();
  const db = getDatabase();

  // Create CTE for complex filtering with JOINs
  const filteredAnalysisBranchesCTE = db
    .selectFrom('analysis_branches')
    .selectAll('analysis_branches')
    .innerJoin('analyses', 'analyses.id', 'analysis_branches.analysis_id')
    .innerJoin('entities', 'entities.sha', 'analysis_branches.entity_sha')
    .$if(includeBranches, (qb) =>
      qb.innerJoin('branches', 'branches.id', 'analysis_branches.branch_id'),
    )
    .where('analyses.project_id', '=', projectId)
    .$if(!!filePaths, (qb) => qb.where('entities.file_path', 'in', filePaths!))
    .$if(!!entityName, (qb) => qb.where('entities.name', '=', entityName!))
    .$if(!!analysisIds, (qb) =>
      qb.where('analysis_branches.analysis_id', 'in', analysisIds!),
    )
    .$if(!!entitySha, (qb) =>
      qb.where('analysis_branches.entity_sha', '=', entitySha!),
    )
    .$if(!!branchId, (qb) =>
      qb.where('analysis_branches.branch_id', '=', branchId!),
    )
    .$if(active !== undefined, (qb) =>
      qb.where('analysis_branches.active', '=', active!),
    )
    .limit(perPage)
    .$if(page !== undefined && page > 0, (qb) => qb.offset(page * perPage));

  // Main query with JSON aggregations referencing the CTE
  const query = db
    .with('filtered_analysis_branches', () => filteredAnalysisBranchesCTE)
    .selectFrom('filtered_analysis_branches')
    .selectAll('filtered_analysis_branches')
    .select(
      (eb) =>
        // experiment with extra nice typing
        [
          jsonObjectFrom(
            eb
              .selectFrom('analyses')
              .select(['id', 'file_path', 'entity_name', 'committed_at'])
              .whereRef('id', '=', 'filtered_analysis_branches.analysis_id')
              .limit(1),
          ).as('analysis'),
          jsonObjectFrom(
            eb
              .selectFrom('entities')
              .select(['sha'])
              .whereRef('sha', '=', 'filtered_analysis_branches.entity_sha')
              .limit(1),
          ).as('entity'),
          ...(includeBranches
            ? [
                jsonObjectFrom(
                  eb
                    .selectFrom('branches')
                    .select(['id', 'name', 'metadata'])
                    .whereRef('id', '=', 'filtered_analysis_branches.branch_id')
                    .limit(1),
                ).as('branch'),
              ]
            : []),
        ] as const,
    );

  let data: InferResult<typeof query>;
  try {
    data = await query.execute();
  } catch (error) {
    awsLog('CodeYam Error: Error loading analysis branches', error, {
      filePaths,
      entityName,
      analysisIds,
      entitySha,
      branchId,
      active,
    });
    return null;
  }

  const analysisBranches = data.map((row) =>
    dbToAnalysisBranch(row as DbAnalysisBranch),
  );

  if (analysisBranches.length >= perPage) {
    const nextPage = await loadAnalysisBranches({
      projectId,
      filePaths,
      entityName,
      analysisIds,
      entitySha,
      branchId,
      active,
      includeBranches,
      perPage,
      page: (page || 0) + 1,
    });

    if (nextPage) {
      return [...analysisBranches, ...nextPage].filter(
        (ab, index, self) => self.findIndex((a) => a.id === ab.id) === index,
      );
    }
  }

  return analysisBranches.filter(
    (ab, index, self) => self.findIndex((a) => a.id === ab.id) === index,
  );
}

// Export for reuse in other loaders
export function getAnalysisBranchesWithBranches(
  eb: JsonSelectBuilder,
  constraint?: JsonSelectConstraint,
) {
  const { jsonArrayFrom, jsonObjectFrom } = getJsonHelper();

  let query = eb
    .selectFrom('analysis_branches')
    .select(AnalysisBranchesTableColumns)
    .select((seb) =>
      jsonObjectFrom(
        seb
          .selectFrom('branches')
          .select(BranchesTableColumns)
          .whereRef('id', '=', 'analysis_branches.branch_id'),
      ).as('branch'),
    );

  if (constraint) {
    query = constraint(query);
  }

  return jsonArrayFrom(query);
}
