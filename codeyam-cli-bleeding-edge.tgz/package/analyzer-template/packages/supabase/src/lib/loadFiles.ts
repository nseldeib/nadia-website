import { File } from '~codeyam/types';
import dbToFile from './dbToFile';
import { getDatabase, getJsonHelper } from './kysely/db';
import { Selectable } from 'kysely';
import { FilesTable, FilesTableColumns } from './kysely/tables/filesTable';
import { ExpressionBuilder } from 'kysely';
import { Database } from './kysely/db';
import { awsLog } from '~codeyam/utils';

const RANGE_LIMIT = 1000;

interface LoadFilesArgs {
  projectId: string;
  filePaths?: string[];
  fileIds?: string[];
  fileNames?: string[];
}

export default async function loadFiles({
  projectId,
  filePaths,
  fileIds,
  fileNames,
}: LoadFilesArgs): Promise<File[] | null> {
  if (filePaths && filePaths.length > 50) {
    const allFiles: File[] = [];
    for (let i = 0; i < filePaths.length; i += 50) {
      const chunk = filePaths.slice(i, i + 50);
      const chunkFiles = await loadFiles({
        projectId,
        filePaths: chunk,
        fileIds,
        fileNames,
      });

      if (chunkFiles) {
        allFiles.push(...chunkFiles);
      }
    }
    return allFiles;
  }

  const db = getDatabase();
  const files: Selectable<FilesTable>[] = [];
  let offset = 0;

  try {
    while (true) {
      let query = db
        .selectFrom('files')
        .selectAll()
        .where('project_id', '=', projectId)
        .limit(RANGE_LIMIT)
        .offset(offset);

      if (filePaths) {
        if (filePaths.length === 0) return [];
        query = query.where('path', 'in', filePaths);
      }

      if (fileIds) {
        if (fileIds.length === 0) return [];
        query = query.where('id', 'in', fileIds);
      }

      if (fileNames) {
        if (fileNames.length === 0) return [];
        query = query.where('name', 'in', fileNames);
      }

      const filesData = await query.execute();

      if (!filesData || filesData.length === 0) {
        break;
      }

      files.push(...filesData);

      if (filesData.length < RANGE_LIMIT) {
        break;
      } else {
        offset += RANGE_LIMIT;
      }
    }

    return files?.map(dbToFile);
  } catch (error) {
    console.log(
      'CodeYam Error: Error loading project files in loadFiles',
      error,
    );
    return null;
  }
}
