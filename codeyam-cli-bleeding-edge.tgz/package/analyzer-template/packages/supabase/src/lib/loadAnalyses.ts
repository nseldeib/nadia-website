import { Analysis } from '~codeyam/types';
import dbToAnalysis from './dbToAnalysis';
import { getDatabase, getJsonHelper } from './kysely/db';
import { DbAnalysis } from './kysely/tableRelations';
import { awsLog } from '~codeyam/utils';
import { aliasedTableColumns } from './kysely/aggregationHelpers';
import { EntitiesTableColumns } from './kysely/tables/entitiesTable';
import { ScenariosTableColumns } from './kysely/tables/scenariosTable';

export const BATCH_SIZE = 50;

function chunk<T>(array: T[], size: number): T[][] {
  return array.length <= size
    ? [array]
    : Array.from({ length: Math.ceil(array.length / size) }, (_, i) =>
        array.slice(i * size, i * size + size),
      );
}

function buildAnalysesQuery({
  projectId,
  ids,
  fileIds,
  entityName,
  entityShas,
  commitIds,
  branchCommitSha,
  limit,
}: LoadAnalysesArgs & {
  ids?: string[];
  fileIds?: string[];
  entityShas?: string[];
  commitIds?: string[];
}) {
  const db = getDatabase();
  const { jsonObjectFrom, jsonArrayFrom } = getJsonHelper();

  // Create CTE for filtering analyses
  let filteredAnalysisCTE = db.selectFrom('analyses').selectAll('analyses');

  // Apply filters
  if (projectId) {
    filteredAnalysisCTE = filteredAnalysisCTE.where(
      'project_id',
      '=',
      projectId,
    );
  }

  if (ids) {
    if (ids.length === 0) return null;
    filteredAnalysisCTE = filteredAnalysisCTE.where('id', 'in', ids);
  }

  if (fileIds) {
    if (fileIds.length === 0) return null;
    filteredAnalysisCTE = filteredAnalysisCTE.where('file_id', 'in', fileIds);
  }

  if (commitIds) {
    if (commitIds.length === 0) return null;
    filteredAnalysisCTE = filteredAnalysisCTE.where(
      'commit_id',
      'in',
      commitIds,
    );
  }

  if (entityName) {
    filteredAnalysisCTE = filteredAnalysisCTE.where(
      'entity_name',
      '=',
      entityName,
    );
  }

  if (entityShas) {
    filteredAnalysisCTE = filteredAnalysisCTE.where(
      'entity_sha',
      'in',
      entityShas,
    );
  }

  if (branchCommitSha) {
    filteredAnalysisCTE = filteredAnalysisCTE.where(
      'branch_commit_sha',
      '=',
      branchCommitSha,
    );
  }

  if (limit) {
    filteredAnalysisCTE = filteredAnalysisCTE.limit(limit);
  }

  // Main query with JSON aggregations referencing the CTE
  return db
    .with('filtered_analyses', () => filteredAnalysisCTE)
    .selectFrom('filtered_analyses')
    .selectAll('filtered_analyses')
    .select((eb) => [
      jsonObjectFrom(
        eb
          .selectFrom('entities')
          .select(aliasedTableColumns('entities', EntitiesTableColumns))
          .whereRef('entities.sha', '=', 'filtered_analyses.entity_sha')
          .limit(1),
      ).as('entity'),

      jsonArrayFrom(
        eb
          .selectFrom('scenarios')
          .select(aliasedTableColumns('scenarios', ScenariosTableColumns))
          .whereRef('scenarios.analysis_id', '=', 'filtered_analyses.id'),
      ).as('scenarios'),

      jsonArrayFrom(
        eb
          .selectFrom('analysis_branches')
          .select(['id', 'branch_id']) // Only select id and branch_id as per original Supabase query
          .whereRef(
            'analysis_branches.analysis_id',
            '=',
            'filtered_analyses.id',
          ),
      ).as('analysis_branches'),
    ]);
}

export interface LoadAnalysesArgs {
  projectId?: string;
  ids?: string[];
  fileIds?: string[];
  commitIds?: string[];
  entityName?: string;
  entityShas?: string[];
  branchCommitSha?: string;
  limit?: number;
}

export default async function loadAnalyses(
  params: LoadAnalysesArgs,
): Promise<Analysis[] | null> {
  const { ids, fileIds, entityShas, commitIds } = params;

  try {
    const paramMap = {
      id: { arr: ids, key: 'ids' },
      file_id: { arr: fileIds, key: 'fileIds' },
      entity_sha: { arr: entityShas, key: 'entityShas' },
      commit_id: { arr: commitIds, key: 'commitIds' },
    };

    // Find first array parameter to batch on
    const batchParams = Object.entries(paramMap).find(
      ([_, { arr }]) => arr?.length > 0,
    );

    let analyses: DbAnalysis[] = [];

    if (!batchParams) {
      // No array parameters - just run a simple query
      const query = buildAnalysesQuery(params);
      const results = await query.execute();

      if (!results || results.length === 0) {
        awsLog('CodeYam: No analyses found', null, params);
        return null;
      }

      analyses = results as DbAnalysis[];
    } else {
      const [field, { arr, key }] = batchParams;
      const batches = chunk(arr, BATCH_SIZE);
      const results: DbAnalysis[] = [];

      for (let batch_ix = 0; batch_ix < batches.length; batch_ix++) {
        const batch = batches[batch_ix];
        const query = buildAnalysesQuery({
          ...params,
          [key]: batch,
        });

        if (batches.length > 1) {
          awsLog(
            `CodeYam: batched loadAnalyses() for '${field}': ${batch_ix + 1}/${batches.length} sized ${batch.length}`,
            null,
            {
              field,
              batchIndex: batch_ix + 1,
              totalBatches: batches.length,
              batchSize: batch.length,
            },
          );
        }

        const batchResults = await query.execute();

        if (batchResults) {
          results.push(...(batchResults as DbAnalysis[]));
        }
      }

      analyses = results;
    }

    if (analyses.length === 0) {
      return null;
    }

    return analyses.map(dbToAnalysis);
  } catch (error) {
    awsLog('CodeYam Error: Database error in loadAnalyses', error, params);
    return null;
  }
}
