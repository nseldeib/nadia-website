import { getDatabase } from './kysely/db';
import { awsLog } from '~codeyam/utils';

export default async function deleteBranch({
  projectId,
  id,
}: {
  projectId: string;
  id: string;
}) {
  const db = getDatabase();

  try {
    const result = await db
      .deleteFrom('branches')
      .where('project_id', '=', projectId)
      .where('id', '=', id)
      .executeTakeFirst();

    return Number(result.numDeletedRows) > 0;
  } catch (error) {
    awsLog('CodeYam Error: Database error deleting branch', error, {
      projectId,
      id,
    });
    return false;
  }
}
