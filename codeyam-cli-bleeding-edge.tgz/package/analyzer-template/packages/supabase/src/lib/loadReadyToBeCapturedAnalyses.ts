import { Analysis } from '~codeyam/types';
import dbToAnalysis from './dbToAnalysis';
import { getSupabase } from './supabase';
import { DbAnalysis } from './kysely/tableRelations';

/**
 * This needs to be rewritten entirely for Kysely since we don't have
 * database functions in SQLite.
 */
export interface LoadReadyToBeCapturedAnalysesArgs {
  projectId?: string;
  ids?: string[];
  branchCommitSha?: string;
}

export default async function loadReadyToBeCapturedAnalyses(
  params: LoadReadyToBeCapturedAnalysesArgs,
): Promise<Analysis[]> {
  let analyses: DbAnalysis[] = [];
  const { projectId, branchCommitSha, ids } = params;

  const query = getSupabase()
    .rpc('get_ready_to_be_captured_analyses', {
      projectid: projectId,
      branchcommitsha: branchCommitSha,
      analysisids: ids,
    })
    .select('*, entity:entities!inner ( * ), scenarios!inner ( * )');

  const { data, error } = await query;

  if (error || !data) {
    console.log(
      'CodeYam Error: Analyses not found for readyToBeCaptured',
      {
        projectId,
        branchCommitSha,
      },
      error,
    );
    return null;
  }

  analyses = data;

  return analyses.map(dbToAnalysis);
}
