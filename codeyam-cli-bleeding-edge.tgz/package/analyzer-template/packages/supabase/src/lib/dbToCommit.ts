import { Commit } from '~codeyam/types';
import dbToBranch from './dbToBranch';
import dbToAnalysis from './dbToAnalysis';
import dbToEntity from './dbToEntity';
import dbToCommitBranch from './dbToCommitBranch';
import dbToBackgroundJob from './dbToBackgroundJob';
import { DbCommit } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToCommit(dbCommit: DbCommit): Commit {
  const {
    project_id,
    branch_id,
    branch: dbBranch,
    background_jobs: backgroundJobs,
    merged_branch_id,
    mergedBranch: dbMergedBranch,
    ai_message,
    html_url,
    author,
    analyses: dbAnalyses,
    entities: dbEntities,
    commit_branches: dbCommitBranches,
    committed_at,
    analyzed_at,
    ...remaining
  } = dbCommit;

  const branch = dbBranch ? dbToBranch(dbBranch) : undefined;
  const mergedBranch = dbMergedBranch ? dbToBranch(dbMergedBranch) : undefined;

  const backgroundJob =
    backgroundJobs?.length > 0
      ? dbToBackgroundJob(backgroundJobs[backgroundJobs.length - 1])
      : undefined;

  const analyses = (dbAnalyses ?? []).map(dbToAnalysis);
  const entities = (dbEntities ?? []).map(dbToEntity);
  const commitBranches =
    dbCommitBranches?.length > 0
      ? dbCommitBranches.map(dbToCommitBranch)
      : undefined;

  if (author) {
    author.username = author.preferredUsername ?? author.username;
  }

  return nullsToUndefines({
    ...remaining,
    projectId: project_id,
    branchId: branch_id,
    branch,
    backgroundJob,
    mergedBranchId: merged_branch_id,
    mergedBranch,
    aiMessage: ai_message,
    htmlUrl: html_url,
    author,
    analyses,
    entities,
    commitBranches,
    committedAt: committed_at,
    analyzedAt: analyzed_at,
  });
}
