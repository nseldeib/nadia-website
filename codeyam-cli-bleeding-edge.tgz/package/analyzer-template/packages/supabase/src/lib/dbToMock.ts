import { Mock } from '~codeyam/types';
import { DbMock } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToMock(dbMock: DbMock): Mock {
  const {
    project_id,
    file_id,
    file_path,
    entity_sha,
    entity_name,
    import_name,
    node_module,
    mocking_required,
    created_at,
    ...remaining
  } = dbMock;

  return nullsToUndefines({
    ...remaining,
    projectId: project_id,
    fileId: file_id,
    filePath: file_path,
    entitySha: entity_sha,
    entityName: entity_name,
    importName: import_name,
    nodeModule: !!node_module,
    mockingRequired: !!mocking_required,
    createdAt: created_at,
  });
}
