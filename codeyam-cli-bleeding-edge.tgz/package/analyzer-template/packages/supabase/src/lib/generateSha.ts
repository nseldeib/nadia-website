import crypto from 'crypto';

export default function generateSha(...includedValues: string[]) {
  try {
    const hash = crypto.createHash('sha256');
    for (const value of includedValues) {
      hash.update(value);
    }
    return hash.digest('hex');
  } catch (e) {
    console.log('CodeYam Error: Error generating sha', includedValues);
    throw e;
  }
}
