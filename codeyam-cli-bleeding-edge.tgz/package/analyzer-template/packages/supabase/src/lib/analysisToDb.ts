import { Analysis } from '~codeyam/types';
import { type Insertable } from 'kysely';
import { AnalysesTable } from './kysely/tables/analysesTable';
import { randomUUID } from 'crypto';

export default function analysisToDb(
  analysis: Analysis,
): Insertable<AnalysesTable> {
  const {
    id,
    projectId,
    commitId,
    fileId,
    filePath,
    entitySha,
    entityType,
    entityName,
    previousAnalysisId,
    entity,
    dependencyAnalyzedTreeSha,
    analyzedTreeSha,
    branchCommitSha,
    committedAt,
    completedAt,
    createdAt,
    updatedAt,
    metadata,
    status,
    commit,
    file,
    project,
    scenarios,
    analysisBranches,
    branches,
    ...remaining
  } = analysis;

  return {
    ...remaining,
    id: id ?? randomUUID(),
    metadata: metadata ? JSON.stringify(metadata) : undefined,
    status: status ? JSON.stringify(status) : undefined,
    project_id: projectId,
    commit_id: commitId,
    file_id: fileId,
    file_path: filePath,
    entity_sha: entitySha,
    entity_type: entityType,
    entity_name: entityName,
    previous_analysis_id: previousAnalysisId,
    dependency_analyzed_tree_sha: dependencyAnalyzedTreeSha,
    analyzed_tree_sha: analyzedTreeSha,
    branch_commit_sha: branchCommitSha,
    committed_at: committedAt,
    completed_at: completedAt,
    created_at: createdAt,
    updated_at: updatedAt,
  };
}
