import { File } from '~codeyam/types';
import { DbFile } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToFile(dbFile: DbFile): File {
  return nullsToUndefines({
    id: dbFile.id,
    projectId: dbFile.project_id,
    name: dbFile.name,
    path: dbFile.path,
    deleted: !!dbFile.deleted,
    metadata: dbFile.metadata ?? undefined,
    createdAt: dbFile.created_at,
    updatedAt: dbFile.updated_at ?? undefined,
  });
}
