import { AnalysisBranch } from '~codeyam/types';
import { DbAnalysisBranch } from './kysely/tableRelations';
import dbToAnalysis from './dbToAnalysis';
import dbToEntity from './dbToEntity';
import dbToBranch from './dbToBranch';
import nullsToUndefines from './nullsToUndefines';

export default function dbToAnalysisBranch(
  dbAnalysisBranch: DbAnalysisBranch,
): AnalysisBranch {
  return nullsToUndefines({
    id: dbAnalysisBranch.id,
    analysisId: dbAnalysisBranch.analysis_id,
    entitySha: dbAnalysisBranch.entity_sha,
    branchId: dbAnalysisBranch.branch_id,
    active: !!dbAnalysisBranch.active,
    analysis: dbAnalysisBranch.analysis
      ? dbToAnalysis(dbAnalysisBranch.analysis)
      : undefined,
    entity: dbAnalysisBranch.entity
      ? dbToEntity(dbAnalysisBranch.entity)
      : undefined,
    branch: dbAnalysisBranch.branch
      ? dbToBranch(dbAnalysisBranch.branch)
      : undefined,
    createdAt: dbAnalysisBranch.created_at,
  });
}
