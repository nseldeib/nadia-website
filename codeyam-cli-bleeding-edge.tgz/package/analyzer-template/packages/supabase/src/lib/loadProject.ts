import { Project } from '~codeyam/types';
import { getDatabase } from './kysely/db';
import dbToProject from './dbToProject';
import loadFiles from './loadFiles';
import loadBranches from './loadBranches';

export default async function loadProject({
  id,
  slug,
  withBranches,
  withFiles,
  silent,
}: {
  id?: string;
  slug?: string;
  withBranches?: boolean;
  withFiles?: boolean;
  silent?: boolean;
}): Promise<Project | null> {
  try {
    const db = getDatabase();

    // Load the main project
    let query = db.selectFrom('projects').selectAll();

    if (id) {
      query = query.where('id', '=', id);
    } else if (slug) {
      query = query.where('slug', '=', slug);
    } else {
      throw new Error('Either id or slug must be provided');
    }

    const project = await query.executeTakeFirst();

    if (!project) {
      if (!silent) {
        console.log('CodeYam Error: Error loading project', {
          id,
          slug,
          withBranches,
          withFiles,
        });
      }
      return null;
    }

    // Convert to business logic object early
    const result = dbToProject(project);

    // Load relations separately if requested
    if (withFiles) {
      result.files = await loadFiles({ projectId: result.id });
    }

    if (withBranches) {
      result.branches = await loadBranches({
        projectId: result.id,
        includeInactive: false,
      });
    }

    return result;
  } catch (e) {
    if (!silent) {
      console.log('CodeYam Error: Error loading project', e);
    }
    return null;
  }
}
