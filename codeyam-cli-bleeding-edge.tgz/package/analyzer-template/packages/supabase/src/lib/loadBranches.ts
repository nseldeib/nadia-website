import dbToBranch from './dbToBranch';
import { getDatabase } from './kysely/db';
import { awsLog } from '~codeyam/utils';

interface LoadBranchesProps {
  projectId: string;
  ids?: string[];
  names?: string[];
  includeInactive?: boolean;
}

export default async function loadBranches({
  projectId,
  ids,
  names,
  includeInactive,
}: LoadBranchesProps) {
  const db = getDatabase();

  try {
    let query = db
      .selectFrom('branches')
      .selectAll('branches')
      .where('project_id', '=', projectId);

    if (ids) {
      if (ids.length === 0) return [];
      query = query.where('id', 'in', ids);
    }

    if (names) {
      if (names.length === 0) return [];
      query = query.where('name', 'in', names);
    }

    if (!includeInactive) {
      query = query.where('active_at', 'is not', null);
    }

    const branches = await query.execute();

    return branches.map(dbToBranch);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading branches', error, {
      projectId,
      ids,
      names,
      includeInactive,
    });
    return [];
  }
}
