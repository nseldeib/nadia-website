import dbToFile from './dbToFile';
import { getDatabase, getJsonHelper } from './kysely/db';
import { FilesTableColumns } from './kysely/tables/filesTable';
import {
  JsonSelectBuilder,
  JsonSelectConstraint,
} from './kysely/aggregationHelpers';

export default async function loadFile({
  projectId,
  id,
  path,
}: {
  projectId?: string;
  id?: string;
  path?: string;
}) {
  const db = getDatabase();

  let query = db.selectFrom('files').selectAll();

  if (projectId) {
    query = query.where('project_id', '=', projectId);
  }

  if (id) {
    query = query.where('id', '=', id);
  }

  if (path) {
    query = query.where('path', '=', path);
  }

  try {
    const file = await query.executeTakeFirst();

    if (!file) {
      console.log('Error loading file', { projectId, id, path }, 'Not found');
      return null;
    }

    return dbToFile(file);
  } catch (error) {
    console.log('Error loading file', { projectId, id, path }, error);
    return null;
  }
}
