import { getDatabase, getJsonHelper } from './kysely/db';
import dbToCommit from './dbToCommit';
import {
  DbAnalysis,
  DbBranch,
  DbCommit,
  DbEntity,
} from './kysely/tableRelations';
import { awsLog } from '~codeyam/utils';
import { Commit } from '~codeyam/types';
import { ScenariosTableColumns } from './kysely/tables/scenariosTable';

interface LoadCommitsArgs {
  projectId?: string;
  branchId?: string;
  fileId?: string; // TODO: This parameter is not used in the original, consider removing
  ids?: string[];
  shas?: string[];
  limit?: number;
}

async function loadBranchesForCommits(
  commitIds: string[],
): Promise<Map<string, DbBranch>> {
  if (commitIds.length === 0) return new Map();

  const db = getDatabase();

  try {
    // Get all branch IDs from commits first
    const commitBranches = await db
      .selectFrom('commits')
      .select(['id', 'branch_id', 'merged_branch_id'])
      .where('id', 'in', commitIds)
      .execute();

    const branchIds = new Set<string>();
    commitBranches.forEach((cb) => {
      if (cb.branch_id) branchIds.add(cb.branch_id);
      if (cb.merged_branch_id) branchIds.add(cb.merged_branch_id);
    });

    if (branchIds.size === 0) return new Map();

    const branches = await db
      .selectFrom('branches')
      .selectAll()
      .where('id', 'in', Array.from(branchIds))
      .execute();

    return new Map(branches.map((branch) => [branch.id, branch]));
  } catch (error) {
    awsLog('CodeYam Error: Loading branches for commits', error, { commitIds });
    return new Map();
  }
}

async function loadAnalysesForCommits(
  commitIds: string[],
): Promise<Map<string, DbAnalysis[]>> {
  if (commitIds.length === 0) return new Map();

  const db = getDatabase();
  const { jsonObjectFrom, jsonArrayFrom } = getJsonHelper();

  try {
    const analyses = await db
      .selectFrom('analyses')
      .selectAll('analyses')
      .select((eb) => [
        jsonObjectFrom(
          eb
            .selectFrom('files')
            .select(['id', 'name', 'path'])
            .whereRef('files.id', '=', 'analyses.file_id'),
        ).as('file'),
        jsonArrayFrom(
          eb
            .selectFrom('scenarios')
            .select(ScenariosTableColumns)
            .whereRef('scenarios.analysis_id', '=', 'analyses.id'),
        ).as('scenarios'),
      ])
      .where('commit_id', 'in', commitIds)
      .execute();

    // Group analyses by commit_id
    const result = new Map<string, DbAnalysis[]>();
    analyses.forEach((analysis) => {
      const commitAnalyses = result.get(analysis.commit_id) || [];
      commitAnalyses.push(analysis as DbAnalysis);
      result.set(analysis.commit_id, commitAnalyses);
    });

    return result;
  } catch (error) {
    awsLog('CodeYam Error: Loading analyses for commits', error, { commitIds });
    return new Map();
  }
}

async function loadEntitiesForCommits(
  commitIds: string[],
): Promise<Map<string, DbEntity[]>> {
  if (commitIds.length === 0) return new Map();

  const db = getDatabase();

  try {
    const entities = await db
      .selectFrom('entities')
      .selectAll()
      .where('commit_id', 'in', commitIds)
      .execute();

    // Group entities by commit_id
    const result = new Map<string, DbEntity[]>();
    entities.forEach((entity) => {
      const commitEntities = result.get(entity.commit_id!) || [];
      commitEntities.push(entity);
      result.set(entity.commit_id!, commitEntities);
    });

    return result;
  } catch (error) {
    awsLog('CodeYam Error: Loading entities for commits', error, { commitIds });
    return new Map();
  }
}

export default async function loadCommits({
  projectId,
  branchId,
  ids,
  shas,
  limit = 10,
}: LoadCommitsArgs): Promise<Commit[]> {
  if (!projectId && !ids) {
    throw new Error('Must provide projectId or ids');
  }

  const db = getDatabase();
  const { jsonObjectFrom } = getJsonHelper();

  try {
    let query = db
      .selectFrom('commits')
      .selectAll('commits')
      .select((eb) => [
        jsonObjectFrom(
          eb
            .selectFrom('github_users')
            .select([
              'username',
              'preferred_username as preferredUsername',
              'avatar_url as avatarUrl',
            ])
            .where(
              'github_users.username',
              '=',
              eb.ref('commits.author_github_username'),
            ),
        ).as('author'),
      ]);

    if (projectId) {
      query = query.where('project_id', '=', projectId);
    }

    if (ids) {
      if (ids.length === 0) return [];
      query = query.where('id', 'in', ids);
    }

    if (shas) {
      if (shas.length === 0) return [];
      query = query.where('sha', 'in', shas);
    }

    if (branchId) {
      query = query.where('branch_id', '=', branchId);
    }

    const commits = await query
      .orderBy('committed_at', 'desc')
      .limit(limit)
      .execute();

    if (!commits || commits.length === 0) {
      return [];
    }

    const commitIds = commits.map((c) => c.id);

    // Load all relations in parallel
    const [branchesMap, analysesMap, entitiesMap] = await Promise.all([
      loadBranchesForCommits(commitIds),
      loadAnalysesForCommits(commitIds),
      loadEntitiesForCommits(commitIds),
    ]);

    // Construct full DbCommit objects
    const dbCommits: DbCommit[] = commits.map((commit) => {
      const branch = commit.branch_id
        ? branchesMap.get(commit.branch_id)
        : undefined;
      const mergedBranch = commit.merged_branch_id
        ? branchesMap.get(commit.merged_branch_id)
        : undefined;
      const analyses = analysesMap.get(commit.id) || [];
      const entities = entitiesMap.get(commit.id) || [];

      return {
        ...commit,
        branch,
        mergedBranch,
        analyses,
        entities,
      };
    });

    return dbCommits.map(dbToCommit);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading commits', error, {
      projectId,
      branchId,
      ids,
      shas,
      limit,
    });
    return [];
  }
}
