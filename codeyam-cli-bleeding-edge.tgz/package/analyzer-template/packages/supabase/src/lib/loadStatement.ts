import { getDatabase } from './kysely/db';
import { DbStatement } from '~codeyam/supabase';

export default async function loadStatement(
  sha: string,
): Promise<Pick<DbStatement, 'sha' | 'results'> | null> {
  try {
    const result = await getDatabase()
      .selectFrom('statements')
      .select(['sha', 'results'])
      .where('sha', '=', sha)
      .executeTakeFirst();
    // for unknown reasons, SQLite parses the JSON in 'results' even though
    // the field is defined as text. We need to stringify it back.
    if (result && result.results && typeof result.results !== 'string') {
      result.results = JSON.stringify(result.results);
    }
    return result ?? null;
  } catch (error) {
    console.log('Error loading statement', error);
    return null;
  }
}
