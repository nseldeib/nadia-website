import { ScenarioComment } from '~codeyam/types';
import { DbScenarioComment } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToScenarioComment(
  dbScenarioComment: DbScenarioComment,
): ScenarioComment {
  const {
    id,
    project_id,
    user_id,
    scenario_id,
    text,
    created_at,
    updated_at,
    user: dbUser,
  } = dbScenarioComment;

  const user = dbUser
    ? {
        username: dbUser.github_username,
        avatarUrl: dbUser.github_user.avatar_url,
      }
    : undefined;

  return nullsToUndefines({
    id,
    projectId: project_id,
    userId: user_id,
    scenarioId: scenario_id,
    text,
    createdAt: created_at,
    updatedAt: updated_at,
    user,
  });
}
