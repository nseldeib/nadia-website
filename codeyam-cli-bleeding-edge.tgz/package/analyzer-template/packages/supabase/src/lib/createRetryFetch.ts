import fetchRetryBuilder from 'fetch-retry';

const IDEMPOTENT_METHODS = ['GET', 'HEAD', 'OPTIONS', 'TRACE'];

/**
 * Creates a fetch-compatible function with retry capabilities
 */
export function createRetryFetch(retries: number = 3, baseDelay: number = 400) {
  return (input: RequestInfo | URL, init?: RequestInit) => {
    const method = (init?.method || 'GET').toUpperCase();

    const retryFetch = fetchRetryBuilder(global.fetch, {
      retries,
      retryDelay: (attempt, error, response) => {
        const delay = Math.pow(2, attempt) * baseDelay;
        console.warn(`Retrying fetch() - attempt ${attempt + 1}:`, {
          input,
          init,
          error,
          response,
          nextRetryIn: `${delay}ms`,
        });
        return delay;
      },
      retryOn: (attempt, error, response) => {
        if (error === null && response.status < 500) {
          return false;
        }
        if (!IDEMPOTENT_METHODS.includes(method)) {
          console.warn(`Skipping retry for non-idempotent method ${method}:`, {
            input,
            init,
            error,
            response,
            responseStatus: response?.status,
          });
          return false;
        }
        return true;
      },
    });

    return retryFetch(input, init);
  };
}
