import { getDatabase, getJsonHelper } from './kysely/db';
import dbToBranch from './dbToBranch';
import { DbBranch, DbCommit } from './kysely/tableRelations';
import { awsLog } from '~codeyam/utils';
import { sql } from 'kysely';
import { getCommitAuthorsAsJson } from './loadCommit';
import { BackgroundJobsTableColumns } from './kysely/tables/backgroundJobsTable';

interface LoadBranchProps {
  projectId: string;
  id?: string;
  ref?: string;
  name?: string;
  sha?: string;
  pullRequestNumber?: number;
  primary?: boolean;
}

export default async function loadBranch({
  projectId,
  id,
  ref,
  name,
  sha,
  pullRequestNumber,
  primary,
}: LoadBranchProps) {
  const db = getDatabase();

  try {
    let query = db
      .selectFrom('branches')
      .selectAll('branches')
      .where('project_id', '=', projectId);

    if (pullRequestNumber) {
      query = query.where(
        sql<string>` ${sql.ref('metadata')} -> 'pullRequest' -> 'number'`,
        '=',
        pullRequestNumber.toString(),
      );
    }

    if (id) {
      query = query.where('id', '=', id);
    } else if (ref) {
      query = query.where('ref', '=', ref);
    } else if (name) {
      query = query.where('name', '=', name);
    } else if (sha) {
      query = query.where('sha', '=', sha);
    }

    if (primary) {
      query = query.where('primary', '=', true);
    }

    const branch = await query.executeTakeFirst();

    if (!branch) {
      awsLog('CodeYam Error: Branch not found', null, {
        projectId,
        id,
        ref,
        name,
        sha,
        pullRequestNumber,
        primary,
      });
      return null;
    }

    // Load commits separately
    const commits = await loadCommitsForBranch(branch.id);

    // Attach commits to branch for dbToBranch conversion
    const branchWithCommits: DbBranch = {
      ...branch,
      commits,
    };

    return dbToBranch(branchWithCommits);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading branch', error, {
      projectId,
      id,
      ref,
      name,
      sha,
      pullRequestNumber,
      primary,
    });
    return null;
  }
}

async function loadCommitsForBranch(branchId: string): Promise<DbCommit[]> {
  const db = getDatabase();

  const { jsonArrayFrom } = getJsonHelper();

  try {
    return await db
      .selectFrom('commits')
      .selectAll()
      .select((eb) => [
        getCommitAuthorsAsJson(eb).as('author'),
        jsonArrayFrom(
          eb
            .selectFrom('background_jobs')
            .select(BackgroundJobsTableColumns)
            .whereRef('background_jobs.commit_id', '=', 'commits.id'),
        ).as('background_jobs'),
      ])
      .where('commits.branch_id', '=', branchId)
      .orderBy('commits.committed_at', 'desc')
      .execute();
  } catch (error) {
    awsLog('CodeYam Error: Loading commits for branch', error, { branchId });
    return [];
  }
}
