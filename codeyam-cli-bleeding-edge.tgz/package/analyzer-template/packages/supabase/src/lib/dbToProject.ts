import { Project } from '~codeyam/types';
import { DbProject } from './kysely/tableRelations';
import dbToBranch from './dbToBranch';
import dbToFile from './dbToFile';
import nullsToUndefines from './nullsToUndefines';

export default function dbToProject(project: DbProject): Project {
  const {
    branches,
    files,
    analyzed_at,
    content_changed_at,
    created_at,
    updated_at,
    github_token,
    configuration,
    team_id,
    ...remaining
  } = project;

  return nullsToUndefines({
    ...remaining,
    branches: branches ? branches.map(dbToBranch) : undefined,
    files: files ? files.map(dbToFile) : undefined,
    analyzedAt: analyzed_at,
    contentChangedAt: content_changed_at,
    createdAt: created_at,
    updatedAt: updated_at,
  });
}
