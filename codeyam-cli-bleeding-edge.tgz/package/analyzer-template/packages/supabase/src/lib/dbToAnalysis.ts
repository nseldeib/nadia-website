import { Analysis } from '~codeyam/types';
import dbToEntity from './dbToEntity';
import dbToFile from './dbToFile';
import dbToProject from './dbToProject';
import dbToCommit from './dbToCommit';
import dbToScenario from './dbToScenario';
import dbToAnalysisBranch from './dbToAnalysisBranch';
import { DbAnalysis } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToAnalysis(dbAnalysis: DbAnalysis): Analysis {
  const {
    project_id,
    commit_id,
    file_id,
    file_path,
    entity_sha,
    entity_type,
    entity_name,
    previous_analysis_id,
    file: dbFile,
    entity: dbEntity,
    commit: dbCommit,
    project: dbProject,
    scenarios: dbScenarios,
    analysis_branches: dbAnalysisBranches,
    dependency_analyzed_tree_sha,
    analyzed_tree_sha,
    branch_commit_sha,
    committed_at,
    completed_at,
    created_at,
    updated_at,
    indirect,
    ...remaining
  } = dbAnalysis;

  const entity = dbEntity ? dbToEntity(dbEntity) : undefined;
  const file = dbFile ? dbToFile(dbFile) : undefined;
  const project = dbProject ? dbToProject(dbProject) : undefined;
  const commit = dbCommit ? dbToCommit(dbCommit) : undefined;
  const scenarios = dbScenarios ? dbScenarios.map(dbToScenario) : undefined;
  const analysisBranches = dbAnalysisBranches
    ? dbAnalysisBranches.map(dbToAnalysisBranch)
    : undefined;
  const branches = analysisBranches
    ? analysisBranches.map((ab) => ab.branch)
    : undefined;

  return nullsToUndefines({
    ...remaining,
    projectId: project_id,
    commitId: commit_id,
    fileId: file_id,
    filePath: file_path,
    entitySha: entity_sha,
    entityType: entity_type,
    entityName: entity_name,
    previousAnalysisId: previous_analysis_id,
    entity,
    file,
    commit,
    project,
    scenarios,
    analysisBranches,
    branches,
    dependencyAnalyzedTreeSha: dependency_analyzed_tree_sha,
    analyzedTreeSha: analyzed_tree_sha,
    branchCommitSha: branch_commit_sha,
    committedAt: committed_at,
    completedAt: completed_at,
    createdAt: created_at,
    updatedAt: updated_at,
    indirect: !!indirect,
  });
}
