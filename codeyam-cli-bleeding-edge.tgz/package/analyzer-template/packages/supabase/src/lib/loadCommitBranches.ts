import { CommitBranch } from '~codeyam/types';
import { getDatabase } from './kysely/db';
import dbToCommitBranch from './dbToCommitBranch';
import { DbCommitBranch } from './kysely/tableRelations';
import { awsLog } from '~codeyam/utils';
import {
  assembleDisambiguatedResult,
  disambiguateTableColumns,
} from './kysely/aggregationHelpers';
import { BranchesTableColumns } from './kysely/tables/branchesTable';

interface LoadCommitBranchArgs {
  projectId: string;
  commitId?: string;
  branchId?: string;
  active?: boolean;
  includeBranches?: boolean;
}

export default async function loadCommitBranches({
  projectId,
  commitId,
  branchId,
  active,
  includeBranches,
}: LoadCommitBranchArgs): Promise<CommitBranch[] | null> {
  const db = getDatabase();

  try {
    // Build the main query with explicit joins
    let query = db
      .selectFrom('commit_branches')
      .selectAll('commit_branches')
      .innerJoin('branches', 'commit_branches.branch_id', 'branches.id')
      .$if(includeBranches, (qb) =>
        qb.select(
          disambiguateTableColumns('branches', BranchesTableColumns, 'branch'),
        ),
      )
      .where('branches.project_id', '=', projectId);

    // Apply filters
    if (commitId) {
      query = query.where('commit_branches.commit_id', '=', commitId);
    }

    if (branchId) {
      query = query.where('commit_branches.branch_id', '=', branchId);
    }

    if (active !== undefined) {
      query = query.where('commit_branches.active', '=', active);
    }

    const results = await query.execute();

    if (!results || results.length === 0) {
      return null;
    }

    // Build DbCommitBranch objects with branch data
    const dbCommitBranches = results.map(
      (result) =>
        assembleDisambiguatedResult(result, 'branch') as DbCommitBranch,
    );

    return dbCommitBranches.map(dbToCommitBranch);
  } catch (error) {
    awsLog('CodeYam Error: Error loading commit branches', error, {
      projectId,
      commitId,
      branchId,
      active,
      includeBranches,
    });
    return null;
  }
}
