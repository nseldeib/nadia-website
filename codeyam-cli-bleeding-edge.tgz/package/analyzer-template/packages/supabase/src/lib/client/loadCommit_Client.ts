import { getSupabase } from '../supabase';
import dbToCommit from '../dbToCommit';
import { DbCommit } from '../kysely/tableRelations';

// A variant of this module that works in the browser using Supabase client
// and never imports anything that doesn't work with our set of polyfills.

interface LoadCommitArgs {
  id?: string;
  projectId?: string;
  sha?: string;
  branchId?: string;
  filePath?: string;
}

export default async function loadCommit_Client({
  id,
  projectId,
  sha,
  branchId,
  filePath,
}: LoadCommitArgs) {
  const query = getSupabase()
    .from('commits')
    .select(
      '*, author:github_users ( username, preferredUsername:preferred_username, avatarUrl:avatar_url ), branch:branches!commits_branch_id_fkey ( * ), mergedBranch:branches!public_commits_merged_branch_id_fkey ( * ), analyses ( *, scenarios ( * ) )',
    );

  if (id) {
    query.eq('id', id);
  }

  if (sha) {
    query.eq('sha', sha);
  }

  if (projectId) {
    query.eq('project_id', projectId);
  }

  if (branchId) {
    query.eq('branch_id', branchId);
  }

  if (filePath) {
    query.filter('files', 'cs', `[{"fileName": "${filePath}"}]`);
  }

  query.order('committed_at', { ascending: false });
  query.limit(1);

  const { data: commits, error } = await query.returns<DbCommit[]>();
  const commit = commits?.[0];

  if (!commit || error) {
    console.log(
      'Error loading commit',
      error,
      JSON.stringify(
        {
          id,
          projectId,
          sha,
          branchId,
          filePath,
        },
        null,
        2,
      ),
    );
    return;
  }

  const username = commit.author?.preferredUsername ?? commit.author?.username;
  commit.author ||= { username, avatarUrl: '' };
  commit.author.username = username;

  return dbToCommit(commit);
}
