import { Analysis } from '~codeyam/types';
import dbToAnalysis from '../dbToAnalysis';
import { getSupabase } from '../supabase';
import { DbAnalysis } from '../kysely/tableRelations';

export const BATCH_SIZE = 50;

// A variant of upsertFiles that works in the browser using Supabase client
// and never imports anything that doesn't work with our set of polyfills.

function chunk<T>(array: T[], size: number): T[][] {
  return array.length <= size
    ? [array]
    : Array.from({ length: Math.ceil(array.length / size) }, (_, i) =>
        array.slice(i * size, i * size + size),
      );
}

function buildAnalysesQuery({
  projectId,
  ids,
  fileIds,
  entityName,
  entityShas,
  commitIds,
  branchCommitSha,
  limit,
}: LoadAnalysesArgs) {
  const query = getSupabase()
    .from('analyses')
    .select(
      '*, entity:entities ( * ), scenarios ( * ), analysis_branches ( id, branch_id )',
    );

  if (projectId) {
    query.eq('project_id', projectId);
  }

  if (ids) {
    query.in('id', ids);
  }

  if (fileIds) {
    query.in('file_id', fileIds);
  }

  if (entityName) {
    query.eq('entity_name', entityName);
  }

  if (entityShas) {
    query.in('entity_sha', entityShas);
  }

  if (commitIds) {
    query.in('commit_id', commitIds);
  }

  if (branchCommitSha) {
    query.eq('branch_commit_sha', branchCommitSha);
  }

  if (limit) {
    query.limit(limit);
  }

  return query;
}

export interface LoadAnalysesArgs {
  projectId?: string;
  ids?: string[];
  fileIds?: string[];
  commitIds?: string[];
  entityName?: string;
  entityShas?: string[];
  branchCommitSha?: string;
  limit?: number;
}

export default async function loadAnalyses_Client(
  params: LoadAnalysesArgs,
): Promise<Analysis[]> {
  let analyses: DbAnalysis[] = [];
  const { ids, fileIds, entityShas, commitIds } = params;

  const paramMap = {
    id: { arr: ids, key: 'ids' },
    file_id: { arr: fileIds, key: 'fileIds' },
    entity_sha: { arr: entityShas, key: 'entityShas' },
    commit_id: { arr: commitIds, key: 'commitIds' },
  };

  // Find first array parameter to batch on
  const batchParams = Object.entries(paramMap).find(
    ([_, { arr }]) => arr?.length > 0,
  );

  if (!batchParams) {
    // No array parameters - just run a simple query
    const query = buildAnalysesQuery(params);
    const { data, error } = await query.returns<DbAnalysis[]>();

    if (error || !data || data.length === 0) {
      console.log('CodeYam Error: Analyses not found', params, error);
      return null;
    }

    analyses = data;
  } else {
    const [field, { arr, key }] = batchParams;
    const batches = chunk(arr, BATCH_SIZE);
    const results: DbAnalysis[] = [];

    for (let batch_ix = 0; batch_ix < batches.length; batch_ix++) {
      const batch = batches[batch_ix];
      const query = buildAnalysesQuery({
        ...params,
        [key]: batch,
      });
      if (batches.length > 1) {
        console.log(
          `CodeYam: batched loadAnalyses() for '${field}': ${batch_ix + 1}/${batches.length} sized ${batch.length}`,
        );
      }
      const { data, error } = await query.returns<DbAnalysis[]>();

      if (error) {
        console.log('CodeYam Error: Batch query failed', {
          batch,
          field,
          error,
        });
        return null;
      }

      if (data) {
        results.push(...data);
      }
    }

    analyses = results;
  }

  return analyses.map(dbToAnalysis);
}
