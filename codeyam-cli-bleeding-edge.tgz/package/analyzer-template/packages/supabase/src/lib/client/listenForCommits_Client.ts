import { Commit } from '~codeyam/types';
import { getSupabase } from '../supabase';
import loadCommit_Client from './loadCommit_Client';

export default function listenForCommits_Client(
  projectId: string,
  onEvent: (commit: Commit) => void,
) {
  const changes = getSupabase()
    .channel('commit-changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'commits',
        filter: `project_id=eq.${projectId}`,
      },
      async (payload) => {
        if (payload.eventType !== 'UPDATE') return;

        const id = payload.new.id;

        const commit = await loadCommit_Client({ id });

        return onEvent(commit);
      },
    )
    .subscribe();

  return changes;
}
