import {} from '~codeyam/types';
import dbToAnalysis from '../dbToAnalysis';
import { DbAnalysis } from '../kysely/tableRelations';
import { getSupabase } from '../supabase';
import { awsLog } from '~codeyam/utils';

// A variant of this module that works in the browser using Supabase client
// and never imports anything that doesn't work with our set of polyfills.

export interface LoadAnalysisArgs {
  id?: string;
  analysisBranchId?: string;
  projectId?: string;
  fileId?: string;
  commitId?: string;
  entityName?: string;
  dependencyAnalyzedTreeSha?: string;
  analyzedTreeSha?: string;
  includeFile?: boolean;
  includeProject?: boolean;
  includeCommitAndBranch?: boolean;
  includeMocks?: boolean;
  includeScenarios?: boolean;
  includeBranches?: boolean;
}

export default async function loadAnalysis_Client({
  id,
  analysisBranchId,
  projectId,
  fileId,
  commitId,
  entityName,
  dependencyAnalyzedTreeSha,
  analyzedTreeSha,
  includeFile,
  includeProject,
  includeCommitAndBranch,
  includeScenarios,
  includeBranches,
}: LoadAnalysisArgs) {
  const includes = ['entity:entities(*)'];

  if (includeFile) {
    includes.push('file:files( * )');
  }

  if (includeProject) {
    includes.push('project:projects( * )');
  }

  if (includeBranches && !analysisBranchId) {
    includes.push('analysis_branches ( branch:branches ( * ) )');
  }

  if (analysisBranchId) {
    if (includeBranches) {
      includes.push(
        'analysis_branches!inner ( id, branch_id, branch:branches ( * ) )',
      );
    } else {
      includes.push('analysis_branches!inner ( id, branch_id )');
    }
  }

  if (includeCommitAndBranch) {
    includes.push(
      'commit:commits( *, branch:branches!commits_branch_id_fkey( * ) )',
    );
  }

  if (includeScenarios) {
    includes.push('scenarios ( * )');
  }

  const query = getSupabase()
    .from('analyses')
    .select(`*, ${includes.join(', ')}` as '*');

  if (id) {
    query.eq('id', id);
  }

  if (projectId) {
    query.eq('project_id', projectId);
  }

  if (dependencyAnalyzedTreeSha) {
    query.eq('dependency_analyzed_tree_sha', dependencyAnalyzedTreeSha);
  } else if (analyzedTreeSha) {
    query.eq('analyzed_tree_sha', analyzedTreeSha);
  } else if (fileId) {
    query.eq('file_id', fileId);
  }

  if (entityName) {
    query.eq('entity_name', entityName);
  }

  if (commitId) {
    query.eq('commit_id', commitId);
  } else {
    query.order('created_at', { ascending: false });
    query.limit(1);
  }

  if (analysisBranchId) {
    query.eq('analysis_branches.id', analysisBranchId);
  }

  const { data: analyses, error } = await query.returns<DbAnalysis[]>();
  const analysis = analyses?.[0];

  if (error || !analysis) {
    awsLog('CodeYam Error: Analysis not found', error, {
      id,
      analysisBranchId,
      projectId,
      fileId,
      commitId,
      entityName,
      dependencyAnalyzedTreeSha,
      analyzedTreeSha,
      includeFile,
      includeProject,
      includeCommitAndBranch,
      includeScenarios,
      includeBranches,
    });
    return null;
  }

  return dbToAnalysis(analysis);
}
