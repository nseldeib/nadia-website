import dbToBranch from '../dbToBranch';
import { getSupabase } from '../supabase';
import { DbBranch } from '../kysely/tableRelations';

// A variant of this module that works in the browser using Supabase client
// and never imports anything that doesn't work with our set of polyfills.

interface LoadBranchesProps {
  projectId: string;
  ids?: string[];
  names?: string[];
  includeInactive?: boolean;
}

export default async function loadBranches_Client({
  projectId,
  ids,
  names,
  includeInactive,
}: LoadBranchesProps) {
  const query = getSupabase()
    .from('branches')
    .select('*')
    .eq('project_id', projectId);

  if (ids?.length) {
    query.in('id', ids);
  }

  if (names?.length) {
    query.in('name', names);
  }

  if (!includeInactive) {
    query.not('active_at', 'is', null);
  }

  const { data, error } = await query.returns<DbBranch[]>();

  if (error) {
    console.log('Error loading branches', projectId, includeInactive, error);
  }

  return data?.map(dbToBranch);
}
