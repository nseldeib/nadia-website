import { Entity } from '~codeyam/types';
import { EntitiesTable } from './kysely/tables/entitiesTable';
import { type Insertable } from 'kysely';

export default function entityToDb(entity: Entity): Insertable<EntitiesTable> {
  const {
    fileId,
    projectId,
    commitId,
    filePath,
    entityType,
    createdAt,
    updatedAt,
    analyses,
    commit,
    metadata,
    ...remaining
  } = entity;

  if ('resolvedFilePath' in remaining) {
    delete remaining.resolvedFilePath;
  }

  if ('resolvedName' in remaining) {
    delete remaining.resolvedName;
  }

  if ('dependenciesGathered' in remaining) {
    delete remaining.dependenciesGathered;
  }

  if ('branches' in remaining) {
    delete remaining.branches;
  }

  if ('branchIds' in remaining) {
    delete remaining.branchIds;
  }

  if ('importCount' in remaining) {
    delete remaining.importCount;
  }

  if ('started' in remaining) {
    delete remaining.started;
  }

  if ('completed' in remaining) {
    delete remaining.completed;
  }

  if ('commit' in remaining) {
    delete remaining.commit;
  }

  if ('code' in remaining) {
    delete remaining.code;
  }

  if ('file' in remaining) {
    delete remaining.file;
  }

  if ('commit' in remaining) {
    delete remaining.commit;
  }

  if ('analyses' in remaining) {
    delete remaining.analyses;
  }

  return {
    metadata: metadata ? JSON.stringify(metadata) : undefined,
    ...remaining,
    file_id: fileId,
    project_id: projectId,
    commit_id: commitId,
    file_path: filePath,
    entity_type: entityType,
    created_at: createdAt,
    updated_at: updatedAt,
  };
}
