import { getDatabase } from './kysely/db';
import dbToScenario from './dbToScenario';
import { awsLog } from '~codeyam/utils';

export default async function loadScenario({
  id,
  projectId,
}: {
  id: string;
  projectId: string;
}) {
  const db = getDatabase();

  try {
    const scenario = await db
      .selectFrom('scenarios')
      .selectAll()
      .where('id', '=', id)
      .where('project_id', '=', projectId)
      .executeTakeFirst();

    if (!scenario) {
      awsLog('CodeYam Error: Scenario not found', null, {
        id,
        projectId,
      });
      return null;
    }

    return dbToScenario(scenario);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading scenario', error, {
      id,
      projectId,
    });
    return null;
  }
}
