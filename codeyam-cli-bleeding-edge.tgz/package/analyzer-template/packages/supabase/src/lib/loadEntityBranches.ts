import { EntityBranch } from '~codeyam/types';
import { getDatabase, getJsonHelper } from './kysely/db';
import dbToEntityBranch from './dbToEntityBranch';
import { DbCommit, DbEntityBranch } from './kysely/tableRelations';
import { getCommitAuthorsAsJson } from './loadCommit';
import {
  JsonSelectBuilder,
  JsonSelectConstraint,
} from './kysely/aggregationHelpers';
import { EntityBranchesTableColumns } from './kysely/tables/entityBranchesTable';
import { BackgroundJobsTableColumns } from './kysely/tables/backgroundJobsTable';

interface LoadEntityBranchArgs {
  filePath?: string;
  entityName?: string;
  entitySha?: string;
  active?: boolean;
  branchId?: string;
}

export default async function loadEntityBranches({
  filePath,
  entityName,
  entitySha,
  active,
  branchId,
}: LoadEntityBranchArgs): Promise<EntityBranch[] | null> {
  const db = getDatabase();

  try {
    // Build the main query with explicit joins
    let query = db
      .selectFrom('entity_branches')
      .innerJoin('entities', 'entity_branches.entity_sha', 'entities.sha')
      .selectAll('entity_branches')
      .selectAll('entities');

    // Apply filters
    if (filePath) {
      query = query.where('entities.file_path', '=', filePath);
    }

    if (entityName) {
      query = query.where('entities.name', '=', entityName);
    }

    if (entitySha) {
      query = query.where('entity_branches.entity_sha', '=', entitySha);
    }

    if (active !== undefined) {
      query = query.where('entity_branches.active', '=', active);
    }

    if (branchId) {
      query = query.where('entity_branches.branch_id', '=', branchId);
    }

    const results = await query.execute();

    if (!results || results.length === 0) {
      return null;
    }

    // Group results by entity to load commits efficiently
    const entityIds = [
      ...new Set(results.map((r) => r.commit_id).filter(Boolean)),
    ];
    const commitsMap = await loadCommitsForEntities(entityIds);

    // Build DbEntityBranch objects with full entity and commit data
    const dbEntityBranches: DbEntityBranch[] = results.map((result) => {
      const entityBranch = {
        entity_sha: result.entity_sha,
        branch_id: result.branch_id,
        active: !!result.active,
      };

      const entity = {
        sha: result.sha,
        project_id: result.project_id,
        file_id: result.file_id,
        name: result.name,
        entity_type: result.entity_type,
        file_path: result.file_path,
        description: result.description,
        documentation: result.documentation,
        metadata: result.metadata,
        quality: result.quality,
        commit_id: result.commit_id,
        created_at: result.created_at,
        updated_at: result.updated_at,
        commit: result.commit_id ? commitsMap.get(result.commit_id) : undefined,
      };

      return {
        ...entityBranch,
        entity,
      };
    });

    return dbEntityBranches.map(dbToEntityBranch);
  } catch (error) {
    console.log(
      'CodeYam Error: Error loading entity branch',
      { filePath, entityName, entitySha, branchId },
      error,
    );
    return null;
  }
}

async function loadCommitsForEntities(
  commitIds: string[],
): Promise<Map<string, DbCommit>> {
  if (commitIds.length === 0) {
    return new Map();
  }

  const db = getDatabase();

  const { jsonArrayFrom } = getJsonHelper();

  try {
    const commits = await db
      .selectFrom('commits')
      .selectAll('commits')
      .select((eb) => [
        getCommitAuthorsAsJson(eb).as('author'),
        jsonArrayFrom(
          eb
            .selectFrom('background_jobs')
            .select(BackgroundJobsTableColumns)
            .whereRef('background_jobs.commit_id', '=', 'commits.id'),
        ).as('background_jobs'),
      ])
      .where('commits.id', 'in', commitIds)
      .execute();

    return new Map(commits.map((commit) => [commit.id, commit]));
  } catch (error) {
    console.log('CodeYam Error: Loading commits for entities', error, {
      commitIds,
    });
    return new Map();
  }
}

// Export for reuse in other loaders
export function getEntityBranchesAsJson(
  eb: JsonSelectBuilder,
  constraint?: JsonSelectConstraint,
) {
  const { jsonArrayFrom } = getJsonHelper();

  let query = eb
    .selectFrom('entity_branches')
    .select(EntityBranchesTableColumns);

  if (constraint) {
    query = constraint(query);
  }

  return jsonArrayFrom(query);
}
