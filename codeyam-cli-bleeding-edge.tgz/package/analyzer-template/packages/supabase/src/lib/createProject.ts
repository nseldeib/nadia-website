import { getSupabase } from './supabase';

export default async function createProject(
  name: string,
  description: string,
  path: string,
  userGitHubToken: string,
) {
  const slug = path
    .toLowerCase()
    .replace(/\//g, '-')
    .replace(/\s/g, '-')
    .replace(/[^a-z0-9-]/g, '');

  const { data: existingProjects, error: existingProjectError } =
    await getSupabase().from('projects').select().eq('slug', slug);

  if (!existingProjectError && existingProjects?.length > 0) {
    return existingProjects[0];
  }

  const { data, error } = await getSupabase()
    .from('projects')
    .insert([{ name, slug, path, description, github_token: userGitHubToken }])
    .select('*');

  if (error) {
    console.log('Error saving project', error);
  }

  const project = data?.[0];

  return project;
}
