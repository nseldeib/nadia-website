import { Branch } from '~codeyam/types';
import dbToCommit from './dbToCommit';
import dbToAnalysis from './dbToAnalysis';

import { DbBranch } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToBranch(dbBranch: DbBranch): Branch {
  const {
    project_id,
    content_changed_at,
    commits: dbCommits,
    analysis_branches: dbAnalysisBranches,
    active_at,
    created_at,
    updated_at,
    primary,
    ...remaining
  } = dbBranch;

  const commits = dbCommits ? dbCommits.map(dbToCommit) : undefined;
  const analyses = dbAnalysisBranches
    ? dbAnalysisBranches.flatMap((dbAnalysisBranch) =>
        dbToAnalysis(dbAnalysisBranch.analysis),
      )
    : undefined;

  return nullsToUndefines({
    ...remaining,
    projectId: project_id,
    contentChangedAt: content_changed_at,
    commits,
    analyses,
    activeAt: active_at,
    createdAt: created_at,
    updatedAt: updated_at,
    primary: !!primary,
  });
}
