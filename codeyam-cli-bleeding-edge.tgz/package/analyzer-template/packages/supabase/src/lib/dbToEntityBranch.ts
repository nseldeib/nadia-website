import { EntityBranch } from '~codeyam/types';
import dbToEntity from './dbToEntity';
import { DbEntityBranch } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToEntityBranch(
  dbEntityBranch: DbEntityBranch,
): EntityBranch {
  return nullsToUndefines({
    entitySha: dbEntityBranch.entity_sha,
    branchId: dbEntityBranch.branch_id,
    active: !!dbEntityBranch.active,
    entity: dbEntityBranch.entity
      ? dbToEntity(dbEntityBranch.entity)
      : undefined,
  });
}
