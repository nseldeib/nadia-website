import { getDatabase } from './kysely/db';
import dbToMock from './dbToMock';
import { awsLog } from '~codeyam/utils';
import { sql } from 'kysely';

interface LoadMockArgs {
  projectId: string;
  id?: string;
  filePath?: string;
  entityName?: string;
  entitySha?: string;
  content?: string;
  sha?: string;
}

export default async function loadMock({
  projectId,
  id,
  filePath,
  entityName,
  entitySha,
  content,
  sha,
}: LoadMockArgs) {
  const db = getDatabase();

  try {
    let query = db
      .selectFrom('mocks')
      .selectAll()
      .select((eb) => eb.lit(null).as('import_name')) // Dummy select to ensure at least one select is present
      .where('project_id', '=', projectId);

    if (id) {
      query = query.where('id', '=', id);
    }

    if (filePath) {
      query = query.where('file_path', '=', filePath);
    }

    if (entityName) {
      query = query.where('entity_name', '=', entityName);
    }

    if (entitySha) {
      query = query.where('entity_sha', '=', entitySha);
    }

    if (content) {
      query = query.where('content', '=', content);
    }

    if (sha) {
      query = query.where('sha', '=', sha);
    }

    const dbMock = await query.executeTakeFirst();

    if (!dbMock) {
      awsLog('CodeYam Error: Mock not found', null, {
        projectId,
        id,
        filePath,
        entityName,
        entitySha,
        content,
        sha,
      });
      return null;
    }

    return dbToMock(dbMock);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading mock', error, {
      projectId,
      id,
      filePath,
      entityName,
      entitySha,
      content,
      sha,
    });
    return null;
  }
}
