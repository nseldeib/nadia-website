import { Database, getDatabase, getJsonHelper } from './kysely/db';
import dbToCommit from './dbToCommit';
import {
  DbAnalysis,
  DbBranch,
  DbCommit,
  DbScenario,
} from './kysely/tableRelations';
import { awsLog } from '~codeyam/utils';
import { ExpressionBuilder } from 'kysely';
import { ScenariosTableColumns } from './kysely/tables/scenariosTable';
import { AnalysisMetadata, ScenarioMetadata } from '~codeyam/types';

interface LoadCommitArgs {
  id?: string;
  projectId?: string;
  sha?: string;
  branchId?: string;
}

async function loadBranchForCommit(branchId: string): Promise<DbBranch | null> {
  const db = getDatabase();

  try {
    return (
      (await db
        .selectFrom('branches')
        .selectAll()
        .where('id', '=', branchId)
        .executeTakeFirst()) || null
    );
  } catch (error) {
    awsLog('CodeYam Error: Loading branch for commit', error, { branchId });
    return null;
  }
}

async function loadAnalysesForCommit(commitId: string): Promise<DbAnalysis[]> {
  const db = getDatabase();

  const { jsonArrayFrom } = getJsonHelper();

  try {
    const analyses = await db
      .selectFrom('analyses')
      .selectAll('analyses')
      .select((eb) =>
        jsonArrayFrom(
          eb
            .selectFrom('scenarios')
            .select(ScenariosTableColumns)
            .whereRef('scenarios.analysis_id', '=', 'analyses.id')
            .$castTo<DbScenario>(),
        ).as('scenarios'),
      )
      .where('commit_id', '=', commitId)
      .execute();

    return analyses;
  } catch (error) {
    awsLog('CodeYam Error: Loading analyses for commit', error, { commitId });
    return [];
  }
}

export default async function loadCommit({
  id,
  projectId,
  sha,
  branchId,
}: LoadCommitArgs) {
  const db = getDatabase();

  try {
    let query = db
      .selectFrom('commits')
      .selectAll('commits')
      .select((eb) => getCommitAuthorsAsJson(eb).as('author'));

    if (id) {
      query = query.where('id', '=', id);
    }

    if (sha) {
      query = query.where('sha', '=', sha);
    }

    if (projectId) {
      query = query.where('project_id', '=', projectId);
    }

    if (branchId) {
      query = query.where('branch_id', '=', branchId);
    }

    query = query.orderBy('committed_at', 'desc').limit(1);

    const commit = await query.executeTakeFirst();

    if (!commit) {
      awsLog('CodeYam Error: Commit not found', null, {
        id,
        projectId,
        sha,
        branchId,
      });
      return null;
    }

    // Load branch and mergedBranch separately
    const [branch, mergedBranch, analyses] = await Promise.all([
      commit.branch_id
        ? loadBranchForCommit(commit.branch_id)
        : Promise.resolve(null),
      commit.merged_branch_id
        ? loadBranchForCommit(commit.merged_branch_id)
        : Promise.resolve(null),
      loadAnalysesForCommit(commit.id),
    ]);

    // Construct the full DbCommit object
    const dbCommit: DbCommit = {
      ...commit,
      branch: branch || undefined,
      mergedBranch: mergedBranch || undefined,
      analyses,
    };

    return dbToCommit(dbCommit);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading commit', error, {
      id,
      projectId,
      sha,
      branchId,
    });
    return null;
  }
}

// Export for reuse in other loaders
export function getCommitAuthorsAsJson(
  eb: ExpressionBuilder<Database, 'commits'>,
) {
  const { jsonObjectFrom } = getJsonHelper();

  return jsonObjectFrom(
    eb
      .selectFrom('github_users')
      .select([
        'username',
        'preferred_username as preferredUsername',
        'avatar_url as avatarUrl',
      ])
      .where(
        'github_users.username',
        '=',
        eb.ref('commits.author_github_username'),
      ),
  );
}
