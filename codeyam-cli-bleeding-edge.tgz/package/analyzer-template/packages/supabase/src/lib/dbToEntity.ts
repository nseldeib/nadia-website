import { Entity, EntityType } from '~codeyam/types';
import dbToAnalysis from './dbToAnalysis';
import dbToCommit from './dbToCommit';
import { DbEntity } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToEntity(dbEntity: DbEntity): Entity {
  const {
    file_id,
    project_id,
    commit_id,
    file_path,
    entity_type,
    entity_branches,
    analyses: dbAnalyses,
    commit: dbCommit,
    created_at,
    updated_at,
    ...remaining
  } = dbEntity;

  const branchIds = (entity_branches ?? []).map(
    (entity_branch) => entity_branch.branch_id,
  );

  const analyses = dbAnalyses ? dbAnalyses.map(dbToAnalysis) : undefined;
  const commit = dbCommit ? dbToCommit(dbCommit) : undefined;

  return nullsToUndefines({
    ...remaining,
    fileId: file_id,
    projectId: project_id,
    commitId: commit_id,
    filePath: file_path,
    entityType: entity_type as EntityType,
    commit,
    analyses,
    branchIds,
    createdAt: created_at,
    updatedAt: updated_at,
  });
}
