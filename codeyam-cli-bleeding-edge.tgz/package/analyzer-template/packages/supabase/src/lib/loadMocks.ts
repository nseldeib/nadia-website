import { getDatabase } from './kysely/db';
import dbToMock from './dbToMock';
import { awsLog } from '~codeyam/utils';

interface LoadMocksArgs {
  projectId: string;
  ids?: string[];
  filePaths?: string[];
  notNames?: string[];
  nodeModule?: boolean;
  latest?: boolean;
}

export default async function loadMocks({
  projectId,
  ids,
  filePaths,
  notNames,
  nodeModule,
  latest, // Note: latest parameter not used in query logic
}: LoadMocksArgs) {
  const db = getDatabase();

  try {
    let query = db
      .selectFrom('mocks')
      .selectAll()
      .where('project_id', '=', projectId);

    if (ids) {
      if (ids.length === 0) return [];
      query = query.where('id', 'in', ids);
    }

    if (filePaths) {
      if (filePaths.length === 0) return [];
      query = query.where('file_path', 'in', filePaths);
    }

    if (notNames && notNames.length > 0) {
      query = query.where('entity_name', 'not in', notNames);
    }

    if (nodeModule) {
      query = query.where('node_module', '=', true);
    }

    const dbMocks = await query.execute();

    return dbMocks.map(dbToMock);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading mocks', error, {
      projectId,
      ids,
      filePaths,
      notNames,
      nodeModule,
      latest,
    });
    return null;
  }
}
