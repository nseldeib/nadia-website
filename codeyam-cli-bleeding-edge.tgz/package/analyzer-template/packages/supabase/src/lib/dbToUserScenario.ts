import { UserScenario } from '~codeyam/types';
import { DbUserScenario } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToUserScenario(
  dbUserScenario: DbUserScenario,
): UserScenario {
  const {
    id,
    project_id,
    user_id,
    scenario_id,
    thumbs_up,
    user: dbUser,
  } = dbUserScenario;

  const user = dbUser
    ? {
        username: dbUser.github_username,
        avatarUrl: dbUser.github_user.avatar_url,
      }
    : undefined;

  return nullsToUndefines({
    id,
    projectId: project_id,
    userId: user_id,
    scenarioId: scenario_id,
    thumbsUp: !!thumbs_up,
    user,
  });
}
