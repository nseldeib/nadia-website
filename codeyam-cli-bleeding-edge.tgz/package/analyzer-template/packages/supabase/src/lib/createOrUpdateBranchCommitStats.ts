import { Branch, Project } from '~codeyam/types';
import upsertBranches from './upsertBranches';
import loadBranch from './loadBranch';

type CommitContributor = {
  username: string;
  avatarUrl: string;
};

interface CreateOrUpdateBranchCommitStatsArgs {
  project: Project;
  branch?: Branch;
  branchName?: string;
  branchRef?: string;
  merge: boolean;
  commitContributors: CommitContributor[];
  commitDate: Date;
  commitSha: string;
}

export default async function createOrUpdateBranchCommitStats({
  project,
  branch,
  branchName,
  branchRef,
  merge,
  commitContributors,
  commitDate,
  commitSha,
}: CreateOrUpdateBranchCommitStatsArgs) {
  if (branch) {
    branch = await loadBranch({
      id: branch.id,
      projectId: branch.projectId,
      ref: branch.ref,
      name: branch.name,
    });

    if (branch) {
      branch = await updateExistingBranchInDb({
        branch,
        merge,
        commitContributors,
        commitDate,
        commitSha,
      });
      return branch;
    }
  }

  branch = await createNewBranchInDb({
    project,
    branchName,
    branchRef,
    commitContributors,
    commitDate,
    commitSha,
  });

  return branch;
}

async function updateExistingBranchInDb({
  branch,
  merge,
  commitContributors,
  commitDate,
  commitSha,
}: {
  branch: Branch;
  merge: boolean;
  commitContributors: CommitContributor[];
  commitDate: Date;
  commitSha: string;
}) {
  const contributors = [
    ...(branch.metadata?.contributors ?? []),
    ...(merge ? [] : commitContributors),
  ].filter((c, i, a) => a.findIndex((cc) => cc.username === c.username) === i);

  const timeline = branch.primary
    ? undefined
    : [
        ...(branch.metadata?.timeline ?? []).filter(
          (t) => t.date !== commitDate.toISOString(),
        ),
        {
          title: 'Change Committed',
          date: commitDate.toISOString(),
          sha: commitSha,
          authors: commitContributors,
        },
      ];

  let contentChangedAt = branch.contentChangedAt
    ? new Date(branch.contentChangedAt)
    : commitDate;
  if (!merge && contentChangedAt && commitDate) {
    contentChangedAt = new Date(
      Math.max(contentChangedAt.getTime(), commitDate.getTime()),
    );
  }

  const updatedBranches = await upsertBranches([
    {
      ...branch,
      metadata: {
        ...branch.metadata,
        contributors,
        commits: {
          total: (branch.metadata?.commits?.total ?? 0) + 1,
          last7Days: Array.from(
            new Set([
              ...(branch.metadata?.commits?.last7Days ?? []),
              commitDate.toISOString(),
            ]),
          ).filter(
            (d) =>
              new Date(d) >
              new Date(new Date().getTime() - 7 * 24 * 60 * 60 * 1000),
          ),
        },
        timeline,
      },
      activeAt: branch.activeAt ?? new Date().toISOString(),
      contentChangedAt: contentChangedAt?.toISOString(),
    },
  ]);

  return updatedBranches[0];
}

async function createNewBranchInDb({
  project,
  branchName,
  branchRef,
  commitContributors,
  commitDate,
  commitSha,
}: {
  project: Project;
  branchName: string;
  branchRef: string;
  commitContributors: CommitContributor[];
  commitDate: Date;
  commitSha: string;
}): Promise<Branch> {
  const date7DaysAgo = new Date(new Date().getTime() - 7 * 24 * 60 * 60 * 1000);

  const branches = await upsertBranches([
    {
      projectId: project.id,
      name: branchName,
      activeAt: new Date().toISOString(),
      ref: branchRef,
      metadata: {
        contributors: commitContributors,
        commits: {
          total: 1,
          last7Days:
            commitDate > date7DaysAgo ? [commitDate.toISOString()] : [],
        },
        timeline: [
          {
            title: 'Created',
            date: commitDate.toISOString(),
            authors: commitContributors,
            sha: commitSha,
          },
        ],
      },
      contentChangedAt: new Date().toISOString(),
      primary: false,
    },
  ]);

  if (!branches || branches.length === 0) {
    throw new Error('Error creating branch');
  }

  return branches[0];
}
