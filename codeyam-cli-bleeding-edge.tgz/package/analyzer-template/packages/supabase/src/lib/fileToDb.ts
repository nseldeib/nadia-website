import { File } from '~codeyam/types';
import { type Insertable } from 'kysely';
import { FilesTable } from './kysely/tables/filesTable';
import { randomUUID } from 'crypto';

export default function fileToDb(file: File): Insertable<FilesTable> {
  return {
    id: file.id ?? randomUUID(),
    project_id: file.projectId!,
    name: file.name,
    path: file.path,
    deleted: file.deleted ?? null,
    metadata: file.metadata ? JSON.stringify(file.metadata) : null,
    created_at: file.createdAt ?? new Date().toISOString(),
    updated_at: file.updatedAt ?? null,
  };
}
