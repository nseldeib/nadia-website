import dbToBackgroundJob from './dbToBackgroundJob';
import { getDatabase } from './kysely/db';

export default async function loadBackgroundJob({
  commitId,
}: {
  commitId: string;
}) {
  try {
    const backgroundJobs = await getDatabase()
      .selectFrom('background_jobs')
      .selectAll()
      .where('commit_id', '=', commitId)
      .execute();

    if (!backgroundJobs?.[0]) return;

    return dbToBackgroundJob(backgroundJobs[0]);
  } catch (error) {
    console.log(`Error loading background job [commit_id]=${commitId}]`, error);
    return;
  }
}
