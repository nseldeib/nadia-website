import dbToAnalysis from './dbToAnalysis';
import { getDatabase, getJsonHelper } from './kysely/db';
import { awsLog } from '~codeyam/utils';
import { getCommitAuthorsAsJson } from './loadCommit';
import { getAnalysisBranchesWithBranches } from './loadAnalysisBranches';
import { EntitiesTableColumns } from './kysely/tables/entitiesTable';
import { FilesTableColumns } from './kysely/tables/filesTable';
import { ProjectsTableColumns } from './kysely/tables/projectsTable';
import { ScenariosTableColumns } from './kysely/tables/scenariosTable';
import { CommitsTableColumns } from './kysely/tables/commitsTable';

export interface LoadAnalysisArgs {
  id?: string;
  analysisBranchId?: string;
  projectId?: string;
  fileId?: string;
  commitId?: string;
  entityName?: string;
  dependencyAnalyzedTreeSha?: string;
  analyzedTreeSha?: string;
  includeFile?: boolean;
  includeProject?: boolean;
  includeCommitAndBranch?: boolean;
  includeMocks?: boolean;
  includeScenarios?: boolean;
  includeBranches?: boolean;
}

export default async function loadAnalysis({
  id,
  analysisBranchId,
  projectId,
  fileId,
  commitId,
  entityName,
  dependencyAnalyzedTreeSha,
  analyzedTreeSha,
  includeFile,
  includeProject,
  includeCommitAndBranch,
  includeScenarios,
  includeBranches,
}: LoadAnalysisArgs) {
  // TODO: Consider refactoring to use CTE + aliasedTableColumns pattern (Pattern 3)
  // like loadMostRecentPreviousAnalysis for more elegant single-query approach
  const db = getDatabase();

  try {
    // Build the main query
    let query = db.selectFrom('analyses').selectAll('analyses');

    // Handle filtering
    if (id) {
      query = query.where('id', '=', id);
    }

    if (projectId) {
      query = query.where('project_id', '=', projectId);
    }

    // Handle the dependency/analyzed tree sha logic
    if (dependencyAnalyzedTreeSha) {
      query = query.where(
        'dependency_analyzed_tree_sha',
        '=',
        dependencyAnalyzedTreeSha,
      );
    } else if (analyzedTreeSha) {
      query = query.where('analyzed_tree_sha', '=', analyzedTreeSha);
    } else if (fileId) {
      query = query.where('file_id', '=', fileId);
    }

    if (entityName) {
      query = query.where('entity_name', '=', entityName);
    }

    if (commitId) {
      query = query.where('commit_id', '=', commitId);
    } else {
      query = query.orderBy('created_at', 'desc').limit(1);
    }

    // Handle analysis_branches filtering when analysisBranchId is provided
    if (analysisBranchId) {
      query = query
        .innerJoin(
          'analysis_branches',
          'analyses.id',
          'analysis_branches.analysis_id',
        )
        .where('analysis_branches.id', '=', analysisBranchId);
    }

    const { jsonObjectFrom, jsonArrayFrom } = getJsonHelper();

    // Add JSON aggregations based on include flags
    query = query.select((eb) => {
      const selections = [];

      // Always include entity
      selections.push(
        jsonObjectFrom(
          eb
            .selectFrom('entities')
            .select(EntitiesTableColumns)
            .whereRef('entities.sha', '=', 'analyses.entity_sha'),
        ).as('entity'),
      );

      if (includeFile) {
        selections.push(
          jsonObjectFrom(
            eb
              .selectFrom('files')
              .select(FilesTableColumns)
              .whereRef('files.id', '=', 'analyses.file_id'),
          ).as('file'),
        );
      }

      if (includeProject) {
        selections.push(
          jsonObjectFrom(
            eb
              .selectFrom('projects')
              .select(ProjectsTableColumns)
              .whereRef('projects.id', '=', 'analyses.project_id'),
          ).as('project'),
        );
      }

      if (includeScenarios) {
        selections.push(
          jsonArrayFrom(
            eb
              .selectFrom('scenarios')
              .select(ScenariosTableColumns)
              .whereRef('scenarios.analysis_id', '=', 'analyses.id'),
          ).as('scenarios'),
        );
      }

      if (includeBranches) {
        selections.push(
          getAnalysisBranchesWithBranches(eb, (seb) =>
            seb.whereRef('analysis_branches.analysis_id', '=', 'analyses.id'),
          ).as('analysis_branches'),
        );
      }

      // Handle commit and branch inclusion
      if (includeCommitAndBranch) {
        selections.push(
          jsonObjectFrom(
            eb
              .selectFrom('commits')
              .select(CommitsTableColumns)
              .select((subEb) => getCommitAuthorsAsJson(subEb).as('author'))
              .whereRef('commits.id', '=', 'analyses.commit_id'),
          ).as('commit'),
        );
      }

      return selections;
    });

    const analysis = await query.executeTakeFirst();
    if (!analysis) {
      awsLog('CodeYam Error: Analysis not found', null, {
        id,
        analysisBranchId,
        projectId,
        fileId,
        commitId,
        entityName,
        dependencyAnalyzedTreeSha,
        analyzedTreeSha,
        includeFile,
        includeProject,
        includeCommitAndBranch,
        includeScenarios,
        includeBranches,
      });
      return null;
    }

    return dbToAnalysis(analysis);
  } catch (error) {
    awsLog('CodeYam Error: Database error loading analysis', error, {
      id,
      analysisBranchId,
      projectId,
      fileId,
      commitId,
      entityName,
      dependencyAnalyzedTreeSha,
      analyzedTreeSha,
      includeFile,
      includeProject,
      includeCommitAndBranch,
      includeScenarios,
      includeBranches,
    });
    return null;
  }
}
