import { Scenario } from '~codeyam/types';
import dbToUserScenario from './dbToUserScenario';
import dbToScenarioComment from './dbToScenarioComment';
import dbToAnalysis from './dbToAnalysis';
import { DbScenario } from './kysely/tableRelations';
import nullsToUndefines from './nullsToUndefines';

export default function dbToScenario(dbScenario: DbScenario): Scenario {
  const {
    project_id,
    analysis_id,
    previous_version_id,
    analysis: dbAnalysis,
    user_scenarios,
    scenario_comments,
    approved,
    ...remaining
  } = dbScenario;

  const analysis = dbAnalysis ? dbToAnalysis(dbAnalysis) : undefined;

  const userScenarios = user_scenarios
    ? user_scenarios.map(dbToUserScenario)
    : undefined;

  const comments = scenario_comments
    ? scenario_comments.map(dbToScenarioComment)
    : undefined;

  return nullsToUndefines({
    ...remaining,
    projectId: project_id,
    analysisId: analysis_id,
    previousVersionId: previous_version_id,
    analysis,
    userScenarios,
    comments,
  });
}
