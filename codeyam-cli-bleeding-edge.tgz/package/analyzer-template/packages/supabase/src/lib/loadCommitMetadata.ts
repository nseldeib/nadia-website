import { getDatabase } from './kysely/db';
import { awsLog } from '~codeyam/utils';

type LoadCommitRunsArgs = {
  commitId: string;
};

export default async function loadCommitMetadata({
  commitId,
}: LoadCommitRunsArgs) {
  const db = getDatabase();

  try {
    const data = await db
      .selectFrom('commits')
      .select('metadata')
      .where('id', '=', commitId)
      .executeTakeFirst();

    const metadata = data?.metadata;
    let runs = [];
    if (metadata) {
      runs = metadata.historicalRuns ?? [];
      if (metadata.currentRun) {
        runs = [metadata.currentRun, ...runs];
      }
    }

    return { metadata, runs };
  } catch (error) {
    awsLog('CodeYam Error: Loading metadata for commit', error, { commitId });
    return null;
  }
}
