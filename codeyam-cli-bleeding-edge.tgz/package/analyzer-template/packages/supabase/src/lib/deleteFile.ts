import { getDatabase } from './kysely/db';

export default async function deleteFile(projectId: string, filePath: string) {
  const db = getDatabase();

  try {
    const result = await db
      .deleteFrom('files')
      .where('project_id', '=', projectId)
      .where('path', '=', filePath)
      .returningAll()
      .execute();

    return result;
  } catch (error) {
    console.log('Error deleting file', error);
    return null;
  }
}
