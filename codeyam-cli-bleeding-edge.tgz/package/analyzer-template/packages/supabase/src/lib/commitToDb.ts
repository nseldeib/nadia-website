import { Commit } from '~codeyam/types';
import { CommitsTable } from './kysely/tables/commitsTable';
import { type Insertable } from 'kysely';
import { randomUUID } from 'crypto';

export default function commitToDb(
  commit: Commit,
  projectId: number | string,
): Insertable<CommitsTable> {
  const {
    id,
    projectId: _projectId,
    branchId,
    mergedBranchId,
    aiMessage,
    htmlUrl,
    analyzedAt,
    committedAt,
    author,
    metadata,
    files,
    ...remaining
  } = commit;

  delete remaining.branch;
  delete remaining.mergedBranch;
  delete remaining.backgroundJob;
  delete remaining.analyses;
  delete remaining.parents;
  delete remaining.entities;
  delete remaining.commitBranches;

  return {
    ...remaining,
    id: id ?? randomUUID(),
    project_id: _projectId ?? String(projectId),
    metadata: metadata ? JSON.stringify(metadata) : undefined,
    files: files ? JSON.stringify(files) : undefined,
    branch_id: branchId,
    merged_branch_id: mergedBranchId,
    author_github_username: author?.username,
    html_url: htmlUrl,
    ai_message: aiMessage,
    analyzed_at: analyzedAt,
    committed_at: committedAt,
  };
}
