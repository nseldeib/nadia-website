import { Branch } from '~codeyam/types';
import { type Insertable } from 'kysely';
import { BranchesTable } from './kysely/tables/branchesTable';
import { randomUUID } from 'crypto';

export default function branchToDb(branch: Branch): Insertable<BranchesTable> {
  const { id, projectId, activeAt, contentChangedAt, metadata, ...remaining } =
    branch;

  delete remaining.commits;
  delete remaining.files;
  delete remaining.analyses;
  delete remaining.createdAt;
  delete remaining.updatedAt;

  return {
    ...remaining,
    id: id ?? randomUUID(),
    project_id: projectId,
    active_at: activeAt,
    content_changed_at: contentChangedAt,
    metadata: metadata ? JSON.stringify(metadata) : null,
  };
}
