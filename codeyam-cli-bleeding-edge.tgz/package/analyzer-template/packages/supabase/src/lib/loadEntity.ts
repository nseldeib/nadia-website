import { getDatabase, getJsonHelper } from './kysely/db';
import dbToEntity from './dbToEntity';
import { awsLog } from '~codeyam/utils';
import { getEntityBranchesAsJson } from './loadEntityBranches';
import { EntitiesTableColumns } from './kysely/tables/entitiesTable';
import {
  JsonSelectBuilder,
  JsonSelectConstraint,
} from './kysely/aggregationHelpers';

export interface loadEntityArgs {
  projectId: string;
  sha: string;
}

export default async function loadEntity({ projectId, sha }: loadEntityArgs) {
  const db = getDatabase();

  try {
    const entity = await db
      .selectFrom('entities')
      .innerJoin('files', 'entities.file_id', 'files.id')
      .selectAll('entities')
      .select((eb) =>
        getEntityBranchesAsJson(eb, (seb) =>
          seb.whereRef('entity_branches.entity_sha', '=', 'entities.sha'),
        ).as('entity_branches'),
      )
      .where('files.project_id', '=', projectId)
      .where('entities.sha', '=', sha)
      .executeTakeFirst();

    if (!entity) {
      awsLog('CodeYam Error: Load Entity: Entity not found', null, {
        projectId,
        sha,
      });
      return null;
    }

    return dbToEntity(entity);
  } catch (error) {
    awsLog('CodeYam Error: Load Entity: Database error', error, {
      projectId,
      sha,
    });
    return null;
  }
}
