export {
  // default as supabase,
  // adminSupabase,
  getSupabase,
  getAdminSupabase,
} from './src/lib/supabase';
export { default as createOrUpdateBranchCommitStats } from './src/lib/createOrUpdateBranchCommitStats';
export { default as createProject } from './src/lib/createProject';
export { default as dbToAnalysis } from './src/lib/dbToAnalysis';
export { default as dbToAnalysisBranch } from './src/lib/dbToAnalysisBranch';
export { default as dbToBranch } from './src/lib/dbToBranch';
export { default as dbToCommit } from './src/lib/dbToCommit';
export { default as dbToEntity } from './src/lib/dbToEntity';
export { default as dbToFile } from './src/lib/dbToFile';
export { default as dbToMock } from './src/lib/dbToMock';
export { default as dbToProject } from './src/lib/dbToProject';
export { default as dbToScenario } from './src/lib/dbToScenario';
export { default as dbToScenarioComment } from './src/lib/dbToScenarioComment';
export { default as dbToUserScenario } from './src/lib/dbToUserScenario';
export { default as deleteBranch } from './src/lib/deleteBranch';
export { default as deleteFile } from './src/lib/deleteFile';
export { default as deleteScenarios } from './src/lib/deleteScenarios';
export { default as generateSha } from './src/lib/generateSha';
export { default as loadAnalyses } from './src/lib/loadAnalyses';
export { default as loadAnalysis } from './src/lib/loadAnalysis';
export { default as loadAnalysisBranches } from './src/lib/loadAnalysisBranches';
export { default as loadBackgroundJob } from './src/lib/loadBackgroundJob';
export { default as loadBranch } from './src/lib/loadBranch';
export { default as loadBranches } from './src/lib/loadBranches';
export { default as loadCommit } from './src/lib/loadCommit';
export { default as loadCommitBranches } from './src/lib/loadCommitBranches';
export { default as loadCommitMetadata } from './src/lib/loadCommitMetadata';
export { default as loadCommits } from './src/lib/loadCommits';
export { default as loadEntities } from './src/lib/loadEntities';
export { default as loadEntity } from './src/lib/loadEntity';
export { default as loadEntityBranches } from './src/lib/loadEntityBranches';
export { default as loadFile } from './src/lib/loadFile';
export { default as loadFiles } from './src/lib/loadFiles';
export { default as loadMock } from './src/lib/loadMock';
export { default as loadMocks } from './src/lib/loadMocks';
export { default as loadMostRecentPreviousAnalysis } from './src/lib/loadMostRecentPreviousAnalysis';
export { default as loadProject } from './src/lib/loadProject';
export { default as loadReadyToBeCapturedAnalyses } from './src/lib/loadReadyToBeCapturedAnalyses';
export { default as loadScenario } from './src/lib/loadScenario';
export { default as loadStatement } from './src/lib/loadStatement';
export { default as saveBackgroundEvent } from './src/lib/saveBackgroundEvent';
export { default as saveEntityStatements } from './src/lib/saveEntityStatements';
export { default as saveFiles } from './src/lib/saveFiles';
export { default as saveStatement } from './src/lib/saveStatement';
export { default as updateBackgroundJobProgress } from './src/lib/updateBackgroundJobProgress';
export { default as updateCommitMetadata } from './src/lib/updateCommitMetadata';
export { default as updateEntityBranch } from './src/lib/updateEntityBranch';
export { default as updateFreshAnalysisMetadata } from './src/lib/updateFreshAnalysisMetadata';
export { default as updateFreshAnalysisStatus } from './src/lib/updateFreshAnalysisStatus';
export { default as updateFreshAnalysisStatusWithScenarios } from './src/lib/updateFreshAnalysisStatusWithScenarios';
export { default as updateProjectMetadata } from './src/lib/updateProjectMetadata';
export { default as upsertAnalyses } from './src/lib/upsertAnalyses';
export { default as upsertAnalysesWithScenarios } from './src/lib/upsertAnalysesWithScenarios';
export { default as upsertAnalysisBranches } from './src/lib/upsertAnalysisBranches';
export { default as upsertBackgroundJob } from './src/lib/upsertBackgroundJob';
export { default as upsertBranches } from './src/lib/upsertBranches';
export { default as upsertCommitBranches } from './src/lib/upsertCommitBranches';
export { default as upsertCommits } from './src/lib/upsertCommits';
export { default as upsertEntities } from './src/lib/upsertEntities';
export { default as upsertEntityBranches } from './src/lib/upsertEntityBranches';
export { default as upsertFiles } from './src/lib/upsertFiles';
export { default as upsertGithubUser } from './src/lib/upsertGithubUser';
export { default as upsertMocks } from './src/lib/upsertMocks';
export { default as upsertProjects } from './src/lib/upsertProjects';
export { default as upsertScenarios } from './src/lib/upsertScenarios';
export { default as userScenarioToDb } from './src/lib/userScenarioToDb';

export * from './src/lib/kysely/db';

export { type Insertable } from 'kysely';

export * from './src/lib/kysely/tableRelations';

export * from './src/lib/kysely/tables/analysesTable';
export * from './src/lib/kysely/tables/analysisBranchesTable';
export * from './src/lib/kysely/tables/backgroundJobsTable';
export * from './src/lib/kysely/tables/branchesTable';
export * from './src/lib/kysely/tables/commitBranchesTable';
export * from './src/lib/kysely/tables/commitsTable';
export * from './src/lib/kysely/tables/entitiesTable';
export * from './src/lib/kysely/tables/entityBranchesTable';
export * from './src/lib/kysely/tables/entityStatementsTable';
export * from './src/lib/kysely/tables/filesTable';
export * from './src/lib/kysely/tables/githubPayloadsTable';
export * from './src/lib/kysely/tables/githubUsersTable';
export * from './src/lib/kysely/tables/mocksTable';
export * from './src/lib/kysely/tables/projectsTable';
export * from './src/lib/kysely/tables/scenarioCommentsTable';
export * from './src/lib/kysely/tables/scenariosTable';
export * from './src/lib/kysely/tables/statementsTable';
export * from './src/lib/kysely/tables/teamsTable';
export * from './src/lib/kysely/tables/userScenariosTable';
export * from './src/lib/kysely/tables/usersTable';
export * from './src/lib/kysely/tables/userTeamsTable';

export type { SupabaseClient } from '@supabase/supabase-js';
