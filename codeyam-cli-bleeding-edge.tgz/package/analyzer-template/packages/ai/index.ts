/**
 * This is the public API of `packages/ai`.
 *
 * Please be careful adding new exports to this file.
 */

export {
  DEFAULT_SMALLER_MODEL,
  DEFAULT_LARGER_MODEL,
} from './src/lib/aiConfig';
export { default as commitMessage } from './src/lib/commitMessage';
export { default as generateEntityDocumentation } from './src/lib/generateEntityDocumentation';
export { default as generateChangesEntityDocumentation } from './src/lib/generateChangesEntityDocumentation';
export { default as codeQualityEntityAnalysis } from './src/lib/codeQualityEntityAnalysis';
export { default as summarizeDiff } from './src/lib/summarizeDiff';
export { default as generateEntityDataMap } from './src/lib/generateEntityDataMap';
export { default as generateEntityDataStructure } from './src/lib/generateEntityDataStructure';
export { default as generateEntityScenarios } from './src/lib/generateEntityScenarios';
export {
  default as generateEntityScenarioData,
  generateDataForScenario,
} from './src/lib/generateEntityScenarioData';
export { default as generateChangesEntityScenarios } from './src/lib/generateChangesEntityScenarios';
export { default as generateChangesEntityScenarioData } from './src/lib/generateChangesEntityScenarioData';
export { default as generateEntityKeyAttributes } from './src/lib/generateEntityKeyAttributes';
export { default as generateChangesEntityKeyAttributes } from './src/lib/generateChangesEntityKeyAttributes';
export {
  default as guessScenarioDataFromName,
  GuessScenarioDataFromNameArgs,
} from './src/lib/guessScenarioDataFromName';
export {
  default as guessScenarioDataFromDescription,
  GuessScenarioDataFromDescriptionArgs,
} from './src/lib/guessScenarioDataFromDescription';
export { default as extractOverlappingMocks } from './src/lib/extractOverlappingMocks';
export { default as mergeJsonTypeDefinitions } from './src/lib/mergeJsonTypeDefinitions';
export { default as jsonTypeDefinitionToStandardTypeDefinition } from './src/lib/jsonTypeDefinitionToStandardTypeDefinition';
export { default as getCodeExplanation } from './src/lib/getCodeExplanation';
export { default as describeCodeChange } from './src/lib/describeCodeChange';
export { default as validateTypeStructure } from './src/lib/validateTypeStructure';
export { default as validateDataStructure } from './src/lib/validateDataStructure';
export { default as isolateScopes } from './src/lib/isolateScopes';
export { default as analyzeScope } from './src/lib/analyzeScope';
export { default as logOrderedMap } from './src/lib/logOrderedMap';
export {
  default as splitOutsideParentheses,
  splitOutsideParenthesesAndArrays,
  joinParenthesesAndArrays,
  functionArguments,
} from './src/lib/splitOutsideParentheses';
export { cleanKnownObjectFunctionsFromMapping } from './src/lib/dataStructure/helpers/cleanKnownObjectFunctions';
export { default as convertDotNotation } from './src/lib/dataStructure/helpers/convertDotNotation';
export { default as cleanOutBoundary } from './src/lib/cleanOutBoundary';
export { fillInDirectSchemaGapsAndUnknowns } from './src/lib/dataStructure/helpers/fillInSchemaGapsAndUnknowns';
export { default as gatherRelevantDependentKeyAttributes } from './src/lib/gatherRelevantDependentKeyAttributes';
export {
  ScopeInfo,
  ScopeDataStructure,
  FunctionCallInfo,
} from './src/lib/dataStructure/ScopeDataStructure';

export { AI } from './src/lib/types/index';

/**
 * This is the beginning of the new public API for packages/ai
 *
 * ## Examples
 *
 * ```ts
 * import ai from `~codeyam/ai`
 *
 * const results = ai.actions.getBranchSummary(...)
 * ```
 */
import { actions } from './src/index';
// import validatePropsStructure from './src/lib/validateDataStructure';
// import mergeScopeAnalyses from './src/lib/mergeScopeAnalyses';

/**
 * placeholder docs for `ai`
 */
const ai = {
  /**
   * placholder docs for actions
   */
  actions,
};

export default ai;
