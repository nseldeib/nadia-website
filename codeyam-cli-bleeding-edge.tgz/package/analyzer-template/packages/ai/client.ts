/**
 * Client-safe exports from packages/ai
 *
 * This file only exports items that are safe to use in browser environments.
 * Server-only functions like analyzeScope (which uses piscina) are not exported here.
 */

export { AI } from './src/lib/types/index';
export { COST_MULTIPLIER, parsers } from './src/lib';
export { default as extractOverlappingMocks } from './src/lib/extractOverlappingMocks';
export { default as validateDataStructure } from './src/lib/validateDataStructure';

export type { GuessScenarioDataFromNameArgs } from './src/lib/guessScenarioDataFromName';

export type { GuessScenarioDataFromDescriptionArgs } from './src/lib/guessScenarioDataFromDescription';
