/**
 * Amongst other things, this is where services get constructed
 * and builders get invoked. These activities should **not** occur within
 * the `lib` folder, since that is where simple functions live. Attempting
 * to do so would likely break the tests.
 */
import { aiServiceBuilder, dbServiceBuilder } from './lib/services';
import { getBranchSummaryBuilder } from './lib/actions';

const aiService = aiServiceBuilder();
const dbService = dbServiceBuilder({ aiService });

export const actions = {
  /**
   * placeholder docs for getBranchSummary
   */
  getBranchSummary: getBranchSummaryBuilder({
    aiService,
    dbService,
  }),
};
