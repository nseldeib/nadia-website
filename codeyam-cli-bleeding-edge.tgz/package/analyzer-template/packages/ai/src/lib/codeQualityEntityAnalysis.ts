import { Entity } from '~codeyam/types';
import completionCall from './completionCall';
import codeQualityEntityAnalysisGenerator from './promptGenerators/codeQualityEntityAnalysisGenerator';
import * as lib from '.';

interface CodeQualityEntityAnalysisArgs {
  entity: Entity;
  model?: lib.types.AI.Model;
}

export default async function codeQualityEntityAnalysis({
  entity,
  model,
}: CodeQualityEntityAnalysisArgs) {
  const prompt = codeQualityEntityAnalysisGenerator(entity);

  const response = await completionCall({
    type: 'codeQuality',
    systemMessage:
      'You are an expert coder and thoughtful analyzer of code, what is does, and how high quality it is.',
    prompt,
    model,
  });

  return response;
}
