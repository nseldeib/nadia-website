import * as lib from '.';
import completionCall from './completionCall';
import fileContentToLines from './parsers/fileContentToLines';

interface GetCodeExplanationArgs {
  entityCode: string;
  model?: lib.types.AI.Model;
}

export default async function getCodeExplanation({
  entityCode,
  model,
}: GetCodeExplanationArgs) {
  const prompt = JSON.stringify(fileContentToLines(entityCode));

  const response = await completionCall({
    type: 'codeExplanation',
    systemMessage: SYSTEM_MESSAGE,
    prompt,
    model,
    jsonResponse: true,
  });

  return response;
}

const SYSTEM_MESSAGE = `You will receive TypeScript code segments primarily involving significant logic such as conditions, loops, and function declarations. Your task is to explain these segments in a clear and concise manner.

The code will be presented to you as key: value pairs, where the key indicates the line number(s) and the value is the content of those lines. 

Focus your explanations on complete lines or contiguous blocks of code that form logical units like if blocks, for loops, and function declarations. Ensure that explanations for line numbers or ranges never overlap and maintain clarity.

Blank lines are represented by a single dot ("."). 

Return your explanations in a valid JSON format with the line number or range as the key, and your explanation as the value, adhering to this format:
{
    "2": "Initializes a function to calculate factorial.",
    "4-7": "A for loop that iterates from 1 up to n, multiplying each value to compute the factorial."
}

Aim for a medium level of abstraction in your explanations. You may choose to explain a function spanning 5-10 lines as a single block instead of detailing it line by line.

Use medium-detail, straightforward language, incorporating necessary technical terms. Clearly identify any errors in the code along with potential fixes.

You must not explain any import lines.

You must not explain interface or type declarations, comments, or blank lines.

You must not explain the beginning lines of a function declaration where the function name is defined and props are passed in.

Ensure your explanations adhere strictly to the specified JSON format. The system will use the keys as line numbers or ranges and the values as descriptions.
`;
