import completionCall from './completionCall';
import generateEntityScenarioDataGenerator from './promptGenerators/generateEntityScenarioDataGenerator';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import type {
  Entity,
  ScenariosDataStructure,
  Scenario,
  ScenarioData,
  Analysis,
} from '~codeyam/types';
import * as lib from '.';
import validateJson from './validateJson';
import { awsLog } from '~codeyam/utils';

const DEFAULT_SCENARIO_NAME = 'Default Scenario';

type ScenarioDataWithoutDescription = Omit<ScenarioData, 'scenarioDescription'>;

interface GenerateEntityScenarioDataArgs {
  entity: Pick<Entity, 'name' | 'filePath' | 'metadata'>;
  structure: ScenariosDataStructure;
  scenarios: Scenario[];
  incompleteResponse?: string;
  analysis: Analysis;
  model?: lib.types.AI.Model;
}

type GenerateDataForScenarioArgs = Omit<
  GenerateEntityScenarioDataArgs,
  'scenarios'
> & {
  scenario: Scenario;
  defaultScenarioData?: ScenarioData;
};

export async function generateDataForScenario({
  entity,
  structure,
  scenario,
  defaultScenarioData,
  incompleteResponse,
  analysis,
  model,
}: GenerateDataForScenarioArgs) {
  console.log('CodeYam: Generating scenario data for', scenario.name);

  const prompt = generateEntityScenarioDataGenerator(
    structure,
    scenario,
    defaultScenarioData,
    incompleteResponse,
  );

  const isDefault = scenario.name === DEFAULT_SCENARIO_NAME;
  const response = await completionCall({
    type: 'generateEntityScenarioData',
    systemMessage: incompleteResponse
      ? generateIncompleteSystemMessage(scenario.name, isDefault)
      : generateSystemMessage(scenario.name, isDefault),
    prompt,
    model,
  });

  const llmCall = await saveLlmCall({
    object_type: 'analysis',
    object_id: analysis.id,
    propsJson: {
      entity: {
        name: entity.name,
        filePath: entity.filePath,
        metadata: {
          exportAlias: entity.metadata?.exportAlias,
        },
      },
      structure,
      scenario,
      defaultScenarioData,
      incompleteResponse,
      analysis: {
        id: analysis.id,
        metadata: {
          isolatedDataStructure: {
            equivalentSignatureVariables:
              entity.metadata.isolatedDataStructure
                .equivalentSignatureVariables,
          },
        },
      },
      model,
    },
    ...response.stats,
  });

  const { completion, finishReason } = response;

  if (!completion) {
    console.log(
      'CodeYam Error: Example data generation failed: No response from AI',
    );
    return null;
  }

  awsLog(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} ${entity.metadata?.exportAlias ?? entity.name} scenario data completion :>> Finish reason:`,
    {
      finishReason,
      completion,
    },
  );

  const validJson = validateJson(completion);

  const parsed = lib.parsers.parseJsonSafe(validJson);
  if (!parsed || typeof parsed !== 'object' || !('scenarioData' in parsed)) {
    return null;
  }

  const { scenarioData: scenarioDataWithoutDescription } = parsed as {
    scenarioData: ScenarioDataWithoutDescription;
  };

  const fullScenarioData: ScenarioData = {
    ...scenarioDataWithoutDescription,
    scenarioDescription: scenario?.description ?? '',
  } as ScenarioData;

  if (structure.dataForMocks && !fullScenarioData.data.argumentsData) {
    fullScenarioData.data.argumentsData = [];
    if (structure.arguments && !fullScenarioData.data.argumentsData) {
      fullScenarioData.data.argumentsData = [];
      for (let i = 0; i < structure.arguments.length; ++i) {
        if (!fullScenarioData.data.argumentsData[i]) {
          fullScenarioData.data.argumentsData[i] = {};
        }
        for (const argKey of Object.keys(structure.arguments[i])) {
          fullScenarioData.data.argumentsData[i][argKey] =
            fullScenarioData.data[argKey];
        }
      }
    }
  }

  if (structure.dataForMocks && !fullScenarioData.data.mockData) {
    fullScenarioData.data.mockData = {};
    for (const propKey of Object.keys(structure.arguments)) {
      fullScenarioData.data.mockData[propKey] = fullScenarioData.data[propKey];
    }
  }

  return {
    scenarioData: fullScenarioData,
    llmCall: { name: scenario.name, id: llmCall.id },
  };
}

export default async function generateEntityScenarioData({
  entity,
  structure,
  scenarios,
  incompleteResponse,
  analysis,
  model,
}: GenerateEntityScenarioDataArgs) {
  if (scenarios.length === 0) {
    return { scenarioDatas: [], llmCalls: [] };
  }

  try {
    const scenarioDatas = [];
    const llmCalls = [];

    const defaultScenario = scenarios.find(
      (s) => s.name === DEFAULT_SCENARIO_NAME,
    );
    const defaultScenarioResult = await generateDataForScenario({
      entity,
      structure,
      scenario: defaultScenario,
      incompleteResponse,
      analysis,
      model,
    });

    if (!defaultScenarioResult) {
      return { scenarioDatas: [], llmCalls: [] };
    }

    const defaultScenarioData = defaultScenarioResult.scenarioData;

    scenarioDatas.push(defaultScenarioData);
    llmCalls.push(defaultScenarioResult.llmCall);

    const results = await Promise.all(
      scenarios
        .filter((s) => s !== defaultScenario)
        .map(async (scenario) => {
          return generateDataForScenario({
            entity,
            structure,
            scenario,
            defaultScenarioData,
            incompleteResponse,
            analysis,
            model,
          });
        }),
    );

    // Filter out any null results and combine the arrays
    const validResults = results.filter(
      (result): result is NonNullable<typeof result> => result !== null,
    );
    scenarioDatas.push(...validResults.map((result) => result.scenarioData));
    llmCalls.push(...validResults.map((result) => result.llmCall));

    awsLog(
      'CodeYam: scenarioDatas :>> ',
      JSON.stringify(
        {
          filePath: entity.filePath,
          entityName: entity.name,
          scenarioDatas,
        },
        null,
        2,
      ),
    );
    return { scenarioDatas, llmCalls };
  } catch (error) {
    console.log('CodeYam Error: Scenario data generation failed:', error);
    throw error;
  }
}

export const generateSystemMessage = (
  scenarioName: string,
  defaultScenario: boolean,
) => `## Overview
- You will be provided with a structure for scenario data, the "mockData structure", and for the arguments of the function, the "argumentsData structure", and a scenario describing a new state of data for this function.

- Your goal is to generate data to fulfill both the data structures and the scenario, to be returned in a JSON object.

## Provided Information

- The "mockData structure" and "argumentsData structure" describe all of the data required for the simulation to work. Copy the data structures exactly (if an attribute is a function it will look like "myFunction()" and that exact key "myFunction()" should be in the return value structure) and replace any primitives (e.g. "string", "number", "boolean", "date") with realistic data. 

${defaultScenario ? '' : '- The "Default Scenario Data" provides the data that has already been generated for the default scenario. This data will be merged into the data for each scenario. Your goal is to modify this data as needed to satisfy the requirements of this scenario. As such you only need to specify data that is different or should be removed from the default scenario data. To remove data set some portion of the data structure to null.'}

- Follow the "keyAttributeInstructions" for the scenario carefully.${defaultScenario ? ' As the Default Scenario ensure that the entire data structure is filled in with appropriate values even if they are not explicitly described in the "keyAttributeInstructions".' : ''}

## Instructions
${
  defaultScenario
    ? `
- We need data for the default scenario.

- The default scenario requires robust and complete data that fulfills all the "mockData" and "argumentsData" data structures if they exist, except for error attributes.

- The one exception to this is error data. Sometimes the data structure will contain structures for both success and error data. In this case you should only fill in the success data and leave out the error data completely.

- This data should cover for every object, attribute, and nested attribute described in the data structures (other than error data). If an item in a data structure is an array then provide multiple objects in the array. Fill in every nested attribute with realistic data. This should provide a robust and complete "database" for the simulation. If the type is described as "any" then create a realistic example of that type based on its name. If the type is "date" or "timestamp" then use the instructions below to generate a dynamic date or timestamp. 

- Remember to fill in each and every attribute and nested attribute in the data structure for the default scenario (other than error data). This will make the simulation more realistic and valuable. Do not add any attributes that are not in the data structure. If an attribute is not in the data structure then it should not be included in the data.
`
    : `
- This scenario is a modification of the default scenario. Figure out what needs to change about the Default Scenario in order to satisfy this scenario. If data must be removed then mark is as null at the appropriate level of the structure that the deletion should occur. Otherwise you can change any data that needs to be modified. Do not include any aspect of the structure that should remain the same as the Default Scenario.

- The data generated will be merged into the Default Scenario Data in order to create the full data for this scenario.
`
}

## Example Response

{
  "scenarioData": {
    "scenarioName": ${scenarioName},
    "data': {
      "mockData": {
        "useUser()": {
          "user": {
            "name": "John Doe",
            "metadata": {
              "hobbies": ["fishing", "hiking", "camping"]
              "favoriteColor": "blue",
            },
            "joinedAt": {
              "~~codeyam-code~~": "new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)"         
            }
          },
        },
        "loadProject()": {
          "project": {
            "name": "New Project",
            "slug": "new-project",
            "files": [
              {
                "name": "File 1",
                "slug": "file-1",
                "content": "This is the content of file 1"
              },
              {
                "name": "File 2",
                "slug": "file-2",
                "content": "This is the content of file 2"
              },
              {
                "name": "File 3",
                "slug": "file-3",
                "content": "This is the content of file 3"
              }
            ]
          }
        }
      },
      "argumentsData": [
        {
          "open": "true",
          "children: {
            "~~codeyam-jsx~~": "<div>Hi!</div>"         
          }      
        }    
      ]  
    }
  }
}

## scenarioData

You will return a JSON object called scenarioData containing the name and data for this scenario.

If you encounter a "date" then you should use "~~codeyam-code~~" along with code in string format. That string will be evaled to create the date or timestamp needed.

For example the "timestamp" above should probably not be a hard-coded timestamp but should be a function that returns a timestamp. If you want to return a timestamp that is 24 hours in the future, you would return this object:

\`\`\`
{
  "scenarioData": {
    "scenarioName": ${scenarioName},
    "data": {
      "mockData": {
        "dataLoaders": {
          "fetchUser()": {
            "user": {
              "name": "John Doe",
              "metadata": {
                "hobbies": ["fishing", "hiking", "camping"],
                "favoriteColor": "blue"
              },
              "joinedAt": {
                "~~codeyam-code~~": "new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()"
              }  
            }
          }
        }
      }
    }
  }
}
\`\`\`

Keep in mind the above pattern is also valid for argumentsData.

All code should be written in JavaScript. It will run in a node environment (not the browser) with no reference to external libraries. It will essentially be run in a sandboxed environment. Do not reference any external libraries in the code.

With argumentsData you may also need to return a "children" argument. "children" can either be a string or a jsx element.

If you want to return a jsx element you would return something like this:

\`\`\`
{
  "scenarioData": {
    "scenarioName": ${scenarioName},
    "data": {
      "argumentsData": [
        {
          "children": {
            "~~codeyam-jsx~~": "<div>Click Me!</div>"
          }
        }
      ]
    }
  }
}
\`\`\`

The "~~codeyam-jsx~~" key in a "children" prop will be rendered directly to the code as a jsx element, not a string. Only return basic elements like "<div>".

Do not import or reference any libraries in this code. No external libraries will be imported.

If either mockData or argumentsData is empty you can return an empty object for mockData ("{}") or empty array for argumentsData ("[]"). 

If an object inside of mockData or argumentsData is intended to not exist you can set it to null.

Never use "~~codeyam-code~~" or "~~codeyam-jsx~~" as a partial key in the response. Even if the key looks like it should have a relative date or code. "~~codeyam-code~~" and "~~codeyam-jsx~~" are only used as independent keys used to mark values that are code.

## Common Mistakes

- Do not use the term undefined in the response. If something is missing leave it out or use null.
- Leave out error data (e.g. a data attribute labeled as "error"), especially when it is in a data structure that has success data as well. Only include the success data and simply leave out the error data. Error data is usually labeled as "error" in the structure. Leave it out entirely.
  - Please double check this. Ensure no error data is included in the response unless specifically requested. ${defaultScenario ? `This includes the ${`DEFAULT_SCENARIO_NAME`}.` : ''} Leave out any error attributes from the response completely!
- Do not reference data in the response (e.g. if there was a "posts" field you can not say "posts[0]" elsewhere in the response - you need to duplicate the data). Unfortunately all data must be written out directly in the response.
- Ensure each scenario in the response matches the full scenario name, commas and all, in the scenarios provided.
- Do not throw errors from this data in any manner. Simple leave out any error data.
- If the data structure contains a type that is a "date" then use ~~codeyam-code~~ to generate a dynamic timestamp or date. Do not hard-code dates unless it needs to be a very specific date. Otherwise it should be a relative, dynamic date.
- The response must be valid JSON. Do not include raw code in the response.
${defaultScenario ? `- As the ${DEFAULT_SCENARIO_NAME} be very robust in generating data that reflects common real-world usage. All arrays and attributes, except error attributes, should be filled in with high quality data so that default simulation provides a good default of how the function behaves` : ''}
`;

export const generateIncompleteSystemMessage = (
  scenarioName: string,
  isDefault: boolean,
) => `Your previous response provided us with an incomplete json object.

Can you help us complete it? The previous response got cut off because it was too long so to complete the response you'll need to pick up where you left off providing just the necessary text to make the full response a valid json object.

Here is the original system message as well:

${generateSystemMessage(scenarioName, isDefault)}
\`\`\`
`;
