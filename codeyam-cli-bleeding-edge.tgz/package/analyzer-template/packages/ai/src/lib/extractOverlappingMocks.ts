import { Mock } from '~codeyam/types';

export interface ExtractOverlappingMocksArgs {
  mocksRequiringContent: Mock[];
  dependentMocks: { [key: string]: { [key: string]: Mock[] } };
}

export default function extractOverlappingMocks({
  mocksRequiringContent,
  dependentMocks,
}) {
  const overlapping: { [key: string]: { [key: string]: Mock[] } } = {};
  const notOverlapping: Mock[] = [];

  for (const filePath of Object.keys(dependentMocks)) {
    for (const entityName of Object.keys(dependentMocks[filePath] ?? {})) {
      const dependentMocksForPath = dependentMocks[filePath][entityName] ?? [];
      for (const mock of dependentMocksForPath) {
        let mustBeIncorporated = false;
        if (
          mock.mockingRequired &&
          (mocksRequiringContent.find((m) => m.path === mock.filePath) ||
            (!mustBeIncorporated &&
              Object.keys(dependentMocks).find((dependencyPath) => {
                Object.keys(dependentMocks[dependencyPath]).find(
                  (dependencyExportName) => {
                    if (
                      dependencyPath === filePath &&
                      dependencyExportName === entityName
                    ) {
                      return false;
                    }
                    if (!dependentMocks[dependencyPath]?.[dependencyExportName])
                      return false;
                    return !!dependentMocks[dependencyPath][
                      dependencyExportName
                    ].find(
                      (m) =>
                        m.filePath === mock.filePath &&
                        m.entityName === mock.entityName,
                    );
                  },
                );
              })))
        ) {
          mustBeIncorporated = true;
        }

        if (mustBeIncorporated) {
          if (!overlapping[filePath]?.[entityName]) {
            overlapping[filePath] ||= {};
            overlapping[filePath][entityName] = [];
          }
          overlapping[filePath][entityName].push(mock);
        } else {
          notOverlapping.push(mock);
        }
      }
    }
  }

  return { overlapping, notOverlapping };
}
