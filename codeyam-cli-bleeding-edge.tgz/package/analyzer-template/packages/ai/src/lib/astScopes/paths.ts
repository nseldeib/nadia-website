import ts from 'typescript';
import {
  PathRelationship,
  PathSegment,
  PropertySegment,
  ElementSegment,
  ParameterSegment,
  KeySegment,
  FunctionCallSegment,
  // Removed PathSegmentType as it doesn't exist in types.ts
} from './types';
// nodeToSource import might become unnecessary here if createLiteralPath uses getText directly
import { nodeToSource } from './nodeToSource';

interface ToStringWithSegmentsOptions {
  withReturnValues?: boolean;
  withNestedReturnValues?: boolean;
}

/**
 * A structured representation of a variable or property path
 *
 * This class addresses the following issues with the current string-based approach:
 * 1. Missing closing parentheses in function call paths
 * 2. Inconsistent .functionCallReturnValue suffixes
 * 3. Brittle string manipulation requiring complex regex
 * 4. Difficulty tracking complex nested paths
 *
 * DESIGN NOTES:
 * This class will become the core path representation for the AST scope analyzer after
 * the migration from string paths is complete. Unlike the transition layer classes,
 * this is NOT temporary and should remain as the permanent solution for path handling.
 *
 * After the migration is complete:
 * - The AnalysisContext interface should be updated to use StructuredPath directly
 * - The PathRegistry should be removed
 * - String path representations should only be used for storage and display
 *
 * Examples of how paths are represented:
 * - "obj.prop" -> { base: "obj", segments: [{ type: "property", value: "prop" }] }
 * - "arr[0]" -> { base: "arr", segments: [{ type: "element", value: 0 }] }
 * - "func().signature[0]" -> { base: "func()", segments: [{ type: "parameter", value: 0 }] }
 * - "func().functionCallReturnValue" -> { base: "func()", segments: [{ type: "returnValue", value: "" }] }
 */
export class StructuredPath {
  // private static pathRegistry = new Map<string, StructuredPath>();

  /**
   * Private constructor - use factory methods instead
   */
  private constructor(
    public readonly base: string,
    public readonly segments: ReadonlyArray<PathSegment>,
    private cachedStringRepresentation?: string,
    // --- New properties for Literal Paths ---
    private readonly _isLiteralPath: boolean = false,
    private readonly _literalType?: string, // Store the literal type ('object', 'array', 'string', etc.)
  ) {}

  /** Checks if this path represents a literal value */
  isLiteral(): boolean {
    return this._isLiteralPath;
  }

  /** Gets the type of the literal, if applicable */
  getLiteralType(): string | undefined {
    return this._literalType;
  }
  // --- End new properties/methods ---

  static empty(): StructuredPath {
    // Use the private constructor directly
    return new StructuredPath('', []);
  }

  static literal(text: string): StructuredPath {
    // Keep old behavior for now, doesn't mark as literal path
    return new StructuredPath(text.trim(), []);
  }

  /**
   * Creates a special path representing a literal value (object, array, string, etc.).
   * These paths are typically ignored when creating final structure/equivalence maps.
   * @param sourceText The source text of the literal (e.g., "{ a: 1 }")
   * @param literalType The type of the literal ('object', 'array', 'string', etc.)
   */
  static createLiteralPath(
    sourceText: string,
    literalType: string, // Corrected type to string
  ): StructuredPath {
    // Use the private constructor, setting the literal flags/type
    return new StructuredPath(
      sourceText.trim(), // Base is the literal's text
      [], // No segments for a base literal
      undefined, // No cached string needed initially
      true, // Mark as literal path
      literalType, // Store the type
    );
  }

  /**
   * Create a path from a base variable
   */
  static fromBase(base: string): StructuredPath {
    // Use the private constructor directly
    return new StructuredPath(base.trim(), []);
  }

  /**
   * Create a path from a function name with optional arguments and type arguments
   * This creates a path that represents a function call (with parentheses)
   * Optionally including generic type arguments
   */
  static fromFunction(
    functionName: string,
    args: StructuredPath[] = [],
    typeArgs?: string[],
  ): StructuredPath {
    // Create the base path with just the function name
    const basePath = this.fromBase(functionName);

    // Add the function call marker with arguments and type arguments
    return basePath.withFunctionCall(args, typeArgs);
  }

  /**
   * Create a new path with an additional property segment
   */
  withKey(name: string): StructuredPath {
    const newSegments = [
      ...this.segments,
      {
        type: PathRelationship.KEY,
        name,
      } as KeySegment,
    ];

    const stringRep = this.toStringWithSegments(this.base, newSegments);
    // Pass existing literal flags through
    return new StructuredPath(
      this.base,
      newSegments,
      stringRep,
      this._isLiteralPath,
      this._literalType,
    );
  }

  /**
   * Create a new path with an additional property segment
   */
  withProperty(name: string): StructuredPath {
    const newSegments = [
      ...this.segments,
      {
        type: PathRelationship.PROPERTY,
        name: name,
      } as PropertySegment,
    ];

    const stringRep = this.toStringWithSegments(this.base, newSegments);
    // Pass existing literal flags through
    return new StructuredPath(
      this.base,
      newSegments,
      stringRep,
      this._isLiteralPath,
      this._literalType,
    );
  }

  /**
   * Create a new path with an additional element segment
   */
  withElement(index: number | string): StructuredPath {
    const newSegments = [
      ...this.segments,
      {
        type: PathRelationship.ELEMENT,
        index: index,
      } as ElementSegment,
    ];

    const stringRep = this.toStringWithSegments(this.base, newSegments);
    // Pass existing literal flags through
    return new StructuredPath(
      this.base,
      newSegments,
      stringRep,
      this._isLiteralPath,
      this._literalType,
    );
  }

  /**
   * Create a new path with an additional parameter segment
   */
  withParameter(
    index: number,
    isRestParameter: boolean = false,
  ): StructuredPath {
    const newSegments = [
      ...this.segments,
      {
        type: PathRelationship.PARAMETER,
        index: index,
        isRestParameter,
      } as ParameterSegment,
    ];

    const stringRep = this.toStringWithSegments(this.base, newSegments);
    // Pass existing literal flags through
    return new StructuredPath(
      this.base,
      newSegments,
      stringRep,
      this._isLiteralPath,
      this._literalType,
    );
  }

  /**
   * Create a new path with a function call marker
   * This marks the path as a function call with parentheses
   *
   * @param args Array of structured paths representing the arguments
   * @param typeArgs Optional array of strings representing type arguments for generic calls
   */
  withFunctionCall(
    args: StructuredPath[] = [],
    typeArgs?: string[],
  ): StructuredPath {
    const newSegments = [
      ...this.segments,
      {
        type: PathRelationship.FUNCTION_CALL,
        args: args,
        typeArgs: typeArgs,
      } as FunctionCallSegment,
    ];

    const stringRep = this.toStringWithSegments(this.base, newSegments);
    // Pass existing literal flags through
    return new StructuredPath(
      this.base,
      newSegments,
      stringRep,
      this._isLiteralPath,
      this._literalType,
    );
  }

  /**
   * Create a new path with a raw segment
   * This is used for building paths programmatically
   */
  withSegment(segment: PathSegment): StructuredPath {
    const newSegments = [...this.segments, segment];

    const stringRep = this.toStringWithSegments(this.base, newSegments);
    return new StructuredPath(this.base, newSegments, stringRep);
  }

  withReturnValues(): StructuredPath {
    const stringRep = this.toStringWithSegments(this.base, this.segments, {
      withReturnValues: true,
    });
    return new StructuredPath(
      this.base,
      [...this.segments],
      stringRep,
      this._isLiteralPath,
      this._literalType,
    );
  }

  /**
   * Return a string representation of this path suitable for use as keys
   * in our 'structure' or 'equivalent variables' mappings.
   */
  toLeftHandSideString(): string {
    return this.toStringWithSegments(this.base, this.segments, {
      withReturnValues: false,
    });
  }

  /**
   * Return a string representation of this path suitable for use as values
   * in 'equivalent variables' mapping. The primary difference is that these
   * values have '.functionCallReturnValue' appended to the last function
   * call in the path.
   */
  toRightHandSideString(): string {
    return this.toStringWithSegments(this.base, this.segments, {
      withReturnValues: true,
    });
  }

  /**
   * Return the string representation of this path
   */
  toString(): string {
    return this.cachedStringRepresentation ?? this.toLeftHandSideString();
  }

  /**
   * Helper to compute string representation with given segments
   *
   * This creates a string representation of the structured path.
   */
  private toStringWithSegments(
    base: string,
    segments: ReadonlyArray<PathSegment>,
    {
      withReturnValues: doRenderFunctionCallReturnValue = false,
      withNestedReturnValues: doRenderNestedFunctionCallReturnValue = false,
    }: ToStringWithSegmentsOptions = {},
  ): string {
    let result = base;
    if (segments.length === 0) {
      return result;
    }

    let lastFunctionCallIndex = -1;
    for (let i = segments.length - 1; i >= 0; i--) {
      const segment = segments[i];
      if (segment.type === PathRelationship.FUNCTION_CALL) {
        lastFunctionCallIndex = i;
        break;
      }
    }

    for (let i = 0; i < segments.length; i++) {
      const segment = segments[i];
      switch (segment.type) {
        case PathRelationship.PROPERTY:
          const propSegment = segment as PropertySegment;
          if (result) result += '.';
          result += propSegment.name;
          break;

        case PathRelationship.ELEMENT:
          const elemSegment = segment as ElementSegment;
          if (elemSegment.index === '*') {
            result += '[]';
          } else if (typeof elemSegment.index === 'number') {
            result += `[${elemSegment.index}]`;
          } else {
            // Handle string keys or variables
            result += `[${elemSegment.index}]`;
          }
          break;

        case PathRelationship.PARAMETER:
          const paramSegment = segment as ParameterSegment;
          if (result) result += '.';
          result += `signature[${
            paramSegment.isRestParameter
              ? `${paramSegment.index}...`
              : `${paramSegment.index}`
          }]`;
          break;

        case PathRelationship.KEY:
          const keySegment = segment as KeySegment;
          result += `*${keySegment.name}*`;
          break;

        case PathRelationship.FUNCTION_CALL:
          const funcSegment = segment as FunctionCallSegment;

          // Add type arguments if present
          if (funcSegment.typeArgs && funcSegment.typeArgs.length > 0) {
            result += `<${funcSegment.typeArgs.join(', ')}>`;
          }

          // Add function arguments
          if (funcSegment.args.length === 0) {
            result += '()';
          } else {
            // Convert each argument to its string representation
            const argsStr = funcSegment.args
              .map((arg) =>
                arg.toStringWithSegments(arg.base, arg.segments, {
                  withReturnValues: doRenderNestedFunctionCallReturnValue,
                }),
              )
              .join(', ');
            result += `(${argsStr})`;
          }

          if (i === lastFunctionCallIndex && doRenderFunctionCallReturnValue) {
            // Add the return value marker
            result += '.functionCallReturnValue';
          }
          break;
      }
    }

    return result;
  }

  /**
   * Compare if this path is equal to another path
   */
  equals(other: StructuredPath): boolean {
    return this.toString() === other.toString();
  }

  /**
   * Create a structured path from a TypeScript AST node
   *
   * This method builds paths directly from AST nodes without any string manipulation.
   * If we can't properly represent a node, we return null rather than guessing.
   */
  /**
   * TODO: Enhance path generation to handle child scope substitution directly in the AST analyzer
   * rather than post-processing as string manipulation in analyzeScope.ts (lines 141-178).
   *
   * This would improve reliability and maintainability by replacing verbatim code text with
   * child scope identifiers during path generation. Implementation would look like:
   *
   * ```typescript
   * static fromNode(
   *   node: ts.Node,
   *   sourceFile: ts.SourceFile,
   *   childScopes?: Record<string, ScopeInfo>
   * ): StructuredPath | null {
   *   // Check if this node corresponds to a child scope
   *   if (childScopes) {
   *     for (const [id, scope] of Object.entries(childScopes)) {
   *       if (node.pos >= scope.start && node.end <= scope.end) {
   *         // This node is contained within a child scope
   *         // Return appropriate identifier (e.g., `childScopeId()`)
   *         return StructuredPath.fromBase(`${id}()`);
   *       }
   *     }
   *   }
   *
   *   // Continue with regular path generation...
   * }
   * ```
   */
  static fromNode(
    node: ts.Expression,
    sourceFile: ts.SourceFile,
  ): StructuredPath | null {
    // Handle identifiers - base variables (e.g., "variable")
    // TODO: should parens really imply we inline the full node text always?
    if (ts.isIdentifier(node) || ts.isParenthesizedExpression(node)) {
      return StructuredPath.fromBase(node.getText(sourceFile));
    }

    if (ts.isAwaitExpression(node)) {
      return StructuredPath.fromNode(node.expression, sourceFile);
    }
    // Handle property access - obj.prop or func().prop
    if (ts.isPropertyAccessExpression(node)) {
      // Get the path for the object being accessed
      const objPath = StructuredPath.fromNode(node.expression, sourceFile);
      if (!objPath) return null;

      // Check if we're accessing a property on a function call
      if (ts.isCallExpression(node.expression)) {
        // Property access on function call: func().prop

        return (
          objPath.hasFunctionCall() ? objPath : objPath.withFunctionCall()
        ).withProperty(node.name.text);
      } else {
        // Regular property access: obj.prop
        return objPath.withProperty(node.name.text);
      }
    }

    // Handle element access - obj[key] or arr[index]
    if (ts.isElementAccessExpression(node)) {
      const objPath = StructuredPath.fromNode(node.expression, sourceFile);
      if (!objPath) return null;

      // Check if we're accessing an element on a function call result
      if (ts.isCallExpression(node.expression)) {
        // Element access on function call: func()[key]

        // Ensure we have both function call and return value
        const pathWithReturn = objPath.hasFunctionCall()
          ? objPath
          : objPath.withFunctionCall();

        // Now add the element access
        // Handle different argument types
        if (ts.isStringLiteral(node.argumentExpression)) {
          return pathWithReturn.withProperty(node.argumentExpression.text);
        } else if (ts.isNumericLiteral(node.argumentExpression)) {
          return pathWithReturn.withElement(
            parseInt(node.argumentExpression.text, 10),
          );
        } else if (ts.isIdentifier(node.argumentExpression)) {
          return pathWithReturn.withElement(node.argumentExpression.text);
        } else {
          return pathWithReturn.withElement('*');
        }
      } else {
        // Regular element access
        // Handle different argument types
        if (ts.isStringLiteral(node.argumentExpression)) {
          return objPath.withProperty(node.argumentExpression.text);
        } else if (ts.isNumericLiteral(node.argumentExpression)) {
          return objPath.withElement(
            parseInt(node.argumentExpression.text, 10),
          );
        } else if (ts.isIdentifier(node.argumentExpression)) {
          return objPath.withElement(node.argumentExpression.text);
        } else {
          return objPath.withElement('*');
        }
      }
    }

    // Handle call expressions - func(arg1, arg2)
    if (ts.isCallExpression(node)) {
      // Get the expression being called
      const expression = node.expression;

      // We'll convert arguments to structured paths in each case below

      if (ts.isIdentifier(expression)) {
        // Simple function call: func(arg1, arg2) or func<T>(arg1, arg2)
        // Convert the arguments to structured paths
        const argPaths = node.arguments.map(
          (arg) =>
            StructuredPath.fromNode(arg, sourceFile) ||
            nodeToSource(arg, sourceFile),
        );

        // Handle type arguments if present
        let typeArgs: string[] | undefined = undefined;
        if (node.typeArguments && node.typeArguments.length > 0) {
          // Use the raw text representation as it preserves the exact type parameters
          // written in the code, even when they're not defined in the environment
          typeArgs = node.typeArguments.map((typeArg) =>
            typeArg.getText(sourceFile),
          );
        }

        // Create a function path with the structured arguments and type args
        return StructuredPath.fromFunction(expression.text, argPaths, typeArgs);
      } else if (ts.isPropertyAccessExpression(expression)) {
        // Method call: obj.method(arg1, arg2) or obj.method<T>(arg1, arg2)
        const objPath = StructuredPath.fromNode(
          expression.expression,
          sourceFile,
        );
        if (!objPath) return null;

        // Add the method name as property
        const withMethod = objPath.withProperty(expression.name.text);

        // Convert the arguments to structured paths
        const argPaths = node.arguments.map(
          (arg) =>
            StructuredPath.fromNode(arg, sourceFile) ||
            nodeToSource(arg, sourceFile),
        );

        // Handle type arguments if present
        let typeArgs: string[] | undefined = undefined;
        if (node.typeArguments && node.typeArguments.length > 0) {
          typeArgs = node.typeArguments.map((typeArg) =>
            typeArg.getText(sourceFile),
          );
        }

        // Add the function call with structured arguments and type arguments
        return withMethod.withFunctionCall(argPaths, typeArgs);
      } else if (ts.isCallExpression(expression)) {
        // Chained call: func(arg1)(arg2) or func(arg1)<T>(arg2)
        const funcPath = StructuredPath.fromNode(expression, sourceFile);
        if (!funcPath) return null;

        // Convert the arguments to structured paths
        const argPaths = node.arguments.map(
          (arg) =>
            StructuredPath.fromNode(arg, sourceFile) ||
            nodeToSource(arg, sourceFile),
        );

        // Handle type arguments if present
        let typeArgs: string[] | undefined = undefined;
        if (node.typeArguments && node.typeArguments.length > 0) {
          typeArgs = node.typeArguments.map((typeArg) =>
            typeArg.getText(sourceFile),
          );
        }

        // Then add the function call with structured arguments and type arguments
        return funcPath.withFunctionCall(argPaths, typeArgs);
      } else {
        // Complex call expression like (a + b)() or (a + b)<T>()
        // Use the expression source as the base
        const exprBase = nodeToSource(expression, sourceFile);

        // Convert the arguments to structured paths
        const argPaths = node.arguments.map(
          (arg) =>
            StructuredPath.fromNode(arg, sourceFile) ||
            nodeToSource(arg, sourceFile),
        );

        // Handle type arguments if present
        let typeArgs: string[] | undefined = undefined;
        if (node.typeArguments && node.typeArguments.length > 0) {
          typeArgs = node.typeArguments.map((typeArg) =>
            typeArg.getText(sourceFile),
          );
        }

        return exprBase.withFunctionCall(argPaths, typeArgs);
      }
    }

    // Handle As Expression - const x as Type
    if (ts.isAsExpression(node)) {
      // Get the expression being cast
      return StructuredPath.fromNode(node.expression, sourceFile);
    }

    return StructuredPath.fromBase(node.getText(sourceFile));
  }

  /**
   * Check if this path includes a function call
   */
  hasFunctionCall(): boolean {
    return this.segments.some(
      (segment) => segment.type === PathRelationship.FUNCTION_CALL,
    );
  }

  /**
   * Get the last function call segment in this path
   * Useful for method semantics handlers that need to access the most recent function call
   */
  getLastFunctionCallSegment(): FunctionCallSegment | undefined {
    const functionCallSegments = this.segments.filter(
      (segment) => segment.type === PathRelationship.FUNCTION_CALL,
    );
    return functionCallSegments.length > 0
      ? (functionCallSegments[
          functionCallSegments.length - 1
        ] as FunctionCallSegment)
      : undefined;
  }
}
