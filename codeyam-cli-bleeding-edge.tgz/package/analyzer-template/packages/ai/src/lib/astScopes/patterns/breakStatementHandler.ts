import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';

/**
 * Handler for break statements
 *
 * These are simple statements that don't affect variables
 * but we need to handle them to ensure completeness.
 */
export class BreakStatementHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return ts.isBreakStatement(node) || ts.isContinueStatement(node);
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    // Break and continue statements don't introduce new variables or affect existing ones
    // They just control loop flow, so we can mark them as fully handled
    return true;
  }
}
