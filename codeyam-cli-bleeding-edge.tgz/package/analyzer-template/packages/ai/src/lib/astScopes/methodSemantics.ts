import { AnalysisContext } from './types';
import { StructuredPath } from './paths';

/**
 * Interface for method-specific semantics
 *
 * This interface allows us to decouple method-specific knowledge (return types,
 * argument behaviors, etc.) from the AST traversal logic.
 */
export interface MethodSemantics {
  /**
   * Get the return type of the method
   */
  getReturnType(): string;

  /**
   * Add method-specific equivalence relationships
   *
   * @param methodCallPath Structured path to the method call
   * @param sourcePath Structured path to the object the method was called on
   * @param context Analysis context for adding equivalences and types
   */
  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void;

  /**
   * Is the analysis deterministic or needs LLM assistance?
   */
  isComplete(): boolean;
}

/**
 * Registry to manage method semantics throughout the codebase
 *
 * This class serves as a central repository for method-specific knowledge,
 * allowing handlers to look up how to handle specific method calls.
 */
export class MethodSemanticsRegistry {
  // Primary index by method name
  private byMethodName = new Map<string, MethodSemantics[]>();

  // Secondary precise index by class+method (when we know the class)
  private byClassAndMethod = new Map<string, Map<string, MethodSemantics>>();

  /**
   * Register method semantics
   *
   * @param methodName Method name (e.g., 'filter', 'map')
   * @param semantics Implementation of method semantics
   * @param className Optional class name for more precise lookups
   */
  register(
    methodName: string,
    semantics: MethodSemantics,
    className?: string,
  ): void {
    // Always index by method name
    if (!this.byMethodName.has(methodName)) {
      this.byMethodName.set(methodName, []);
    }
    this.byMethodName.get(methodName)!.push(semantics);

    // Optionally index by class+method
    if (className) {
      if (!this.byClassAndMethod.has(className)) {
        this.byClassAndMethod.set(className, new Map());
      }
      this.byClassAndMethod.get(className)!.set(methodName, semantics);
    }
  }

  /**
   * Primary lookup - by method name only
   *
   * @param methodName Method name to look up
   * @returns List of semantics registered for this method name, if any
   */
  getByMethodName(methodName: string): MethodSemantics[] | undefined {
    return this.byMethodName.get(methodName);
  }

  /**
   * Secondary precise lookup when class is known
   *
   * @param className Class name (e.g., 'Array')
   * @param methodName Method name
   * @returns Semantics for this specific class+method, if registered
   */
  getByClassAndMethod(
    className: string,
    methodName: string,
  ): MethodSemantics | undefined {
    return this.byClassAndMethod.get(className)?.get(methodName);
  }
}

/**
 * Array filter method semantics
 *
 * filter() returns a new array containing elements that pass the test
 */
export class ArrayFilterSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'array';
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array
    context.addType(sourcePath, 'array');

    context.addType(methodCallPath, 'array');

    // Get the last function call segment to access the arguments
    const lastFunctionCallSegment = methodCallPath.getLastFunctionCallSegment();

    if (lastFunctionCallSegment && lastFunctionCallSegment.args.length > 0) {
      // The first argument is the callback
      const callbackPath = lastFunctionCallSegment.args[0];

      // Add the callback to the structure
      context.addType(callbackPath, 'function');

      context.addEquivalence(
        callbackPath.withParameter(0),
        sourcePath.withElement('*'),
      );
    }
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Array find method semantics
 *
 * find() returns the first element that passes the test, or undefined
 */
export class ArrayFindSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'unknown'; // Could be any type from the array or undefined
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array
    context.addType(sourcePath, 'array');

    // Get the last function call segment to access the arguments
    const functionCallSegment = methodCallPath.getLastFunctionCallSegment();

    if (functionCallSegment && functionCallSegment.args.length > 0) {
      // The first argument is the callback
      const callbackPath = functionCallSegment.args[0];

      // Add the callback to the structure
      context.addType(callbackPath, 'function');

      // Mark that the callback's first parameter receives array elements
      context.addEquivalence(
        callbackPath.withParameter(0),
        sourcePath.withElement('*'),
      );

      // THIS IS PRODUCING STRANGE RESULTS SUCH AS
      // 'people.filter(cyScope2()).find(cyScope3())': 'people.filter(cyScope2()).functionCallReturnValue[]',
      // 'personWithHome.places.find(cyScope5())': 'personWithHome.places[]'
      // WHICH DO NOT MAKES SENSE
      // REMOVING BUT LEAVING IN PLACE IN CASE THERE IS A VALID USE CASE
      // The result is an element from the array that matches the callback condition
      // context.addEquivalence(methodCallPath, sourcePath.withElement('*'));
    }
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Array reduce method semantics
 *
 * reduce() returns a single value accumulated from array elements
 */
export class ArrayReduceSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'unknown'; // Return type depends on reducer function and initial value
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array
    context.addType(sourcePath, 'array');

    // Get the last function call segment to access the arguments
    const functionCallSegment = methodCallPath.getLastFunctionCallSegment();

    if (functionCallSegment && functionCallSegment.args.length > 0) {
      // The first argument is the callback
      const callbackPath = functionCallSegment.args[0];

      // Add the callback to the structure
      context.addType(callbackPath, 'function');

      // Mark that the callback's first parameter receives the accumulator
      // and second parameter receives array elements
      context.addEquivalence(
        callbackPath.withParameter(1),
        sourcePath.withElement('*'),
      );

      // If there's an initial value (second argument), connect it to the accumulator
      if (functionCallSegment.args.length > 1) {
        const initialValuePath = functionCallSegment.args[1];
        context.addEquivalence(callbackPath.withParameter(0), initialValuePath);
      }
    }
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Array concat method semantics
 *
 * concat() returns a new array combining the original array and additional items
 */
export class ArrayConcatSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'array';
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array
    context.addType(sourcePath, 'array');

    // Any arguments are also added to the array
    const functionCallSegment = methodCallPath.getLastFunctionCallSegment();

    if (functionCallSegment) {
      // Each argument could be an array or single element
      functionCallSegment.args.forEach((argPath) => {
        // No need to guess the type - we'll discover it through normal processing
        // But we can indicate that these elements will be in the result array
        context.addEquivalence(methodCallPath, argPath);
      });
    }

    // The original array elements are also in the result
    context.addType(methodCallPath, 'array');
    context.addEquivalence(methodCallPath, sourcePath.withElement('*'));
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Array slice method semantics
 *
 * slice() returns a shallow copy of a portion of an array
 */
export class ArraySliceSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'array';
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array
    context.addType(sourcePath, 'array');

    // The elements in the result are the same type as the source array
    const methodCallPathWithReturnValues = methodCallPath.withReturnValues();
    context.addType(methodCallPathWithReturnValues, 'array');
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Array splice method semantics
 *
 * splice() changes array in place by removing/replacing elements and returns removed elements
 */
export class ArraySpliceSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'array';
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array
    context.addType(sourcePath, 'array');

    // The returned array contains the removed elements
    context.addType(methodCallPath, 'array');

    // Get the last function call segment to access the arguments
    const functionCallSegment = methodCallPath.getLastFunctionCallSegment();

    if (functionCallSegment && functionCallSegment.args.length > 2) {
      // Arguments after index and deleteCount are items to be added
      // Add them to the source array
      for (let i = 2; i < functionCallSegment.args.length; i++) {
        const argPath = functionCallSegment.args[i];
        context.addEquivalence(sourcePath.withElement('*'), argPath);
      }
    }
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Array join method semantics
 *
 * join() returns a string by concatenating array elements with a separator
 */
export class ArrayJoinSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'string';
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array - this works for any collection being joined,
    // whether it's a direct array or the result of another method like filter()
    context.addType(sourcePath, 'array');

    // Get the last function call segment to access the arguments
    const functionCallSegment = methodCallPath.getLastFunctionCallSegment();

    if (functionCallSegment && functionCallSegment.args.length > 0) {
      // The first argument is the separator
      const separatorPath = functionCallSegment.args[0];

      // Typically we'd expect a string separator, but this maps the equivalence regardless
      context.addEquivalence(methodCallPath.withParameter(0), separatorPath);
    }

    // We only use .functionCallReturnValue on the right side of equivalence mappings
    // The method call itself is added to structure by the calling code
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Array map method semantics
 *
 * map() returns a new array with results of calling a function on every element
 */
export class ArrayMapSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'array';
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Mark source as array
    context.addType(sourcePath, 'array');

    // Get the last function call segment to access the arguments
    const lastFunctionCallSegment = methodCallPath.getLastFunctionCallSegment();

    if (lastFunctionCallSegment && lastFunctionCallSegment.args.length > 0) {
      // The first argument is the callback
      const callbackPath = lastFunctionCallSegment.args[0];

      // Add the callback to the structure
      context.addType(callbackPath, 'function');

      // Mark that the callback's first parameter receives array elements
      context.addEquivalence(
        callbackPath.withParameter(0),
        sourcePath.withElement('*'),
      );
    }
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * UseMemo React hook semantics
 *
 * useMemo returns a memoized value from a creation function
 */
export class UseMemoSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'unknown'; // The return type depends on the callback function
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // For useMemo, we add special handling for dependency array elements
    // Each array element needs to map to the correct dependency
    // For a call like useMemo(callbackFn, [dep1, dep2]), we need:
    // useMemo(...).signature[1][0] = dep1
    // useMemo(...).signature[1][1] = dep2

    // Get the last function call segment to access the arguments
    const functionCallSegment = methodCallPath.getLastFunctionCallSegment();

    // With our new structured argument support, we could now easily handle
    // the dependency array by analyzing the second argument's structure
    // This would be implemented in a future enhancement

    // Note: We only use .functionCallReturnValue on the right side of equivalence mappings
    // The type of the method call itself is added to structure by the calling code
    // We don't add any additional equivalences here yet, just rely on the regular
    // parameter handling in CallExpressionHandler.processMethodArguments
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * useState React hook semantics
 *
 * useState returns an array with the state value and a setter function
 */
export class UseStateSemantics implements MethodSemantics {
  getReturnType(): string {
    return 'array'; // Returns [state, setState]
  }

  addEquivalences(
    methodCallPath: StructuredPath,
    sourcePath: StructuredPath,
    context: AnalysisContext,
  ): void {
    // Get the last function call segment to access the arguments
    const functionCallSegment = methodCallPath.getLastFunctionCallSegment();

    // IMPORTANT: We intentionally do NOT add a type to methodCallPath here
    // The type 'function' is handled elsewhere in the system

    // Specifically mark the second element (index 1) of the return array as a function
    // This ensures the setter function (setX) is properly typed
    context.addType(methodCallPath.withParameter(1), 'function');

    // Handle initial value if provided
    if (functionCallSegment && functionCallSegment.args.length > 0) {
      const initialValuePath = functionCallSegment.args[0];
      context.addEquivalence(methodCallPath.withParameter(0), initialValuePath);
    }

    // The destructuring pattern is handled by the VariableDeclarationHandler
    // which creates the appropriate equivalences for array destructured elements
    // and also establishes the relationship between the entire pattern
    // and the function call return value
  }

  isComplete(): boolean {
    return true;
  }
}

/**
 * Create and populate the registry with method semantics
 */
export function createMethodRegistry(): MethodSemanticsRegistry {
  const registry = new MethodSemanticsRegistry();

  // Register array methods
  registry.register('filter', new ArrayFilterSemantics(), 'Array');
  registry.register('map', new ArrayMapSemantics(), 'Array');
  registry.register('join', new ArrayJoinSemantics(), 'Array');
  registry.register('find', new ArrayFindSemantics(), 'Array');
  registry.register('reduce', new ArrayReduceSemantics(), 'Array');
  registry.register('concat', new ArrayConcatSemantics(), 'Array');
  registry.register('slice', new ArraySliceSemantics(), 'Array');
  registry.register('splice', new ArraySpliceSemantics(), 'Array');

  // Register React hooks
  registry.register('useState', new UseStateSemantics(), 'React');
  registry.register('useMemo', new UseMemoSemantics(), 'React');

  return registry;
}

// Create a singleton instance of the registry for use throughout the codebase
export const methodRegistry = createMethodRegistry();
