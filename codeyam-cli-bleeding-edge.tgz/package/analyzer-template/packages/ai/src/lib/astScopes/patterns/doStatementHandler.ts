import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';

/**
 * Handler for do...while loops
 *
 * Processes:
 * - The loop body
 * - The condition expression
 */
export class DoStatementHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return ts.isDoStatement(node);
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    if (!ts.isDoStatement(node)) return false;

    context.processExpression(node.expression);

    context.processNode(node.statement);

    // Do...while loops themselves don't introduce new structure/equivalence mappings
    return true;
  }
}
