import ts from 'typescript';
import { StructuredPath } from './paths';

/**
 * Converts a TypeScript AST node to a canonical source representation.
 *
 * This is a utility for generating clean, consistent source code from AST nodes.
 * Unlike node.getText(), this produces a canonical representation that can be
 * used for analysis, comparison, and presentation.
 *
 * TODO: Implement expression normalization for more complex cases:
 * - Normalize associative operations (e.g., (a + b) + c -> a + b + c)
 * - Handle commutative operations (e.g., a + b = b + a)
 * - Consider operator precedence for mixed operations
 * - Implement structural fingerprinting for complex expressions
 *
 * @param node The AST node to convert
 * @param sourceFile The source file containing the node (needed for some operations)
 * @param options Optional configuration for the serialization
 * @returns A string representation of the node in canonical form
 */
export function nodeToSource(
  node: ts.Node,
  sourceFile: ts.SourceFile,
): StructuredPath {
  // Handle different node types
  // if (ts.isIdentifier(node)) {
  //   return serializeIdentifier(node);
  // } else if (ts.isBinaryExpression(node)) {
  //   return serializeBinaryExpression(node, sourceFile, options);
  // } else if (ts.isPropertyAccessExpression(node)) {
  //   return serializePropertyAccessExpression(node, sourceFile, options);
  // } else if (ts.isStringLiteral(node)) {
  //   return serializeStringLiteral(node);
  // } else if (ts.isNumericLiteral(node)) {
  //   return serializeNumericLiteral(node);
  // } else if (ts.isCallExpression(node)) {
  //   return serializeCallExpression(node, sourceFile, options);
  // } else if (ts.isObjectLiteralExpression(node)) {
  //   return serializeObjectLiteral(node, sourceFile, options);
  // } else if (ts.isArrayLiteralExpression(node)) {
  //   return serializeArrayLiteral(node, sourceFile, options);
  // } else if (ts.isElementAccessExpression(node)) {
  //   return serializeElementAccessExpression(node, sourceFile, options);
  // } else if (ts.isObjectBindingPattern(node)) {
  //   return serializeObjectBindingPattern(node, sourceFile, options);
  // } else if (ts.isArrayBindingPattern(node)) {
  //   return serializeArrayBindingPattern(node, sourceFile, options);
  // } else if (ts.isTemplateExpression(node)) {
  //   return serializeTemplateExpression(node, sourceFile, options);
  // } else if (ts.isNoSubstitutionTemplateLiteral(node)) {
  //   return serializeNoSubstitutionTemplateLiteral(node);
  // } else if (ts.isBindingElement(node)) {
  //   return serializeBindingElement(node, sourceFile, options);
  // }

  // Fallback for unsupported node types
  return StructuredPath.fromBase(node.getText(sourceFile));
}
