import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';

/**
 * Handler for if statements
 *
 * Processes:
 * - The condition expression
 * - The then block
 * - The else block if present
 */
export class IfStatementHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return ts.isIfStatement(node);
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    if (!ts.isIfStatement(node)) return false;

    // Process the condition expression first
    context.processExpression(node.expression);

    // Process the 'then' statement block
    context.processNode(node.thenStatement);

    // Process the 'else' statement block if it exists
    if (node.elseStatement) {
      context.processNode(node.elseStatement);
    }

    // If statements themselves don't introduce new structure/equivalence mappings
    // They just contain other statements that might. So we always return true
    // as we've successfully processed the if statement itself.
    return true;
  }
}
