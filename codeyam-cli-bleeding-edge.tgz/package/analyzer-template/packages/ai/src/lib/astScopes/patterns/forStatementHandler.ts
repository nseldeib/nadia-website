import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';

/**
 * Handler for standard for loops
 *
 * Processes:
 * - The initializer (e.g., let i = 0)
 * - The condition (e.g., i < 10)
 * - The incrementor (e.g., i++)
 * - The loop body
 */
export class ForStatementHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return ts.isForStatement(node);
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    if (!ts.isForStatement(node)) return false;

    const allComponentsSupported = true;

    // Process the initializer if present (e.g., let i = 0)
    if (node.initializer) {
      if (ts.isVariableDeclarationList(node.initializer)) {
        // Handle variable declarations like 'let i = 0'
        for (const declaration of node.initializer.declarations) {
          context.processNode(declaration);
        }
      } else {
        // Handle a single identifier initializer (e.g., 'i = 0')
        context.processExpression(node.initializer);
      }
    }

    // Process the condition if present (e.g., i < 10)
    if (node.condition) {
      // Add type information for the condition
      context.inferAndAddType(
        context.getStructuralPath(node.condition),
        node.condition,
      );

      // Process the condition normally
      context.processExpression(node.condition);
    }

    // Process the incrementor if present (e.g., i++)
    if (node.incrementor) {
      // Process the incrementor node - this will trigger our prefix/postfix handlers
      context.processExpression(node.incrementor);
    }

    // Process the loop body
    context.processNode(node.statement);

    // Our compound assignment and increment/decrement handlers now support all loop operations
    // No need to mark the loop as not fully supported anymore

    // Set completeness based on the loop components
    return allComponentsSupported;
  }
}
