import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';

import { StructuredPath } from '../paths';
import { processBindingPattern } from '../processBindings';

/**
 * Handler for function declarations
 *
 * Handles patterns like:
 * - function fn(a, b) { ... }
 * - const arrowFn = (x, y) => { ... }
 * - const conciseArrowFn = x => x.prop
 */
export class FunctionDeclarationHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return (
      ts.isFunctionDeclaration(node) ||
      ts.isFunctionExpression(node) ||
      ts.isArrowFunction(node)
    );
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    if (
      !ts.isFunctionDeclaration(node) &&
      !ts.isFunctionExpression(node) &&
      !ts.isArrowFunction(node)
    ) {
      return false;
    }

    let fullySupported = true;

    // Process function parameters
    fullySupported &&= this.processParameters(node, context);

    // Handle arrow functions
    if (ts.isArrowFunction(node)) {
      fullySupported &&= this.processArrowFunction(node, context);
    } else if (node.body) {
      // Process function body for non-concise functions
      context.processNode(node.body);
    }

    return fullySupported;
  }

  /**
   * Process function parameters and map them to signature indices
   */
  private processParameters(
    node: ts.FunctionLikeDeclaration,
    context: AnalysisContext,
  ): boolean {
    let fullySupported = true;

    // Process each parameter
    node.parameters.forEach((param, index) => {
      // Check if this is a rest parameter (e.g., ...args)
      const isRestParam = param.dotDotDotToken !== undefined;

      // For rest parameters, use signature[index...] notation
      const signaturePath = StructuredPath.empty().withParameter(
        index,
        isRestParam,
      );

      if (ts.isIdentifier(param.name)) {
        const paramName = context.getStructuralPath(param.name);

        // Add equivalence: param = signature[index] or param = signature[index...]
        context.addEquivalence(paramName, signaturePath);

        // Try to infer parameter type using TypeChecker
        try {
          // Get the parameter's type from TypeScript's TypeChecker
          const paramType = context.typeChecker.getTypeAtLocation(param);
          const inferredType = context.inferTypeFromTsType(paramType);

          // For rest parameters of array type, mark them as arrays
          if (isRestParam && inferredType !== 'array') {
            context.addType(paramName, 'array');
          } else {
            context.addType(paramName, inferredType);
          }
        } catch (error) {
          // If TypeChecker fails, fall back to explicit type annotations
          if (param.type) {
            const typeText = this.getTypeText(param.type);
            if (typeText) {
              context.addType(paramName, typeText);
            } else {
              // For rest parameters, default to array if we can't determine type
              if (isRestParam) {
                context.addType(paramName, 'array');
              } else {
                context.addType(paramName, 'unknown');
              }
            }
          } else {
            // For rest parameters, default to array if no type annotation
            if (isRestParam) {
              context.addType(paramName, 'array');
            } else {
              context.addType(paramName, 'unknown');
            }
          }
        }
      }
      // Handle object/array destructuring in parameters: function fn({ a, b }) {...} or function fn([a, b]) {...}
      else if (
        ts.isObjectBindingPattern(param.name) ||
        ts.isArrayBindingPattern(param.name)
      ) {
        // Use the centralized binding pattern processor
        const bindingProcessed = processBindingPattern(
          param.name,
          signaturePath,
          context,
        );

        fullySupported = fullySupported && bindingProcessed;
      } else {
        // Unsupported parameter pattern
        context.markUnsupported(
          param,
          `Unsupported parameter name kind`,
          false, // Non-blocking
        );
        fullySupported = false;
      }
    });

    return fullySupported;
  }

  /**
   * Process concise arrow functions (without block body)
   * Example: const getProperty = p => p.property;
   */
  private processArrowFunction(
    node: ts.ArrowFunction,
    context: AnalysisContext,
  ): boolean {
    if (ts.isExpression(node.body)) {
      return context.processExpression(
        node.body,
        StructuredPath.literal('returnValue'),
      );
    }
    context.processNode(node.body);
  }

  /**
   * Gets a string representation of a type node
   */
  private getTypeText(typeNode: ts.TypeNode): string | null {
    if (ts.isTypeReferenceNode(typeNode)) {
      if (ts.isIdentifier(typeNode.typeName)) {
        const typeName = typeNode.typeName.text.toLowerCase();

        // Map TypeScript types to our simplified type system
        switch (typeName) {
          case 'string':
          case 'number':
          case 'boolean':
          case 'object':
          case 'array':
            return typeName;
          case 'date':
            return 'date';
          case 'function':
            return 'function';
          case 'map':
          case 'record':
          case 'dictionary':
            return 'map';
          default:
            return 'object'; // Default to object for custom types
        }
      }
    } else if (ts.isLiteralTypeNode(typeNode)) {
      if (ts.isStringLiteral(typeNode.literal)) {
        return 'string';
      } else if (ts.isNumericLiteral(typeNode.literal)) {
        return 'number';
      } else if (
        typeNode.literal.kind === ts.SyntaxKind.TrueKeyword ||
        typeNode.literal.kind === ts.SyntaxKind.FalseKeyword
      ) {
        return 'boolean';
      }
    } else if (typeNode.kind === ts.SyntaxKind.StringKeyword) {
      return 'string';
    } else if (typeNode.kind === ts.SyntaxKind.NumberKeyword) {
      return 'number';
    } else if (typeNode.kind === ts.SyntaxKind.BooleanKeyword) {
      return 'boolean';
    } else if (typeNode.kind === ts.SyntaxKind.ObjectKeyword) {
      return 'object';
    } else if (ts.isArrayTypeNode(typeNode)) {
      return 'array';
    }

    return null;
  }
}
