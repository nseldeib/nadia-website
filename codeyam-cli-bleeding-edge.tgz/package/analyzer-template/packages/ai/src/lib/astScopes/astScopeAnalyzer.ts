import ts from 'typescript';
import { StatementInfo } from '~codeyam/types';
import {
  AnalysisContext,
  AnalysisIssue,
  AstScopeAnalysisResult,
  CompletenessInfo,
} from './types';
import { PatternHandler } from './patterns/patternHandler';
import { VariableDeclarationHandler } from './patterns/variableDeclarationHandler';
import { FunctionDeclarationHandler } from './patterns/functionDeclarationHandler';
import { ReturnStatementHandler } from './patterns/returnStatementHandler';
import { IfStatementHandler } from './patterns/ifStatementHandler';
import { BlockHandler } from './patterns/blockHandler';
import { ForStatementHandler } from './patterns/forStatementHandler';
import { ForInStatementHandler } from './patterns/forInStatementHandler';
import { ForOfStatementHandler } from './patterns/forOfStatementHandler';
import { WhileStatementHandler } from './patterns/whileStatementHandler';
import { DoStatementHandler } from './patterns/doStatementHandler';
import { SwitchStatementHandler } from './patterns/switchStatementHandler';
import { TryStatementHandler } from './patterns/tryStatementHandler';
import { BreakStatementHandler } from './patterns/breakStatementHandler';
import { StandaloneExpressionHandler } from './patterns/standaloneExpressionHandler';
import { TypeAndInterfaceHandler } from './patterns/typeAndInterfaceHandler';
import { nodeToSource } from './nodeToSource';
import { FileAnalyzer } from '~codeyam/analyze';
import { StructuredPath } from './paths';
import { processExpression } from './processExpression'; // Import the new function
import { ThrowStatementHandler } from './patterns/throwStatementHandler';

/**
 * AST-based Scope Analyzer - Extracts variable type structures and equivalence mappings
 * *
 * KEY CHARACTERISTICS:
 *
 * 1. Pattern-first traversal (not a naive visitor pattern):
 *    - Does NOT blindly traverse all nodes in the AST
 *    - Each handler selectively processes only relevant nodes for its pattern
 *    - Processing only occurs on explicitly registered patterns and node types
 *
 * 2. Deterministic analysis flag (isComplete): ⚠️ IMPORTANT
 *    - Name "isComplete" can be misleading: it's NOT about implementation completeness
 *    - True = "ALL information NEEDED for analysis CAN be extracted deterministically"
 *    - False = "SOME information REQUIRES LLM assistance/inference"
 *    - Critical decision point: when true, we can bypass LLM calls entirely
 *    - Undefined variables (like 'x = y' where 'y' is undefined) don't affect completeness
 *      as long as we can deterministically extract the necessary relationship
 *    - References that can be fully mapped (whether their targets exist or not) are "complete"
 *    - Simple patterns (assignments, function params, property access) are typically "complete"
 *
 * 3. Accuracy vs. completeness (isFullySupported vs. isComplete):
 *    - isFullySupported = "Did our implementation handle everything it encountered?"
 *    - isComplete = "Can all necessary information be extracted without guesswork?"
 *    - Example: For 'const x = complexExpression()', we may handle it (supported)
 *      but still need LLM to infer types (incomplete)
 *
 * 4. Non-blocking vs. blocking issues:
 *    - Non-blocking: Pattern recognized but partial information extracted
 *    - Blocking: Pattern fundamentally cannot be processed by current implementation
 *    - Both cause isComplete to be false, but handling differs downstream
 *
 * 5. Handler registration order matters:
 *    - First matching handler gets priority (StandaloneExpressionHandler is first)
 *    - No cascading/fallthrough between handlers
 *
 * 6. Selective child traversal:
 *    - Only specific node types trigger child traversal
 *    - Other node types don't automatically traverse children
 *
 * 7. PATH NOTATION REFERENCE:
 *    - Standard property:        "obj.prop.subprop"
 *    - Array indexing:           "arr[0]", "arr[index]"
 *    - Array elements:           "arr[]" (any element)
 *    - Dynamic properties:       "obj[key]" (access by variable)
 *    - Object keys:              "obj*key*" (for-in loop key)
 *    - Function parameters:      "functionName().signature[0]"
 *    - Function return values:   "functionName().functionCallReturnValue"
 *    - Return statements:        "returnValue" (special keyword)
 *
 * 8. SPECIAL FUNCTION HANDLING:
 *    - React useState:           "count": "setCount().signature[0]"
 *    - Array methods:
 *      • map(): "returnValue[]": "cyScope1()"
 *      • filter(): Preserves item structure
 *      • find(): "returnValue": "items[]"
 *      • reduce(): "result": "cyScope1()"
 *    - JSX components:           "Component().signature[0].propName"
 *    - Method chaining:          Each method tracked in full path
 *
 * This analyzer serves as the first phase in the scope analysis pipeline, potentially
 * bypassing LLM calls when deterministic analysis is sufficient. The isComplete flag
 * is the critical decision point for whether we can skip LLM processing entirely.
 *
 * FUNCTION RETURN VALUE HANDLING:
 *    * When one or more function calls appear on the RIGHT side of an equivalence mapping,
 *      the *last* one gets `.functionCallReturnValue` appended
 *    * We never append `.functionCallReturnValue` on the LEFT side ofeither the structure
 *      or equivalentVariables maps
 */
export class ASTScopeAnalyzer {
  private structure: Record<string, string> = {};
  private equivalentVariables: Record<string, string> = {};
  private sourceFile: ts.SourceFile;
  private statementInfo: StatementInfo;
  private issues: AnalysisIssue[] = [];
  private patternHandlers: PatternHandler[] = [];
  private fileAnalyzer: FileAnalyzer;

  constructor(fileAnalyzer: FileAnalyzer, statementInfo: StatementInfo) {
    this.statementInfo = statementInfo;

    this.fileAnalyzer = fileAnalyzer;
    this.sourceFile = fileAnalyzer.sourceFile;

    // Register pattern handlers
    this.registerPatternHandlers();
  }

  /**
   * Register all pattern handlers
   *
   * IMPORTANT: Registration order matters! More specialized handlers should be registered first,
   * and general catch-all handlers should be registered last. This ensures that specialized
   * handlers get first opportunity to process nodes they're designed for.
   */
  private registerPatternHandlers(): void {
    // Register specialized handlers first

    this.patternHandlers.push(new VariableDeclarationHandler());
    this.patternHandlers.push(new FunctionDeclarationHandler());
    this.patternHandlers.push(new ReturnStatementHandler());

    // Control flow statement handlers
    this.patternHandlers.push(new IfStatementHandler());
    this.patternHandlers.push(new BlockHandler());
    this.patternHandlers.push(new ForStatementHandler());
    this.patternHandlers.push(new ForInStatementHandler());
    this.patternHandlers.push(new ForOfStatementHandler());
    this.patternHandlers.push(new WhileStatementHandler());
    this.patternHandlers.push(new DoStatementHandler());
    this.patternHandlers.push(new SwitchStatementHandler());
    this.patternHandlers.push(new TryStatementHandler());
    this.patternHandlers.push(new ThrowStatementHandler());
    this.patternHandlers.push(new BreakStatementHandler());
    this.patternHandlers.push(new TypeAndInterfaceHandler());

    // Add the general-purpose handler last
    this.patternHandlers.push(new StandaloneExpressionHandler());
  }

  /**
   * Performs the analysis by identifying and processing patterns in the AST
   */
  analyze(): AstScopeAnalysisResult {
    // Debug log the source code
    // console.log('Analyzing source code:', this.scope.text);

    // Create analysis context
    const context: AnalysisContext = this.createAnalysisContext();

    // Process the AST with a pattern-first approach
    const relevantNodes = this.getNodesWithinRange(
      this.sourceFile,
      this.statementInfo.start,
      this.statementInfo.end,
    );
    // console.info('SOURCEFILE', this.sourceFile.getText());
    // console.info('RANGE', this.statementInfo.start, this.statementInfo.end, this.sourceFile.getText().slice(this.statementInfo.start, this.statementInfo.end));

    // console.info('RELEVANT NODES:\n\n', this.statementInfo.text);
    // relevantNodes.forEach((node, i) =>
    //   console.info(`RELEVANT NODE ${i}`, node.getText(this.sourceFile)),
    // );

    // console.info(
    //   'CHILD BOUNDARIES',
    //   this.statementInfo.childBoundaries.map((b) =>
    //     this.sourceFile.getText().slice(b.start, b.end),
    //   ),
    // );
    this.processNodes(relevantNodes, context);

    // for (const childBoundary of this.statementInfo.childBoundaries) {
    //   const boundaryText = this.sourceFile.getText().slice(childBoundary.start, childBoundary.end);
    //   console.info('CHILD', boundaryText);
    //   for (const equivalentVariableKey in this.equivalentVariables) {
    //     const equivalentVariableValue = this.equivalentVariables[equivalentVariableKey];
    //     for (const path of [equivalentVariableKey, equivalentVariableValue]) {
    //       console.info('CHECKING', path);
    //       console.info("REPLACE", path.replace(boundaryText, ''))
    //       if (path.replace(boundaryText, '').replace(/[\s\(\)]*/g, '') === '') {
    //         this.equivalentVariables[equivalentVariableKey] = 'cyScope3'
    //         delete this.equivalentVariables[equivalentVariableKey];
    //       }
    //     }
    //   }
    // }

    // Calculate completeness
    const completeness = this.calculateCompleteness();

    // Debug log the results
    // console.log(
    //   'Analysis results:',
    //   JSON.stringify(
    //     {
    //       structure: this.structure,
    //       equivalentVariables: this.equivalentVariables,
    //       isComplete:
    //         completeness.equivalences === 'full' &&
    //         completeness.structures === 'full',
    //       completeness,
    //     },
    //     null,
    //     2,
    //   ),
    // );

    // Debug log the issues
    // console.log(
    //   'Issues:',
    //   this.issues.map((issue) => ({
    //     nodeKind: ts.SyntaxKind[issue.nodeKind],
    //     category: issue.category,
    //     severity: issue.severity,
    //     message: issue.message,
    //   })),
    // );

    return {
      structure: this.structure,
      equivalentVariables: this.equivalentVariables,
      isComplete:
        completeness.equivalences === 'full' &&
        completeness.structures === 'full',
      completeness,
    };
  }

  private createAnalysisContext(): AnalysisContext {
    const context: AnalysisContext = {
      sourceFile: this.sourceFile,
      statementInfo: this.statementInfo,
      typeChecker: this.fileAnalyzer.typeChecker,
      addEquivalence: (leftSide, rightSide) =>
        this.addEquivalence(leftSide, rightSide),
      addType: (path, type) => this.addType(path, type),
      markUnsupported: (node, message, isBlocking) =>
        this.markUnsupported(node, message, isBlocking),
      markSemanticLimitation: (node, message) =>
        this.markSemanticLimitation(node, message),
      getStructuralPath: (node) => this.getStructuralPath(node, context),
      inferAndAddType: (path, node) => this.inferAndAddType(path, node),
      processNode: (node) => this.processNode(node, context),
      getTypeInfo: (path) => this.structure[path.toString()],
      inferTypeFromNode: (node) => this.inferTypeFromNode(node),
      inferTypeFromTsType: (tsType) => this.inferTypeFromTsType(tsType),
      getStructure: () => this.structure,
      getEquivalentVariables: () => this.equivalentVariables,
      getChildBoundary: (node) => this.getChildBoundary(node, context),
      isChildBoundary: (node) => this.isChildBoundary(node, context),
      addChildBoundaryEquivalence: (equivalence, node) =>
        this.addChildBoundaryEquivalence(equivalence, node, context),
      artificialReturnStatementProcessed: false,
      setArtificialReturnStatementProcessed: () =>
        this.setArtificialReturnStatementProcessed(context),
      isArtificialReturnStatement: (node) =>
        this.isArtificialReturnStatement(node, context),
      processExpression: (node, targetPath) =>
        processExpression({ node, context, targetPath }),
    };
    return context;
  }

  private getNodeRange(
    node: ts.Node,
    sourceFile: ts.SourceFile,
  ): { nodeStart: number; nodeEnd: number } {
    const sourceText = sourceFile.text;
    const sourceGetText = sourceFile.getText();
    const startWhiteSpaceDiff =
      sourceText.trimStart().length - sourceGetText.trimStart().length;
    return {
      nodeStart: node.getStart(sourceFile) + startWhiteSpaceDiff,
      nodeEnd: node.getEnd() + startWhiteSpaceDiff,
    };
  }

  private getNodesWithinRange(
    sourceFile: ts.SourceFile,
    rangeStart: number,
    rangeEnd: number,
  ): ts.Node[] {
    const nodes: ts.Node[] = [];

    const getNodeRange = this.getNodeRange;
    function visit(node: ts.Node) {
      const { nodeStart, nodeEnd } = getNodeRange(node, sourceFile);

      if (nodeStart >= rangeStart && nodeEnd <= rangeEnd + 1) {
        if (node.getText().length > 0) {
          nodes.push(node);
        }
        return; // Stop recursing into this node's children.
      }

      // Otherwise, keep checking its children.
      ts.forEachChild(node, visit);
    }

    visit(sourceFile);
    return nodes;
  }

  /**
   * Process a node by finding and applying the appropriate pattern handlers
   */
  private processNode(node: ts.Node, context: AnalysisContext) {
    if (context.isChildBoundary(node)) {
      // console.info("SKIPPING:\n\n", node.getText(context.sourceFile));
      return;
    }

    // if (
    //   ts.isJsxOpeningElement(node) ||
    //   ts.isJsxText(node) ||
    //   ts.isJsxClosingElement(node) ||
    //   ts.isJsxExpression(node) ||
    //   ts.isJsxSelfClosingElement(node)
    // ) {
    //   console.warn(
    //     `Saw JSX node: ${ts.SyntaxKind[node.kind]} with ts.isExpression(node) = ${ts.isExpression(node)}`,
    //   );
    // }

    let handled = false;
    for (const handler of this.patternHandlers) {
      if (handler.canHandle(node, context)) {
        handled = true;
        handler.process(node, context);
      }
    }
    if (!handled) {
      handled = true;
      if (ts.isSourceFile(node) || ts.isBlock(node)) {
        // For source files and blocks, process all statements
        node.statements.forEach((statement) => {
          this.processNode(statement, context);
        });
      } else if (ts.isVariableStatement(node)) {
        // For variable statements, process each declaration
        node.declarationList.declarations.forEach((declaration) => {
          this.processNode(declaration, context);
        });
      } else {
        handled = false;
      }
    }

    if (!handled) {
      if (this.isStatementOrDeclaration(node)) {
        // console.warn(
        //   `No handler found for node kind: ${ts.SyntaxKind[node.kind]}`,
        //   node.getText(context.sourceFile),
        //   new Error().stack,
        // );
        this.markUnsupported(
          node,
          `No handler found for node kind: ${ts.SyntaxKind[node.kind]}`,
          false, // Non-blocking
        );
      } else {
        // console.warn(
        //   `Completely unexpected node kind: ${node.kind} => ${ts.SyntaxKind[node.kind]}`,
        //   node.getText(context.sourceFile),
        //   new Error().stack,
        // );
      }
    }
  }

  private processNodes(nodes: ts.Node[], context: AnalysisContext) {
    // for (let node of nodes) {
    //   console.warn(
    //     `Top level processNodes: ${ts.SyntaxKind[node.kind]} = ${node.getText()}`,
    //     {
    //       isChildBoundary: this.isChildBoundary(node, context),
    //     },
    //   );
    // }
    for (const node of nodes) {
      this.processNode(node, context);
    }
  }

  private getChildBoundary(node: ts.Node, context: AnalysisContext) {
    return context.statementInfo.childBoundaries.find((childBoundary) => {
      return (
        node.getStart(context.sourceFile) >= childBoundary.start &&
        node.getEnd() <= childBoundary.end + 1 // accounting for optional ";"
      );
    });
  }

  private isChildBoundary(node: ts.Node, context: AnalysisContext): boolean {
    return !!context.getChildBoundary(node);
  }

  private addChildBoundaryEquivalence(
    equivalence: StructuredPath,
    node: ts.Node,
    context: AnalysisContext,
  ) {
    const childBoundary = context.getChildBoundary(node);
    if (childBoundary) {
      let childBoundaryName = childBoundary.name;
      if (childBoundaryName) {
        // TODO: This is frustrating. Would be nice to improve how this is tracked.
        if (context.statementInfo.text.includes(childBoundaryName + 'F')) {
          childBoundaryName = childBoundaryName + 'F';
        } else if (
          context.statementInfo.text.includes(childBoundaryName + '()')
        ) {
          childBoundaryName = childBoundaryName + '()';
        }

        const childBoundaryPath = StructuredPath.fromBase(childBoundaryName);

        context.addEquivalence(equivalence, childBoundaryPath);
        context.addType(equivalence, 'unknown');
        context.addType(childBoundaryPath, 'unknown');
      }
    }
  }

  private setArtificialReturnStatementProcessed(context: AnalysisContext) {
    context.artificialReturnStatementProcessed = true;
  }

  private isArtificialReturnStatement(
    node: ts.Node,
    context: AnalysisContext,
  ): boolean {
    if (context.artificialReturnStatementProcessed) return false;
    if (ts.isReturnStatement(node)) return false;
    if (node.getText(context.sourceFile).startsWith('return')) return false;
    if (!context.statementInfo.text.startsWith('return')) return false;
    if (context.statementInfo.start !== node.getStart(context.sourceFile))
      if (ts.isReturnStatement(node)) return false;
    if (node.getText(context.sourceFile).startsWith('return')) return false;
    if (!context.statementInfo.text.startsWith('return')) return false;
    if (context.statementInfo.start !== node.getStart(context.sourceFile))
      return false;
    if (context.statementInfo.end !== node.getEnd()) return false;
    return true;
  }

  /**
   * Check if a node is a statement or declaration (i.e., a high-level construct)
   */
  private isStatementOrDeclaration(node: ts.Node): boolean {
    return (
      ts.isStatement(node) ||
      ts.isFunctionDeclaration(node) ||
      ts.isClassDeclaration(node) ||
      ts.isInterfaceDeclaration(node) ||
      ts.isTypeAliasDeclaration(node) ||
      ts.isEnumDeclaration(node) ||
      ts.isVariableDeclaration(node) ||
      ts.isExpression(node)
    );
  }

  /**
   * Calculate detailed completeness information
   *
   * This determines whether all necessary information can be extracted deterministically
   * without requiring LLM assistance (isComplete = true) or if some aspects need
   * inference or guesswork (isComplete = false).
   *
   * Completeness is NOT about whether our implementation handled everything
   * successfully - it's about whether we can bypass the LLM for this analysis.
   * Simple patterns with references to undefined variables can still be "complete"
   * if we can deterministically extract the relationship/structure.
   */
  private calculateCompleteness(): CompletenessInfo {
    // Check if there are any blocking issues
    const hasBlockingIssues = this.issues.some(
      (issue) => issue.severity === 'blocking',
    );

    // Check if there are any non-blocking issues
    const hasNonBlockingIssues = this.issues.some(
      (issue) => issue.severity === 'non-blocking',
    );

    // Check specifically for semantic limitations
    const hasSemanticLimitations = this.issues.some(
      (issue) => issue.category === 'semantic-limitation',
    );

    // If we have semantic limitations, we consider the analysis incomplete
    // even if we've successfully processed all syntax
    return {
      // Equivalence completeness
      equivalences: hasBlockingIssues
        ? 'invalid'
        : hasNonBlockingIssues || hasSemanticLimitations
          ? 'partial'
          : 'full',

      // Structure completeness
      structures: hasBlockingIssues
        ? 'invalid'
        : hasNonBlockingIssues || hasSemanticLimitations
          ? 'partial'
          : 'full',

      // Issues
      issues: this.issues,
    };
  }

  /**
   * Mark a node as unsupported
   */
  private markUnsupported(
    node: ts.Node,
    message: string,
    isBlocking: boolean,
  ): void {
    this.issues.push({
      nodeKind: node.kind,
      nodeText: node.getText(this.sourceFile),
      category: 'unsupported-node',
      severity: isBlocking ? 'blocking' : 'non-blocking',
      message,
    });
  }

  /**
   * Mark a semantic limitation (pattern is syntactically supported but semantically not fully understood)
   */
  private markSemanticLimitation(node: ts.Node, message: string): void {
    this.issues.push({
      nodeKind: node.kind,
      nodeText: node.getText(this.sourceFile),
      category: 'semantic-limitation',
      severity: 'non-blocking',
      message,
    });
  }

  /**
   * Gets a structured representation of an expression's path
   *
   * Returns paths only for expressions that represent structural elements
   * (variables, properties, etc.), not literal values.
   *
   * This filters out literals since they don't represent useful structural
   * paths in the code and would just add noise to the structure.
   *
   * NOTE: This method now returns StructuredPath objects directly instead of
   * converting them to strings, as part of our path representation migration.
   *
   * @param node The expression to get a path for
   * @param context The analysis context
   */
  private getStructuralPath(
    node: ts.Expression,
    context: AnalysisContext,
  ): StructuredPath | null {
    return (
      StructuredPath.fromNode(node, this.sourceFile) ??
      nodeToSource(node, this.sourceFile)
    );
  }

  /**
   * Adds an equivalence relationship between two variable paths
   */
  private addEquivalence(
    leftSide: StructuredPath,
    rightSide: StructuredPath,
  ): void {
    // Skip adding equivalences if left side is a literal path.
    if (leftSide?.isLiteral()) {
      return;
    }

    const leftSideStr = leftSide?.toLeftHandSideString();
    const rightSideStr = rightSide?.toRightHandSideString();

    if (leftSideStr && rightSideStr && leftSideStr !== rightSideStr) {
      this.equivalentVariables[leftSideStr] = rightSideStr;
    }
  }

  /**
   * Adds a type for a variable path
   */
  private addType(path: string | StructuredPath, type: string): void {
    if (path instanceof StructuredPath && path.isLiteral()) {
      return;
    }

    const pathStr = path.toString();

    // Do not overwrite a more specific type with a less specific one
    if (
      this.structure[pathStr] &&
      this.structure[pathStr] !== 'unknown' &&
      type === 'unknown'
    )
      return;
    this.structure[pathStr] = type;
  }

  /**
   * Get a simplified type string from a TypeScript Type object
   * This converts TypeScript's internal type representation to our type system
   */
  private inferTypeFromTsType(tsType: ts.Type): string {
    // Handle primitive types
    if (tsType.symbol?.getName() === 'Date') return 'date';
    if (tsType.flags & ts.TypeFlags.String) return 'string';
    if (tsType.flags & ts.TypeFlags.StringLiteral) return 'string';
    if (tsType.flags & ts.TypeFlags.Number) return 'number';
    if (tsType.flags & ts.TypeFlags.NumberLiteral) return 'number';
    if (tsType.flags & ts.TypeFlags.Boolean) return 'boolean';
    if (tsType.flags & ts.TypeFlags.BooleanLiteral) return 'boolean';
    if (tsType.flags & ts.TypeFlags.Undefined) return 'undefined';
    if (tsType.flags & ts.TypeFlags.Null) return 'null';

    // Handle array type
    if (tsType.flags & ts.TypeFlags.Object) {
      const objectType = tsType as ts.ObjectType;

      // Check for arrays
      if (
        objectType.objectFlags & ts.ObjectFlags.Reference &&
        objectType.symbol &&
        objectType.symbol.name === 'Array'
      ) {
        return 'array';
      }

      // Check for other common built-in types
      if (objectType.symbol) {
        const typeName = objectType.symbol.name.toLowerCase();
        if (typeName === 'date') return 'date';
        if (typeName === 'map') return 'map';
        if (typeName === 'set') return 'set';
        if (typeName === 'promise') return 'promise';
      }

      return 'unknown';
    }

    // Handle union types - we simplify unions to the most specific common type
    if (tsType.flags & ts.TypeFlags.Union) {
      const unionType = tsType as ts.UnionType;

      // Check if it's a string literal union
      const isAllStringLiterals = unionType.types.every(
        (t) => (t.flags & ts.TypeFlags.StringLiteral) !== 0,
      );
      if (isAllStringLiterals) return 'string';

      // Check if it's a number literal union
      const isAllNumberLiterals = unionType.types.every(
        (t) => (t.flags & ts.TypeFlags.NumberLiteral) !== 0,
      );
      if (isAllNumberLiterals) return 'number';

      // For mixed unions, return 'unknown'
      return 'unknown';
    }

    // Default to unknown for any other type
    return 'unknown';
  }

  /**
   * Infer type from a node using TypeScript's TypeChecker
   */
  private inferTypeFromNode(node: ts.Node): string {
    if (!ts.isExpression(node)) {
      return 'unknown';
    }
    try {
      // Handle common literal cases directly for better reliability
      if (ts.isNumericLiteral(node)) {
        return 'number';
      }
      if (node.kind === ts.SyntaxKind.NullKeyword) {
        return 'null';
      }
      if (
        ts.isStringLiteral(node) ||
        ts.isNoSubstitutionTemplateLiteral(node) ||
        ts.isTemplateExpression(node)
      ) {
        return 'string';
      }
      if (
        node.kind === ts.SyntaxKind.TrueKeyword ||
        node.kind === ts.SyntaxKind.FalseKeyword
      ) {
        return 'boolean';
      }
      if (ts.isFunctionLike(node)) {
        return 'function';
      }
      if (ts.isArrayLiteralExpression(node)) {
        return 'array';
      }
      if (ts.isObjectLiteralExpression(node)) {
        return 'object';
      }
      if (ts.isConditionalExpression(node)) {
        const trueType = this.inferTypeFromNode(node.whenTrue);
        const falseType = this.inferTypeFromNode(node.whenFalse);

        if (trueType === falseType) {
          return trueType;
        }

        return trueType === 'unknown' ? falseType : trueType;
      }
      if (ts.isParenthesizedExpression(node)) {
        return this.inferTypeFromNode(node.expression);
      }
      if (ts.isBinaryExpression(node)) {
        const operator = node.operatorToken.kind;
        const isComparisonOperator =
          operator === ts.SyntaxKind.EqualsEqualsToken ||
          operator === ts.SyntaxKind.EqualsEqualsEqualsToken ||
          operator === ts.SyntaxKind.ExclamationEqualsToken ||
          operator === ts.SyntaxKind.ExclamationEqualsEqualsToken ||
          operator === ts.SyntaxKind.LessThanToken ||
          operator === ts.SyntaxKind.LessThanEqualsToken ||
          operator === ts.SyntaxKind.GreaterThanToken ||
          operator === ts.SyntaxKind.GreaterThanEqualsToken;

        if (isComparisonOperator) {
          return 'boolean';
        }

        const leftType = this.inferTypeFromNode(node.left);
        const rightType = this.inferTypeFromNode(node.right);

        return leftType === 'unknown' ? rightType : leftType;
      }

      // Get the type from TypeScript's type checker for more complex cases
      const tsType = this.fileAnalyzer.typeChecker.getTypeAtLocation(node);
      const typeFromTs = this.inferTypeFromTsType(tsType);

      // Convert to our simplified type system
      return typeFromTs;
    } catch (error) {
      console.error('Error inferring type from node:', error);
      return 'unknown';
    }
  }

  /**
   * Tries to infer the type of a node and adds it to the structure
   */
  private inferAndAddType(path: string | StructuredPath, node: ts.Node): void {
    // Use TypeScript's TypeChecker to get more accurate type information
    const type = this.inferTypeFromNode(node);

    // Add the type to the structure
    this.addType(path, type);

    // If this is a literal value being assigned to a property, extract the path
    // This handles the case where we're processing a node that's part of an assignment
    if (
      ts.isNumericLiteral(node) ||
      ts.isStringLiteral(node) ||
      node.kind === ts.SyntaxKind.TrueKeyword ||
      node.kind === ts.SyntaxKind.FalseKeyword
    ) {
      const literalValue = nodeToSource(node, this.sourceFile);
      const pathStr = path.toString();
      if (this.equivalentVariables[pathStr] === literalValue.toString()) {
        this.addType(path, type);
      }
    }
  }
}
