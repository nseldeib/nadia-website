import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';

/**
 * Handler for block statements ({ ... })
 *
 * Processes all statements within a code block
 */
export class BlockHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return ts.isBlock(node);
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    if (!ts.isBlock(node)) return false;

    // Process all statements in the block
    for (const statement of node.statements) {
      context.processNode(statement);
    }

    // Blocks themselves don't introduce new structure/equivalence mappings
    // They just contain other statements that might. So we always return true
    // as we've successfully processed the block itself.
    return true;
  }
}
