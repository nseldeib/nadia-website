import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';
import { StructuredPath } from '../paths';

/**
 * Handler for for...in loops
 *
 * Processes:
 * - The initializer (e.g., const key in object)
 * - The expression being iterated over
 * - The loop body
 */
export class ForInStatementHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return ts.isForInStatement(node);
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    if (!ts.isForInStatement(node)) return false;

    // Process the expression being iterated over first (e.g., object)
    context.processExpression(node.expression);

    // Get the path of the object being iterated
    const expressionPath = context.getStructuralPath(node.expression);

    // If the initializer is a variable declaration with an identifier, establish equivalence
    // to indicate it's iterating over the keys of the expression
    if (ts.isVariableDeclarationList(node.initializer)) {
      const declarations = node.initializer.declarations;
      if (
        declarations.length === 1 &&
        declarations[0].name &&
        ts.isIdentifier(declarations[0].name)
      ) {
        const variableName = StructuredPath.fromBase(declarations[0].name.text);

        // Add type for the key variable (string for object keys)
        context.addType(variableName, 'string');

        if (expressionPath) {
          // For for...in loops, the variable is equivalent to the keys of the object
          // We represent this with a *key* suffix to indicate it's a key, not a value
          context.addEquivalence(variableName, expressionPath.withKey('key'));
        }
      }
    } else if (ts.isIdentifier(node.initializer)) {
      // If the initializer is directly an identifier (rare but possible)
      const variableName = StructuredPath.fromBase(node.initializer.text);

      // Add type for the key variable
      context.addType(variableName, 'string');

      if (expressionPath) {
        context.addEquivalence(variableName, expressionPath.withKey('key'));
      }
    } else {
      context.processExpression(node.initializer);
    }

    // Process the loop body
    context.processNode(node.statement);

    // We can handle basic for...in loops completely
    return true;
  }
}
