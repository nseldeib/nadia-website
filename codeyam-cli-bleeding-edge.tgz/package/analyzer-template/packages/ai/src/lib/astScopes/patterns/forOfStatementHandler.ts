import ts from 'typescript';
import { AnalysisContext } from '../types';
import { PatternHandler } from './patternHandler';
import { StructuredPath } from '../paths';

/**
 * Handler for for...of loops
 *
 * Processes:
 * - The initializer (e.g., const item of array)
 * - The expression being iterated over
 * - The loop body
 */
export class ForOfStatementHandler implements PatternHandler {
  canHandle(node: ts.Node): boolean {
    return ts.isForOfStatement(node);
  }

  process(node: ts.Node, context: AnalysisContext): boolean {
    if (!ts.isForOfStatement(node)) return false;

    // Process the expression being iterated over first (e.g., array)
    context.processExpression(node.expression);

    // Get the path of the iterable being used
    const expressionPath = context.getStructuralPath(node.expression);

    // If we have a valid expression path, ensure it's marked as an iterable with element placeholder
    if (expressionPath) {
      // Check the existing type information
      const existingType = context.getTypeInfo(expressionPath);

      // If no type exists or is "unknown", explicitly set to "array"
      // For a for...of loop, we can guarantee it's at least array-like
      if (!existingType || existingType === 'unknown') {
        context.addType(expressionPath, 'array');
      }

      // Add the array element placeholder to the structure if not already present
      const elementPath = expressionPath.withElement('*');
      if (!context.getTypeInfo(elementPath)) {
        // For the element type, we don't have direct inference - use unknown for now
        // TypeScript's type system could theoretically provide this but it's complex
        context.addType(elementPath, 'unknown');
      }
    }

    // If the initializer is a variable declaration with an identifier, establish equivalence
    // to indicate it's an element of the expression
    if (ts.isVariableDeclarationList(node.initializer)) {
      const declarations = node.initializer.declarations;
      if (
        declarations.length === 1 &&
        declarations[0].name &&
        ts.isIdentifier(declarations[0].name)
      ) {
        const variableName = StructuredPath.fromBase(declarations[0].name.text);

        // We'll set the type later after getting element type info from the array

        if (expressionPath) {
          const elementExpression = expressionPath.withElement('*');
          // For for...of loops, the variable is equivalent to an element of the array
          // We use [] to indicate it's an array element
          context.addEquivalence(variableName, elementExpression);

          // Transfer the element type information if available from the array literal handler
          const elementType =
            context.getTypeInfo(elementExpression) || 'unknown';

          // Always add the variable to the structure, with the best type we have
          context.addType(variableName, elementType);
        }
      }
    } else if (ts.isIdentifier(node.initializer)) {
      // If the initializer is directly an identifier (rare but possible)
      const variableName = StructuredPath.fromBase(node.initializer.text);

      if (expressionPath) {
        const elementExpression = expressionPath.withElement('*');

        context.addEquivalence(variableName, elementExpression);

        // Transfer the element type information if available
        const elementType = context.getTypeInfo(elementExpression) || 'unknown';

        // Always add the variable to the structure, with the best type we have
        context.addType(variableName, elementType);
      } else {
        // Add default type for the item variable if we couldn't get expression path
        context.addType(variableName, 'unknown');
      }
    } else {
      context.processExpression(node.initializer);
    }

    // Process the loop body
    context.processNode(node.statement);

    // The loop is fully handled if we can get the element type from the array
    if (expressionPath) {
      const elementPath = expressionPath.withElement('*');
      const elementType = context.getTypeInfo(elementPath);
      if (elementType && elementType !== 'unknown') {
        return true; // We have element type info, so this is completely handled
      }
    }

    // If we don't have proper element type info, mark as incomplete
    return false;
  }
}
