import ts from 'typescript';
import { AnalysisContext } from '../types';

/**
 * Interface for pattern handlers
 *
 * Pattern handlers are responsible for recognizing and processing specific AST patterns.
 * Each handler focuses on a specific pattern (e.g., variable declarations, function declarations)
 * and only processes the parts of the AST relevant to that pattern.
 */
export interface PatternHandler {
  /**
   * Check if this handler can process the given node
   */
  canHandle(node: ts.Node, context: AnalysisContext): boolean;

  /**
   * Process a node that matches this pattern
   *
   * @param node The node to process
   * @param context The analysis context
   * @returns isFullySupported - Whether our implementation handled everything (true) or
   *          encountered aspects it couldn't process fully (false).
   *
   *          NOTE: This does NOT directly determine isComplete, which answers
   *          a different question: "Can the necessary information be extracted
   *          deterministically without LLM assistance?" Even partially supported
   *          patterns may yield deterministic (complete) analysis for the parts
   *          that matter.
   */
  process(node: ts.Node, context: AnalysisContext): boolean;
}
