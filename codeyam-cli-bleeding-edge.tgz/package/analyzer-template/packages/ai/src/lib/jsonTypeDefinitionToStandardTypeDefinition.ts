import { JsonTypeDefinition } from '~codeyam/types';
import splitOutsideParentheses from './splitOutsideParentheses';

const spacing = '    ';
export default function jsonTypeDefinitionToStandardTypeDefinition(
  jsonTypeDefinition:
    | string
    | string[]
    | JsonTypeDefinition
    | JsonTypeDefinition[],
  level = 0,
): string {
  const typeDefinitions: string[] = [];

  if (!jsonTypeDefinition || typeof jsonTypeDefinition !== 'object')
    return 'any';

  const keys = Object.keys(jsonTypeDefinition);

  if (keys.length === 0) return 'any';

  for (const key of keys) {
    const value = jsonTypeDefinition[key];

    if (key.includes('.')) {
      const keyParts = splitOutsideParentheses(key);
      typeDefinitions.push(
        `${keyParts[0]}: ${jsonTypeDefinitionToStandardTypeDefinition({ [keyParts.slice(1).join('.')]: value }, level + 1)}`,
      );
    } else if (Array.isArray(value)) {
      if (typeof value[0] === 'string') {
        typeDefinitions.push(`${key}: ${value[0]}[]`);
      } else {
        typeDefinitions.push(
          `${key}: ${jsonTypeDefinitionToStandardTypeDefinition(value[0], level + 1)}[]`,
        );
      }
    } else if (typeof value === 'string') {
      typeDefinitions.push(`${key}: ${value}`);
    } else {
      typeDefinitions.push(
        `${key}: ${jsonTypeDefinitionToStandardTypeDefinition(value, level + 1)}`,
      );
    }
  }
  const values = typeDefinitions.join(`;\n${spacing.repeat(level + 1)}`);
  return `{\n${spacing.repeat(level + 1)}${values};\n${spacing.repeat(level)}}`;
}
