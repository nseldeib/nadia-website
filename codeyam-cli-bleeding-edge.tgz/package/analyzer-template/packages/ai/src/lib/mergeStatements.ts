import { LlmCall } from '~codeyam/types';
import cleanOutBoundary from './cleanOutBoundary';
import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from './splitOutsideParentheses';

export interface Statement {
  structure: { [key: string]: string };
  equivalentVariables: { [key: string]: string };
  llmCall?: LlmCall;
}

export default function mergeStatements(statements: Statement[]) {
  // This should be handled by the AST Analyzer but it currently has a bug
  const ensureFunctionCallReturnValue = (path: string, value: string) => {
    if (path.endsWith(')') && value !== 'function') {
      return `${path}.functionCallReturnValue`;
    }
    return path;
  };

  const deBinaryPath = (path: string) => {
    const binarySymbols = ['??', '||'];
    const debinaryContents = (contents: string, preParts, postParts) => {
      for (const symbol of binarySymbols) {
        if (contents.includes(symbol)) {
          const binaryParts = contents.split(symbol).map((p) => p.trim());
          return binaryParts
            .flatMap((p) => {
              if (p === '""' || p === "''" || p === '[]' || p === '{}') {
                return;
              }

              return joinParenthesesAndArrays([...preParts, p, ...postParts]);
            })
            .filter(Boolean);
        }
      }

      return [joinParenthesesAndArrays([...preParts, contents, ...postParts])];
    };

    const pathParts = splitOutsideParenthesesAndArrays(path).map((p) =>
      p.replace(/\?$/, '').trim(),
    );
    for (let i = 0; i < pathParts.length; i++) {
      const part = pathParts[i];
      if (part.match(/^\s*\(.*\)\s*$/)) {
        const contents = part.replace(/^\s*\(/, '').replace(/\)\s*$/, '');
        return debinaryContents(
          contents,
          pathParts.slice(0, i),
          pathParts.slice(i + 1),
        );
      }

      for (const symbol of binarySymbols) {
        const cleanPart = cleanOutBoundary(cleanOutBoundary(part), '[', ']');
        if (cleanPart.includes(symbol)) {
          return debinaryContents(path, [], []);
        }
      }
    }

    return [path];
  };

  const checkStructureKey = (
    key: string,
    value: string,
    mapping: { [key: string]: string },
  ) => {
    if (!mapping[key] || mapping[key] === 'unknown') {
      mapping[key] = value;
    }
  };

  const structure = statements.reduce((acc, result) => {
    for (const [key, value] of Object.entries(result.structure ?? {})) {
      const validatedPath = ensureFunctionCallReturnValue(key, value);

      if (validatedPath !== key) {
        for (const [equivalentKey, equivalentValue] of Object.entries(
          result.equivalentVariables ?? {},
        )) {
          if (equivalentKey === key) {
            result.equivalentVariables[validatedPath] = equivalentValue;
            delete result.equivalentVariables[key];
          } else if (equivalentValue === key) {
            result.equivalentVariables[equivalentKey] = validatedPath;
          }
        }
      }

      const nonOptionalKey = validatedPath
        .replace(/\?\./g, '.')
        .replace(/\?\[/g, '[')
        .replace(/\?$/g, '')
        .trim();
      const keyOptions = deBinaryPath(nonOptionalKey);
      for (const keyOption of keyOptions) {
        checkStructureKey(keyOption, value, acc);
      }
    }
    return acc;
  }, {});

  const equivalentVariables = statements.reduce((acc, result) => {
    for (const [key, value] of Object.entries(
      result.equivalentVariables ?? {},
    )) {
      const keyOptions = deBinaryPath(key);
      const valueOptions = deBinaryPath(value);
      delete result.equivalentVariables[key];
      if (keyOptions.length === 2) {
        if (valueOptions.length === 2) {
          acc[keyOptions[0]] = valueOptions[0];
          result.equivalentVariables[keyOptions[0]] = valueOptions[1];
          acc[keyOptions[1]] = valueOptions[0];
          result.equivalentVariables[keyOptions[1]] = valueOptions[1];
        } else {
          result.equivalentVariables[keyOptions[0]] = valueOptions[0];
          result.equivalentVariables[keyOptions[1]] = valueOptions[0];
        }
      } else {
        if (valueOptions.length === 2) {
          acc[keyOptions[0]] = valueOptions[0];
          result.equivalentVariables[keyOptions[0]] = valueOptions[1];
        } else {
          result.equivalentVariables[keyOptions[0]] = valueOptions[0];
        }
      }
    }

    for (const [key, value] of Object.entries(
      result.equivalentVariables ?? {},
    )) {
      if (acc[key]) {
        if (acc[key] === value) continue;

        let duplicateId = 1;
        while (acc[`${key}::cyDuplicateKey${duplicateId}::`]) {
          duplicateId++;
        }
        acc[`${key}::cyDuplicateKey${duplicateId}::`] = value;
      } else {
        acc[key] = value;
      }
    }
    return acc;
  }, {});

  const llmCalls = statements.map((result) => result.llmCall).filter(Boolean);

  return { structure, equivalentVariables, llmCalls };
}
