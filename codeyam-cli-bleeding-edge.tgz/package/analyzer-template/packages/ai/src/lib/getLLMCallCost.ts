import { AI } from './types';
import Model = AI.Model;

const ONE_MILLION = 1000000;

// Number of USD spent on an OpenAI completion call
// OpenAI specific for now
export function getLLMCallCost({
  model,
  usage,
}: {
  model: Model;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
  };
}) {
  const MODEL_PRICING = PRICING[model];
  if (!MODEL_PRICING) {
    return null;
  }
  return (
    usage.prompt_tokens * (MODEL_PRICING.input / ONE_MILLION) +
    usage.completion_tokens * (MODEL_PRICING.output / ONE_MILLION)
  );
}

type ModelPricing = {
  input: number; // USD per 1M tokens
  output: number; // USD per 1M tokens
};

const PRICING: Partial<Record<Model, ModelPricing>> = {
  [Model.OPENAI_GPT5]: { input: 1.25, output: 10.0 },
  [Model.OPENAI_GPT5_MINI]: { input: 0.25, output: 2.0 },
  [Model.OPENAI_GPT5_NANO]: { input: 0.05, output: 0.4 },
  [Model.OPENAI_GPT4_1]: { input: 2.0, output: 8.0 },
  [Model.OPENAI_GPT4_1_MINI]: { input: 0.4, output: 1.6 },
  [Model.OPENAI_GPT4_O]: { input: 2.5, output: 10.0 },
  [Model.OPENAI_GPT4_O_MINI]: { input: 0.15, output: 0.6 },
};
