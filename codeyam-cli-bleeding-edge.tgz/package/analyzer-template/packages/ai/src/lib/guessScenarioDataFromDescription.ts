import { saveLlmCall } from '~codeyam/aws/dynamodb';
import { ScenariosDataStructure, Scenario } from '~codeyam/types';
import * as lib from '.';
import completionCall from './completionCall';
import guessNewScenarioDataFromDescriptionGenerator from './promptGenerators/guessNewScenarioDataFromDescriptionGenerator';
import guessEditScenarioDataFromDescriptionGenerator from './promptGenerators/guessEditScenarioDataFromDescriptionGenerator';
import { DEFAULT_LARGER_MODEL } from '~codeyam/ai';

export interface GuessScenarioDataFromDescriptionArgs {
  description: string;
  editingMockName?: string;
  editingMockData?: { [key: string]: unknown };
  existingScenarios: Scenario[];
  scenariosDataStructure: ScenariosDataStructure;
  model?: lib.types.AI.Model;
}

export default async function generateEntityScenarios({
  description,
  editingMockName,
  editingMockData,
  existingScenarios,
  scenariosDataStructure,
  model,
}: GuessScenarioDataFromDescriptionArgs): Promise<
  Scenario['metadata']['data'] | null
> {
  const prompt = editingMockName
    ? guessEditScenarioDataFromDescriptionGenerator({
        description,
        editingMockName,
        editingMockData,
        existingScenarios,
        scenariosDataStructure,
      })
    : guessNewScenarioDataFromDescriptionGenerator({
        description,
        existingScenarios,
        scenariosDataStructure,
      });

  const response = await completionCall({
    type: 'guessScenarioDataFromDescription',
    systemMessage: editingMockName
      ? editSystemMessage(editingMockData)
      : NEW_SYSTEM_MESSAGE,
    prompt,
    model: model ?? DEFAULT_LARGER_MODEL,
  });

  await saveLlmCall({
    object_type: 'guessScenarioDataFromDescription',
    object_id: 'new',
    propsJson: {
      description,
      editingMockName,
      editingMockData,
      existingScenarios,
      scenariosDataStructure,
      model,
    },
    ...response.stats,
  });

  const { completion: scenarioDataString } = response;

  if (!scenarioDataString) {
    console.log('CodeYam: guessing scenario data failed: No response from AI');
    return null;
  }

  return lib.parsers.parseJsonSafe(
    scenarioDataString,
  ) as Scenario['metadata']['data'];
}

const NEW_SYSTEM_MESSAGE = `
You will be provided with a list of data secnarios for a component and the overall structure for the data. Additionally you'll receive a description for a new scenario written by the user.

Your goal is to add one scenario to the list of existing scenarios by generating an english name, proper description, and a JSON data structure that describes the data that would be used in a scenario for the code.

The data for the scenario will be merged with the "Default Scenario" data, so you don't need to replicate any data in the default scenario but must overwrite any data that should be different.

You must respond with valid JSON following this format of this TS type definition:
\`\`\`
export type ScenarioData = {
  name: string;
  description: string;
  data: {
    mockData: { [key: string]: unknown };
    argumentsData: { [key: string]: unknown };
  };
};

\`\`\`
`;

const editSystemMessage = (editingMockData?: { [key: string]: unknown }) => `
You will be provided with a list of data secnarios for a component and the overall structure for the data. Additionally you'll receive a description for a new scenario written by the user.

Your goal is to edit one of the scenarios, named as the "Mock Scenario that should be edited".
${
  editingMockData
    ? `
We only want to edit a specific portion of the data, which is provided in the "The portion of the data that should be edited" section. You should only change the data that is provided in this section.`
    : ''
}

Always return the complete data structure for the scenario, with both mockData and argumentsData, even if you only changed a small portion of the data.

You must respond with valid JSON following this type definition:
\`\`\`
{
  data: {
    mockData: { [key: string]: unknown };
    argumentsData: { [key: string]: unknown };
  }
}
\`\`\`
`;
