import { saveLlmCall } from '~codeyam/aws/dynamodb';
import {
  FileProp,
  Mock,
  ScenariosDataStructure,
  Scenario,
  ScenarioData,
} from '~codeyam/types';
import completionCall from './completionCall';
import guessScenarioDataFromNameGenerator from './promptGenerators/guessScenarioDataFromNameGenerator';
import * as lib from '../lib';

export interface GuessScenarioDataFromNameArgs {
  newScenarioName: string;
  mocks: Mock[];
  props: FileProp[];
  existingScenarios: Scenario[];
  scenariosDataStructure: ScenariosDataStructure;
  model?: lib.types.AI.Model;
}

export default async function generateEntityScenarios({
  newScenarioName,
  mocks,
  props,
  existingScenarios,
  scenariosDataStructure,
  model,
}: GuessScenarioDataFromNameArgs): Promise<ScenarioData | null> {
  const prompt = guessScenarioDataFromNameGenerator({
    newScenarioName,
    mocks,
    props,
    existingScenarios,
    scenariosDataStructure,
  });

  console.log(prompt);

  const response = await completionCall({
    type: 'guessScenarioDataFromName',
    systemMessage: SYSTEM_MESSAGE,
    prompt,
    model,
  });

  await saveLlmCall({
    object_type: 'guessScenario',
    object_id: 'new',
    propsJson: {
      newScenarioName,
      mocks,
      props,
      existingScenarios,
      scenariosDataStructure,
      model,
    },
    ...response.stats,
  });

  const { completion: scenarioDataString } = response;
  if (!scenarioDataString) {
    console.log('CodeYam: guessing scenario data failed: No response from AI');
    return null;
  }

  return lib.parsers.parseJsonSafe(scenarioDataString) as ScenarioData;
}

const SYSTEM_MESSAGE = `
You will be provided with a list of mocks and props for a TypeScript React component, as well as its current "scenarios". Additionally you'll receive a name for a new scenario.

Your goal is to add one scenario to the list of existing scenarios by generating an english description and a JSON data structure that describes the data that would be used in a scenario for the code.

You must respond with valid JSON following this format of this TS type definition:
\`\`\`
type ScenarioData = {
  scenarioName: string;
  scenarioDescription: string;
  data: {
    mockData: { [key: string]: unknown };
    argumentsData: { [key: string]: unknown }[];
  };
};
\`\`\`
`;
