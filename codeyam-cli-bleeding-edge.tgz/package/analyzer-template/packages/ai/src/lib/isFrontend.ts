export default function isFrontend(filePath: string): boolean {
  const frontendExtensions = ['.jsx', '.tsx'];
  return frontendExtensions.some((ext) => filePath.endsWith(ext));
}
