import commitMessageGenerator from './promptGenerators/commitMessageGenerator';
import { Commit } from '~codeyam/types';
import completionCall from './completionCall';

export default async function commitMessage({ commit }: { commit: Commit }) {
  const prompt = commitMessageGenerator(commit);

  const response = await completionCall({
    type: 'commitMessage',
    systemMessage:
      'You are an expert coder and a succint writer / summarizer capable of identifying the most important parts of a commit change and describing them in simple terms.',
    prompt,
  });

  return response;
}
