import OpenAI from 'openai';
import * as lib from '../lib';
import { getLLMCallCost } from './getLLMCallCost';

export function getLLMCallStats({
  chatRequest,
  chatCompletion,
  model,
}: {
  chatRequest: lib.types.AI.ChatRequest;
  chatCompletion: OpenAI.ChatCompletion;
  model: lib.types.AI.Model;
}): lib.types.LlmCallStats {
  const usage = chatCompletion.usage || {
    prompt_tokens: 0,
    completion_tokens: 0,
  };

  return {
    model,
    prompt_type: chatRequest.type,
    system_message: chatRequest.messages.system,
    prompt_text: chatRequest.messages.prompt,
    response: JSON.stringify(chatCompletion, null, 2),
    input_tokens: usage.prompt_tokens,
    output_tokens: usage.completion_tokens,
    cost: Math.floor(
      (usage.prompt_tokens * (0.01 / 1000) +
        usage.completion_tokens * (0.03 / 1000)) *
        lib.COST_MULTIPLIER,
    ),
  };
}

/**
 * It looks like this function can be massively simplified, and I (AG) think
 * that we aren't using openrouter anymore. But, until this is figured out, it
 * might not be worth refactoring and messing something subtle up. Ideally
 * whatever implicit functionality is in here can be represented in the new
 * `getLLMCallStats` such that this get replaced by it.
 */
export function getLLMCallStatsOld({
  chatRequest,
  chatCompletion,
  model,
}: {
  chatRequest: lib.types.AI.ChatRequest;
  chatCompletion: OpenAI.ChatCompletion;
  model: lib.types.AI.Model;
}): lib.types.LlmCallStats | null {
  if ('error' in chatCompletion && chatCompletion.error) {
    return {
      model,
      prompt_type: chatRequest.type,
      system_message: chatRequest.messages.system,
      prompt_text: chatRequest.messages.prompt,
      response: JSON.stringify(chatCompletion, null, 2),
      error: JSON.stringify(chatCompletion.error),
    };
  }
  if (!chatRequest.model) {
    // this was previously used to indicate openrouter calls, but we aren't
    // doing that anymore and anyway it was a pretty obscure way to indicate
    // that state of affairs. if we bring multi-provider back, we will want
    // to rewrite a fair bit of this.
    return null;
  }

  const usage = chatCompletion.usage || {
    prompt_tokens: 0,
    completion_tokens: 0,
  };
  const cost = getLLMCallCost({ model, usage });
  return {
    model,
    prompt_type: chatRequest.type,
    system_message: chatRequest.messages.system,
    prompt_text: chatRequest.messages.prompt,
    response: JSON.stringify(chatCompletion, null, 2),
    input_tokens: usage.prompt_tokens,
    output_tokens: usage.completion_tokens,
    cost: cost ? Math.round(cost * 100000) / 100000 : undefined,
  };
}
