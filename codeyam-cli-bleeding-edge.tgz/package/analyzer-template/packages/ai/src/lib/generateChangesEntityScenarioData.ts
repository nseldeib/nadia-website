import completionCall from './completionCall';
import generateChangesEntityScenarioDataGenerator from './promptGenerators/generateChangesEntityScenarioDataGenerator';
import generateEntityScenarioDataGenerator from './promptGenerators/generateEntityScenarioDataGenerator';
import {
  generateIncompleteSystemMessage,
  generateSystemMessage,
} from './generateEntityScenarioData';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
// import { DEFAULT_SCENARIO } from '~codeyam/types';
import type {
  Entity,
  ScenariosDataStructure,
  Scenario,
  ScenarioData,
} from '~codeyam/types';
import * as lib from '.';
import validateJson from './validateJson';
import checkAllAttributes from './checkAllAttributes';
import { LlmCall } from '~codeyam/types/src/types/LlmCall';
import { awsLog } from '~codeyam/utils';

const DEFAULT_SCENARIO_NAME = 'Default Scenario';

type ScenarioDataWithoutDescription = Omit<ScenarioData, 'scenarioDescription'>;

interface GenerateChangesEntityScenariosDataArgs {
  entity: Entity;
  structure: ScenariosDataStructure;
  existingStructure: ScenariosDataStructure;
  scenarios: Scenario[];
  defaultScenario: Scenario;
  existingScenarios: Scenario[];
  analysisId: string;
  incompleteResponse?: string;
  model?: lib.types.AI.Model;
}

type GenerateChangesDataForScenario = Omit<
  GenerateChangesEntityScenariosDataArgs,
  'scenarios' | 'defaultScenario' | 'existingScenarios'
> & {
  scenario: Scenario;
  defaultScenarioData?: ScenarioData;
  existingScenario: Scenario;
};

async function generateChangesDataForScenario({
  entity,
  structure,
  existingStructure,
  scenario,
  defaultScenarioData,
  existingScenario,
  analysisId,
  incompleteResponse,
  model,
}: GenerateChangesDataForScenario): Promise<{
  scenarioData: ScenarioData;
  llmCalls: LlmCall[];
}> {
  if (
    structure === existingStructure &&
    scenario.metadata.keyAttributeInstructions ===
      existingScenario.metadata.keyAttributeInstructions
  ) {
    console.log(
      "CodeYam: No changes in scenario's structure or keyAttributeInstructions - returning existing scenario data",
      {
        analysisId: scenario.analysisId,
        scenarioId: scenario.id,
        scenarioName: scenario.name,
      },
    );
    return {
      scenarioData: {
        scenarioName: scenario.name,
        scenarioDescription: scenario.description,
        data: existingScenario.metadata.data,
      },
      llmCalls: [],
    };
  }

  try {
    let prompt = '';
    if (existingScenario) {
      prompt = generateChangesEntityScenarioDataGenerator(
        structure,
        scenario,
        existingScenario,
        defaultScenarioData,
        incompleteResponse,
      );
    } else {
      prompt = generateEntityScenarioDataGenerator(
        structure,
        scenario,
        defaultScenarioData,
        incompleteResponse,
      );
    }

    prompt = prompt.replace(
      /\*functionResponse\*/g,
      `"*a function that returns*"`,
    );
    prompt = prompt.replace(/\*function\*/g, `"*a void function*"`);

    const isDefault = scenario.name === DEFAULT_SCENARIO_NAME;
    let systemMessage = '';
    if (existingScenario) {
      if (incompleteResponse) {
        systemMessage = generateChangesIncompleteSystemMessage(
          scenario.name,
          isDefault,
        );
      } else {
        systemMessage = generateChangesSystemMessage(scenario.name, isDefault);
      }
    } else {
      if (incompleteResponse) {
        systemMessage = generateIncompleteSystemMessage(
          scenario.name,
          isDefault,
        );
      } else {
        systemMessage = generateSystemMessage(scenario.name, isDefault);
      }
    }

    const response = await completionCall({
      type: existingScenario
        ? 'generateChangesEntityScenarioData'
        : 'generateEntityScenarioData',
      systemMessage,
      prompt,
      model,
    });

    const llmCall = await saveLlmCall({
      object_type: 'analysis',
      object_id: analysisId,
      propsJson: {
        entity: { name: entity.name, filePath: entity.filePath },
        structure,
        existingStructure,
        scenario,
        defaultScenarioData,
        existingScenario,
        analysisId,
        incompleteResponse,
        model,
      },
      ...response.stats,
    });

    const { completion, finishReason } = response;

    if (!completion) {
      console.log(
        'CodeYam Error: Example changes data generation failed: No response from AI',
      );
      return null;
    }

    const fullCompletion = incompleteResponse
      ? `${incompleteResponse}${completion}`
      : completion;

    awsLog(
      `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} ${entity.name} ${scenario.name} changes data completion :>> Finish reason:`,
      finishReason,
      fullCompletion,
    );

    if (finishReason === 'length') {
      const fullResult = await generateChangesDataForScenario({
        entity,
        structure,
        existingStructure,
        scenario,
        defaultScenarioData,
        existingScenario,
        analysisId,
        incompleteResponse: fullCompletion,
        model,
      });
      // return the improved result with our original llmCall prepended
      fullResult.llmCalls.unshift({ name: scenario.name, id: llmCall.id });
      return fullResult;
    }

    const validJson = validateJson(fullCompletion);

    const { scenarioData: scenarioDataWithoutDescription } =
      lib.parsers.parseJsonSafe(validJson) as {
        scenarioData: ScenarioDataWithoutDescription;
      };

    const fullScenarioData = {
      ...scenarioDataWithoutDescription,
      scenarioDescription: scenario.description,
    };

    if (structure.arguments && !fullScenarioData.data.argumentsData) {
      fullScenarioData.data.argumentsData = [];
      for (let i = 0; i < structure.arguments.length; ++i) {
        if (!fullScenarioData.data.argumentsData[i]) {
          fullScenarioData.data.argumentsData[i] = {};
        }
        for (const argKey of Object.keys(structure.arguments[i])) {
          fullScenarioData.data.argumentsData[i][argKey] =
            fullScenarioData.data[argKey];
        }
      }
    }
    let argumentsData = fullScenarioData.data.argumentsData;
    if (!Array.isArray(argumentsData)) {
      argumentsData = [];
    }
    fullScenarioData.data.argumentsData = argumentsData.map((arg) =>
      checkAllAttributes(arg),
    );

    if (structure.dataForMocks && !fullScenarioData.data.mockData) {
      fullScenarioData.data.mockData = {};
      for (const propKey of Object.keys(structure.arguments)) {
        fullScenarioData.data.mockData[propKey] =
          fullScenarioData.data[propKey];
      }
    }
    fullScenarioData.data.mockData = checkAllAttributes(
      fullScenarioData.data.mockData,
    );

    return {
      llmCalls: [{ name: scenario.name, id: llmCall.id }],
      scenarioData: fullScenarioData,
    };
  } catch (error) {
    console.log(
      'CodeYam Error: Example changes data generation failed:',
      scenario,
      error,
    );
    throw error;
  }
}

export default async function generateChangesEntityScenarioData({
  entity,
  structure,
  existingStructure,
  scenarios,
  defaultScenario,
  existingScenarios,
  analysisId,
  model,
}: GenerateChangesEntityScenariosDataArgs) {
  const scenarioDatas: ScenarioData[] = [];
  const llmCalls: LlmCall[] = [];

  const defaultScenarioResponse = await generateChangesDataForScenario({
    entity,
    structure,
    existingStructure,
    scenario: defaultScenario,
    existingScenario: existingScenarios.find(
      (existingScenario) => existingScenario.name === defaultScenario.name,
    ),
    analysisId,
    model,
  });

  const defaultScenarioData = defaultScenarioResponse.scenarioData;
  scenarioDatas.push(defaultScenarioData);
  llmCalls.push(...defaultScenarioResponse.llmCalls);

  const scenariosOtherThanDefault = scenarios.filter(
    (scenario) => scenario.name !== DEFAULT_SCENARIO_NAME,
  );

  const resolutions = await Promise.all(
    scenariosOtherThanDefault.map(
      async (scenario) =>
        await generateChangesDataForScenario({
          entity,
          structure,
          existingStructure,
          scenario,
          defaultScenarioData,
          existingScenario: existingScenarios.find(
            (existingScenario) => existingScenario.name === scenario.name,
          ),
          analysisId,
          incompleteResponse: null,
          model,
        }),
    ),
  );

  for (const resolution of resolutions) {
    scenarioDatas.push(resolution.scenarioData);
    llmCalls.push(...resolution.llmCalls);
  }
  awsLog(
    'CodeYam: scenarioDatas :>> ',
    JSON.stringify(
      {
        filePath: entity.filePath,
        entityName: entity.name,
        scenarioDatas,
      },
      null,
      2,
    ),
  );
  return { scenarioDatas, llmCalls };
}

const generateChangesSystemMessage = (
  scenarioName: string,
  isDefault: boolean,
) => `## Overview
- You will be provided with a structure for scenario data, the "mockData structure", and for the arguments of the function, the "argumentsData structure", and a scenario describing a new state of data for this function.

- Your goal is to modify the existing data, if necssary, to satisfy the current scenario "keyAttributeInstructions" and the data structures.

## Provided Information

- The "mockData structure" and "argumentsData structure" describe all of the data required for the simulation to work. ${isDefault ? 'Generate valid data for every object, attribute, and nested attribute described in the data structure' : 'Ensure between the default data and the data for this scenario all attributes are appropriately filled in unless they are intentionally not defined'}. 

- The "Scenario" provides instruction on how to generate the data for this scenario. 

${
  isDefault
    ? ''
    : `- The "Default Scenario" provides the default scenario data. The data for this scenario will be merged into the ${DEFAULT_SCENARIO_NAME} data to produce the full data.
`
}
- The "Existing Scenario" provides the data for this scenario prior to the code change. This data should be maintained as much as possible. It should only be edited to satisfy the requirements for this scenario.

## Instructions
${
  isDefault
    ? `
- As the ${DEFAULT_SCENARIO_NAME} please ensure all data is filled in to meet the needs of the current code.

- The one exception to this is error data. Sometimes the data structure will contain structures for both success and error data. In this case you should only fill in the success data and leave out the error data completely.

- Always use realistic data, filling in all arrays, attributes, and sub-attributes (except for error data), creating a high quality default scenario.
`
    : `
- If the code change and new "keyAttributeInstructions" dictate changes to the "Existing Scenario" then make those changes, returning the complete data that will be merged into the "Default Scenario" data. There is no need to duplicate any of the "Default Scenario" data.

- If you need to remove data from the ${DEFAULT_SCENARIO_NAME} data then you can set any attribute to null, which will remove it during the merge process.`
}
- If the type is described as "any" then create a realistic example of that type based on its name. If the type is "date" or "timestamp" then use the instructione below to generate a dynamic date or timestamp. If the type is "*a void function*" then provide a void function per the instructions below. If the key value is "*a function that returns*" then provide a function that returns a value as described by the "*a function that returns*".

- If the data in the "Existing Scenario" is sufficient then return the following:

\`\`\`
{
  "scenarioData": {
    "scenarioName: "${scenarioName}",
    "data": {}
  }
}
\`\`\`

## Example Response

{
  "scenarioData": {
    "scenarioName": "${scenarioName}",
    "data': {
      "mockData": {
        "user": {
          "name": "John Doe",
          "metadata": {
            "hobbies": ["fishing", "hiking", "camping"]
            "favoriteColor": "blue",
          },
          "joinedAt": {
            "~~codeyam-code~~": "new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)"         
          },
          "loadRank: {
            "~~codeyam-code~~": "() => { console.log('loadRank called'); return { rank: 5 } }" 
          }
        },
        "project": {
          "name": "New Project",
          "slug": "new-project",
          "files": [
            {
              "name": "File 1",
              "slug": "file-1",
              "content": "This is the content of file 1"
            },
            {
              "name": "File 2",
              "slug": "file-2",
              "content": "This is the content of file 2"
            },
            {
              "name": "File 3",
              "slug": "file-3",
              "content": "This is the content of file 3"
            }
          ]
        }
      },
      "argumentsData": [
        {
          "open": "true",
          "onClick": {
            "~~codeyam-code~~": "() => console.log('clicked')"
          },
          "children: "Click Me!"        
        }      
      ]        
    }
  }
}

## scenarioData

You will return a JSON object called scenarioData containing the name and data for this scenario.

If you encounter a "date" then you should use "~~codeyam-code~~" along with code in string format. That string will be evaled to create the date or timestamp needed.

For example the "timestamp" above should probably not be a hard-coded timestamp but should be a function that returns a timestamp. If you want to return a timestamp that is 24 hours in the future, you would return this object:

\`\`\`
{
  "scenarioData": {
    "scenarioName": ${scenarioName},
    "data": {
      "mockData": {
        "dataLoaders": {
          "fetchUser()": {
            "user": {
              "name": "John Doe",
              "metadata": {
                "hobbies": ["fishing", "hiking", "camping"],
                "favoriteColor": "blue"
              },
              "joinedAt": {
                "~~codeyam-code~~": "new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()"
              }  
            }
          }
        }
      }
    }
  }
}
\`\`\`

Keep in mind the above pattern is also valid for argumentsData.

All code should be written in JavaScript. It will run in a node environment (not the browser) with no reference to external libraries. It will essentially be run in a sandboxed environment. Do not reference any external libraries in the code.

With argumentsData you may also need to return a "children" argument. "children" can either be a string or a jsx element.

If you want to return a jsx element you would return something like this:

\`\`\`
{
  "scenarioData": {
    "scenarioName": ${scenarioName},
    "data": {
      "argumentsData": [
        {
          "children": {
            "~~codeyam-jsx~~": "<div>Click Me!</div>"
          }
        }
      ]
    }
  }
}
\`\`\`

The "~~codeyam-jsx~~" key in a "children" prop will be rendered directly to the code as a jsx element, not a string. Only return basic elements like "<div>".

Do not import or reference any libraries in this code. No external libraries will be imported.

If either mockData or argumentsData is empty you can return an empty object for mockData ("{}") or empty array for argumentsData ("[]"). 

If an object inside of mockData or argumentsData is intended to not exist you can set it to null.

Never use "~~codeyam-code~~" or "~~codeyam-jsx~~" as a partial key in the response. Even if the key looks like it should have a relative date or code. "~~codeyam-code~~" and "~~codeyam-jsx~~" are only used as independent keys used to mark values that are code.

## Common Mistakes

- Do not use the term undefined in the response. If something is missing leave it out or use null.
- Leave out error data (e.g. a data attribute labeled as "error"), especially when it is in a data structure that has success data as well. Only include the success data and simply leave out the error data. Error data is usually labeled as "error" in the structure. Leave it out entirely.
- Do not reference data in the response (e.g. if there was a "posts" field you can not say "posts[0]" elsewhere in the response - you need to duplicate the data). Unfortunately all data must be written out directly in the response.
- Ensure each scenario in the response matches the full scenario name, commas and all, in the scenarios provided.
- Do not throw errors from this data in any manner. Simple leave out any error data.
- If the data structure contains a type that is a "date" then use ~~codeyam-code~~ to generate a dynamic timestamp or date. Do not hard-code dates unless it needs to be a very specific date. Otherwise it should be a relative, dynamic date.
- The response must be valid JSON. Do not include raw code in the response.
`;

const generateChangesIncompleteSystemMessage = (
  scenarioName: string,
  isDefault: boolean,
) => `Your previous response provided us with an incomplete json object.

Can you help us complete it? 

The previous response got cut off because it was too long so to complete the response you'll need to pick up where you left off providing just the necessary text to make the full response a valid json object.

We'll combine the initial response with your response this time to form the full json object.

Here is the initial system message:

${generateChangesSystemMessage(scenarioName, isDefault)}
\`\`\`
`;
