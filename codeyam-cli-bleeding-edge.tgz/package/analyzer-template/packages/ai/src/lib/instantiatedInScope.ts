import * as ts from 'typescript';

/**
 * Analyzes TypeScript code to identify all variables and functions declared in each scope
 * @param scopeCode The code snippet string to analyze
 */
export default function instantiatedInScope(scopeCode: string): string[] {
  const sourceFile = ts.createSourceFile(
    'temp.tsx',
    scopeCode,
    ts.ScriptTarget.Latest,
    /*setParentNodes*/ true,
    ts.ScriptKind.TSX,
  );

  const result: string[] = [];

  const isTopLevelConciseArrow = (node: ts.Node): boolean => {
    if (!ts.isArrowFunction(node)) return false;
    // concise body (not a block)
    if (ts.isBlock(node.body)) return false;

    // must be the single top-level expression statement in the file
    const parent = node.parent;
    if (!parent || !ts.isExpressionStatement(parent)) return false;
    const sf = parent.parent;
    return !!(
      sf &&
      ts.isSourceFile(sf) &&
      sf.statements.length === 1 &&
      sf.statements[0] === parent
    );
  };

  // Track whether we saw a return-with-expression in a default-exported function,
  // or a concise-body arrow that should synthesize a returnValue.
  let needsReturnValue = false;

  const isDefaultExported = (node: ts.Node): boolean => {
    const mods = (node as ts.FunctionDeclaration).modifiers ?? [];
    const kinds = new Set(mods.map((m) => m.kind));
    return (
      kinds.has(ts.SyntaxKind.ExportKeyword) &&
      kinds.has(ts.SyntaxKind.DefaultKeyword)
    );
  };

  // Stack to know if we're inside a default-exported function while visiting children
  const defaultExportFnStack: boolean[] = [];

  const pushUnique = (name: string) => {
    if (!result.includes(name)) result.push(name);
  };

  const collectIdentifiersFromBindingPattern = (
    pattern: ts.BindingPattern,
  ): string[] => {
    const identifiers: string[] = [];
    for (const element of pattern.elements) {
      if (!element) continue;
      if (ts.isOmittedExpression(element)) continue;

      const bindingElement = element as ts.BindingElement;

      // Rest element
      if (bindingElement.dotDotDotToken) {
        const n = bindingElement.name;
        if (ts.isIdentifier(n)) {
          identifiers.push(n.text);
        } else if (
          ts.isObjectBindingPattern(n) ||
          ts.isArrayBindingPattern(n)
        ) {
          identifiers.push(...collectIdentifiersFromBindingPattern(n));
        }
        continue;
      }

      const n = bindingElement.name;
      if (ts.isIdentifier(n)) {
        identifiers.push(n.text);
      } else if (ts.isObjectBindingPattern(n) || ts.isArrayBindingPattern(n)) {
        identifiers.push(...collectIdentifiersFromBindingPattern(n));
      }
    }
    return identifiers;
  };

  const collectFromVarDeclList = (declList: ts.VariableDeclarationList) => {
    for (const decl of declList.declarations) {
      const n = decl.name;
      if (ts.isIdentifier(n)) {
        pushUnique(n.text);
      } else if (ts.isObjectBindingPattern(n) || ts.isArrayBindingPattern(n)) {
        for (const id of collectIdentifiersFromBindingPattern(n))
          pushUnique(id);
      }
    }
  };

  const visit = (node: ts.Node) => {
    // Enter function contexts (to know if returns happen in default-exported fn)
    let pushedFn = false;

    if (ts.isFunctionDeclaration(node)) {
      if (node.name) pushUnique(node.name.text);
      // include parameters
      for (const p of node.parameters) {
        const n = p.name;
        if (ts.isIdentifier(n)) pushUnique(n.text);
        else if (ts.isObjectBindingPattern(n) || ts.isArrayBindingPattern(n)) {
          for (const id of collectIdentifiersFromBindingPattern(n))
            pushUnique(id);
        }
      }
      defaultExportFnStack.push(isDefaultExported(node));
      pushedFn = true;
    } else if (
      ts.isFunctionExpression(node) ||
      ts.isMethodDeclaration(node) ||
      ts.isArrowFunction(node)
    ) {
      // params for function expressions, methods, and arrows
      for (const p of node.parameters) {
        const n = p.name;
        if (ts.isIdentifier(n)) pushUnique(n.text);
        else if (ts.isObjectBindingPattern(n) || ts.isArrayBindingPattern(n)) {
          for (const id of collectIdentifiersFromBindingPattern(n))
            pushUnique(id);
        }
      }

      // If this node is an arrow with a concise body at top level, synthesize returnValue
      if (ts.isArrowFunction(node) && isTopLevelConciseArrow(node)) {
        needsReturnValue = true;
      }

      // Not a default-exported function declaration
      defaultExportFnStack.push(false);
      pushedFn = true;
    }

    // Variable statements (const/let/var at statement level)
    if (ts.isVariableStatement(node)) {
      collectFromVarDeclList(node.declarationList);
    }

    // Loop initializers: for, for..of, for..in
    if (ts.isForStatement(node)) {
      const init = node.initializer;
      if (init && ts.isVariableDeclarationList(init)) {
        collectFromVarDeclList(init);
      }
    } else if (ts.isForOfStatement(node)) {
      const init = node.initializer;
      if (ts.isVariableDeclarationList(init)) {
        collectFromVarDeclList(init);
      }
    } else if (ts.isForInStatement(node)) {
      const init = node.initializer;
      if (ts.isVariableDeclarationList(init)) {
        collectFromVarDeclList(init);
      }
    }

    // Class declarations
    if (ts.isClassDeclaration(node) && node.name) {
      pushUnique(node.name.text);
    }

    // Import declarations
    if (ts.isImportDeclaration(node)) {
      const clause = node.importClause;
      if (clause) {
        if (clause.namedBindings) {
          if (ts.isNamedImports(clause.namedBindings)) {
            for (const el of clause.namedBindings.elements) {
              pushUnique(el.name.text);
            }
          } else if (ts.isNamespaceImport(clause.namedBindings)) {
            pushUnique(clause.namedBindings.name.text);
          }
        }
        if (clause.name) {
          pushUnique(clause.name.text);
        }
      }
    }

    // Return statements with expressions inside a default-exported function
    if (ts.isReturnStatement(node) && node.expression) {
      const inDefaultExportFn =
        defaultExportFnStack[defaultExportFnStack.length - 1] === true;
      if (inDefaultExportFn) {
        needsReturnValue = true;
      }
    }

    ts.forEachChild(node, visit);

    if (pushedFn) defaultExportFnStack.pop();
  };

  visit(sourceFile);

  if (needsReturnValue) {
    pushUnique('returnValue');
  }

  return result;
}
