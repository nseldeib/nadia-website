import { Entity } from '~codeyam/types';
import * as lib from '.';
import isolateScopes from './isolateScopes';
import analyzeScope from './analyzeScope';
import { FileAnalyzer } from '~codeyam/analyze';
import { awsLog } from '~codeyam/utils';

interface GenerateEntityDataStructureArgs {
  entity: Entity;
  fileAnalyzer: FileAnalyzer;
  model?: lib.types.AI.Model;
}

export default async function generateEntityDataStructure({
  entity,
  fileAnalyzer,
  model,
}: GenerateEntityDataStructureArgs) {
  awsLog('CodeYam: Generating entity data structure', {
    filePath: entity.filePath,
    entityName: entity.name,
    // code: entity.code.length,
  });

  const fileScope = isolateScopes(fileAnalyzer.sourceFile.getText(), {
    entityNames: [entity.name],
  });
  let entityScope =
    fileScope.name === entity.name
      ? fileScope
      : fileScope.childScopes[entity.name];
  if (!entityScope && entity.name === 'default') {
    entityScope = fileScope.text.startsWith('export default')
      ? fileScope
      : Object.values(fileScope.childScopes).find((s) =>
          s.text.toLowerCase().startsWith('export default'),
        );
  }

  if (!entityScope) {
    if (entity.code === fileAnalyzer.sourceFile.getText()) {
      entityScope = fileScope;
    } else {
      const entityStartIndex = fileAnalyzer.sourceFile
        .getText()
        .indexOf(entity.code);
      const entityIndex = entityStartIndex + entity.code.length / 2;
      entityScope = Object.values(fileScope.childScopes).find(
        (s) => entityIndex > s.start && entityIndex < s.end,
      );
    }
  }

  if (!entityScope) {
    // console.log(
    //   'CodeYam Warn: Entity scope not found for',
    //   {
    //     filePath: entity.filePath,
    //     entityName: entity.name,
    //     indexOfEntityCode: fileAnalyzer.sourceFile.getText().indexOf(entity.code),
    //   }
    // );
    // console.log(JSON.stringify(fileScope, null, 2));
    // console.log(fileAnalyzer.sourceFile.getText());
    // console.log(entity.code);
    // throw new Error('Entity scope not found');
    return;
  }

  await analyzeScope({
    entity,
    fileAnalyzer,
    scope: entityScope,
    model,
  });

  return entityScope.dataStructure;
}
