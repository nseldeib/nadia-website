export default function mergeJsonTypeDefinitions(...typeDefs) {
  // console.log("MERGING JSON TYPE DEFINITIONS", JSON.stringify(typeDefs, null, 2))

  const mergedDef = {};

  for (const typeDef of typeDefs) {
    if (!typeDef) continue;
    if (typeof typeDef === 'string') continue;
    for (const [key, value] of Object.entries(typeDef)) {
      if (typeof value === 'string') {
        if (!mergedDef[key]) {
          mergedDef[key] = value;
        }
      } else if (Array.isArray(value) || Array.isArray(mergedDef[key])) {
        if (
          typeof value[0] !== 'object' ||
          typeof mergedDef[key] !== 'object'
        ) {
          if (!mergedDef[key] || typeof mergedDef[key] === 'string') {
            mergedDef[key] = [value[0]];
          }
        } else {
          if (typeof mergedDef[key]?.[0] !== 'object') {
            mergedDef[key] = [value[0]];
          } else {
            const typeDef1 = Array.isArray(mergedDef[key])
              ? (mergedDef[key]?.[0] ?? {})
              : mergedDef[key];
            const typeDef2 = Array.isArray(value) ? value[0] : value;
            mergedDef[key] = [mergeJsonTypeDefinitions(typeDef1, typeDef2)];
          }
        }
      } else if (typeof value === 'object') {
        if (!mergedDef[key]) {
          mergedDef[key] = {};
        }
        mergedDef[key] = mergeJsonTypeDefinitions(mergedDef[key], value);
      }
    }
  }

  // if (Array.isArray(mergedDef) && mergedDef[0] === "s") {
  //   console.log("BAD MERGE1", JSON.stringify(typeDefs, null, 2))
  //   console.log("BAD MERGE2", JSON.stringify(mergedDef, null, 2))
  // }
  // console.log("MERGED JSON TYPE DEFINITIONS RESULT", JSON.stringify(mergedDef, null, 2))

  return mergedDef;
}
