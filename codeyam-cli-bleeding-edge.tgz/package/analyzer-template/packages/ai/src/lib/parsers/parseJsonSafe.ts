import json5 from 'json5';
import * as lib from '../../lib';

export function parseJsonSafe(
  jsonString: string,
): lib.types.JSON.Object | null {
  if (jsonString === undefined || jsonString === null) {
    return null;
  }

  try {
    return json5.parse(jsonString);
  } catch (error) {
    const errorMessage = error.message;
    // Example error message: "SyntaxError: JSON5: invalid character 'u' at 1:68"
    const match = errorMessage.match(/invalid character .* at (\d+):(\d+)/);
    if (match) {
      const position = parseInt(match[2], 10);
      if (jsonString.substring(position - 2, position - 1) === '"') {
        // Attempt to escape the quote
        jsonString =
          jsonString.substring(0, position - 2) +
          '\\' +
          jsonString.substring(position - 2);
        return parseJsonSafe(jsonString);
      }
    }
    // If the error is not due to an unescaped quote or cannot be parsed, break and log
    // console.log('Error parsing JSON:', jsonString, error);
    return null;
  }
}
