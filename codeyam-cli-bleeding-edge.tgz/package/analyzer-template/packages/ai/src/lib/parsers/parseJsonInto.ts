/* eslint-disable @typescript-eslint/no-explicit-any */

import * as lib from '../../lib';

/**
 * Parses json strings into the desired type. Requires a type
 * predicate to check the validity of the type. `undefined` means
 * the json is **not** the desired type
 */
export function parseJsonInto<T extends lib.types.JSON.Object>(
  jsonString: string,
  isType: lib.types.TypePredicateFunction<T>,
): T | undefined {
  const t = lib.parsers.parseJsonSafe(jsonString);
  if (!t) return undefined;

  if (isType(t)) {
    return t;
  } else {
    return undefined;
  }
}
