export default function fileContentToLines(
  fileContent: string,
): Record<number, string> {
  const lines = fileContent.split('\n');
  return lines.reduce(
    (acc, line, index) => {
      acc[index + 1] = line;
      return acc;
    },
    {} as Record<number, string>,
  );
}
