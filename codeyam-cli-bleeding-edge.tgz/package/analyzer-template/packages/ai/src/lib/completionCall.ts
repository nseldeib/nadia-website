import OpenAI from 'openai';
import * as lib from '../lib';

import PQueue from 'p-queue';
import PRetry from 'p-retry';
import { DEFAULT_SMALLER_MODEL } from './aiConfig';

interface CompletionCallProps {
  type: string;
  systemMessage: string;
  prompt: string;
  jsonResponse?: boolean;
  model?: lib.types.AI.Model;
  attempts?: number;
}

const queue = new PQueue({
  concurrency: 100,
  timeout: 20 * 60 * 1000, // 20 minutes
  throwOnTimeout: true,
  autoStart: true,
});

const defaultRetryOptions = {
  retries: 5,
  factor: 2,
  minTimeout: 1000,
  maxTimeout: 60000,
  randomize: true,
};

export default async function completionCall({
  type,
  systemMessage,
  prompt,
  jsonResponse = true,
  model = DEFAULT_SMALLER_MODEL,
  // model = lib.types.AI.Model.OPENAI_GPT4_O,
  // model = lib.types.AI.Model.GEMINI_2_0_FLASH_001,
  // model = lib.types.AI.Model.DEEPSEEK_CHAT,
  attempts = 0,
}: CompletionCallProps) {
  console.log(
    `CodeYam Debug: LLM Pool [queued=${queue.size}, running=${queue.pending}]`,
  );

  const startTime = Date.now();
  let queueEndTime: number;
  let retryCount = 0;

  const openAiModel = [
    lib.types.AI.Model.OPENAI_GPT35_TURBO,
    lib.types.AI.Model.OPENAI_GPT4_PREVIEW,
    lib.types.AI.Model.OPENAI_GPT4_TURBO_PREVIEW,
    lib.types.AI.Model.OPENAI_GPT4_O,
    lib.types.AI.Model.OPENAI_GPT4_O_MINI,
    lib.types.AI.Model.OPENAI_GPT5,
    lib.types.AI.Model.OPENAI_GPT5_MINI,
    lib.types.AI.Model.OPENAI_GPT5_NANO,
    lib.types.AI.Model.OPENAI_GPT4_1,
    lib.types.AI.Model.OPENAI_GPT4_1_MINI,
  ].includes(model);

  if (!openAiModel) {
    throw new Error(
      `Only OpenAI models are supported at the moment, but got: ${model}`,
    );
  }

  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });
  const chatRequest: lib.types.AI.ChatRequest = {
    type,
    messages: {
      system: systemMessage,
      prompt: prompt,
    },
    model,
    responseType: jsonResponse ? 'json' : 'text',
  };
  const params = lib.openai.chatRequestToOpenAIChatParams(chatRequest);

  const chatCompletion = await queue.add(
    () => {
      queueEndTime = Date.now();
      return PRetry(
        () => {
          return openai.chat.completions.create(params, {
            timeout: 5 * 60 * 1000, // 5 minute timeout
          });
        },
        {
          ...defaultRetryOptions,
          onFailedAttempt: (error) => {
            retryCount++;
            console.log('CodeYam Error: Completion call failed', {
              error,
              prompt,
              systemMessage,
              attempts,
              retryCount,
            });
          },
        },
      );
    },
    {
      throwOnTimeout: true,
    },
  );
  const endTime = Date.now();

  const llmCallStats = await lib.getLLMCallStatsOld({
    chatRequest,
    chatCompletion,
    model,
  });

  llmCallStats['retries'] = retryCount;
  llmCallStats['wait_ms'] = queueEndTime - startTime;
  llmCallStats['duration_ms'] = endTime - startTime;

  const rawCompletion =
    lib.openai.extractReplyFromChatCompletion(chatCompletion);

  const completion = jsonResponse
    ? rawCompletion
      ? (rawCompletion.match(/\{[\s\S]*\}/)?.[0] ?? rawCompletion)
      : rawCompletion
    : rawCompletion;

  if (!completion) {
    console.log(
      'CodeYam Error: undefined rawCompletion',
      JSON.stringify({ completion, rawCompletion, chatCompletion }, null, 2),
    );

    if (attempts < 3) {
      console.log('CodeYam Error: Retrying completion', {
        prompt,
        systemMessage,
        attempts,
      });
      return await completionCall({
        type,
        systemMessage,
        prompt,
        jsonResponse,
        model,
        attempts: attempts + 1,
      });
    }

    throw new Error('Undefined completion');
  }

  if (completion.replace(/\s/g, '') === '') {
    console.log('CodeYam Error: Empty Completion', {
      rawCompletion,
      prompt,
      systemMessage,
    });
    throw new Error('Empty completion');
  }

  return {
    finishReason: chatCompletion.choices[0].finish_reason,
    completion,
    stats: llmCallStats,
  };
}

export const QueuePending = () => queue.pending;
export const QueueSize = () => queue.size;
