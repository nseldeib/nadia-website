export default function generateEntityDataStructureGenerator(
  entityContent: string,
  dataVariables: string[],
) {
  return `Code:
\`\`\`
${entityContent}
\`\`\`

${
  dataVariables.length > 0
    ? `Data Variables:
\`\`\`
${JSON.stringify(dataVariables, null, 2)}
\`\`\``
    : ''
}`;
}
