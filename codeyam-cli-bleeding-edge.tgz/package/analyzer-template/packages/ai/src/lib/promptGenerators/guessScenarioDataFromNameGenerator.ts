import {
  FileProp,
  Mock,
  ScenariosDataStructure,
  Scenario,
} from '~codeyam/types';

interface GenerateEntityScenariosGeneratorArgs {
  newScenarioName: string;
  mocks: Mock[];
  props: FileProp[];
  existingScenarios: Scenario[];
  scenariosDataStructure: ScenariosDataStructure;
}

export default function guessScenarioDataFromNameGenerator({
  newScenarioName,
  mocks,
  props,
  existingScenarios,
  scenariosDataStructure,
}: GenerateEntityScenariosGeneratorArgs) {
  return `Mocks:
  \`\`\`
  ${JSON.stringify(mocks, null, 2)}
  \`\`\`
  Props:
  \`\`\`
  ${JSON.stringify(props, null, 2)}
  \`\`\`
  Existing Mock Scenario Data:
  \`\`\`
  ${JSON.stringify(existingScenarios, null, 2)}
  \`\`\`
  Mock data structure:
  \`\`\`
  ${JSON.stringify(scenariosDataStructure, null, 2)}
  \`\`\
  New Scenario Name: "${newScenarioName}"
  `;
}
