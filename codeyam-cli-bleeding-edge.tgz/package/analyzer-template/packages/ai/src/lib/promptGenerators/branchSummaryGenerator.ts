import { CommitOverview } from '~codeyam/types';

export default function branchSummaryGenerator({
  branchName,
  commitOverviews,
}: {
  branchName: string;
  commitOverviews: CommitOverview[];
}) {
  return `Branch: ${branchName}
  Commits:
  ${JSON.stringify(commitOverviews, null, 2)}`;
}
