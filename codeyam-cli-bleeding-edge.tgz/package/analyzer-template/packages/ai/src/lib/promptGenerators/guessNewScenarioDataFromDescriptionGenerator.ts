import { ScenariosDataStructure, Scenario } from '~codeyam/types';

interface GenerateEntityScenariosGeneratorArgs {
  description: string;
  existingScenarios: Scenario[];
  scenariosDataStructure: ScenariosDataStructure;
}

export default function guessNewScenarioDataFromDescriptionGenerator({
  description,
  existingScenarios,
  scenariosDataStructure,
}: GenerateEntityScenariosGeneratorArgs) {
  return `Mock Scenario Data Structure:
  \`\`\`
  ${JSON.stringify(scenariosDataStructure, null, 2)}
  \`\`\
  Existing Mock Scenario Data:
  \`\`\`
  ${JSON.stringify(existingScenarios, null, 2)}
  \`\`\`
  New Scenario user-created prompt: "${description}"
  `;
}
