import { Commit } from '~codeyam/types';

export default function commitMessageGenerator(commit: Commit) {
  const filesDiff = commit.files.reduce((diff, file) => {
    const fileDiff = `${file.fileName} ${file.status}: ${file.patch}`;
    if (diff.join('').length + fileDiff.length > 4000) return diff;
    diff.push(fileDiff);
    return diff;
  }, [] as string[]);

  return `Here is information about a git commit:
  
Message: ${commit.message}

### FILES ###

${filesDiff.join('\n\n')}

### END FILES ###

For each file provide a short and clear explanation that contains no technical jargon (or if necessary, an explanation for the jargon) so that a non-technical person can understand what changed. 

Write the explanation in markdown. Use bullets (no paragraphs) to describe the changes. Each file explanation should be a string of bullets in markdown.

Then write a concise title and very brief commit explanation of the intent of the overall commit. 

Present it as a json object with the following structure:

{
  "title": "[commit title]",
  "explanation": "[commit explanation]",
  "[file name]": "[file explanation]"
}

Please start the response with the json object (e.g. start with "{" and end the response with "}"). Provide no other text than the json object and follow the json structure exactly.
`;
}
