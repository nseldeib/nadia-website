import {
  Entity,
  Scenario,
  ReadonlyAnalysisMap,
  Analysis,
} from '~codeyam/types';
import gatherRelevantDependentKeyAttributes from '../gatherRelevantDependentKeyAttributes';

interface GenerateChangesEntityScenariosGeneratorArgs {
  entity: Pick<Entity, 'name' | 'code' | 'metadata'>;
  keyAttributes: Analysis['metadata']['keyAttributes'];
  addedKeyAttributes: Analysis['metadata']['keyAttributes'];
  removedKeyAttributes: Analysis['metadata']['keyAttributes'];
  dependentAnalyses: ReadonlyAnalysisMap;
  existingScenarios: Scenario[];
  commitDiff: string;
  error: boolean;
}

export default function generateChangesEntityScenariosGenerator({
  entity,
  keyAttributes,
  addedKeyAttributes,
  removedKeyAttributes,
  dependentAnalyses,
  existingScenarios,
  commitDiff,
  error,
}: GenerateChangesEntityScenariosGeneratorArgs) {
  const relevantDependentKeyAttributes = gatherRelevantDependentKeyAttributes(
    entity,
    dependentAnalyses,
  );

  return `Added Key Attributes:

\`\`\`
${
  addedKeyAttributes
    ? JSON.stringify(
        addedKeyAttributes.map((ka) => ({
          path: ka.internalPath,
          description: ka.description,
          validValueOptions: ka.validValueOptions,
        })),
        null,
        2,
      )
    : 'None'
}
\`\`\`

Removed Key Attributes:

\`\`\`
${removedKeyAttributes ? JSON.stringify(removedKeyAttributes, null, 2) : 'None'}
\`\`\`

Existing Key Attributes:

\`\`\`
${JSON.stringify(
  keyAttributes.map((ka) => ({
    path: ka.internalPath,
    description: ka.description,
    validValueOptions: ka.validValueOptions,
  })),
  null,
  2,
)}
\`\`\`

Existing Scenarios:

\`\`\`
${JSON.stringify(
  existingScenarios
    .filter((s) => (error ? !!s.metadata.error : !s.metadata.error))
    .map((s) => ({
      name: s.name,
      description: s.description,
      keyAttributeInstructions: s.metadata.keyAttributeInstructions,
      playwrightInstructions: s.metadata.playwrightInstructions,
    })),
  null,
  2,
)}
\`\`\`

${
  commitDiff
    ? `
Code Change:

\`\`\`
${commitDiff}
\`\`\`
`
    : ''
}
Function Code:

\`\`\`
${entity.code}
\`\`\`

${
  !error &&
  relevantDependentKeyAttributes &&
  Object.keys(relevantDependentKeyAttributes).length > 0
    ? `Key Attributes for Dependencies:
\`\`\`
${JSON.stringify(
  Object.keys(relevantDependentKeyAttributes).reduce((acc, path) => {
    acc[path] = Object.keys(relevantDependentKeyAttributes[path]).reduce(
      (entityAcc, entityName) => {
        entityAcc[entityName] = relevantDependentKeyAttributes[path][
          entityName
        ].map((ka) => ({
          path: ka.path,
          description: ka.description,
          validValueOptions: ka.validValueOptions,
        }));
        return entityAcc;
      },
      {},
    );
    return acc;
  }, {}),
  null,
  2,
)}
\`\`\``
    : ''
}
`;
}
