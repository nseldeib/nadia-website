import { ScenariosDataStructure, Scenario, ScenarioData } from '~codeyam/types';

function filterData(
  rootStructure: ScenariosDataStructure,
  rootData: ScenarioData['data'],
) {
  if (!rootStructure || !rootData) return;

  const filterLevel = (structure, data) => {
    if (!structure || !data) return null;

    if (typeof structure === 'object' && !Array.isArray(structure)) {
      const filteredData = {};
      for (const key in structure) {
        if (key === '~~codeyam-code~~' || key === '~~codeyam-jsx~~') {
          filteredData[key] = data[key];
        } else if (data.hasOwnProperty(key)) {
          if (typeof structure[key] === 'object') {
            filteredData[key] = filterLevel(structure[key], data[key]);
          } else {
            filteredData[key] = data[key];
          }
        }
      }
      return filteredData;
    } else if (Array.isArray(structure)) {
      const filteredArray = [];
      for (let i = 0; i < data.length; i++) {
        if (typeof data[i] === 'object') {
          filteredArray.push(
            filterLevel(structure[i] ?? structure[0], data[i]),
          );
        } else {
          filteredArray.push(data[i]);
        }
      }
      return filteredArray;
    }
    return data;
  };

  return {
    arguments: filterLevel(rootStructure.arguments, rootData.argumentsData),
    dataForMocks: filterLevel(rootStructure.dataForMocks, rootData.mockData),
  };
}

export default function generateChangesEntityScenarioDataGenerator(
  structure: ScenariosDataStructure,
  scenario: Scenario,
  existingScenario: Scenario,
  defaultScenarioData?: ScenarioData,
  incompleteResponse?: string,
) {
  return `${
    incompleteResponse
      ? `## Incomplete Response

Here is the incomplete response. Please use this and the following data to complete the response, only returning the missing data.

Just pick up where this response left off. It will be improper json but we will combine the responses into proper json.

\`\`\` START INCOMPLETE RESPONSE \`\`\`
${incompleteResponse}
\`\`\` END INCOMPLETE RESPONSE \`\`\`

`
      : ''
  }## Scenario
  
This scenario needs mock data to support it. Here are the keyAttributeInstructions for generating this scenario:
\`\`\`
${JSON.stringify(
  {
    name: scenario.name,
    description: scenario.description,
    keyAttributeInstructions: scenario.metadata.keyAttributeInstructions,
  },
  null,
  2,
)}
\`\`\`

## Existing Scenario
  
Here are the "keyAttributeInstructions" and data for this scenario before this more recent code change. Please maintain the existing data as effectively as possible while fulfilling the new data structure and "keyAttributeInstructions".
\`\`\`
${JSON.stringify(
  {
    name: existingScenario.name,
    data: filterData(structure, existingScenario.metadata.data),
  },
  null,
  2,
)}
\`\`\`
${
  defaultScenarioData
    ? `
## Default Scenario

Data for the default scenario. Do not modify it. The data you are generating will be merged into it to create the full data.
\`\`\`
${JSON.stringify(defaultScenarioData.data, null, 2)}
\`\`\`
`
    : ''
}
${
  structure.dataForMocks
    ? `The mockData structure (for the default scenario provide robust values for the entire structure):
\`\`\`
${JSON.stringify(structure.dataForMocks, null, 2)}
\`\`\`
`
    : 'There is no mockData for this file. Return {} for the mockData.'
}
    
${
  structure.arguments
    ? `The argumentsData structure (for the default scenario provide robust values for the entire structure):
\`\`\`
${JSON.stringify(structure.arguments, null, 2)}
\`\`\`
`
    : 'There is no argumentsData for this file. Return [] for the argumentsData.'
}`;
}
