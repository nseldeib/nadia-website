import { Entity } from '~codeyam/types';

export default function codeQualityEntityAnalysisGenerator(entity: Entity) {
  return `Here is the code for ${entity.name}:
  
------- START CODE -------
${entity.code
  .replace('------- START CODE -------', '')
  .replace('------- END CODE -------', '')}
------- END CODE -------

Please analyze the code quality for this code.

Please identify any areas of concern. Pay attention to:

Length (shorter is better but not at the expense of readability)
Complexity (are there areas that are too complex and would benefit from being broken up into smaller functions?)
Readability (how easy is it to understand overall? are there any parts that are particularly hard to understand?)
Focus (how focused is it on the stated intent - e.g the filename)
Comments (are there good, but not excessive, comments for the complex parts?)
Error Handling (are errors and edge cases handled well)
Security (is the code free of security vulnerabilities?)
Accessibility (if the code is UI code, does it follow accessibility best practices?)

For each area of concern provide a score of 1 - 10 where 1 is bad and 10 is good. Provide a short explanation for each score.

Do not include all areas of evaluation, only include areas that would rate below an 7.

Finally provide an overall score for the code quality (again 1 - 10 where 1 is bad and 10 is good) and a short explanation of the overall score.

Provide the full response as json using the following format with no additional text outside of the json:

{
  "codeQuality": {
    "[AREA OF CONCERN #1 (e.g. Length)": {
      "score": number;
      "explanation": string;
    };
    "[AREA OF CONCERN #2 (e.g. Error Handling)": {
      "score": number;
      "explanation": string;
    };
    "[AREA OF CONCERN #3 (e.g. Security)": {
      "score": number;
      "explanation": string;
    };
    "Overall": {
      "score": number;
      "explanation": string;
    };
  };
}`;
}
