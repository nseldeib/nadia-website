import { Entity } from '~codeyam/types';
import cleanOutBoundary from '../cleanOutBoundary';
import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from '../splitOutsideParentheses';

function validAttribute(attribute: string) {
  if (!attribute || attribute.length === 0 || attribute.startsWith('['))
    return false;
  const attributeParts = splitOutsideParenthesesAndArrays(attribute);
  if (
    attributeParts.some((part) =>
      cleanOutBoundary(cleanOutBoundary(part), '<', '>').match(/\s/),
    )
  ) {
    return false;
  }

  return true;
}

export function gatherAttributesMap(
  entity: Pick<Entity, 'metadata'>,
  reverse = false,
) {
  const attributesMap: Record<string, string> = {};
  const associationMap: Record<string, string> = {};
  const { signatureSchema, equivalentSignatureVariables, dependencySchemas } =
    entity.metadata.isolatedDataStructure;
  for (const key in signatureSchema) {
    const keyParts = splitOutsideParenthesesAndArrays(key);
    if (keyParts[0].startsWith('signature')) {
      const equivalentSignatureVariable =
        equivalentSignatureVariables[keyParts[0]];
      const equivalentSignatureVariableParts = splitOutsideParenthesesAndArrays(
        equivalentSignatureVariable,
      );
      if (
        equivalentSignatureVariable &&
        !equivalentSignatureVariableParts[0].includes('(')
      ) {
        const equivalentKey = equivalentSignatureVariables[keyParts[0]];
        const equivalentPath = joinParenthesesAndArrays([
          equivalentKey,
          ...keyParts.slice(1),
        ]);
        attributesMap[equivalentPath] = signatureSchema[key];
        associationMap[reverse ? equivalentPath : key] = reverse
          ? key
          : equivalentPath;
      } else {
        const relativePath = joinParenthesesAndArrays(keyParts.slice(1));
        attributesMap[relativePath] = signatureSchema[key];
        associationMap[reverse ? relativePath : key] = reverse
          ? key
          : relativePath;
      }
    }
  }

  for (const filePath in dependencySchemas) {
    for (const entityName in dependencySchemas[filePath]) {
      const returnValueDataStructure =
        dependencySchemas[filePath][entityName].returnValueSchema ?? {};
      const functionPaths: string[] = [];
      for (const path in returnValueDataStructure) {
        const pathParts = splitOutsideParenthesesAndArrays(path);
        if (pathParts.length < 2) continue;

        if (returnValueDataStructure[path] === 'function') {
          functionPaths.push(path);
          continue;
        }

        if (
          functionPaths.some((functionPath) => path.startsWith(functionPath))
        ) {
          continue;
        }

        const relativePath = joinParenthesesAndArrays(pathParts.slice(2));
        if (!validAttribute(relativePath)) continue;

        attributesMap[relativePath] = returnValueDataStructure[path];
        associationMap[reverse ? relativePath : path] = reverse
          ? path
          : relativePath;
      }
    }
  }

  for (const attribute in attributesMap) {
    if (!validAttribute(attribute)) {
      delete attributesMap[attribute];
    }
  }

  return { attributesMap, associationMap };
}
