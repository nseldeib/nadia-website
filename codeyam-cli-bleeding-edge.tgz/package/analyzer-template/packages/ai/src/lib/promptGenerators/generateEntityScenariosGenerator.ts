import { Analysis, Entity } from '~codeyam/types';

interface GenerateEntityScenariosGeneratorArgs {
  entity: Pick<Entity, 'code' | 'metadata' | 'filePath' | 'name'>;
  keyAttributes: Analysis['metadata']['keyAttributes'];
  error: boolean;
}

export default function generateEntityScenariosGenerator({
  entity,
  keyAttributes,
  error,
}: GenerateEntityScenariosGeneratorArgs) {
  const thisEntityKeyAttributes = keyAttributes?.filter(
    (ka) => !ka.dependentEntityName,
  );

  const relevantDependentKeyAttributes = keyAttributes?.filter(
    (ka) => ka.dependentEntityName,
  );

  return `Key Attributes:

\`\`\`
${JSON.stringify(
  thisEntityKeyAttributes.map((ka) => ({
    path: ka.internalPath,
    description: ka.description,
    validValueOptions: ka.validValueOptions,
  })),
  null,
  2,
)}
\`\`\`

Code:
\`\`\`
${entity.code}
\`\`\`

${
  !error &&
  relevantDependentKeyAttributes &&
  Object.keys(relevantDependentKeyAttributes).length > 0
    ? `Key Attributes for Dependencies:
\`\`\`
${JSON.stringify(
  relevantDependentKeyAttributes.map((ka) => ({
    path: ka.internalPath,
    forDependency: ka.dependentEntityName,
    description: ka.description,
    validValueOptions: ka.validValueOptions,
  })),
  null,
  2,
)}
\`\`\``
    : ''
}
`;
}
