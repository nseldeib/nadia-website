import { FileProp, Mock } from '~codeyam/types';

export default function getComponentExamplesGenerator(
  fileContent: string,
  props: FileProp[],
  mocks?: Mock[],
) {
  return `Props:
  \`\`\`
  ${JSON.stringify(props, null, 2)}
  \`\`\`
  Mocks to customize:
  \`\`\`
  ${JSON.stringify(mocks, null, 2)}
  \`\`\`
  File:
  \`\`\`
  ${fileContent}
  \`\`\``;
}
