import { Entity } from '~codeyam/types';

export default function generateEntityDocumentationGenerator(entity: Entity) {
  return `Here is the code for ${entity.name}:
  
"""
${entity.code}
"""

What does this code do? Please create documentation for this code. 

- Start with an overview that describes the overall intent of the code. Be concise in your language. Immediately start with the intent of the code. Here is an example Overview:

\`\`\` Overview
Displays details about a specific Git commit. It shows the commit message, author, date, and provides a link to the commit on GitHub. Users can copy the commit SHA to their clipboard, with a visual indication of the copy action.
\`\`\`

Note that it does not mention the name of the function but dives directly into what the code does in concise language followed by a small amount of detail.

- Next, specify the inputs (with details about types, how the input is used, and examples) and expected outputs (with details about types and examples).

- Finally, provide examples of how the code can be used with clear inputs and outputs for each example. Provide diverse examples (there's no need to include repetitive examples). 

Write the documentation as markdown. Be concise. Use bullets when possible. No one wants to read long paragraphs of text. 

Provide no other text than the documentation in proper markdown using the headers below.

## Overview

## Inputs

## Output

## Examples`;
}
