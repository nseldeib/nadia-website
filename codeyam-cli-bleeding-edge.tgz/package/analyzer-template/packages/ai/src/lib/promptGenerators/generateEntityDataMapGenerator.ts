export default function generateEntityDataMapGenerator(
  entityCode: string,
  importStatements: string,
  localImports: string,
) {
  return `Imported Dependencies:
\`\`\`
${importStatements}
\`\`\`

Locally Dependencies:
\`\`\`
${localImports}
\`\`\`

Function
\`\`\`
${entityCode}
\`\`\``;
}
