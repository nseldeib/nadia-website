import { JsonTypeDefinition } from '~codeyam/types';

export default function noErrorAttributes(
  data: JsonTypeDefinition | JsonTypeDefinition[] | string | string[],
) {
  if (Array.isArray(data)) {
    return data.map((item) => noErrorAttributes(item));
  } else if (typeof data === 'object' && data !== null) {
    if (Object.keys(data).length > 1) {
      delete data.error;
    }
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        data[key] = noErrorAttributes(data[key]);
      }
    }
  }
  return data;
}
