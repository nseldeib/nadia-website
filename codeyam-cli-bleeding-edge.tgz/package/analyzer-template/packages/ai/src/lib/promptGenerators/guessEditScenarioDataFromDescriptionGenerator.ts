import {
  DEFAULT_SCENARIO_NAME,
  ScenariosDataStructure,
  Scenario,
} from '~codeyam/types';
import { deepMerge } from '~codeyam/generate';

interface GenerateEntityScenariosGeneratorArgs {
  description: string;
  editingMockName: string;
  editingMockData?: { [key: string]: unknown };
  existingScenarios: Scenario[];
  scenariosDataStructure: ScenariosDataStructure;
}

export default function guessEditScenarioDataFromDescriptionGenerator({
  description,
  editingMockName,
  editingMockData,
  existingScenarios,
  scenariosDataStructure,
}: GenerateEntityScenariosGeneratorArgs) {
  const defaultScenario = existingScenarios.find(
    (scenario) => scenario.name === DEFAULT_SCENARIO_NAME,
  );

  return `Mock Scenario Data Structure:
  \`\`\`
  ${JSON.stringify({ props: scenariosDataStructure.arguments, dataVariables: scenariosDataStructure.dataForMocks }, null, 2)}
  \`\`\`

  Existing Mock Scenario Data:
  \`\`\`
  ${JSON.stringify(
    existingScenarios.map((s) => ({
      name: s.name,
      data: deepMerge(defaultScenario.metadata.data, s.metadata.data),
    })),
    null,
    2,
  )}
  \`\`\`

  Mock Scenario that should be edited: "${editingMockName}"
  ${
    editingMockData
      ? `The portion of the data that should be edited:
  \`\`\`
  ${JSON.stringify(editingMockData, null, 2)}
  \`\`\``
      : ''
  }

  How this data should be changed: "${description}"
  `;
}
