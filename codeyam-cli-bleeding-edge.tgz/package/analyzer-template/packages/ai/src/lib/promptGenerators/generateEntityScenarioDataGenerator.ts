import { ScenariosDataStructure, Scenario, ScenarioData } from '~codeyam/types';
import noErrorAttributes from './noErrorAttributes';

export default function generateEntityScenarioDataGenerator(
  structure: ScenariosDataStructure,
  scenario: Scenario,
  defaultScenarioData?: ScenarioData,
  incompleteResponse?: string,
) {
  if (incompleteResponse) {
    return incompleteResponse;
  }

  return `## Scenarios

This scenario needs mock data to support it:
\`\`\`
${JSON.stringify(
  {
    name: scenario.name,
    description: scenario.description,
    keyAttributeInstructions: scenario.metadata.keyAttributeInstructions,
  },
  null,
  2,
)}
\`\`\`
${
  defaultScenarioData
    ? `
## Default Scenario Data

Here is the Default Scenario data. The data generated for this scenario will be merged into this Default Scenario data.
\`\`\`
${JSON.stringify(defaultScenarioData.data, null, 2)}
\`\`\`

`
    : ''
}
${
  structure.dataForMocks
    ? `The mockData structure (for the default scenario provide robust values for the entire structure, excluding error attributes unless specifically requested):
\`\`\`
${JSON.stringify(noErrorAttributes(structure.dataForMocks), null, 2)}
\`\`\`
`
    : 'There is no mockData for this file. Return {} for the mockData.'
}
    
${
  structure.arguments
    ? `The argumentsData structure (for the default scenario provide robust values for the entire structure, excluding error attributes unless specifically requested):
\`\`\`
${JSON.stringify(noErrorAttributes(structure.arguments), null, 2)}
\`\`\`
`
    : 'There is no argumentsData for this file. Return [] for the argumentsData.'
}`;
}
