import { Analysis } from '~codeyam/types';

interface GenerateEntityKeyAttributesGeneratorArgs {
  code: string;
  attributesMap: Record<string, string>;
  existingKeyAttributes?: Analysis['metadata']['keyAttributes'];
  commitDiff?: string;
}

export default function generateEntityKeyAttributesGenerator({
  code,
  attributesMap,
  existingKeyAttributes,
  commitDiff,
}: GenerateEntityKeyAttributesGeneratorArgs) {
  return `Attributes and Value Types:

\`\`\`
${Object.entries(attributesMap)
  .sort((a, b) => a[0].localeCompare(b[0]))
  .map(([key, value]) => `${key}: ${value}`)
  .join('\n')}
\`\`\`
${
  existingKeyAttributes
    ? `
Existing Key Attributes:
\`\`\`
${JSON.stringify(
  existingKeyAttributes.filter((attr) => attributesMap[attr.internalPath]),
  null,
  2,
)}
\`\`\`

`
    : ``
}
${
  commitDiff
    ? `
Code Change:
\`\`\`
${commitDiff}
\`\`\`

`
    : ''
}
Code:
\`\`\`
${code}
\`\`\`
    : ''
}`;
}
