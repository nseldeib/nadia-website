export default function generateEntityPropsStructureGenerator({
  code,
  variables,
}: {
  code: string;
  variables?: string;
}) {
  let variablesString = '';

  if (variables) {
    variablesString = `## Variables List

\`\`\`
${variables}
\`\`\`

`;
  }

  return `## Function Code:
\`\`\`
${code}
\`\`\``;
}
