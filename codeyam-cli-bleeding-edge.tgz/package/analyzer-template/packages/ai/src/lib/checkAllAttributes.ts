export default function checkAllAttributes(data: { [key: string]: unknown }) {
  if (data === null) return data;

  for (const key of Object.keys(data)) {
    try {
      if (data[key] === undefined) {
        delete data[key];
        continue;
      }

      if (typeof data[key] === 'object') {
        checkAllAttributes(data[key] as { [key: string]: unknown });
      } else if (typeof data[key] === 'string') {
        data[key] = (data[key] as string).replace(/\n/g, '\\n');
      }
    } catch (e) {
      console.error('Error checking all attributes', {
        key,
        data,
        error: e,
      });
      throw e;
    }
  }

  return data;
}
