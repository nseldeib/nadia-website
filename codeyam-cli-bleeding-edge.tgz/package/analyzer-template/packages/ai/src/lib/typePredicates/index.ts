import * as lib from '../../lib';

export function isBranchSummary(
  t: lib.types.JSON.Object,
): t is lib.types.BranchSummary {
  return typeof t.name === 'string' && typeof t.description === 'string';
}
