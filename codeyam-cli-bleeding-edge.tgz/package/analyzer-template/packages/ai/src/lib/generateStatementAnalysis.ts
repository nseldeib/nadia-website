import { Entity } from '~codeyam/types';
import completionCall from './completionCall';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import generateEntityPropsStructureGenerator from './promptGenerators/generateEntityPropsStructureGenerator';
import * as lib from '.';
import identifyReserved, { ReservedFeature } from './identifyReserved';
import splitOutsideParentheses from './splitOutsideParentheses';
import { loadStatement, saveStatement, generateSha } from '~codeyam/supabase';
import { ScopeInfo } from './dataStructure/ScopeDataStructure';

interface GenerateStatementAnalysisArgs {
  entity: Entity;
  scope: Pick<ScopeInfo, 'name' | 'text'>;
  issues: string;
  model?: lib.types.AI.Model;
}

export default async function generateStatementAnalysis({
  entity,
  scope,
  issues,
  model,
}: GenerateStatementAnalysisArgs) {
  const sha = generateSha(scope.text);

  const existingStatement = await loadStatement(sha);
  if (existingStatement) {
    const { structure, equivalentVariables } = JSON.parse(
      existingStatement.results,
    );
    return { structure, equivalentVariables, sha };
  }

  const prompt = generateEntityPropsStructureGenerator({
    code: scope.text,
  });

  const reservedStrategies = identifyReserved(scope.text).map((feature) =>
    feature.toString(),
  );

  const response = await completionCall({
    type: 'generateStatementAnalysis',
    systemMessage: SYSTEM_MESSAGE(reservedStrategies),
    prompt,
    model,
  });

  const llmCall = await saveLlmCall({
    object_type: 'entity',
    object_id: entity.sha,
    propsJson: {
      entity: {
        sha: entity.sha,
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      scope,
      model,
    },
    ...response.stats,
  });

  const { completion: responseString } = response;
  if (!responseString) {
    console.log(
      'CodeYam Error: Generating entity variable relations failed: No response from AI',
    );
    return null;
  }

  console.log(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} ${entity.name} scope statement (${scope.name}) :>> `,
  );
  const parse = (s: string) => {
    try {
      const { structure, equivalentVariables } = lib.parsers.parseJsonSafe(
        s.replace(/await\s+/g, '').replace(/\?/g, ''),
      ) as {
        structure: { [key: string]: string };
        equivalentVariables: { [key: string]: string };
      };
      return { structure, equivalentVariables };
    } catch (e) {
      console.info("CodeYam Error: Couldn't parse response from AI");
      console.info(scope.text);
      console.info(response);
      console.info(e);
      throw e;
    }
  };

  const { structure, equivalentVariables } = parse(responseString);

  await saveStatement({
    sha,
    llmCallId: llmCall.id,
    text: scope.text,
    results: JSON.stringify({ structure, equivalentVariables }, null, 2),
    issues,
  });

  // console.info(prompt);
  // console.info(SYSTEM_MESSAGE(reservedStrategies));
  // console.info(scope.text);
  // console.info({
  //   reservedStrategies: reservedStrategies.map((s) => ({
  //     name: s,
  //     exampleCount: STRATEGIES[s]?.examples?.length ?? 0,
  //   })),
  // });

  for (const keyPath in structure) {
    const parts = splitOutsideParentheses(keyPath);
    if (parts[parts.length - 1].match(/\(.*?\)/)) {
      structure[keyPath] = 'function';
    }

    const clean = (s: string) => s.replace(/\?\./g, '.');
    const cleanKeyPath = clean(keyPath);
    if (cleanKeyPath === keyPath) continue;

    structure[cleanKeyPath] = clean(structure[keyPath]);
    delete structure[keyPath];
  }

  for (const keyPath in equivalentVariables) {
    const value = equivalentVariables[keyPath];
    const valueParts = splitOutsideParentheses(value);
    const lastValue = valueParts[valueParts.length - 1];
    if (lastValue.match(/\(.*?\)/)) {
      equivalentVariables[keyPath] = `${value}.functionCallReturnValue`;
    }

    const keyPathParts = splitOutsideParentheses(keyPath);
    const lastKeyPath = keyPathParts[keyPathParts.length - 1];
    if (lastKeyPath.match(/\(.*?\)/)) {
      equivalentVariables[`${keyPath}.signature[0]`] =
        equivalentVariables[keyPath];
      delete equivalentVariables[keyPath];
    }

    if (keyPath.includes('functionCallReturnValue')) {
      if (!equivalentVariables[equivalentVariables[keyPath]]) {
        equivalentVariables[equivalentVariables[keyPath]] = keyPath;
      }
      delete equivalentVariables[keyPath];
    }
  }

  return { sha, structure, equivalentVariables, llmCall };
}

const SYSTEM_MESSAGE = (reservedStrategies: string[]) => `**Task:**  

We have a code snippet we need to analyze.

We want to determine:

1) What is the data structure of the variables in the code snippet?
3) What variables or aspects of variables are equivalent in the code snippet?

If there is any type information in the code snippet leverage it to inform the data structure of the variables but do not otherwise worry about it or include it. If a type is not a primitive simply label it as "object".

**Definitions:**

Data Structure: 
- Every variable in the code snippet has a data structure.
- The data structure of a variable is the type of data it holds. For example, a variable could hold a string, a number, an array, an object, a function, etc.
- We want to identify every aspect of every variable in the code snippet.

Example:
\`\`\`typescript
const { name, age } = person;
\`\`\`

In this case three variables are declared: \`name\`, \`age\`, and \`person\` so the overall structure would be:

\`\`\`json
{
  "structure": {
    "person": "object",
    "person.name": "string",
    "person.age": "number"
    "name": "string",
    "age": "number"
  }
}
\`\`\`

Equivalent Variables:
- In the code variables or aspects of a variable may be assigned to one another, passed in as arguments to a function call, or assigned to the return value of a function call.
- We want to track all of these equivalent variables so that we can merge the data structure of all equivalencies together.
- The key should be the variable or aspect of a variable that is recieving existing data from the other variable, which is the path.

Example:
\`\`\`typescript
const { name, hobbies } = person;
hobbies[0].started = selectedHobby.alreadyStarted;
\`\`\`

Here we have a number of equivalencies:

\`\`\`
{
  "equivalentVariables": {
    "name": "person.name",
    "hobbies": "person.hobbies",
    "hobbies[0].started": "selectedHobby.alreadyStarted"    
  }
}
\`\`\`

**Response:**

Combine these together to form the response:

\`\`\`json
{
  "structure": {
    "person": "object",
    "person.name": "string",
    "person.hobbies": "array",
    "person.hobbies[0]": "object",
    "person.hobbies[0].started": "boolean",
    "selectedHobby": "object",
    "selectedHobby.alreadyStarted": "boolean"
  },
  "equivalentVariables": {
    "name": "person.name",
    "hobbies": "person.hobbies",
    "hobbies[0].started": "selectedHobby.alreadyStarted"    
  }
}
\`\`\`
${keywords(reservedStrategies)}
${relevantExamples(reservedStrategies)}

---

**Important:**

- Take your time and analyze the code snippet carefully. Capture all the data structures, function calls, and equivalencies you can find. If you miss any the simulation will fail.
- Double check your work to ensure nothing was missed and all rules are followed.
`;

function keywords(reservedStrategies: string[]) {
  const messages: string[] = [];
  for (const strategy of reservedStrategies) {
    switch (strategy) {
      case ReservedFeature.FunctionCallWithPositionalArguments:
      case ReservedFeature.FunctionCallWithPositionalAndNamedArguments:
        messages.push(
          `- "signature[n]": The nth argument of a function call. For example, "foo(arg1, arg2)" has "signature[0]" equal to arg1 and "signature[1]" equal to arg2.`,
        );
        break;
      case ReservedFeature.FunctionCallWithNamedArguments:
      case ReservedFeature.FunctionCallWithPositionalAndNamedArguments:
        messages.push(
          `- "signature[n].name": A named variable in the nth argument of a function call. For example, "foo({ name, age })" has "signature[0].name" equal to name and "signature[0].age" equal to age.`,
        );
        break;
      case ReservedFeature.FunctionWithPositionalArguments:
      case ReservedFeature.FunctionWithPositionalAndNamedArguments:
      case ReservedFeature.ArrowFunctionWithPositionalArguments:
      case ReservedFeature.ArrowFunctionWithPositionalAndNamedArguments:
        messages.push(
          `- "signature[n]": The nth argument of a function definition. For example, "(arg1, arg2) => {...}" has arg1 equal to "signature[0]" and "arg2" equal to "signature[1]".`,
        );
        break;
      case ReservedFeature.FunctionWithNamedArguments:
      case ReservedFeature.FunctionWithPositionalAndNamedArguments:
      case ReservedFeature.FunctionWithComplexNamedArguments:
      case ReservedFeature.ArrowFunctionWithNamedArguments:
      case ReservedFeature.ArrowFunctionWithPositionalAndNamedArguments:
        messages.push(
          `- "signature[n].name": A named variable in the nth argument of a function definition. For example, "({ arg1, arg2 }) => {...}" has arg1 equal to "signature[0].arg1" and "arg2" equal to "signature[1].arg2".`,
        );
        break;
      case ReservedFeature.FunctionCallWithReturnValue:
        messages.push(
          `- "functionCallReturnValue": The return value of a function call. For example, "const result = foo(arg1, arg2);" has "result" equal to "foo(arg1, arg2).functionCallReturnValue". The "functionCallReturnValue" is always on the right hand side of the "equivalentVariables" because no data can be assigned to it.`,
        );
        break;
      case ReservedFeature.Return:
        messages.push(
          `- "returnValue": If this snippet is a return statement then the "returnValue" should be in the "equivalentVariables" section. For example, "return { name, age };" has "returnValue.name" equal to "name" and "returnValue.age" equal to "age".`,
        );
        break;
      case ReservedFeature.ReturnValueWithJSX:
        messages.push(
          `- "JSX": If this snippet has a return value that is JSX then you can simple label it as JSX (e.g. \`{ "returnValue": "JSX" }\`).`,
        );
        break;
    }
  }

  if (messages.length === 0) return '';

  return `
**Keywords:**

${messages.filter((m, index, self) => self.indexOf(m) === index).join('\n\n')}

`;
}

function relevantExamples(reservedStrategies: string[]) {
  if (reservedStrategies.length === 0) reservedStrategies = ['simple'];

  return `**Relevant Examples**

${reservedStrategies
  .map((strategy) => {
    const info = STRATEGIES[strategy];
    if (!info) return '';

    return `**${info.name}**
${
  info.explanation
    ? `${info.explanation}

`
    : ''
}
${info.examples
  .map((ex, i) => {
    return `**Example ${i + 1} ${ex.name}:**

\`\`\`typescript
${ex.code}
\`\`\`

Response:
\`\`\`json
${ex.response}
\`\`\`
`;
  })
  .join('\n\n')}`;
  })
  .join('\n\n')}`;
}

const STRATEGIES = {
  simple: {
    name: 'Basic Variable Assignment',
    examples: [
      {
        name: 'Simple',
        code: `selectedPerson.position = position.name;`,
        response: `{
    "structure": {
      "selectedPerson": "object",
      "selectedPerson.position": "string",
      "position": "object",
      "position.name": "string"
    },
    "equivalentVariables": {
      "selectedPerson.position": "position.name"
    }
  }`,
      },
      {
        name: 'Basic Deconstruction',
        code: `const { name, age } = getPerson(personId);`,
        response: `{
    "structure": {
      "personId": "string",
      "name": "string",
      "age": "number",
      "getPerson(personId)": "function"
    },
    "equivalentVariables": {
      "name": "getPerson(personId).functionCallReturnValue.name",
      "age": "getPerson(personId).functionCallReturnValue.age"
    }
  }`,
      },
    ],
  },
  function: {
    name: 'Function Definitions',
    examples: [
      {
        name: 'Function Definition',
        code: `function foo() { /* function body */ }`,
        response: `{
    "structure": {},
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  functionWithPositionalArguments: {
    name: 'Function Definition with Positional Arguments',
    explanation:
      'This snippet is a function definition (the wrapper function) that accepts positional arguments. Please capture the arguments passed into this function.',
    examples: [
      {
        name: 'Function Definition with Positional Arguments',
        code: `function foo(person, options) { /* function body */ }`,
        response: `{
    "structure": {
      "person": "object",
      "options: "object"
    },
    "equivalentVariables": {
      "person": "signature[0]": 
      "options": "signature[1]"
    }
  }`,
      },
    ],
  },
  functionWithNamedArguments: {
    name: 'Function Definition with Named Arguments',
    examples: [
      {
        name: 'Function Definition with Named Arguments',
        code: `function foo({ name, age }) { /* function body */ }`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number"
    },
    "equivalentVariables": {
      "name": "signature[0].name",
      "age": "signature[0].age"
    }
  }`,
      },
      {
        name: 'Function Definition with Named Argument That Has Type (ignore the type)',
        code: `function foo({ person }: { person: Person }) { /* function body */ }`,
        response: `{
    "structure": {
      "person": "object"
    },
    "equivalentVariables": {
      "person": "signature[0].person"
    }
  }`,
      },
      {
        name: 'Function Definition with Named Array Argument',
        code: `function foo({ items }: { items: Item[] }) { /* function body */ }`,
        response: `{
    "structure": {
      "items": "array",
      "items[]": "unknown"
    },
    "equivalentVariables": {
      "items": "signature[0].items"
    }
  }`,
      },
    ],
  },
  functionWithComplexNamedArguments: {
    name: 'Function Definition with Complex Named Arguments',
    examples: [
      {
        name: 'Function Definition with Named Arguments',
        code: `function PreviewCard({
  name,
  hobbies: { title, category }[],
  age
}: {
  name: string;
  hobbies: Hobby[];
  age: number;
}) { /* function body */ }`,
        response: `{
    "structure": {
      "name": "string",
      "title": "string",
      "category": "string",
      "age": "number",
    },
    "equivalentVariables": {
      "name": "signature[0].name",
      "title": "signature[0].hobbies.title",
      "category": "signature[0].hobbies.category",
      "age": "signature[0].age"
    }
  }`,
      },
    ],
  },
  functionWithPositionalAndNamedArguments: {
    name: 'Function Definition with Positional and Named Arguments',
    examples: [
      {
        name: 'Function Definition with Positional and Named Arguments',
        code: `function foo(name, { age, hobbies }) { /* function body */ }`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "hobbies": "array"
    },
    "equivalentVariables": {
      "signature[0]": "name",
      "signature[1].age": "age",
      "signature[1].hobbies": "hobbies"
    }
  }`,
      },
    ],
  },
  functionCall: {
    name: 'Function Calls',
    examples: [
      {
        name: 'Function Call No Arguments',
        code: `foo();`,
        response: `{
    "structure": {
      "foo()": "function"
    },
    "equivalentVariables": {}
  }`,
      },
      {
        name: 'Function Call As An Argument',
        code: `foo(cyScope2());`,
        response: `{
    "structure": {
      "foo(cyScope2())": "function",
      "cyScope2()": "function"
    },
    "equivalentVariables": {
      "foo(cyScope2()).signature[0]": "cyScope2().functionCallReturnValue"
    }
  }`,
      },
    ],
  },
  functionCallWithPositionalArguments: {
    name: 'Function Call with Positional Arguments',
    explanation:
      'There is one or more functions being called in this snippet. Please capture it and its positional arguments. Be sure to differentiate between called functions and a function definition.',
    examples: [
      {
        name: 'Function Call with Positional Arguments',
        code: `foo(person.name, person.age);`,
        response: `{
    "structure": {
      "person": "object",
      "person.name": "string",
      "person.age": "number",
      "foo(person.name, person.age)": "function"
    },
    "equivalentVariables": {
      "foo(person.name, person.age).signature[0]": "person.name",
      "foo(person.name, person.age).signature[1]": "person.age"
    }
  }`,
      },
      {
        name: 'Function Call with Function Call as a Positional Argument',
        code: `const biz = baz(cyScope5());`,
        response: `{
    "structure": {
      "cyScope5()": "function",
      "baz(cyScope5())": "function",
      "biz": "unknown"
    },
    "equivalentVariables": {
      "baz(cyScope5()).signature[0]": "cyScope5().functionCallReturnValue",
      "biz": "baz(cyScope5()).functionCallReturnValue"
    }
  }`,
      },
      {
        name: 'Function Call with Complex Positional Arguments',
        code: `const bar = foo(person.name, isSelected(), [group]);`,
        response: `{
    "structure": {
      "person": "object",
      "person.name": "string",
      "group": "string",
      "foo(person.name, isSelected(), [group])": "function",
      "isSelected()": "function"
      "bar": "unknown"
    },
    "equivalentVariables": {
      "foo(person.name, isSelected(), [group]).signature[0]": "person.name",
      "foo(person.name, isSelected(), [group]).signature[1]": "isSelected().functionCallReturnValue",
      "foo(person.name, isSelected(), [group]).signature[2][0]": "group",
      "bar": "foo(person.name, isSelected(), [group]).functionCallReturnValue"
    }
  }`,
      },
    ],
  },
  functionCallWithNamedArguments: {
    name: 'Function Call with Named Arguments',
    examples: [
      {
        name: 'Function Call with Named Arguments',
        code: `foo({ name, age }) { /* function body */ }`,
        response: `{
      "structure": {
        "name": "string",
        "age": "number",
        "foo({ name, age })": "function"
      },
      "equivalentVariables": {
        "foo({ name, age }).signature[0].name": "name",
        "foo({ name, age }).signature[0].age": "age"
      }
    }`,
      },
      {
        name: 'Function Call with Complex Named Arguments',
        code: `foo({ name, selected: isSelected(), options: { name, dependencies: [group] } }) { /* function body */ }`,
        response: `{
      "structure": {
        "name": "string",
        "group": "string",
        "isSelected()": "function",
        "foo({ name, selected: isSelected(), options: { name, dependencies: [group] } })": "function"  
      },
      "equivalentVariables": {
        "foo({ name, selected: isSelected(), options: { name, dependencies: [group] } }).signature[0].name": "name",
        "foo({ name, selected: isSelected(), options: { name, dependencies: [group] } }).signature[0].selected": "isSelected().functionCallReturnValue",
        "foo({ name, selected: isSelected(), options: { name, dependencies: [group] } }).signature[0].options.dependencies[0]": "group"
      }
    }`,
      },
    ],
  },
  functionCallWithPositionalAndNamedArguments: {
    name: 'Function Call with Positional and Named Arguments',
    examples: [
      {
        name: 'Function Call with Positional and Named Arguments',
        code: `foo(name, { age, hobbies }) { /* function body */ }`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "hobbies": "array",
      "foo(name, { age, hobbies })": "function"
    },
    "equivalentVariables": {
      "foo(name, { age, hobbies }).signature[0]": "name",
      "foo(name, { age, hobbies }).signature[1].age": "age",
      "foo(name, { age, hobbies }).signature[1].hobbies": "hobbies"
    }
  }`,
      },
    ],
  },
  functionCallWithReturnValue: {
    name: 'Function Call with Return Value',
    explanation:
      "Be sure to capture the functionCallReturnValue. It always goes on the right side of the equivalentVariables because it can't be assigned to. You do not need to describe the return value of the function in the structure section. Simply capture its equivalent values in the equivalentVariables section.",
    examples: [
      {
        name: 'Function Call with Return Value',
        code: `const data = foo(arg1, arg2);`,
        response: `{
    "structure": {
      "data": "unknown",
      "arg1": "unknown",
      "arg2": "unknown",
      "foo(arg1, arg2)": "function"
    },
    "equivalentVariables": {
      "foo(arg1, arg2).signature[0]": "arg1",
      "foo(arg1, arg2).signature[1]": "arg2",
      "data": "foo(arg1, arg2).functionCallReturnValue"
    }
  };`,
      },
      {
        name: 'Async Function Call with Return Value',
        code: `const foo = async bar({ selected });`,
        response: `{
    "structure": {
      "foo": "unknown",
      "selected": "unknown",
      "bar({ selected })": "function"
    },
    "equivalentVariables": {
      "bar({ selected }).signature[0].selected": "selected",
      "foo": "bar({ selected }).functionCallReturnValue"
    }
  };`,
      },
      {
        name: 'Function Call with Return Value used as Argument',
        code: `baz({ height: getHeight(), selected: isSelected(person) });`,
        response: `{
    "structure": {
      "person": "object",
      "getHeight()": "function",
      "isSelected(person)": "function",
      "baz({ height: getHeight(), selected: isSelected(person) })": "function"
    },
    "equivalentVariables": {
      "baz({ height: getHeight(), selected: isSelected(person) }).signature[0].height": "getHeight().functionCallReturnValue",
      "baz({ height: getHeight(), selected: isSelected(person) }).signature[0].selected": "isSelected(person).functionCallReturnValue",
      "isSelected(person).signature[0]": "person"
    }
  };`,
      },
    ],
  },
  functionCallWithReturnValueObjectDeconstructed: {
    name: 'Function Call with Deconstructed Return Value',
    examples: [
      {
        name: 'Function Call with Deconstructed Return Value',
        code: `const { name, age } = foo(arg1);`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "foo(arg1)": "function"
    },
    "equivalentVariables": {
      "foo(arg1).signature[0]": "arg1",
      "name": "foo().functionCallReturnValue.name",
      "age": "foo().functionCallReturnValue.age"
    }
  }`,
      },
    ],
  },
  functionCallWithReturnValueArrayDeconstructed: {
    name: 'Function Call with Deconstructed Return Value',
    examples: [
      {
        name: 'Function Call with Deconstructed Return Value',
        code: `const [name, age] = foo();`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "foo()": "function"
    },
    "equivalentVariables": {
      "name": "foo().functionCallReturnValue[0]",
      "age": "foo().functionCallReturnValue[1]"
    }
  }`,
      },
    ],
  },
  arrowFunction: {
    name: 'Arrow Function',
    examples: [
      {
        name: 'Arrow Function',
        code: `const foo = () => { /* function body */ };`,
        response: `{
    "structure": {},
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  anonymousArrowFunction: {
    name: 'Anonymous Arrow Function',
    explanation:
      'This code snippet is an anonymous arrow function. You do not need to record anything about it as it has no arguments.',
    examples: [
      {
        name: 'Anonymous Arrow Function With No Arguments',
        code: `() => { /* function body */ };`,
        response: `{
    "structure": {},
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  anonymousArrowFunctionWithPositionalArguments: {
    name: 'Anonymous Arrow Function with Positional Arguments',
    explanation:
      'This code snippet is an anonymous arrow function with positional arguments. Be sure to capture the arguments passed into this arrow function.',
    examples: [
      {
        name: 'Anonymous Arrow Function With Positional Arguments',
        code: `(arg1, arg2) => { /* function body */ };`,
        response: `{
    "structure": {
      "arg1": "unknown",
      "arg2": "unknown"
    },
    "equivalentVariables": {
      "arg1": "signature[0]",
      "arg2": "signature[1]" 
    }
  }`,
      },
    ],
  },
  anonymousArrowFunctionWithNamedArguments: {
    name: 'Anonymous Arrow Function With Named Arguments',
    explanation:
      'This code snippet is an anonymous arrow function with named arguments. Be sure to capture the arguments passed into this arrow function.',
    examples: [
      {
        name: 'Anonymous Arrow Function With Implicit Return Value',
        code: `({ name, age }) => ({ name, age })`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number"
    },
    "equivalentVariables": {
      "name": "signature[0].name",
      "age": "signature[0].age",
      "returnValue.name": "name",
      "returnValue.age": "age"
    }
  }`,
      },
    ],
  },
  anonymousArrowFunctionWithImplicitJSXReturnValue: {
    name: 'Anonymous Arrow Function With Implicit JSX Return Value',
    explanation:
      'This code snippet is an anonymous arrow function with an implicit JSX return value. Be sure to capture any arguments passed into the function and note that the return value is JSX.',
    examples: [
      {
        name: 'Anonymous Arrow Function With JSX Return Value',
        code: `(arg1) => (
    <Component name={arg1} />
  )`,
        response: `{
    "structure": {
      "arg1": "string",
      "Component()": "function"
    },
    "equivalentVariables": {
      "arg1": "signature[0]",
      "Component().signature[0].name": "arg1",
      "returnValue": "JSX"
    }
  }`,
      },
    ],
  },
  arrowFunctionWithPositionalArguments: {
    name: 'Arrow Function with Positional Arguments',
    explanation:
      'This code snippet is an arrow function with positional arguments. Be sure to capture the arguments passed into this arrow function.',
    examples: [
      {
        name: 'Arrow Function with Positional Arguments',
        code: `const foo = (a, b) => { /* function body */ };`,
        response: `{
    "structure": {
      "a": "string",
      "b": "string"
    },
    "equivalentVariables": {
      "a": "signature[0]",
      "b": "signature[1]"
    }
  }`,
      },
      {
        name: 'Anonymous Arrow Function with Positional Arguments',
        code: `(arg1, arg2) => { /* function body */ };`,
        response: `{
    "structure": {
      "arg1": "unknown",
      "arg2": "unknown"
    },
    "equivalentVariables": {
      "arg1": "signature[0]",
      "arg2": "signature[1]"
    }
  }`,
      },
    ],
  },
  arrowFunctionWithNamedArguments: {
    name: 'Arrow Function With Named Arguments',
    examples: [
      {
        name: 'Arrow Function with Named Arguments',
        code: `const foo = ({ name, age }) => { /* function body */ };`,
        response: `{
    "structure": {
      "name": "string",
      "age": "string"
    },
    "equivalentVariables": {
      "name": "signature[0].name",
      "age": "signature[0].age"
    }
  }`,
      },
    ],
  },
  arrowFunctionWithPositionalAndNamedArguments: {
    name: 'Arrow Function with Positional and Named Arguments',
    examples: [
      {
        name: 'Arrow Function with Positional and Named Arguments',
        code: `const foo = (a, { b, c }) => { /* function body */ };`,
        response: `{
    "structure": {
      "a": "string",
      "b": "string",
      "c": "string"
    },
    "equivalentVariables": {
      "a": "signature[0]",
      "b": "signature[1].b",
      "c": "signature[1].c"
    }
  }`,
      },
    ],
  },
  return: {
    name: 'Return Value',
    examples: [
      {
        name: 'Simple Return',
        code: `return age;`,
        response: `{
    "structure": {
      "age": "number",
      "returnValue": "number",
    },
    "equivalentVariables": {
      "returnValue: "age"
    }
  }`,
      },
      {
        name: 'Deconstructed Return',
        code: `return { name, age };`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "returnValue": "object",
      "returnValue.name": "string",
      "returnValue.age": "number"
    },
    "equivalentVariables": {
      "returnValue.name": "name",
      "returnValue.age": "age"
    }
  }`,
      },
    ],
  },
  returnValueWithJSX: {
    name: 'Return with JSX',
    examples: [
      {
        name: 'Return with JSX',
        code: `return <Person name={name} age={age} />;`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "Person()": "function"
    },
    "equivalentVariables": {
      "Person().signature[0].name": "name",
      "Person().signature[0].age": "age",
      "returnValue": "JSX"
    }
  }`,
      },
      {
        name: 'Return with Complex JSX',
        code: `return (
      <div>
        <List items={items.filter(cyScope1())} />
      </div>
    );`,
        response: `{
    "structure": {
      "items": "array",
      "items.filter(cyScope1())": "function",
      "cyScope1()" : "function",
      "List()": "function",
      "div()": "function"
    },
    "equivalentVariables": {
      "items.filter(cyScope1()).signature[0]": "cyScope1().functionCallReturnValue",
      "div().signature[0].children": "List().functionCallReturnValue",
      "List().signature[0].items": "items",
      "returnValue": "JSX"
    }
  }`,
      },
    ],
  },
  implicitReturn: {
    name: 'An Implicit Return Value',
    examples: [
      {
        name: 'Implicit Return',
        code: `const foo = (a, b) => ({ name: a, age: b });`,
        response: `{
    "structure": {
      "a": "string",
      "b": "string",
      "returnValue": "object",
      "returnValue.name": "string",
      "returnValue.age": "string"
    },
    "equivalentVariables": {
      "a": "signature[0]",
      "b": "signature[1]",
      "returnValue.name": "a",
      "returnValue.age": "b"
    }
  }`,
      },
      {
        name: 'Anonymous Function Implicit JSX Return',
        code: `(arg1) => (
    <div>{arg1}</div>
  );`,
        response: `{
    "structure": {
      "arg1": "string",
      "div()": "function"
    },
    "equivalentVariables": {
      "arg1": "signature[0]",
      "div().signature[0].children": "arg1",
      "returnValue": "JSX"
    }
  }`,
      },
    ],
  },
  jsx: {
    name: 'JSX Elements',
    examples: [
      {
        name: 'Simple JSX',
        code: `<PersonCard />`,
        response: `{
    "structure": {
      "PersonCard()": "function"
    },
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  jsxWithProps: {
    name: 'JSX with Props',
    explanation:
      "This code snippet has one or more JSX Elements that have props. The JSX element itself is a function call and each prop is a named argument to that function, represented with the 'signature[0]' keyword.",
    examples: [
      {
        name: 'JSX with Props',
        code: `<div className={className} style={style}></div>`,
        response: `{
    "structure": {
      "className": "string",
      "style": "object",
      "div()": "function"
    },
    "equivalentVariables": {
      "div().signature[0].className": "className",
      "div().signature[0].style": "style"
    }
  }`,
      },
      {
        name: 'Named JSX with Props',
        code: `<Person name={person.name} age={person.age} />`,
        response: `{
    "structure": {
      "name": "string",
      "age": "object",
      "Person()": "function"
    },
    "equivalentVariables": {
      "Person().signature[0].name": "name",
      "Person().signature[0].age": "age"
    }
  }`,
      },
      {
        name: 'Complex JSX with Props',
        code: `<Entity
  id={entity.id}   
  analysisKey={analysis.key}
  onClick={handleClick}
  className={className}
  userName={user.name}     
/>`,
        response: `{
    "structure": {
      "entity": "object",
      "entity.id": "string",
      "analysis": "object",
      "analysis.key": "string",
      "handleClick()": "function",
      "className": "string",
      "user": "object",
      "user.name": "string",
      "Entity()": "function"
    },
    "equivalentVariables": {
      "Entity().signature[0].id": "entity.id",
      "Entity().signature[0].analysisKey": "analysis.key",
      "Entity().signature[0].onClick": "handleClick",
      "Entity().signature[0].className": "className",
      "Entity().signature[0].userName": "user.name"
    }
  }`,
      },
    ],
  },
  functionCallWithinJSXProp: {
    name: 'Function Call within JSX Prop',
    examples: [
      {
        name: 'Function Call within JSX Prop',
        code: `<Person name={getName()} />`,
        response: `{
    "structure": {
      "getName()": "function",
      "Person()": "function"
    },
    "equivalentVariables": {
      "Person().signature[0].name": "getName().functionCallReturnValue"
    }
  }`,
      },
      {
        name: 'JSX with function calls that take arguments within props',
        code: `<ItemPreview
  name={item.name}
  img={getImg(item)}  
  cost={determineCostForItem(item)}
/>`,
        response: `{
  "structure": {
    "item": "object",
    "item.name": "string",
    "item.priceAttributes": "object",
    "getImg(item)": "function",
    "determineCostForItem(item.priceAttributes)": "function",
    "ItemPreview()": "function"
  },
  "equivalentVariables": {
    "ItemPreview().signature[0].name": "item.name",
    "ItemPreview().signature[0].img": "getImg(item).functionCallReturnValue",
    "ItemPreview().signature[0].cost": "determineCostForItem(item).functionCallReturnValue",
    "getImg(item).signature[0]": "item",
    "determineCostForItem(item.priceAttributes).signature[0]": "item.priceAttributes"
  }
}`,
      },
      {
        name: 'JSX with function calls that take complex arguments within props',
        code: `<Preview
  title={getTitle()}
  img={getImg(preview.image, preview.size)}  
  selected={isSelected({ preview })}
/>`,
        response: `{
  "structure": {
    "preview": "object",
    "preview.image": "string",
    "preview.size": "string",
    "getTitle()": "function",
    "getImg(preview.image, preview.size)": "function",
    "isSelected({ preview })": "function",
    "Preview()": "function"
  },
  "equivalentVariables": {
    "Preview().signature[0].title": "getTitle().functionCallReturnValue",
    "Preview().signature[0].img": "getImg(preview.image, preview.size).functionCallReturnValue",
    "Preview().signature[0].selected": "isSelected({ preview }).functionCallReturnValue",
    "getImg(preview.image, preview.size).signature[0]": "preview.image",
    "getImg(preview.image, preview.size).signature[1]": "preview.size",
    "isSelected({ preview }).signature[0].preview": "preview"
  }
}`,
      },
    ],
  },
  jsxWithChildren: {
    name: 'JSX Elements with Children',
    examples: [
      {
        name: 'JSX with Children',
        code: `<div>{name}</div>`,
        response: `{
    "structure": {
      "name": "string",
      "div()": "function"
    },
    "equivalentVariables": {
      "div().signature[0].children": "name"
    }
  }`,
      },
      {
        name: 'JSX with Props and Children',
        code: `(selectedName) => <ListItem 
    className={className} 
    selected={name === selectedName}
    onClick={handleClick}
  >
    {name}
  </List>`,
        response: `{
    "structure": {
      "className": "string",
      "name": "string",
      "selectedName": "string",
      "handleClick()": "function",
      "ListItem()": "function"
    },
    "equivalentVariables": {
      "selectedName": "signature[0]",
      "ListItem().signature[0].className": "className",
      "ListItem().signature[0].selected": "name === selectedName",
      "ListItem().signature[0].onClick": "handleClick",
      "ListItem().signature[0].children": "name",
      "returnValue": "JSX"
    }
  }`,
      },
    ],
  },
  nestedJSX: {
    name: 'Nested JSX Elements',
    examples: [
      {
        name: 'Nested JSX',
        code: `<div>
    <PersonCard name={name} age={age} />
  </div>`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "PersonCard()": "function",
      "div()": "function"
    },
    "equivalentVariables": {
      "PersonCard().signature[0].name": "name",
      "PersonCard().signature[0].age": "age",
      "div().signature[0].children": "PersonCard().functionCallReturnValue"
    }
  }`,
      },
      {
        name: 'Return Value with Nested JSX',
        code: `return <Link>
    <Emoji name={name} className={className} />
  </Link>`,
        response: `{
    "structure": {
      "name": "string",
      "className": "string",
      "Link()": "function",
      "Emoji()": "function"
    },
    "equivalentVariables": {
      "Link().signature[0].children": "Emoji().functionCallReturnValue",
      "Emoji().signature[0].name": "name",
      "Emoji().signature[0].className": "className",
      "returnValue": "JSX"
    }
  }`,
      },
    ],
  },
  arrayMap: {
    name: 'An array.map()',
    examples: [
      {
        name: 'Map',
        code: `items.map(cyScope1());`,
        response: `{
    "structure": {
      "items": "array",
      "cyScope1()": "function",
      "items.map(cyScope1())": "function"
    },
    "equivalentVariables": {
      "items.map(cyScope1()).signature[0]": "cyScope1().functionCallReturnValue"
    }
  }`,
      },
    ],
  },
  arrayMapInJsx: {
    name: 'An array.map() in JSX',
    examples: [
      {
        name: 'Map in JSX',
        code: `return (
    <div>
      {items.map(cyScope1())}
    </div>
  );`,
        response: `{
    "structure": {
      "items": "array",
      "cyScope1()": "function",
      "items.map(cyScope1())": "function",
      "div()": "function"
    },
    "equivalentVariables": {
      "div().signature[0].children": "items.map(cyScope1()).functionCallReturnValue",
      "items.map(cyScope1()).signature[0]": "cyScope1().functionCallReturnValue",
      "returnValue": "JSX"
    }
  }`,
      },
      {
        name: 'Map in JSX with other children',
        code: `return (
    <div>
      {name}
      {friends.map(cyScope1())}
      {cyScope2}
    </div>
  );`,
        response: `{
    "structure": {
      "name": "string",
      "friends": "array",
      "cyScope1()": "function",
      "items.map(cyScope1())": "function",
      "cyScope2": "unknown",
      "div()": "function"
    },
    "equivalentVariables": {
      "div().signature[0].children": "name",
      "div().signature[1].children": "friends.map(cyScope1()).functionCallReturnValue",
      "div().signature[2].children": "cyScope2",
      "friends.map(cyScope1()).signature[0]": "cyScope1().functionCallReturnValue",
      "returnValue": "JSX"
    }
  }`,
      },
      {
        name: 'Multiple maps in JSX',
        code: `return (
    <div>
      {items.map(cyScope1()).map(cyScope2())}
    </div>
  );`,
        response: `{
    "structure": {
      "items": "array",
      "cyScope1()": "function",
      "cyScope2()": "function",
      "items.map(cyScope1())": "function",
      "items.map(cyScope1()).map(cyScope2())": "function",
      "div()": "function"
    },
    "equivalentVariables": {
      "div().signature[0].children": "items.map(cyScope1()).map(cyScope2()).functionCallReturnValue",
      "items.map(cyScope1()).signature[0]": "cyScope1().functionCallReturnValue",
      "items.map(cyScope1()).map(cyScope2()).signature[0]": "cyScope2().functionCallReturnValue",
      "returnValue": "JSX"
    }
  }`,
      },
    ],
  },
  for: {
    name: 'A For Loop',
    examples: [
      {
        name: 'Simple For Loop',
        code: `for (let i = 0; i < items.length; i++) { /* loop body */ }`,
        response: `{
    "structure": {
      "items": "array",
      "items[]": "unknown",
      "i": "number"
    },
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  forOf: {
    name: 'A for-of Loop',
    examples: [
      {
        name: 'For Loop with Array',
        code: `for (const item of items) { /* loop body */ }`,
        response: `{
    "structure": {
      "items": "array",
      "items[]": "unknown",
      "item": "unknown"
    },
    "equivalentVariables": {
      "item": "items[]"
    }
  }`,
      },
    ],
  },
  while: {
    name: 'A While Loop',
    examples: [
      {
        name: 'Simple While Loop',
        code: `while (condition) { /* loop body */ }`,
        response: `{
    "structure": {
      "condition": "boolean"
    },
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  if: {
    name: 'An If Statement',
    examples: [
      {
        name: 'Simple If Statement',
        code: `if (condition) { /* if body */ }`,
        response: `{
    "structure": {
      "condition": "boolean"
    },
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  forIn: {
    name: 'A for-in Loop',
    examples: [
      {
        name: 'Simple For In Loop',
        code: `for (const key in obj) { /* loop body */ }`,
        response: `{
    "structure": {
      "obj": "object",
      "key": "string"
    },
    "equivalentVariables": {
      "key": "obj[*key*]"
    }
  }`,
      },
    ],
  },
  switch: {
    name: 'A Switch Statement',
    examples: [
      {
        name: 'Simple Switch Statement',
        code: `switch (value) {
    case 1:
      /* case 1 body */
      break;
    case 2:
      /* case 2 body */
      break;
  }`,
        response: `{
    "structure": {
      "value": "unknown"
    },
    "equivalentVariables": {}
  }`,
      },
    ],
  },
  ternary: {
    name: 'Ternary Operator',
    examples: [
      {
        name: 'Simple Ternary',
        code: `const value = condition ? trueValue : falseValue;`,
        response: `{
    "structure": {
      "condition": "boolean",
      "trueValue": "unknown",
      "falseValue": "unknown",
      "value": "unknown"
    },
    "equivalentVariables": {
      "value": "trueValue",
    }
  }`,
      },
    ],
  },
  stringInterpolation: {
    name: 'String Interpolation',
    explanation:
      'Interpolated strings are not equivalent to anything, but please extract any variable structure that is exposed within the string.',
    examples: [
      {
        name: 'Simple String Interpolation',
        code: `const message = \`Hello, \${name}!\`;`,
        response: `{
  "structure": {
    "name": "string",
    "message": "string"
  },
  "equivalentVariables": {}
}`,
      },
      {
        name: 'String Interpolation with Complex Structure',
        code: `const message = \`Hello, \${person.name}! You are \${person.age} years old.\`;`,
        response: `{
  "structure": {
    "person": "object",
    "person.name": "string",  
    "person.age": "number",
    "message": "string"
  },
  "equivalentVariables": {}
}`,
      },
    ],
  },
  useState: {
    name: 'useState React Hook',
    explanation:
      'We need to track the state variable and the setter function for each useState call so this is a special case.',
    examples: [
      {
        name: 'useState with Default Value',
        code: `const [person, setPerson] = useState<Person>(selectedPerson);`,
        response: `{
  "structure": {
    "person": "unknown",
    "setPerson": "function",
    "useState<Person>(selectedPerson)": "function"
  },
  "equivalentVariables": {
    "useState<Person>(selectedPerson).signature[0]": "selectedPerson",
    "[person, setPerson]": "useState<Person>(selectedPerson).functionCallReturnValue"
  }
}`,
      },
      {
        name: 'useState with No Default Value',
        code: `const [name, setName] = useState();`,
        response: `{
  "structure": {
    "name": "unknown",
    "setName": "function",
    "useState()": "function"
  },
  "equivalentVariables": {
    "[name, setName]": "useState().functionCallReturnValue"
  }
}`,
      },
    ],
  },
  useEffect: {
    name: 'useEffect React Hook',
    explanation:
      'The useEffect hook does not affect the structure or equivalentVariables so it can be ignored',
    examples: [
      {
        name: 'Simple useEffect',
        code: `useEffect(cyScope1(), [name]);`,
        response: `{
  "structure": {
    "name": "unknown",
    "cyScope1()": "function",
  },
  "equivalentVariables": {}
}`,
      },
    ],
  },
  functionCallWithReturnValueObjectDestructured: {
    name: 'Function Call with Destructured Return Value',
    examples: [
      {
        name: 'Function Call with Destructured Return Value',
        code: `const { name, age } = foo();`,
        response: `{
    "structure": {
      "name": "string",
      "age": "number",
      "foo()": "function"
    },
    "equivalentVariables": {
      "foo().signature[0]": "unknown",
      "name": "foo().functionCallReturnValue.name",
      "age": "foo().functionCallReturnValue.age"
    }
  }`,
      },
    ],
  },
  destructuring: {
    name: 'Destructured Instantiation',
    examples: [
      {
        name: 'Simple Destructuring',
        code: `const { name, age } = api.fetchPerson();`,
        response: `{
  "structure": {
    "api": "object",
    "api.fetchPerson()": "function",
    "name": "string",
    "age": "number"
  },
  "equivalentVariables": {
    "name": "api.fetchPerson().functionCallReturnValue.name",
    "age": "api.fetchPerson().functionCallReturnValue.age"
  }
}`,
      },
    ],
  },
  repeatedMethodChaining: {
    name: 'Repeated Method Chaining',
    explanation:
      "With long method chains it's crucial to capture the full structure of the chain, especially for the functionCallReturnValue.",
    examples: [
      {
        name: 'Simple Method Chaining',
        code: `const biz = foo(arg1)
  .bar({ arg2, arg3 })
  .bar()
  .baz(arg4, arg5)
  .boo();`,
        response: `{
  "structure": {
    "arg1": "unknown",
    "arg2": "unknown",
    "arg3": "unknown",
    "arg4": "unknown",
    "arg5": "unknown",
    "foo(arg1)": "function",
    "foo(arg1).bar({ arg2, arg3 })": "function",
    "foo(arg1).bar({ arg2, arg3 }).bar()": "function",
    "foo(arg1).bar({ arg2, arg3 }).bar().baz(arg4, arg5)": "function",
    "foo(arg1).bar({ arg2, arg3 }).bar().baz(arg4, arg5).boo()": "function"
  },
  "equivalentVariables": {
   "biz": "foo(arg1).bar({ arg2, arg3 }).bar().baz(arg4, arg5).boo().functionCallReturnValue"
  }
}`,
      },
      {
        name: 'Method Chaining with Destructured Value',
        code: `const { data, error } = foo(arg1)
  .bar({ arg2, arg3 })
  .bar()
  .baz(arg4, arg5)
  .boo();`,
        response: `{
  "structure": {
    "arg1": "unknown",
    "arg2": "unknown",
    "arg3": "unknown",
    "arg4": "unknown",
    "arg5": "unknown",
    "foo(arg1)": "function",
    "foo(arg1).bar({ arg2, arg3 })": "function",
    "foo(arg1).bar({ arg2, arg3 }).bar()": "function",
    "foo(arg1).bar({ arg2, arg3 }).bar().baz(arg4, arg5)": "function",
    "foo(arg1).bar({ arg2, arg3 }).bar().baz(arg4, arg5).boo()": "function"
  },
  "equivalentVariables": {
   "data": "foo(arg1).bar({ arg2, arg3 }).bar().baz(arg4, arg5).boo().functionCallReturnValue.data"
   "error": "foo(arg1).bar({ arg2, arg3 }).bar().baz(arg4, arg5).boo().functionCallReturnValue.error"
  }
}`,
      },
    ],
  },
  alternativeValues: {
    name: 'Alternative Values',
    explanation:
      'We are focused on discovering the structure of the variables, so alternative values are simlply two things with at least partially equivalent structures.',
    examples: [
      {
        name: 'Alternative Values',
        code: `const name = person.name || "Unknown";`,
        response: `{
    "structure": {
      "person": "object",
      "person.name": "string",
      "name": "string"
    },
    "equivalentVariables": {
      "name": "person.name"
    }
  }`,
      },
      {
        name: 'Alternative Values with Two Variables',
        code: `const selectedPerson = group.selectedPerson || person;`,
        response: `{
    "structure": {
      "group": "object",
      "group.selectedPerson": "object",
      "person": "object",
      "selectedPerson": "object"
    },
    "equivalentVariables": {
      "selectedPerson": "group.selectedPerson",
      "group.selectedPerson": "person"
    }
  }`,
      },
    ],
  },
  nullishCoalescing: {
    name: 'Nullish Coalescing',
    explanation:
      'We are focused on discovering the structure of the variables so create an equivalency with the variable path before the ?? operator. Do not worry about the default value.',
    examples: [
      {
        name: 'Basic Default Value',
        code: `const name = person.name ?? "Unknown";`,
        response: `{
    "structure": {
      "person": "object",
      "person.name": "string",
      "name": "string"
    },
    "equivalentVariables": {
      "name": "person.name"
    }
  }`,
      },
      {
        name: 'Object as Default Value',
        code: `const selectedPerson = group.selectedPerson ?? person;`,
        response: `{
    "structure": {
      "group": "object",
      "group.selectedPerson": "object",
      "person": "object",
      "selectedPerson": "object"
    },
    "equivalentVariables": {
      "selectedPerson": "group.selectedPerson",
      "group.selectedPerson": "person"
    }
  }`,
      },
    ],
  },
  arrayFilter: {
    name: 'Array Filter',
    examples: [
      {
        name: 'Simple Array Filter',
        code: `const selectedItems = items.filter(cyScope1());`,
        response: `{
    "structure": {
      "items": "array",
      "cyScope1()": "function",
      "items.filter(cyScope1())": "function"
    },
    "equivalentVariables": {
      "selectedItems": "items.filter(cyScope1()).functionCallReturnValue",
      "items.filter(cyScope1()).signature[0]": "cyScope1().functionCallReturnValue"
    }
  }`,
      },
    ],
  },
  functionCallReturnValueInFunctionCall: {
    name: "A Function Call's Return Value Used in Another Function Call",
    examples: [
      {
        name: 'Function Call Return Value in Another Function Call',
        code: `const selectedItems = items.filter(cyScope1()).map(cyScope2());`,
        response: `{
  "structure": {
    "selectedItems": "array",
    "items": "array",
    "cyScope1()": "function",
    "cyScope2()": "function",
    "items.filter(cyScope1())": "function",
    "items.filter(cyScope1()).map(cyScope2())": "function"
  },
  "equivalentVariables": {
    "selectedItems": "items.filter(cyScope1()).map(cyScope2()).functionCallReturnValue",
    "items.filter(cyScope1()).signature[0]": "cyScope1().functionCallReturnValue",
    "items.filter(cyScope1()).map(cyScope2()).signature[0]": "cyScope2().functionCallReturnValue"
  }
}`,
      },
    ],
  },
};
