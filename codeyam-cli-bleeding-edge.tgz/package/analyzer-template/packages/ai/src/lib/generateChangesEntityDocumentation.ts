import { Entity } from '~codeyam/types';
import completionCall from './completionCall';
import generateChangesEntityDocumentationGenerator from './promptGenerators/generateChangesEntityDocumentationGenerator';
import * as lib from '.';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import { awsLog } from '~codeyam/utils';

interface DocumentationArgs {
  entity: Entity;
  previousDocumentation: string;
  model?: lib.types.AI.Model;
}

export default async function generateChangesEntityDocumentation({
  entity,
  previousDocumentation,
  model,
}: DocumentationArgs) {
  if (!['visual', 'library'].includes(entity.entityType)) return null;

  const prompt = generateChangesEntityDocumentationGenerator(
    entity,
    previousDocumentation,
  );

  const { completion: documentation, stats } = await completionCall({
    type: 'entityDocumentation',
    systemMessage:
      'You are an expert coder and educator. You think a lot about how people can understand new things, recognizing that it is a mixture of direct facts and numerous examples from different perspectives.',
    prompt,
    model,
    jsonResponse: false,
  });

  const llmCall = await saveLlmCall({
    object_type: 'entity',
    object_id: entity.sha,
    propsJson: {
      entity: {
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      model,
    },
    ...stats,
  });

  if (!documentation) {
    console.log('CodeYam Error: Documentation failed: No response from AI');
    return null;
  }

  awsLog(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} (${entity.name}): ${entity.filePath} (${entity.name}) documentation :>> `,
    documentation,
  );

  if (documentation === 'No changes needed') {
    return { documentation: previousDocumentation, llmCall };
  }

  return { documentation, llmCall };
}
