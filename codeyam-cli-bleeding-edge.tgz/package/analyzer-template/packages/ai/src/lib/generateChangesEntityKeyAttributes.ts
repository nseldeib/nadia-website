import completionCall from './completionCall';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import { Entity, Analysis } from '~codeyam/types';
import generateEntityKeyAttributesGenerator from './promptGenerators/generateEntityKeyAttributesGenerator';
import * as lib from '.';
import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from './splitOutsideParentheses';
import findMatchingAttribute from './findMatchingAttribute';
import { awsLog } from '~codeyam/utils';
import { DEFAULT_LARGER_MODEL } from '~codeyam/ai';
import isFrontend from './isFrontend';

interface GenerateChangesEntityKeyAttributesArgs {
  entity: Entity;
  existingKeyAttributes: Analysis['metadata']['keyAttributes'];
  analysis: Analysis;
  commitDiff: string;
  model?: lib.types.AI.Model;
}

export default async function generateChangesEntityKeyAttributes({
  entity,
  existingKeyAttributes,
  analysis,
  commitDiff,
  model,
}: GenerateChangesEntityKeyAttributesArgs) {
  awsLog(`CodeYam: Generating entity key attributes`, {
    filePath: entity.filePath,
    entityName: entity.name,
    analysisId: analysis.id,
    existingKeyAttributes: existingKeyAttributes?.map((a) => a.externalPath),
  });

  const attributesMap: Record<string, string> = {};

  const { signatureSchema, equivalentSignatureVariables, dependencySchemas } =
    entity.metadata.isolatedDataStructure;
  for (const key in signatureSchema) {
    const keyParts = splitOutsideParenthesesAndArrays(key);
    if (keyParts[0].startsWith('signature')) {
      const equivalentSignatureVariable =
        equivalentSignatureVariables[keyParts[0]];
      const equivalentSignatureVariableParts = splitOutsideParenthesesAndArrays(
        equivalentSignatureVariable,
      );
      if (
        equivalentSignatureVariable &&
        !equivalentSignatureVariableParts[0].includes('(')
      ) {
        const equivalentKey = equivalentSignatureVariables[keyParts[0]];
        attributesMap[
          joinParenthesesAndArrays([equivalentKey, ...keyParts.slice(1)])
        ] = signatureSchema[key];
      } else {
        attributesMap[joinParenthesesAndArrays(keyParts.slice(1))] =
          signatureSchema[key];
      }
    }
  }

  for (const filePath in dependencySchemas) {
    for (const entityName in dependencySchemas[filePath]) {
      const returnValueDataStructure =
        dependencySchemas[filePath][entityName].returnValueSchema ?? {};
      const functionPaths: string[] = [];
      for (const path in returnValueDataStructure) {
        const pathParts = splitOutsideParenthesesAndArrays(path);
        if (pathParts.length < 2) continue;

        if (returnValueDataStructure[path] === 'function') {
          functionPaths.push(path);
          continue;
        }

        if (
          functionPaths.some((functionPath) => path.startsWith(functionPath))
        ) {
          continue;
        }

        const relativePath = joinParenthesesAndArrays(pathParts.slice(2));
        if (relativePath.length === 0 || relativePath.startsWith('[')) continue;

        attributesMap[relativePath] = returnValueDataStructure[path];
      }
    }
  }

  const prompt = generateEntityKeyAttributesGenerator({
    code: entity.code,
    attributesMap,
    existingKeyAttributes,
    commitDiff,
  });

  const response = await completionCall({
    type: `generateChangesEntityKeyAttributes`,
    systemMessage: isFrontend(entity.filePath)
      ? FRONTEND_SYSTEM_MESSAGE
      : BACKEND_SYSTEM_MESSAGE,
    prompt,
    model: model ?? DEFAULT_LARGER_MODEL,
  });

  const llmCall = await saveLlmCall({
    object_type: 'analysis',
    object_id: analysis.id,
    propsJson: {
      entity: {
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      analysis: {
        id: analysis.id,
        metadata: {
          isolatedDataStructure: {
            signatureSchema,
            equivalentSignatureVariables,
          },
          keyAttributes: analysis.metadata?.keyAttributes ?? [],
        },
      },
      commitDiff,
      model,
    },
    ...response.stats,
  });

  const { completion: keyAttributesString } = response;
  if (!keyAttributesString) {
    console.log(
      `CodeYam Error: Error Generating changes entity key attributes failed: No response from AI`,
    );
    return null;
  }

  awsLog(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} ${entity.name} changes key attributes :>> `,
    keyAttributesString,
  );

  const { addedKeyAttributes, removedKeyAttributes } =
    JSON.parse(keyAttributesString);

  const keyAttributes: Analysis['metadata']['keyAttributes'] = [
    ...(existingKeyAttributes ?? []),
  ];

  for (const addedKeyAttribute of addedKeyAttributes ?? []) {
    const index = keyAttributes.findIndex(
      (a) => a.internalPath === addedKeyAttribute.internalPath,
    );
    if (index !== -1) {
      keyAttributes.splice(index, 1, addedKeyAttribute);
    } else {
      keyAttributes.push(addedKeyAttribute);
    }
  }

  for (const removedKeyAttribute of removedKeyAttributes ?? []) {
    const index = keyAttributes.findIndex(
      (a) => a.internalPath === removedKeyAttribute.internalPath,
    );
    if (index !== -1) {
      keyAttributes.splice(index, 1);
    }
  }

  const sortedUniqueKeyAttributes = keyAttributes
    .filter(
      (keyAttribute, index, self) =>
        self.findIndex(
          (ka) => ka.internalPath === keyAttribute.internalPath,
        ) === index,
    )
    .map((keyAttribute) => {
      const matchingAttribute = findMatchingAttribute(
        keyAttribute.internalPath,
        Object.keys(attributesMap),
        entity.metadata.isolatedDataStructure.equivalentSignatureVariables,
      );
      if (!matchingAttribute) return;
      return {
        ...keyAttribute,
        path: matchingAttribute,
      };
    })
    .filter(Boolean);

  return {
    keyAttributes: sortedUniqueKeyAttributes,
    llmCall,
  };
}

const FRONTEND_SYSTEM_MESSAGE = `We have a frontend function that was recently changed.

Can you help us identify if any of the key data attributes in the function are no longer valid or if any new key data attributes should be added to the list?

We've provided a list of the existing key data attributes, the commit diff, a list of all data attributes that are now valid, and the function code.

Each key attribute represents a path from a top level variable and that path must be noted exactly as it is in the "Attributes and Value Types" list.

Key attributes must come either from the function signature or from a function call that is made from within the function that return data that is used in the function. Please capture the attrribute path exactly from the list.

If an attribute has the keyword "functionCallReturnValue" in it, it is a function call that returns data that is used in the function. That keyword simply designated the return value of the function call. If an attribute path has "[]" in it (e.g. "items[]") that represents one item in that array.

## Key Attribute Rules

- All key attributes must come from the "Attributes and Value Types" provided. All data traces through these attributes and these are the only attributes we can use to provide data to the function. Only use these attributes. Do not reference internally computed variables. Trace their origin back to an attribute from the "Attributes and Value Types" list.

### Should be a key attribute

- Changing the value, length (e.g. for strings or arrays), etc of this variable will dramatically change how the component displays (the return value of the function).

- Is used in a conditional that dramatically alters how the component displays (note: if the conditional compares two or more variables, note which variables are involved and how they must be set to cause different behavior).

### Should NOT be a key attribute

- Changing the value of this variable will cause an error or exception to be thrown.

- Changing the value of this variable will cause a guard clause to be triggered that results in nothing being displayed.

- Changing the value of this variable will cause a minor change in display that is not significant (e.g. slightly different text).

- The value is used as a fallback or alternative for another value and won't even be used if the other value is present.

- The value changes non-visible behavior (e.g. the href in a link or src in an image - all images sources are mocked out).

## Instructions

- Read each line of code. Pay particular attention to the return value of the function and how this frontend component will be displayed. What will cause it display distinctly different but functional and robust results to the user?
- Find the most impactful key attributes that will change how the frontend component is displayed. This should be a limited subset of the "Attributes and Value Types" provided.
- Reference the list of existing key attributes to determine if any of them are no longer valid or if any new key attributes should be added.
- Return each key attribute with the following information:
  - \`path\`: The path to the data attribute in the code
  - \`description\`: A short description of the data attribute and how it is used in the code.
  - \`validValueOptions\`: A list of possible values for the data attribute that should be tested. This should include extreme values that could cause different behavior in the code but these values should not cause an error.
- Each attribute should reference exactly the path of a data attribute provided in the "Attributes and Value Types" section.

## Response

Please respond by specifying which attributes need to be added or removed. For removed attributes just specify the path that is no longer valid.

\`\`\`json
{
  "addedKeyAttributes": [
    {
      "path": "notification.read",
      'percentage": 50,
      "description": "The read status of the notification determines how the message is displayed.",
      "validValueOptions": [
        "true",
        "false"
      ],
      "errorValueOptions": []
    },
  ],
  "removedKeyAttributes": [
    "notification.message"
  ]
}
\`\`\`

## Important

- A key attribute must be an exact attribute path from the "Attributes and Value Types" provided. Do not return any other attribute paths.  The only data we can provide to the function comes from these attributes so any other attribute is useless. For internally computed variables trace them back to one of the higher level variables that we can actually impact. Be sure to match the text from the attribute list exactly including spaces, commas, etc.
`;

const BACKEND_SYSTEM_MESSAGE = `We have a function that was recently changed.

Can you help us identify if any of the key data attributes in the function are no longer valid or if any new key data attributes should be added to the list?

We've provided a list of the existing key data attributes, the commit diff, a list of all data attributes that are now valid, and the function code.

Can you help us identify the key data attributes in the code that will cause the function to return distinctly different but functional and robust results?

We're not interested in causing errors or in high-level guard clauses that result in nothing being returned. We're interested in always returning a robust result that demonstrates the core intent of the function.

In order to do so we want to identify the key data attributes in the code.

Each key attribute represents a path from a top level variable and that path must be noted exactly as it is in the "Attributes and Value Types" list.

Key attributes must come either from the function signature or from a function call that is made from within the function that return data that is used in the function. Please capture the attrribute path exactly from the list.

If an attribute has the keyword "functionCallReturnValue" in it, it is a function call that returns data that is used in the function. That keyword simply designated the return value of the function call. If an attribute path has "[]" in it (e.g. "items[]") that represents one item in that array.

## Key Attribute Rules

- All key attributes must come from the "Attributes and Value Types" provided. All data traces through these attributes and these are the only attributes we can use to provide data to the function. Only use these attributes. Do not reference internally computed variables. Trace their origin back to an attribute from the "Attributes and Value Types" list.

### Should be a key attribute

- Changing the value, length (e.g. for strings or arrays), etc of this variable will dramatically impact the return value of the function.

- Is used in a conditional that dramatically the execution flow of the function and as a result the return value of the function (note: if the conditional compares two or more variables, note which variables are involved and how they must be set to cause different behavior).

- Note: some functions do not return anything but instead call out to other systems (e.g. send an email, write to a database, etc). In those cases, the key attributes should be those that dramatically change how the function interacts with those other systems.

### Should NOT be a key attribute

- Changing the value of this variable will cause an error or exception to be thrown.

- Changing the value of this variable will cause a guard clause to be triggered that results in nothing or very little being returned.

- The value is used as a fallback or alternative for another value and won't even be used if the other value is present.

## Instructions

- Read each line of code. Pay particular attention to the return value of the function. What data attributes will cause it to return distinctly different but functional and robust results?
- Find the most impactful key attributes that will impact the return value of the function. This should be a limited subset of the "Attributes and Value Types" provided.
- Reference the list of existing key attributes to determine if any of them are no longer valid or if any new key attributes should be added.
- Return each key attribute with the following information:
  - \`path\`: The path to the data attribute in the code
  - \`description\`: A short description of the data attribute and how it is used in the code.
  - \`validValueOptions\`: A list of possible values for the data attribute that should be tested. This should include extreme values that could cause different behavior in the code but these values should not cause an error.
- Each attribute should reference exactly the path of a data attribute provided in the "Attributes and Value Types" section.

## Response

Please respond by specifying which attributes need to be added or removed. For removed attributes just specify the path that is no longer valid.

\`\`\`json
{
  "addedKeyAttributes": [
    {
      "path": "notification.read",
      'percentage": 50,
      "description": "The read status of the notification determines how the message is displayed.",
      "validValueOptions": [
        "true",
        "false"
      ],
      "errorValueOptions": []
    },
  ],
  "removedKeyAttributes": [
    "notification.message"
  ]
}
\`\`\`

## Important

- A key attribute must be an exact attribute path from the "Attributes and Value Types" provided. Do not return any other attribute paths.  The only data we can provide to the function comes from these attributes so any other attribute is useless. For internally computed variables trace them back to one of the higher level variables that we can actually impact. Be sure to match the text from the attribute list exactly including spaces, commas, etc.
`;
