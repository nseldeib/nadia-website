import { normalizeKey } from '~codeyam/utils';
import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from './splitOutsideParentheses';

function findEquivalent(path: string, equivalents: Record<string, string>) {
  const pathParts = splitOutsideParenthesesAndArrays(path);
  for (const equivalentKey in equivalents) {
    const equivalentKeyParts = splitOutsideParenthesesAndArrays(equivalentKey);
    if (equivalentKeyParts.some((part) => part.startsWith('signature['))) {
      continue;
    }

    const relevantKey = joinParenthesesAndArrays(
      pathParts.slice(0, equivalentKeyParts.length),
    );
    if (equivalentKey === relevantKey) {
      const equivalentValue = equivalents[equivalentKey];
      return joinParenthesesAndArrays([
        equivalentValue,
        ...pathParts.slice(equivalentKeyParts.length),
      ]);
    }
  }
}

function findReverseEquivalent(
  path: string,
  equivalents: Record<string, string>,
) {
  const pathParts = splitOutsideParenthesesAndArrays(path);
  for (const [equivalentKey, equivalentValue] of Object.entries(equivalents)) {
    const equivalentKeyParts = splitOutsideParenthesesAndArrays(equivalentKey);

    if (equivalentKeyParts.some((part) => part.startsWith('signature['))) {
      continue;
    }

    const equivalentValueParts =
      splitOutsideParenthesesAndArrays(equivalentValue);

    const relevantKey = joinParenthesesAndArrays(
      pathParts.slice(0, equivalentValueParts.length),
    );
    if (equivalentValue === relevantKey) {
      return joinParenthesesAndArrays([
        equivalentKey,
        ...pathParts.slice(equivalentValueParts.length),
      ]);
    }
  }
}

export default function findMatchingAttribute(
  attributePath: string,
  attributesList: string[],
  equivalents: Record<string, string>,
) {
  // console.log("CODEYAM DEBUG: findMatchingAttribute called with", JSON.stringify({
  //   attributePath,
  //   attributesList,
  //   equivalents,
  // }, null, 2));

  const equivalent = findEquivalent(attributePath, equivalents);
  const reverseEquivalent = findReverseEquivalent(attributePath, equivalents);
  if (attributesList.includes(attributePath)) {
    if (reverseEquivalent) {
      return reverseEquivalent;
    }
    return attributePath;
  } else if (equivalent && attributesList.includes(equivalent)) {
    return equivalent;
  } else {
    const normalizedPath = normalizeKey(attributePath);
    const matchingAttribute = attributesList.find(
      (attr) => normalizeKey(attr) === normalizedPath,
    );

    // If no exact match find the attribute that matches the most characters starting from the beginning
    if (!matchingAttribute) {
      const options = attributesList;
      const normalizedPathCharacters = normalizedPath.split('');
      for (const attr of options) {
        const attrCharacters = normalizeKey(attr).split('');
        const matchLength = normalizedPathCharacters.findIndex(
          (char, index) => char !== attrCharacters[index],
        );
        if (matchLength !== -1) {
          const matchedPrefix = normalizedPathCharacters.slice(0, matchLength);
          if (matchedPrefix.length > 0) {
            return attr;
          }
        }
      }
    }

    if (matchingAttribute) return matchingAttribute;
    return null;
  }
}
