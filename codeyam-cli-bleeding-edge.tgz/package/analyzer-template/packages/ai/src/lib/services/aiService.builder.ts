import OpenAI from 'openai';
import * as lib from '..';
import { DEFAULT_SMALLER_MODEL } from '../aiConfig';

/**
 * The **single responsibility** of the AIService is to send requests and
 * receive responses. Additional functionality / features should live elsewhere.
 */
export function aiServiceBuilder(): lib.types.AI.OpenAI.Service {
  const model = DEFAULT_SMALLER_MODEL;

  return {
    model,
    async sendChatRequest(chatRequest) {
      // Moving this constructor out of this function means it will get invoked
      // immediately, even in testing, which causes problem when the config
      // isn't set. Once we need to move this outside of this function, we
      // should discuss configuration solutions to accomodate.
      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      const params = lib.openai.chatRequestToOpenAIChatParams(chatRequest);
      return await openai.chat.completions.create(params);
    },
  };
}
