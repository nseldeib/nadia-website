import { saveLlmCall } from '~codeyam/aws/dynamodb';
import * as lib from '..';
import OpenAI from 'openai';

export function dbServiceBuilder({
  aiService,
}: {
  aiService: lib.types.AI.OpenAI.Service;
}): lib.types.AI.DBService {
  return {
    async saveAICall({
      chatRequest,
      chatCompletion,
    }: {
      chatRequest: lib.types.AI.ChatRequest;
      chatCompletion: OpenAI.ChatCompletion;
    }) {
      const llmCallStats = lib.getLLMCallStats({
        chatRequest,
        chatCompletion,
        model: aiService.model,
      });

      await saveLlmCall({
        object_type: 'chat',
        object_id: 'new',
        propsJson: {
          model: aiService.model,
        },
        ...llmCallStats,
      });
    },
  };
}
