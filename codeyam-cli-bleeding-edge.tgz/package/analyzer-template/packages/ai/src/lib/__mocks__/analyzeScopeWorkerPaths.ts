export default function analyzeScopeWorkerPaths() {
  return {
    PRE_WORKER_PATH: null,
    POST_WORKER_PATH: null
  };
}
