import OpenAI from 'openai';
import * as lib from '../../lib';

/**
 * Meant to be used for Jest tests only. This is a verbatim copy of the completionCall
 * function from the ai package, with the dependency on p-queue and p-retry stripped out
 * because Jest can't handle pure ESM packages.
 */

interface CompletionCallProps {
  type: string;
  systemMessage: string;
  prompt: string;
  jsonResponse?: boolean;
  model?: lib.types.AI.Model;
  attempts?: number;
}

export default async function completionCall({
  type,
  systemMessage,
  prompt,
  jsonResponse = true,
  model = lib.types.AI.Model.OPENAI_GPT4_O_MINI,
  // model = lib.types.AI.Model.OPENAI_GPT4_O,
  // model = lib.types.AI.Model.GEMINI_2_0_FLASH_001,
  // model = lib.types.AI.Model.DEEPSEEK_CHAT,
  attempts = 0,
}: CompletionCallProps) {
  const openAiModel = [
    lib.types.AI.Model.OPENAI_GPT35_TURBO,
    lib.types.AI.Model.OPENAI_GPT4_PREVIEW,
    lib.types.AI.Model.OPENAI_GPT4_TURBO_PREVIEW,
    lib.types.AI.Model.OPENAI_GPT4_O,
    lib.types.AI.Model.OPENAI_GPT4_O_MINI,
  ].includes(model);
  const options = openAiModel
    ? {
        apiKey: process.env.OPENAI_API_KEY,
      }
    : {
        baseURL: 'https://openrouter.ai/api/v1',
        apiKey: process.env.OPENROUTER_API_KEY,
      };

  const openai = new OpenAI(options);
  const chatRequest: lib.types.AI.ChatRequest = {
    type,
    messages: {
      system: systemMessage,
      prompt: prompt,
    },
    model,
    responseType: jsonResponse ? 'json' : 'text',
  };
  const params = lib.openai.chatRequestToOpenAIChatParams(chatRequest);

  const chatCompletion = await openai.chat.completions.create(params);

  const llmCallStats = await lib.getLLMCallStatsOld({
    chatRequest,
    chatCompletion,
    model,
  });

  const rawCompletion =
    lib.openai.extractReplyFromChatCompletion(chatCompletion);

  const completion = jsonResponse
    ? rawCompletion
      ? (rawCompletion.match(/\{[\s\S]*\}/)?.[0] ?? rawCompletion)
      : rawCompletion
    : rawCompletion;

  if (!completion) {
    console.log(
      'CodeYam Error: undefined rawCompletion',
      JSON.stringify({ completion, rawCompletion, chatCompletion }, null, 2),
    );

    if (attempts < 3) {
      console.log('CodeYam Error: Retrying completion', {
        prompt,
        systemMessage,
        attempts,
      });
      return await completionCall({
        type,
        systemMessage,
        prompt,
        jsonResponse,
        model,
        attempts: attempts + 1,
      });
    }

    throw new Error('Undefined completion');
  }

  if (completion.replace(/\s/g, '') === '') {
    console.log('CodeYam Error: Empty Completion', {
      rawCompletion,
      prompt,
      systemMessage,
    });
    throw new Error('Empty completion');
  }

  return {
    finishReason: chatCompletion.choices[0].finish_reason,
    completion,
    stats: llmCallStats,
  };
}
