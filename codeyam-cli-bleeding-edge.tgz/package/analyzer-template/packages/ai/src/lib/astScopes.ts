import { FileAnalyzer } from '~codeyam/analyze';
import { ASTScopeAnalyzer } from './astScopes/astScopeAnalyzer';
import { AstScopeAnalysisResult } from './astScopes/types';
import { StatementInfo } from '~codeyam/types';

/**
 * Analyzes a scope using AST traversal with a pattern-first approach and returns raw results.
 * This function returns the direct output from the AST analyzer without any transformations.
 */
export function analyzeScopeWithAst(
  fileAnalyzer: FileAnalyzer,
  statementInfo: StatementInfo,
): AstScopeAnalysisResult {
  const analyzer = new ASTScopeAnalyzer(fileAnalyzer, statementInfo);
  return analyzer.analyze();
}

// Export the implementation for direct use
export { ASTScopeAnalyzer };

// Export types
export { AstScopeAnalysisResult };
