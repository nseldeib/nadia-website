import { Entity } from '~codeyam/types';
import completionCall from './completionCall';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import * as lib from '.';
import generateEntityDataMapGenerator from './promptGenerators/generateEntityDataMapGenerator';
import { DEFAULT_LARGER_MODEL } from '~codeyam/ai';

interface GenerateEntityDataMapArgs {
  entity: Entity;
  importStatements: string;
  localImports: string;
  analysisId: string;
  model?: lib.types.AI.Model;
}

export default async function generateEntityDataMap({
  entity,
  importStatements,
  localImports,
  analysisId,
  model,
}: GenerateEntityDataMapArgs) {
  localImports = localImports
    .split('\n')
    .map((line) => `cy_localDependency.${line.trim()}`)
    .join('\n');

  const prompt = generateEntityDataMapGenerator(
    entity.code,
    importStatements,
    localImports,
  );

  console.log(
    'CodeYam: Generating entity data map',
    entity.filePath,
    entity.name,
  );

  const response = await completionCall({
    type: 'generateEntityDataMap',
    systemMessage: SYSTEM_MESSAGE,
    prompt,
    model: model ?? DEFAULT_LARGER_MODEL,
  });

  const llmCall = await saveLlmCall({
    object_type: 'analysis',
    object_id: analysisId,
    propsJson: {
      entity: {
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      importStatements,
      localImports,
      analysisId,
      model,
    },
    ...response.stats,
  });

  const { completion: dataMapString } = response;
  if (!dataMapString) {
    console.log(
      'CodeYam Error: Generating entity data map failed: No response from AI',
    );
    return null;
  }

  console.log(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} dataMapString :>> `,
  );
  console.log(dataMapString);

  const { dataMap } = lib.parsers.parseJsonSafe(dataMapString) as {
    dataMap: {
      [key: string]: string[];
    };
  };

  return { dataMap, llmCall };
}

const SYSTEM_MESSAGE = `
## Overview

This is a tricky task. We need to identify what data this function passes into dependencies or returns from the function and where that data originated.

This lets us piece together the overall structure of the data used in the app.

So our goal is to map data coming into this function to the data that passes out of it either into a dependency or into the return value.

## Instructions

- Look at each dependency listed in the "Local Dependencies" and "Imported Dependencies" sections of the prompt (if they exist). Identify any dependencies that provide data to this function.
- Look at the arguments and named arguments that are passed into the function.
- List out the data that is passed into the function from each dependency in the "inData" section.

- Look at each dependency listed in the "Local Dependencies" and "Imported Dependencies" sections of the prompt (if they exist). Identify any dependencies that are passed data from this function.
- Look at the return value of the function if it exists and is not returning a react component.
- List out the data that is passed into each dependency or returned from the function in the "outData" section.

- We want to figure out if any of the "inData" (or any of the attributes or nested attributes of the "inData") are used for the "outData" or are used to create the "outData".
- List out any attributes or nested attributes from the "inData" that are used in the "outData" in the "attributes" section.
- Create a "dataMap" section that details how the "inData" maps to the "outData" capturing attributes and nested attributes as needed.

## Keywords

- \`cy_namedArg\` = data passed into the function as a named argument
- \`cy_arg[0]\` = data passed into the function as the first argument (not named) - Use [1], [2], etc. for subsequent arguments
- \`cy_returnValue\` = data returned from the function or data returned from a dependency
- \`cy_localDependency\` = a function that is in the same file as this function
- \`cy_manipulatedData\` = data that was manipulated in the function, dissasociating it from any original external data
- \`cy_spread\` = data that is passed into a dependency via a spread operator \`...variable\` (e.g. \`<Component {...data} />\`). Only use this when the spread operator is explicitly used in the code (e.g. the three dots are present in the code).

Here are a few examples:
----

To start a simple \`user\` object passed in as a named argument. The \`hobby\` attribute of the user object is then passed to the UserHobby component:

---- START EXAMPLE ----

Prompt:

\`\`\`
Imported Dependencies:

import UserHobby from '@/components/user/UserHobby';

Function

export UserProfile({ user, options }) {
  return (
    <div className='user-profile' style={{ fontSize: options.large ? '24px' : '16px' }}> 
      <div>{user.name}</div>
      {user.hobbies.map(
        (hobby, index) => (
          <UserHobby key={index} hobby={hobby} options={options} />
        )
      )}
    </div>
  )
}
\`\`\`

Response:

\`\`\`
{
  "inData": [
    "cy_namedArg.user",
    "cy_namedArg.options"
  ],
  "outData": [
    "@/components/user/UserHobby.UserHobby.hobby",
    "@/components/user/UserHobby.UserHobb.options"
  ],
  "attributes": [
    "cy_namedArg.user.hobbies[] -> @/components/user/UserHobby.UserHobby.hobby"
  ],
  "dataMap": {
    "cy_namedArg.user.hobbies[]": ["@/components/user/UserHobby.UserHobby.hobby"],
    "cy_namedArg.options": ["@/components/user/UserHobby.UserHobby.options"]
  }
}
\`\`\`

---- END EXAMPLE ----

Note: The \`[]\` syntax is used to indicate that the \`user.hobbies\` attribute is an array which is being iterated over.

---- START EXAMPLE ----

Prompt:

\`\`\`
Imported Dependencies:

import { useParams } from '@remix-run/react';
import { useFile } from './providers/FileProvider';
import FilesDownloader from '~/home/download/FilesDownloader';

Function

export FilePreview({ className }) {
  const { folderId } = useParams();
  const { folder } = useFile(folderId);

  return (
    <div className={\`flex flex-col gap-3 \${className}\`> 
      <div>Download: {folder.name}</div>
      <FilesDownloader files={folder.files} />
    </div>
  )
}
\`\`\`

Response:

\`\`\`
{
  "inData": [
    "cy_namedArg.className",
    "@remix-run/react.useParams.cy_returnValue.folderId",
    "./providers/FileProvider.useFile.cy_returnValue.folder",
  ],
  "outData": [
    "./providers/FileProvider.useFile.cy_arg[0]",
    "~/home/download/FilesDownloader.FilesDownloader.files"
  ],
  "attributes": [
    "./providers/FileProvider.useFile.cy_returnValue.folder.files -> ~/home/download/FilesDownloader.FilesDownloader.files"
  ],
  "dataMap": {
    "@remix-run/react.useParams.cy_returnValue.folderId": ["./providers/FileProvider.useFile.cy_arg[0]"],
    "./providers/FileProvider.useFile.cy_returnValue.folder.files": ["~/home/download/FilesDownloader.FilesDownloader.files"]
  }
}
\`\`\`

---- END EXAMPLE ----

Note the use of \`cy_returnValue\` to capture that \`useFile\` is a function returning the data.

---- START EXAMPLE ----

Prompt:

\`\`\`
Function

const incrementUserStats = (views, user) => {
  user.stats.views += views.length;
  user.lastViewed = views[views.length - 1].date;

  return user
};
\`\`\`

Response:

\`\`\`
{
  "inData": [
    "cy_arg[0]",
    "cy_arg[1]"
  ],
  "outData": [
    "cy_returnValue"
  ],
  "attributes": [
    "cy_arg[0].length -> cy_returnValue.stats.views",
    "cy_arg[0][].date -> cy_returnValue.lastViewed"
  ],
  "dataMap": {
    "cy_arg[0].length": ["cy_returnValue.stats.views"],
    "cy_arg[0][].date": ["cy_returnValue.lastViewed"],
    "cy_arg[1]": ["cy_returnValue"]
  }
}
\`\`\`

---- END EXAMPLE ----

Note how we capture any available details of the cy_returnValue.

---- START EXAMPLE ----

Prompt:

\`\`\`
Imported Dependencies:

import { useMemo } from 'react';
import { useFile } from '~/providers/FileProvider';
import FilePreview from '../components/files/FilePreview';

Local Dependencies:

cy_localDependency.calculateStats
cy_localDependency.Emojis

Function

export FilePreview({ user }) {
  const { folder } = useFile();

  const filesWithFolderAndStats = useMemo(() => {
    return folder.files.map((file) => ({
      ...file,
      user,
      folder,
    }));
  }, []);

  return (
    <div className='flex items-center gap-3'> 
      <div>Download: {folder.name}</div>
      {filesWithFolderAndStats.map(
        (file) => (
          <div>
            <FilePreview key={file.id} {...file} />
            <Emojis awards={file.stats?.awards ?? calculateStats(file, user).awards} />
          </div>
        )
      )}
    </div>
  )
}
\`\`\`

Response:

\`\`\`
{
  "inData": [
    "cy_namedArg.user",
    "~/providers/FileProvider.useFile.cy_returnValue.folder",
  ],
  "outData": [
    "cy_localDependency.calculateStats.arg[0]",
    "cy_localDependency.calculateStats.arg[1]",
    "../components/files/FilePreview.FilePreview.cy_spread",
    "cy_localDependency.Emojis.awards"
  ],
  "attributes": [
    "cy_namedArg.user -> ../components/files/FilePreview.FilePreview.cy_spread.file.user",
    "~/providers/FileProvider.useFile.cy_returnValue.folder -> ../components/files/FilePreview.FilePreview.cy_spread.file.folder",
    "~/providers/FileProvider.useFile.cy_returnValue.folder.files[].stats.awards -> cy_localDependency.Emojis.awards",
    "cy_localDependency.calculateStats.cy_returnValue.awards -> cy_localDependency.Emojis.awards"
  ],
  "dataMap": {
    "cy_namedArg.user": [
      "../components/files/FilePreview.FilePreview.cy_spread.file.user"],
      "cy_localDependency.calculateStats.arg[1]"
    ],
    "~/providers/FileProvider.useFile.cy_returnValue.folder": [
      "../components/files/FilePreview.FilePreview.cy_spread.file.folder"
    ],
    "~/providers/FileProvider.useFile.cy_returnValue.folder.files[]": [
      "../components/files/FilePreview.FilePreview.cy_spread.file",
      "cy_localDependency.calculateStats.arg[0]"
    ],
    "~/providers/FileProvider.useFile.cy_returnValue.folder.files[].stats.awards": [
      "cy_localDependency.Emojis.awards"
    ],
    "cy_localDependency.calculateStats.functionCallReturnValue.awards": [
      "cy_localDependency.Emojis.awards"
    ]
  }
}
\`\`\`

---- END EXAMPLE ----

Note how the attributes contained in the \`FilePreview.cy_spread.file\` are captured as in the code it is clear that \`user\` and \`folder\` are added to the \`file\` before being passed to the \`FilePreview\` component. Also note how the value for some mappings contain two entries to reflect the data beind used in multiple places.

## Rules

Be sure to capture any data that is passed into a dependency or returned from the function as outData. There is frequently data passed into a dependency that creates both an "outData" and an "inData" entry. Capture both.

If data (or a nested attribute) is passed to multiple dependencies, create an entry for each dependency. Similarly, if a dependency takes in different data in different situations then map each situation separately.

Look out for data that is reorganized in the function. For example if the function takes an array of "books" but then gathers all the "chapters" of all the books into a new array then if that data is passed to a dependency we can map the "chapters" back to the original "books".

You do not need to map the return value of a react component.

Do not create duplicate entries. They are not necessary.

Be sure to capture the exact path, with proper capitalization, for each dependency as it is listed in either the "Imported Dependencies" or "Local Dependencies". Capture all relative aspects (e.g. "cy_localDependency", "@", "~", "../", "~/", etc.) and the rest of the path to the dependency file or node module. Do not make up any dependency paths as this will cause the data mapping to break.

Just provide the json with the map and nothing else (no comments or text around the json).
`;
