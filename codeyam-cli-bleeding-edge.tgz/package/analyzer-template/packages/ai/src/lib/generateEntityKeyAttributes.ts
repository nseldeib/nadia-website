import completionCall from './completionCall';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import { Entity } from '~codeyam/types';
import generateEntityKeyAttributesGenerator from './promptGenerators/generateEntityKeyAttributesGenerator';
import * as lib from '.';
import { awsLog } from '~codeyam/utils';
import { DEFAULT_LARGER_MODEL } from './aiConfig';
import { gatherAttributesMap } from './promptGenerators/gatherAttributesMap';
import isFrontend from './isFrontend';

interface GenerateEntityKeyAttributesArgs {
  entity: Pick<Entity, 'sha' | 'name' | 'filePath' | 'code' | 'metadata'>;
  model?: lib.types.AI.Model;
}

export default async function generateEntityKeyAttributes({
  entity,
  model,
}: GenerateEntityKeyAttributesArgs) {
  awsLog(`CodeYam: Generating entity key attributes`, {
    filePath: entity.filePath,
    entityName: entity.name,
  });

  const { attributesMap, associationMap } = gatherAttributesMap(entity, true);

  if (Object.keys(attributesMap).length === 0) {
    console.log(
      `CodeYam Error: No valid attributes found for ${entity.filePath} ${entity.name}`,
    );
    return {
      keyAttributes: [],
      llmCall: null,
    };
  }

  const prompt = generateEntityKeyAttributesGenerator({
    code: entity.code,
    attributesMap,
  });

  console.info('Generated prompt for generateEntityKeyAttributes:');
  console.info(prompt);

  const response = await completionCall({
    type: `generateEntityKeyAttributes`,
    systemMessage: isFrontend(entity.filePath)
      ? FRONTEND_SYSTEM_MESSAGE
      : BACKEND_SYSTEM_MESSAGE,
    prompt,
    model: model ?? DEFAULT_LARGER_MODEL,
  });

  const llmCall = await saveLlmCall({
    object_type: 'entity',
    object_id: entity.sha,
    propsJson: {
      entity: {
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      model,
    },
    ...response.stats,
  });

  const { completion: keyAttributesString } = response;
  if (!keyAttributesString) {
    console.log(
      `CodeYam Error: Error Generating entity key attributes failed: No response from AI`,
    );
    return null;
  }

  console.log(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} ${entity.name} key attributes :>> `,
  );
  console.log(keyAttributesString);

  let keyAttributes = undefined;
  try {
    const parsed = JSON.parse(keyAttributesString);
    keyAttributes = parsed?.keyAttributes;
  } catch (error) {
    console.log(
      `CodeYam Error: Invalid JSON response in generateEntityKeyAttributes for ${entity.filePath} ${entity.name}:`,
      error,
    );
  }

  if (!keyAttributes || !Array.isArray(keyAttributes)) {
    return { keyAttributes: [], llmCall };
  }

  const fullKeyAttributes = keyAttributes
    .filter(Boolean)
    .filter(
      (keyAttribute, index, self) =>
        keyAttribute?.path &&
        self.findIndex((ka) => ka?.path === keyAttribute.path) === index,
    )
    .filter((keyAttribute) => associationMap[keyAttribute.path])
    .map((keyAttribute) => ({
      internalPath: keyAttribute.path,
      externalPath: associationMap[keyAttribute.path],
      description: keyAttribute.description,
      validValueOptions: keyAttribute.validValueOptions,
      errorValueOptions: keyAttribute.errorValueOptions,
    }));

  return {
    keyAttributes: fullKeyAttributes,
    llmCall,
  };
}

const FRONTEND_SYSTEM_MESSAGE = `We have a frontend function and need to determine how best to vary what is returned from this function and displayed to the user.

We're not interested in causing errors or in high-level guard clauses that often display nothing on the screen. We're interested in always displaying a robust return value that shows what this frontend component does.

In order to do so we want to identify the key data attributes in the code.

Each key attribute represents a path from a top level variable and that path must be noted exactly as it is in the "Attributes and Value Types" list.

Key attributes must come either from the function signature or from a function call that is made from within the function that return data that is used in the function. Please capture the attrribute path exactly from the list.

If an attribute has the keyword "functionCallReturnValue" in it, it is a function call that returns data that is used in the function. That keyword simply designated the return value of the function call. If an attribute path has "[]" in it (e.g. "items[]") that represents one item in that array.

## Key Attribute Rules

- All key attributes must come from the "Attributes and Value Types" provided. All data traces through these attributes and these are the only attributes we can use to provide data to the function. Only use these attributes. Do not reference internally computed variables. Trace their origin back to an attribute from the "Attributes and Value Types" list.

### Should be a key attribute

- Changing the value, length (e.g. for strings or arrays), etc of this variable will dramatically change how the component displays (the return value of the function).

- Is used in a conditional that dramatically alters how the component displays (note: if the conditional compares two or more variables, note which variables are involved and how they must be set to cause different behavior).

### Should NOT be a key attribute

- Changing the value of this variable will cause an error or exception to be thrown.

- Changing the value of this variable will cause a guard clause to be triggered that results in nothing being displayed.

- Changing the value of this variable will cause a minor change in display that is not significant (e.g. slightly different text).

- The value is used as a fallback or alternative for another value and won't even be used if the other value is present.

- The value changes non-visible behavior (e.g. the href in a link or src in an image - all images sources are mocked out).

## Instructions

- Read each line of code. Pay particular attention to the return value of the function and how this frontend component will be displayed. What will cause it display distinctly different but functional and robust results to the user?
- Find the most impactful key attributes that will change how the frontend component is displayed. This should be a limited subset of the "Attributes and Value Types" provided.
- Return each key attribute with the following information:
  - \`path\`: The path to the data attribute in the code
  - \`description\`: A short description of the data attribute and how it is used in the code.
  - \`validValueOptions\`: A list of possible values for the data attribute that should be tested. This should include extreme values that could cause different behavior in the code but these values should not cause an error.
- List the key attributes in the order of importance (most important first, with importance determined by how much changing the attribute will impact how the component is displayed).
- Each attribute should reference exactly the path of a data attribute provided in the "Attributes and Value Types" section.

## Example

Given the following "Attributes and Value Types":
\`\`\`
[
  'notification.read': 'boolean'
  'notification.message': 'string'
]
\`\`\`

and code:

\`\`\`typescript
const NotificationText = (notification) => {
  if (notification.read) {
    return (
      <span onClick={markAsRead(notification.id)}>
        <img src={notification.icon} alt="Notification Icon" />
        {notification.message}
      </span>
    );
  } else {
    return <strong>{notification.message}</strong>;
  }
};
\`\`\`

The response might be:

\`\`\`json
{
  "keyAttributes": [
    {
      "path": "notification.read",
      "description": "The read status of the notification determines how the message is displayed.",
      "validValueOptions": [
        "true",
        "false"
      ]
    },
    {
      "path": "notification.message",
      "description": "The message text is displayed and should be tested for various lengths.",
      "validValueOptions": [
        "A short message (fewer than 30 characters)",
        "A medium message (around 100 characters)",
        "A long message (longer than 200 characters)"
      ]
    }
  ]
}
\`\`\`

## Important

- A key attribute must be an exact attribute path from the "Attributes and Value Types" provided. Do not return any other attribute paths.  The only data we can provide to the function comes from these attributes so any other attribute is useless. For internally computed variables trace them back to one of the higher level variables that we can actually impact. Be sure to match the text from the attribute list exactly including spaces, commas, etc.
`;

const BACKEND_SYSTEM_MESSAGE = `We have a function that we want to test in various ways by passing in appropriate data.

Can you help us identify the key data attributes in the code that will cause the function to return distinctly different but functional and robust results?

We're not interested in causing errors or in high-level guard clauses that result in nothing being returned. We're interested in always returning a robust result that demonstrates the core intent of the function.

In order to do so we want to identify the key data attributes in the code.

Each key attribute represents a path from a top level variable and that path must be noted exactly as it is in the "Attributes and Value Types" list.

Key attributes must come either from the function signature or from a function call that is made from within the function that return data that is used in the function. Please capture the attrribute path exactly from the list.

If an attribute has the keyword "functionCallReturnValue" in it, it is a function call that returns data that is used in the function. That keyword simply designated the return value of the function call. If an attribute path has "[]" in it (e.g. "items[]") that represents one item in that array.

## Key Attribute Rules

- All key attributes must come from the "Attributes and Value Types" provided. All data traces through these attributes and these are the only attributes we can use to provide data to the function. Only use these attributes. Do not reference internally computed variables. Trace their origin back to an attribute from the "Attributes and Value Types" list.

### Should be a key attribute

- Changing the value, length (e.g. for strings or arrays), etc of this variable will dramatically impact the return value of the function.

- Is used in a conditional that dramatically the execution flow of the function and as a result the return value of the function (note: if the conditional compares two or more variables, note which variables are involved and how they must be set to cause different behavior).

- Note: some functions do not return anything but instead call out to other systems (e.g. send an email, write to a database, etc). In those cases, the key attributes should be those that dramatically change how the function interacts with those other systems.

### Should NOT be a key attribute

- Changing the value of this variable will cause an error or exception to be thrown.

- Changing the value of this variable will cause a guard clause to be triggered that results in nothing or very little being returned.

- The value is used as a fallback or alternative for another value and won't even be used if the other value is present.

## Instructions

- Read each line of code. Pay particular attention to the return value of the function. What data attributes will cause it to return distinctly different but functional and robust results?
- Find the most impactful key attributes that will impact the return value of the function. This should be a limited subset of the "Attributes and Value Types" provided.
- Return each key attribute with the following information:
  - \`path\`: The path to the data attribute in the code
  - \`description\`: A short description of the data attribute and how it is used in the code.
  - \`validValueOptions\`: A list of possible values for the data attribute that should be tested. This should include extreme values that could cause different behavior in the code but these values should not cause an error.
- List the key attributes in the order of importance (most important first, with importance determined by how much changing the attribute will change the return value of the function).
- Each attribute should reference exactly the path of a data attribute provided in the "Attributes and Value Types" section.

## Example

Given the following "Attributes and Value Types":
\`\`\`
[
  items[].quantity: 'number',
  items[].price: 'number',
  discount: 'number',
  taxRate: 'number',
]
\`\`\`

and code:

\`\`\`typescript
const calculateTotal = (items, discount, taxRate) => {
  const subtotal = items.reduce((sum, item) => sum + item.quantity * item.price, 0);
  const discountedTotal = subtotal - discount;
  const tax = discountedTotal * taxRate;
  return discountedTotal + tax;
}
\`\`\`

The response might be:

\`\`\`json
{
  "keyAttributes": [
    {
      "path": "items[].quantity",
      "description": "The quantity of each item affects the subtotal calculation.",
      "validValueOptions": [
        "0 (no items)",
        "1 (single item)",
        "5 (multiple items)",
        "100 (large quantity)"
      ]
    },
    {
      "path": "items[].price",
      "description": "The price of each item affects the subtotal calculation.",
      "validValueOptions": [
        "0.00 (free item)",
        "1.00 (low price)",
        "19.99 (average price)",
        "999.99 (high price)"
      ]
    },
    {
      "path": "discount",
      "description": "The discount amount directly reduces the subtotal.",
      "validValueOptions": [
        "0 (no discount)",
        "5.00 (small discount)",
        "20.00 (large discount)"
      ]
    },
    {
      "path": "taxRate",
      "description": "The tax rate affects the final total calculation.",
      "validValueOptions": [
        "0 (no tax)",
        "0.05 (5% tax)",
        "0.10 (10% tax)",
        "0.20 (20% tax)"
      ]
    }
  ]
}
\`\`\`

## Important

- A key attribute must be an exact attribute path from the "Attributes and Value Types" provided. Do not return any other attribute paths.  The only data we can provide to the function comes from these attributes so any other attribute is useless. For internally computed variables trace them back to one of the higher level variables that we can actually impact. Be sure to match the text from the attribute list exactly including spaces, commas, etc.
`;
