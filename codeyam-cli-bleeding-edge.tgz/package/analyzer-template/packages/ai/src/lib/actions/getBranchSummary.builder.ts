import { Commit, CommitOverview } from '~codeyam/types';
import * as lib from '..';

export const getBranchSummaryBuilder: lib.types.AI.Action.Builder<
  lib.types.AI.Action.GetBranchSummary
> =
  ({ aiService, dbService }) =>
  async ({ branchName, commits }) => {
    const commitOverviews = getCommitOverviews(commits);
    const chatRequest: lib.types.AI.ChatRequest = {
      type: 'branchSummary',
      messages: {
        system: SYSTEM_MESSAGE,
        prompt: lib.promptGenerators.branchSummary({
          branchName,
          commitOverviews,
        }),
      },
    };
    const completion = await aiService.sendChatRequest(chatRequest);
    if (!completion)
      throw 'AI service failed to receive response to chat service request';

    await dbService.saveAICall({
      chatRequest,
      chatCompletion: completion,
    });

    const reply = lib.openai.extractReplyFromChatCompletion(completion);
    const branchSummary = lib.parsers.parseJsonInto<lib.types.BranchSummary>(
      reply,
      lib.typePredicates.isBranchSummary,
    );
    return branchSummary;
  };

function getCommitOverviews(commits: Commit[]): CommitOverview[] {
  const commitOverviews: CommitOverview[] = commits.map(
    (commit) =>
      ({
        title: commit.title,
        message: commit.message,
        aiMessage: commit.aiMessage,
      }) as CommitOverview,
  );

  return commitOverviews;
}

const SYSTEM_MESSAGE = `You will be given a branch name and a list of commits on that branch.
It is your job to name and summarize the work going on into a cohesive "workstream".
The description must be one short, concise sentence. You must return valid JSON mapping to:
\`\`\`
{
  "name": "<name here>",
  "description": "<description here>"
}
\`\`\`
`;
