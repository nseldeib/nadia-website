import ts from 'typescript';

export enum ReservedFeature {
  Function = 'function',
  RestParameter = 'restParameter',
  FunctionWithPositionalAndNamedArguments = 'functionWithPositionalAndNamedArguments',
  FunctionWithComplexNamedArguments = 'functionWithComplexNamedArguments',
  FunctionWithNamedArguments = 'functionWithNamedArguments',
  FunctionWithPositionalArguments = 'functionWithPositionalArguments',
  ArrowFunction = 'arrowFunction',
  AnonymousArrowFunction = 'anonymousArrowFunction',
  ArrowFunctionWithPositionalArguments = 'arrowFunctionWithPositionalArguments',
  ArrowFunctionWithNamedArguments = 'arrowFunctionWithNamedArguments',
  ArrowFunctionWithPositionalAndNamedArguments = 'arrowFunctionWithPositionalAndNamedArguments',
  AnonymousArrowFunctionWithPositionalArguments = 'anonymousArrowFunctionWithPositionalArguments',
  AnonymousArrowFunctionWithNamedArguments = 'anonymousArrowFunctionWithNamedArguments',
  AnonymousArrowFunctionWithPositionalAndNamedArguments = 'anonymousArrowFunctionWithPositionalAndNamedArguments',
  ImplicitReturn = 'implicitReturn',
  Generator = 'generator',
  ArrayReduce = 'arrayReduce',
  ArrayMap = 'arrayMap',
  ArrayMapInJsx = 'arrayMapInJsx',
  ArrayFilter = 'arrayFilter',
  ArrayFind = 'arrayFind',
  RepeatedMethodChaining = 'repeatedMethodChaining',
  MethodChaining = 'methodChaining',
  UseState = 'useState',
  FunctionCall = 'functionCall',
  FunctionCallWithPositionalArguments = 'functionCallWithPositionalArguments',
  FunctionCallWithNamedArguments = 'functionCallWithNamedArguments',
  FunctionCallWithPositionalAndNamedArguments = 'functionCallWithPositionalAndNamedArguments',
  FunctionCallWithReturnValue = 'functionCallWithReturnValue',
  FunctionCallWithReturnValueArrayDestructured = 'functionCallWithReturnValueArrayDestructured',
  FunctionCallWithReturnValueObjectDestructured = 'functionCallWithReturnValueObjectDestructured',
  FunctionCallWithinJSXProp = 'functionCallWithinJSXProp',
  TernaryInReturn = 'ternaryInReturn',
  Ternary = 'ternary',
  Return = 'return',
  FunctionCallInReturn = 'functionCallInReturn',
  JSX = 'jsx',
  JSXWithProps = 'jsxWithProps',
  JSXWithChildren = 'jsxWithChildren',
  NestedJSX = 'nestedJSX',
  ReturnValueWithJSX = 'returnValueWithJSX',
  Spread = 'spread',
  For = 'for',
  ForOf = 'forOf',
  ForIn = 'forIn',
  While = 'while',
  DoWhile = 'doWhile',
  If = 'if',
  Switch = 'switch',
  Class = 'class',
  Method = 'method',
  Try = 'try',
  Catch = 'catch',
  Finally = 'finally',
  Destructuring = 'destructuring',
  StringInterpolation = 'stringInterpolation',
  ChainedProperties = 'chainedProperties',
  // New feature flags:
  AlternativeValues = 'alternativeValues',
  NullishCoalescing = 'nullishCoalescing',
  FunctionCallReturnValueInFunctionCall = 'functionCallReturnValueInFunctionCall',
}

export default function identifyReserved(code: string): ReservedFeature[] {
  const reserved = new Set<ReservedFeature>();

  const sourceFile = ts.createSourceFile(
    'temp.tsx',
    code,
    ts.ScriptTarget.Latest,
    /*setParentNodes*/ true,
    ts.ScriptKind.TSX,
  );

  // Helper function to check if a node is within a JSX context.
  const isInJsx = (node: ts.Node): boolean => {
    let current: ts.Node | undefined = node;
    while (current) {
      if (
        ts.isJsxElement(current) ||
        ts.isJsxSelfClosingElement(current) ||
        ts.isJsxFragment(current) ||
        ts.isJsxExpression(current)
      ) {
        return true;
      }
      current = current.parent;
    }
    return false;
  };

  // Helper function to check if a node is within a return statement.
  const isInReturnStatement = (node: ts.Node): boolean => {
    let current: ts.Node | undefined = node;
    while (current) {
      if (ts.isReturnStatement(current)) {
        return true;
      }
      current = current.parent;
    }
    return false;
  };

  const unwrapExpression = (expr: ts.Expression): ts.Expression => {
    while (ts.isParenthesizedExpression(expr) || ts.isAwaitExpression(expr)) {
      if (ts.isParenthesizedExpression(expr)) {
        expr = expr.expression;
      } else if (ts.isAwaitExpression(expr)) {
        expr = expr.expression;
      }
    }
    return expr;
  };

  const visit = (
    node: ts.Node,
    insideFunction: boolean = false,
    inReturn: boolean = false,
  ) => {
    // New: Detect binary expressions for alternative/default values.
    if (ts.isBinaryExpression(node)) {
      if (node.operatorToken.kind === ts.SyntaxKind.BarBarToken) {
        reserved.add(ReservedFeature.AlternativeValues);
      } else if (
        node.operatorToken.kind === ts.SyntaxKind.QuestionQuestionToken
      ) {
        reserved.add(ReservedFeature.NullishCoalescing);
      }
    }

    // Detect property access chains (user.firstName.lastName)
    if (ts.isPropertyAccessExpression(node)) {
      // Check if this property access is part of a chain
      const parent = node.expression;
      if (ts.isPropertyAccessExpression(parent)) {
        reserved.add(ReservedFeature.ChainedProperties);
      }
    }

    // Detect JSX elements anywhere in the AST.
    if (
      ts.isJsxElement(node) ||
      ts.isJsxSelfClosingElement(node) ||
      ts.isJsxFragment(node)
    ) {
      reserved.add(ReservedFeature.JSX);

      // Check for props in JSX elements
      if (
        ts.isJsxElement(node) &&
        node.openingElement.attributes.properties.length > 0
      ) {
        reserved.add(ReservedFeature.JSXWithProps);
      } else if (
        ts.isJsxSelfClosingElement(node) &&
        node.attributes.properties.length > 0
      ) {
        reserved.add(ReservedFeature.JSXWithProps);
      }

      // Check for children in JSX elements
      if (ts.isJsxElement(node) && node.children.length > 0) {
        reserved.add(ReservedFeature.JSXWithChildren);
      }

      // Check if this JSX element is inside a return statement
      if (isInReturnStatement(node)) {
        reserved.add(ReservedFeature.ReturnValueWithJSX);
      }

      // Check for nested JSX elements
      if (ts.isJsxElement(node)) {
        // Look for JSX elements in the children
        for (const child of node.children) {
          if (
            ts.isJsxElement(child) ||
            ts.isJsxSelfClosingElement(child) ||
            ts.isJsxFragment(child)
          ) {
            reserved.add(ReservedFeature.NestedJSX);
            break;
          }

          // Also check for JSX inside JSX expressions
          if (ts.isJsxExpression(child) && child.expression) {
            const hasNestedJsx = (expr: ts.Node): boolean => {
              if (
                ts.isJsxElement(expr) ||
                ts.isJsxSelfClosingElement(expr) ||
                ts.isJsxFragment(expr)
              ) {
                return true;
              }

              let foundNested = false;
              ts.forEachChild(expr, (subExpr) => {
                if (hasNestedJsx(subExpr)) {
                  foundNested = true;
                }
              });

              return foundNested;
            };

            if (hasNestedJsx(child.expression)) {
              reserved.add(ReservedFeature.NestedJSX);
              break;
            }
          }
        }
      }
    }

    // Detect template literals with expressions (string interpolation)
    if (ts.isTemplateExpression(node)) {
      reserved.add(ReservedFeature.StringInterpolation);
    }

    // Handle function nodes: declaration, expression, or arrow function.
    if (
      ts.isFunctionDeclaration(node) ||
      ts.isFunctionExpression(node) ||
      ts.isArrowFunction(node)
    ) {
      let hasRestParameter = false;
      let hasPositional = false;
      let hasNamed = false;
      let hasComplexNamed = false;

      if (node.parameters) {
        for (const param of node.parameters) {
          // Treat rest parameters as positional.
          if (param.dotDotDotToken) {
            hasRestParameter = true;
          } else if (ts.isIdentifier(param.name)) {
            hasPositional = true;
          } else if (
            ts.isObjectBindingPattern(param.name) ||
            ts.isArrayBindingPattern(param.name)
          ) {
            hasNamed = true;
            // Check for nested (complex) destructuring.
            if (ts.isObjectBindingPattern(param.name)) {
              for (const element of param.name.elements) {
                if (element && ts.isBindingElement(element)) {
                  if (
                    ts.isObjectBindingPattern(element.name) ||
                    ts.isArrayBindingPattern(element.name)
                  ) {
                    hasComplexNamed = true;
                  }
                }
              }
            } else if (ts.isArrayBindingPattern(param.name)) {
              for (const element of param.name.elements) {
                if (element && ts.isBindingElement(element)) {
                  if (
                    ts.isObjectBindingPattern(element.name) ||
                    ts.isArrayBindingPattern(element.name)
                  ) {
                    hasComplexNamed = true;
                  }
                }
              }
            }
          }
        }
      }

      if (hasRestParameter) {
        reserved.add(ReservedFeature.RestParameter);
      }

      // Additional arrow function specific checks.
      if (ts.isArrowFunction(node)) {
        // Check if this is an anonymous arrow function (not part of a variable declaration)
        let isAnonymous = true;
        let parent = node.parent;

        // Check if the arrow function is part of a variable declaration
        // If it is, it's not anonymous
        while (parent) {
          if (ts.isVariableDeclaration(parent) && parent.initializer === node) {
            isAnonymous = false;
            break;
          }
          // Also check property assignments (e.g., { handler: (e) => {...} })
          if (ts.isPropertyAssignment(parent) && parent.initializer === node) {
            isAnonymous = false;
            break;
          }
          parent = parent.parent;
        }

        // Add specific arrow function parameter type checks
        if (hasPositional && hasNamed) {
          reserved.add(
            isAnonymous
              ? ReservedFeature.AnonymousArrowFunctionWithPositionalAndNamedArguments
              : ReservedFeature.ArrowFunctionWithPositionalAndNamedArguments,
          );
        } else if (hasNamed) {
          reserved.add(
            isAnonymous
              ? ReservedFeature.AnonymousArrowFunctionWithNamedArguments
              : ReservedFeature.ArrowFunctionWithNamedArguments,
          );
        } else if (hasPositional || hasRestParameter) {
          reserved.add(
            isAnonymous
              ? ReservedFeature.AnonymousArrowFunctionWithPositionalArguments
              : ReservedFeature.ArrowFunctionWithPositionalArguments,
          );
        } else {
          reserved.add(
            isAnonymous
              ? ReservedFeature.AnonymousArrowFunction
              : ReservedFeature.ArrowFunction,
          );
        }

        // Implicit return: if the body is an expression rather than a block.
        if (node.body && node.body.kind !== ts.SyntaxKind.Block) {
          reserved.add(ReservedFeature.ImplicitReturn);

          // Check if the implicit return contains JSX
          if (
            ts.isJsxElement(node.body) ||
            ts.isJsxSelfClosingElement(node.body) ||
            ts.isJsxFragment(node.body) ||
            (ts.isParenthesizedExpression(node.body) &&
              (ts.isJsxElement(node.body.expression) ||
                ts.isJsxSelfClosingElement(node.body.expression) ||
                ts.isJsxFragment(node.body.expression)))
          ) {
            reserved.add(ReservedFeature.ReturnValueWithJSX);
          }
        }
      } else {
        if (hasPositional && hasNamed) {
          reserved.add(ReservedFeature.FunctionWithPositionalAndNamedArguments);
        } else if (hasNamed) {
          if (hasComplexNamed) {
            reserved.add(ReservedFeature.FunctionWithComplexNamedArguments);
          } else {
            reserved.add(ReservedFeature.FunctionWithNamedArguments);
          }
        } else if (hasPositional) {
          reserved.add(ReservedFeature.FunctionWithPositionalArguments);
        } else {
          reserved.add(ReservedFeature.Function);
        }
      }

      // Check for generator functions (only applicable for declarations/expressions).
      if (
        (ts.isFunctionDeclaration(node) || ts.isFunctionExpression(node)) &&
        node.asteriskToken
      ) {
        reserved.add(ReservedFeature.Generator);
      }

      insideFunction = true;
    }

    // Mark call expressions.
    if (ts.isCallExpression(node)) {
      if (ts.isPropertyAccessExpression(node.expression)) {
        if (node.expression.name.text === 'reduce') {
          reserved.add(ReservedFeature.ArrayReduce);
        } else if (node.expression.name.text === 'map') {
          reserved.add(ReservedFeature.ArrayMap);
          // Check if this map call is inside a JSX expression.
          if (isInJsx(node)) {
            reserved.add(ReservedFeature.ArrayMapInJsx);
          }
        } else if (node.expression.name.text === 'filter') {
          reserved.add(ReservedFeature.ArrayFilter);
        } else if (node.expression.name.text === 'find') {
          reserved.add(ReservedFeature.ArrayFind);
        }

        // Check for method chaining
        if (ts.isPropertyAccessExpression(node.expression)) {
          // Store all method names in the chain to check for repeats
          const methodNames = new Set<string>();
          methodNames.add(node.expression.name.text);

          // Check if this is part of a method chain
          let parent = node.expression.expression;
          let isChain = false;
          let chainCount = 1; // Start with 1 for the current method

          // Traverse up the chain to find other method calls
          while (ts.isCallExpression(parent)) {
            if (ts.isPropertyAccessExpression(parent.expression)) {
              isChain = true;
              chainCount++;
              const methodName = parent.expression.name.text;

              // Check for repeated method names
              if (methodNames.has(methodName)) {
                reserved.add(ReservedFeature.RepeatedMethodChaining);
              }

              methodNames.add(methodName);
              parent = parent.expression.expression;
            } else {
              break;
            }
          }

          if (isChain) {
            reserved.add(ReservedFeature.MethodChaining);
            // Only mark as RepeatedMethodChaining if there are 3 or more methods chained
            // or if the same method name appears more than once
            if (chainCount >= 3 && node.expression.name.text === 'eq') {
              reserved.add(ReservedFeature.RepeatedMethodChaining);
            }
          }
        }
      }

      // Detect useState hook
      if (
        ts.isIdentifier(node.expression) &&
        node.expression.text === 'useState'
      ) {
        reserved.add(ReservedFeature.UseState);
      }

      // Check argument types to classify the function call
      let hasPositionalArgs = false;
      let hasNamedArgs = false;
      let hasFunctionCallAsArg = false;

      // NEW: Check for function calls as arguments
      for (const arg of node.arguments) {
        if (ts.isCallExpression(arg)) {
          hasFunctionCallAsArg = true;
        }

        if (ts.isObjectLiteralExpression(arg)) {
          // If the argument is an object literal like { name: 'value' }
          hasNamedArgs = true;
        } else {
          // Any other expression is considered positional
          hasPositionalArgs = true;
        }
      }

      // NEW: Add flag if a function call is used as an argument
      if (hasFunctionCallAsArg) {
        reserved.add(ReservedFeature.FunctionCallReturnValueInFunctionCall);
      }

      // Add appropriate feature flags based on argument types
      if (hasPositionalArgs && hasNamedArgs) {
        reserved.add(
          ReservedFeature.FunctionCallWithPositionalAndNamedArguments,
        );
      } else if (hasNamedArgs) {
        reserved.add(ReservedFeature.FunctionCallWithNamedArguments);
      } else if (hasPositionalArgs || node.arguments.length > 0) {
        reserved.add(ReservedFeature.FunctionCallWithPositionalArguments);
      } else {
        reserved.add(ReservedFeature.FunctionCall);
      }

      // Check if this function call is part of a variable declaration or assignment
      // This means it returns a value that's being used
      let isInJsxProp = false;
      let parent = node.parent;

      while (parent) {
        if (ts.isJsxAttribute(parent)) {
          isInJsxProp = true;
          reserved.add(ReservedFeature.FunctionCallWithinJSXProp);
          break;
        }

        // Stop if we reach certain node types that would break the context
        if (
          ts.isArrowFunction(parent) ||
          ts.isFunctionExpression(parent) ||
          ts.isFunctionDeclaration(parent) ||
          ts.isMethodDeclaration(parent)
        ) {
          break;
        }

        parent = parent.parent;
      }

      parent = node.parent;
      while (
        parent &&
        !(ts.isExpressionStatement(parent) && parent.expression === node)
      ) {
        // Variable declarations (e.g. const { a } = foo() or const [a] = foo())
        if (ts.isVariableDeclaration(parent)) {
          if (ts.isObjectBindingPattern(parent.name)) {
            reserved.add(
              ReservedFeature.FunctionCallWithReturnValueObjectDestructured,
            );
          } else if (ts.isArrayBindingPattern(parent.name)) {
            reserved.add(
              ReservedFeature.FunctionCallWithReturnValueArrayDestructured,
            );
          } else {
            reserved.add(ReservedFeature.FunctionCallWithReturnValue);
          }
          break;
        }

        // Assignment expressions (e.g. ({ a } = foo()) or ([a] = foo()))
        if (ts.isBinaryExpression(parent)) {
          let leftExpr = parent.left;
          // Unwrap any parentheses that might obscure the actual pattern.
          while (ts.isParenthesizedExpression(leftExpr)) {
            leftExpr = leftExpr.expression;
          }
          if (ts.isObjectLiteralExpression(leftExpr)) {
            reserved.add(
              ReservedFeature.FunctionCallWithReturnValueObjectDestructured,
            );
          } else if (ts.isArrayLiteralExpression(leftExpr)) {
            reserved.add(
              ReservedFeature.FunctionCallWithReturnValueArrayDestructured,
            );
          } else {
            reserved.add(ReservedFeature.FunctionCallWithReturnValue);
          }
          break;
        }

        // Other cases where the function call's return value is used
        if (
          ts.isPropertyAssignment(parent) ||
          ts.isReturnStatement(parent) ||
          ts.isJsxAttribute(parent) ||
          ts.isJsxExpression(parent) ||
          ts.isPropertyAccessExpression(parent) ||
          ts.isCallExpression(parent)
        ) {
          reserved.add(ReservedFeature.FunctionCallWithReturnValue);
          break;
        }
        parent = parent.parent;
      }

      // If in a return statement, mark as function call in return
      if (inReturn) {
        reserved.add(ReservedFeature.FunctionCallInReturn);
      }
    }

    // Conditional (ternary) expressions.
    if (ts.isConditionalExpression(node)) {
      reserved.add(ReservedFeature.Ternary);
      if (inReturn) {
        reserved.add(ReservedFeature.TernaryInReturn);
      }
    }

    // Mark all return statements
    if (ts.isReturnStatement(node)) {
      reserved.add(ReservedFeature.Return);

      if (node.expression) {
        // Check for nested function calls inside the return expression.
        const checkCalls = (child: ts.Node) => {
          if (ts.isCallExpression(child)) {
            reserved.add(ReservedFeature.FunctionCallInReturn);
          }
          ts.forEachChild(child, checkCalls);
        };
        checkCalls(node.expression);

        // Check for JSX in the return expression
        const unwrapped = unwrapExpression(node.expression);
        if (
          ts.isJsxElement(unwrapped) ||
          ts.isJsxSelfClosingElement(unwrapped) ||
          ts.isJsxFragment(unwrapped) ||
          ts.isJsxExpression(unwrapped)
        ) {
          reserved.add(ReservedFeature.ReturnValueWithJSX);
          reserved.add(ReservedFeature.JSX);
        }

        visit(node.expression, insideFunction, true);
      }

      return;
    }

    // Identify spread operators.
    if (
      node.kind === ts.SyntaxKind.SpreadAssignment ||
      node.kind === ts.SyntaxKind.SpreadElement
    ) {
      reserved.add(ReservedFeature.Spread);
    }

    if (ts.isForStatement(node)) {
      reserved.add(ReservedFeature.For);
    }

    if (ts.isForOfStatement(node)) {
      reserved.add(ReservedFeature.ForOf);
    }

    if (ts.isForInStatement(node)) {
      reserved.add(ReservedFeature.ForIn);
    }

    // While loops.
    if (ts.isWhileStatement(node)) {
      reserved.add(ReservedFeature.While);
    }

    // Do-while loops.
    if (ts.isDoStatement(node)) {
      reserved.add(ReservedFeature.DoWhile);
    }

    // If statements.
    if (ts.isIfStatement(node)) {
      reserved.add(ReservedFeature.If);
    }

    // Switch statements.
    if (ts.isSwitchStatement(node)) {
      reserved.add(ReservedFeature.Switch);
    }

    // Class declarations.
    if (ts.isClassDeclaration(node)) {
      reserved.add(ReservedFeature.Class);
    }

    // Methods inside classes, including constructors.
    if (ts.isMethodDeclaration(node) || ts.isConstructorDeclaration(node)) {
      reserved.add(ReservedFeature.Method);
    }

    // Try-catch-finally blocks.
    if (ts.isTryStatement(node)) {
      reserved.add(ReservedFeature.Try);
      if (node.catchClause) {
        reserved.add(ReservedFeature.Catch);
      }
      if (node.finallyBlock) {
        reserved.add(ReservedFeature.Finally);
      }
    }

    // Destructuring in variable declarations.
    if (ts.isVariableDeclaration(node)) {
      if (
        ts.isObjectBindingPattern(node.name) ||
        ts.isArrayBindingPattern(node.name)
      ) {
        reserved.add(ReservedFeature.Destructuring);

        // Check if we're destructuring the result of a function call
        if (node.initializer) {
          const initializer = unwrapExpression(node.initializer);
          if (ts.isCallExpression(initializer)) {
            if (ts.isArrayBindingPattern(node.name)) {
              reserved.add(
                ReservedFeature.FunctionCallWithReturnValueArrayDestructured,
              );
            } else if (ts.isObjectBindingPattern(node.name)) {
              reserved.add(
                ReservedFeature.FunctionCallWithReturnValueObjectDestructured,
              );
            } else {
              reserved.add(ReservedFeature.FunctionCallWithReturnValue);
            }
          }
        }
      }

      // Check initializer for array methods
      if (node.initializer) {
        if (ts.isCallExpression(node.initializer)) {
          const expression = node.initializer.expression;
          if (ts.isPropertyAccessExpression(expression)) {
            if (expression.name.text === 'reduce') {
              reserved.add(ReservedFeature.ArrayReduce);
            } else if (expression.name.text === 'map') {
              reserved.add(ReservedFeature.ArrayMap);
              if (isInJsx(node.initializer)) {
                reserved.add(ReservedFeature.ArrayMapInJsx);
              }
            } else if (expression.name.text === 'filter') {
              reserved.add(ReservedFeature.ArrayFilter);
            } else if (expression.name.text === 'find') {
              reserved.add(ReservedFeature.ArrayFind);
            }
          }
        }
      }
    }

    // Continue traversing the AST
    ts.forEachChild(node, (child) => visit(child, insideFunction, inReturn));
  };

  visit(sourceFile);

  // Remove redundant flags
  if (reserved.has(ReservedFeature.ReturnValueWithJSX)) {
    reserved.delete(ReservedFeature.Return);
  }

  if (
    reserved.has(ReservedFeature.JSXWithChildren) ||
    reserved.has(ReservedFeature.JSXWithProps)
  ) {
    reserved.delete(ReservedFeature.JSX);
  }

  if (reserved.has(ReservedFeature.ArrayMapInJsx)) {
    reserved.delete(ReservedFeature.ArrayMap);
  }

  return Array.from(reserved);
}
