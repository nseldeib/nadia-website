import completionCall from './completionCall';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import generateEntityScenariosGenerator from './promptGenerators/generateEntityScenariosGenerator';
import * as lib from '.';

import {
  Entity,
  Scenario,
  Analysis,
  ReadonlyAnalysisMap,
  PlaywrightInstruction,
} from '~codeyam/types';
import findMatchingAttribute from './findMatchingAttribute';
import { awsLog } from '~codeyam/utils';
import { sanitizePlaywrightInstructions } from './validatePlaywrightInstructions';
import { DEFAULT_LARGER_MODEL } from '~codeyam/ai';

export interface ScenarioResult {
  name: string;
  testName: string;
  description: string;
  keyAttributeInstructions: { [key: string]: string };
  codeSnippet: string;
  fix: string;
  fixSnippet: string;
  likelihood: number;
  likelihoodDescription: string;
  severity: number;
  severityDescription: string;
  dataMapping: { [key: string]: string };
  playwrightInstructions?: PlaywrightInstruction[];
}

interface GenerateEntityScenariosArgs {
  entity: Pick<Entity, 'projectId' | 'filePath' | 'name' | 'code' | 'metadata'>;
  keyAttributes: Analysis['metadata']['keyAttributes'];
  dependentAnalyses?: ReadonlyAnalysisMap;
  analysis: Analysis;
  error?: boolean;
  model?: lib.types.AI.Model;
}

const DEFAULT_SCENARIO_NAME = 'Default Scenario';

export default async function generateEntityScenarios({
  entity,
  keyAttributes,
  analysis,
  error,
  model,
}: GenerateEntityScenariosArgs) {
  awsLog(`CodeYam: Generating entity ${error ? 'error ' : ''}scenarios`, {
    filePath: entity.filePath,
    entityName: entity.name,
  });

  const prompt = generateEntityScenariosGenerator({
    entity,
    keyAttributes,
    error,
  });

  const response = await completionCall({
    type: `generate${error ? 'Error' : ''}EntityScenarios`,
    systemMessage: error ? ERROR_SYSTEM_MESSAGE : SYSTEM_MESSAGE,
    prompt,
    model: model ?? DEFAULT_LARGER_MODEL,
  });

  const llmCall = await saveLlmCall({
    object_type: 'analysis',
    object_id: analysis.id,
    propsJson: {
      entity: {
        projectId: entity.projectId,
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      keyAttributes,
      analysis: {
        id: analysis.id,
        metadata: {
          isolatedDataStructure: {
            equivalentSignatureVariables:
              entity.metadata.isolatedDataStructure
                .equivalentSignatureVariables,
          },
        },
      },
      error,
      model,
    },
    ...response.stats,
  });

  const { completion: scenariosString } = response;
  if (!scenariosString) {
    console.log(
      `CodeYam Error: Error Generating entity ${error ? 'error ' : ''}scenarios failed: No response from AI`,
    );
    return null;
  }

  console.log(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} ${entity.name} ${error ? 'error ' : ''}scenariosString :>> `,
  );
  console.log(scenariosString);

  const result = lib.parsers.parseJsonSafe(scenariosString);
  if (!result) {
    console.log(
      `CodeYam Error: Error Generating entity ${error ? 'error ' : ''}scenarios failed: Invalid JSON response from AI`,
      response.finishReason,
    );
    throw new Error(
      `CodeYam Error: Error Generating entity ${error ? 'error ' : ''}scenarios failed: Invalid JSON response from AI`,
    );
  }

  if (typeof result !== 'object') {
    return { scenarios: [], llmCall };
  }

  const scenarios = (
    result[
      `${error ? 'errorD' : 'd'}ataScenarios`
    ] as unknown as ScenarioResult[]
  ).map(
    (scenarioInfo) =>
      ({
        projectId: entity.projectId,
        analysisId: analysis.id,
        name: scenarioInfo.name,
        description: scenarioInfo.description,
        metadata: {
          testName: scenarioInfo.testName,
          error,
          codeSnippet: scenarioInfo.codeSnippet,
          fix: scenarioInfo.fix,
          fixSnippet: scenarioInfo.fixSnippet,
          likelihood: scenarioInfo.likelihood,
          likelihoodDescription: scenarioInfo.likelihoodDescription,
          severity: scenarioInfo.severity,
          severityDescription: scenarioInfo.severityDescription,
          dataMapping: scenarioInfo.dataMapping,
          keyAttributeInstructions: Object.keys(
            scenarioInfo.keyAttributeInstructions,
          ).reduce((acc, key) => {
            const attributesList = keyAttributes.map(
              (attr) => attr.internalPath,
            );
            const matchingKey = findMatchingAttribute(
              key,
              attributesList,
              entity.metadata.isolatedDataStructure
                .equivalentSignatureVariables,
            );
            acc[matchingKey] = scenarioInfo.keyAttributeInstructions[key];
            return acc;
          }, {}),
          playwrightInstructions: sanitizePlaywrightInstructions(
            scenarioInfo.playwrightInstructions || [],
            entity.name,
            scenarioInfo.name,
          ),
        },
      }) as Scenario,
  );

  return {
    scenarios,
    llmCall,
  };
}

const SYSTEM_MESSAGE = `We want to generate a few (between one and four) data scenarios that will demonstrate the behavior of a function.

## The ${DEFAULT_SCENARIO_NAME}:

- Start with the "${DEFAULT_SCENARIO_NAME}" - Call this exactly that, "${DEFAULT_SCENARIO_NAME}" and just that (case sensitive, no other text).
- The "${DEFAULT_SCENARIO_NAME}" should provide a robust demonstration of the function with instructions for all key attributes provided. 
  - Fill in all key attributes in the "keyAttributes" list with valid values from the "validValueOptions" list.
  - All values provided must be from the "validValueOptions" list in the "keyAttributes" list. Do not make up values that are not in the "validValueOptions" list.
  - Ignore any error attributes (e.g. an attribute called "error"). These should not be included or set to null.
  - If a front-end (visual) function accepts "children" as an argument this must be populated with a valid value or the output may be blank.
  - Do not include any "playwrightInstructions" in the "${DEFAULT_SCENARIO_NAME}" as we want a screenshot of the function before any user interactions take place.

## Other scenarios:

- Other scenarios should produce distinct output (for a front-end (visual) function this means a visually distinct screenshot, for back-end this means a distinct return value or side effect). Focus on varying the key attributes to create distinctly different outputs.
- You do not need to specify key attributes that are the same as the ${DEFAULT_SCENARIO_NAME}.
- Again ignore any error attributes. These should not be included or set to null.
- If the function is a front-end (visual) function that accepts user actions and will change it's appearance based on those user actions, then create a non-default scenario that includes "playwrightInstructions" to trigger those user actions.

## Instructions

- Each scenario should have: 
  - a unique name (should be short and concise with no special characters except spaces).
  - a "testName" written in the style of Jest the focuses on specific expectations for the test. Try to avoid generic names like "it('should work')" or "it('should render')" and describe more specific expectations.
  - a description that describes why the key attributes were changed from the default scenario.
  - "keyAttributeInstructions" specifying how the key attributes should be set. All key attributes should be set with valid values from the "validValueOptions" list in the "keyAttributes" list.
  - Optional "playwrightInstructions" that provide the necessary code to run in Playwright to put the function into the correct state to demonstrate the scenario.
- Focus on positive scenarios that showcase the intended behavior of this function. We have another prompt for generating error scenarios. These scenarios should focus on robust but different data between scenarios that vary key attributes to demonstrate different aspects of the function's behavior.

## Dependencies

This function may dependend on other functions that have key attributes as well. You can leverage those to generate data scenarios also by creating key attribute instructions for those key attributes in the same manner. Generally speaking key attributes for dependencies are necessary for robust scenarios.

## Relative Dates

If a relative date is required you can describe it in the "keyAttributeInstructions", e.g. 'today', 'tomorrow', 'next week', 'last month'.

## Rules

- If the key attributes require react elements, keep them simple (e.g. <div> or <span>). Do not reference custom jsx elements as they will not exist.

- Do not reference any external libraries, such as React, in the "keyAttributeInstructions". Assume no external libraries are available. Do not reference custom jsx elements. 

## Response Structure

Respond with the data scenarios in a JSON object format, without additional information or delimiters. Ensure clarity and specificity in each data scenario to facilitate accurate data generation for testing or demonstration purposes.

{
  "dataScenarios": [
    {
      "name": string;
      "testName": string;
      "description": string;
      "keyAttributeInstructions": {
        ["keyAttributePath"]: string;
      },
      "playwrightInstructions?": {
        "selectorFn": string;
        "selectorArgs": string[];
        "actionFn": string;
        "actionArgs": string[];
      }[]
    }
  ]
}

Optionally you can include playwright instructions for front-end functions to put the function into the correct state to demonstrate the scenario.

Usually playwright instructions should not be included in the ${DEFAULT_SCENARIO_NAME}. If playwright instructions will cause the front-end function's results to look different than create a non-default scenario that includes those instructions.

This is often the case if the key attributes are only used through a button click or form submission or if the data required for this scenario is not listed as a key attribute and must be provided directly by the user.

If the data won't exist or be used without user actions then use the "playwrightInstructions" to trigger execution of that code through the user actions.

For \`playwrightInstructions\`, provide an array of strings representing the necessary code to run.
\`\`\`json
{
  "playwrightInstructions": [
    {
      "selectorFn": "getByLabel",
      "selectorArgs": ["email"],
      "actionFn": "fill",
      "actionArgs": ["test@example.com"]
    },
    {
      "selectorFn": "getByText",
      "selectorArgs": ["Submit"],
      "actionFn": "click",
      "actionArgs": []
    }
  ]
}
\`\`\`

## Example Response

\`\`\`json
{
  "dataScenarios": [
    {
      "name": ${DEFAULT_SCENARIO_NAME},
      "description": "The component displays notifications. As a default state demonstrates common usage, there are 3 unread notifications and two read notifications.",
      "testName": "it(\"displays notifications indicating unread status with a green dot")",
      "keyAttributeInstructions": {
        "notifications[]": "Create 5 notifications",
        "notifications[].read": "Set to false for 3 notifications and true for 2 notifications",
        "notifications[].message": "Messages should be no longer than 200 characters"
      }
    },
    {
      "name": "No notifications",
      "testName": "it(\"renders a default message when there are no notifications\")",
      "description": "A user has no notifications at all.",
      "keyAttributeInstructions": {
        "notifications[]": "Should be an empty array"
      }
    },
    {
      "name": "Many notifications, all unread, one long message",
      "testName": "it(\"properly truncates long messages with the title containing the full message\")"
      "description": "A user has many notifications, all unread, with one notification featuring a long message.",
      "keyAttributeInstructions": {
        "notifications[]": "Create 10 notifications",
        "notifications[].read": "Set to false for all notifications",
        "notifications[].message": "Ensure at least one message is longer than 500 characters"
      }
    }
  ]
}
\`\`\`

Remember:

- Name the first scenario exactly "${DEFAULT_SCENARIO_NAME}".
- For the ${DEFAULT_SCENARIO_NAME} scenario fill in all key attributes with valid values from the "validValueOptions" list in the "keyAttributes" list. Do not leave any key attributes out of the "keyAttributeInstructions" unless they are error attributes.
- For other scenarios, find ways to create distinctly different outputs using other valid values for key attributes or providing playwright instructions to trigger user interactions. 
- Do not use playwright instructions in the ${DEFAULT_SCENARIO_NAME} as we want a screenshot of the function before any user interactions.
`;

const ERROR_SYSTEM_MESSAGE = `What data will cause this funtion to fail with an uncaught error?

In "errorDataScenarios", give each scenario a description that explains what the predicted error is, a code snippet (or multiple) showing where it will occur, a description of how it can be fixed along with example code, and provide detailed "keyAttributeInstructions" on how to generate the necessary data to cause the error.

For each error scenario also provide two evaluation dynamics:

1) How likely is this error to occur? (1-10)
- 1 = Unlikely. It would require passing in data that is clearly wrong and not suited for the function.
- 10 = Guaranteed. There is a bug in the function that will happen regardless of the data passed in.

2) How severe is the error? (1 or 2)
- 1 = Minor. The error will not break the application. It may cause confusion or unexpected behavior, but will not cause a direct failure.
- 2 = Major. The error will cause the function to fail and will need to be fixed.

## Instructions

Another AI will then read the "keyAttributeInstructions" and generate the necessary data. You can assume the other AI will generate reasonable default data to satisfy the data structure, so only provide instructions for the essential parts of the data that should be generated.

We can only generate data for the exact data structure provided, regardless of the code for the function. Do not provide "keyAttributeInstructions" for data that is not in the data structure.

All data must be plain that can be run in a node environment (not in the browser). Do not reference any external libraries in the "keyAttributeInstructions". If an external library is required by the function, then provide instructructions on how to fake or mock that data. 

Focus on "Major" errors. Only include "Minor" errors is they are very likely to occur.

## Response

For each error scenario, start with a data mapping between the phrase you want to use in the "keyAttributeInstructions" and the exact variable in the data strucure. Then provide a name and a description that predicts how the function will error out and a suggested way to fix the error. The name should be unique and short (no more than 30 characters), and the description should provide context for the error scenario.

## Rules

- Do not provide "keyAttributeInstructions" for data that is not in the data structure. 

- If the data structure calls for react elements, keep them simple (e.g. <div> or <span>). Do not reference custom jsx elements as they will not exist.

- Do not reference any external libraries, such as React, in the "keyAttributeInstructions". Assume no external libraries are available. Do not reference custom jsx elements. If needed describe how to mock the enternal library data using plain javascript that can be run in a node environment.

- Only create new error scenarios if the scenario will literally cause an error. We are not looking for awkward or unintended results, only literal errors. Do not create an error scenario if you are not confident it will cause an error. 

- Do not assume that another function might cause an error. We are looking for errors that are a direct result of the code in this function.

- Do not create errors that can be caught through normal type detection. We only want errors that are reasonably likely to happen and won't be caught by basic static code analysis.

- Only create error scenarios that can be fixed by changing the code in this function. Do not create error scenarios that require changes to other functions or external libraries. 

- Look to create a few error scenarios, but if you can not identify any way to cause an error then do not generate any error scenarios. Each error scenario should represent a distinctly different way to cause an error. If there are no errors you can respond with:

\`\`\`
{
  "errorDataScenarios": "No errors found"
}
\`\`\`

- Make sure each error scenario has a unique name.

## Response Structure

Respond with the data scenarios in a JSON object format, without additional information or delimiters. Ensure clarity and specificity in each data scenario to facilitate accurate data generation for testing or demonstration purposes.

{
  "errorDataScenarios": [
    {
      "dataMapping": { [key: string]: string };
      "name": string;
      "codeSnippet": string;
      "description": string;
      "fix": string;
      "fixSnippet": string;
      "likelihood": number;
      "likelihoodDescription": string;
      "severity": number;
      "severityDescription": string;      
      "instructions": string[];
    }
  ]
}

## Example
Given the following data structure:

\`\`\`
{
  "arguments": [
    {
      "notifications": {
        "message": "string",
        "read": "boolean"
      }[]
    }
  ]
}
\`\`\`

The full response might be:

\`\`\`
{
  "errorDataScenarios": [
    {
      "dataMapping": {
        "notifications array": "arguments - notifications"
      },
      "name": "Error: Message with non-utf8 characters",
      "codeSnippet": "...\nconst encodedMessage = encodeURIComponent(message);\n...",
      "description": "If the message contains non-utf8 characters the function will error out. The \`encodeURIComponent\` call will throw an error which is not caught.",
      "fix": "Wrap the \`encodeURIComponent\` call in a try/catch block.",
      "fixSnippet: "...\nlet encodedMessage: string | undefined;\ntry {\n  encodedMessage = encodeURIComponent(message)\n} catch (e) {\n  console.error('Error encoding message:', e)\n..."
      "likelihood": 7,
      "likelihoodDescription": "The international nature of the function makes it likely that a user will input a message with non-utf8 characters.",
      "severity": 2,
      "severityDescription": "The function will error out if a message contains non-utf8 characters.",
      "keyAttributeInstructions": {
        "notifications[]": "Set the \"notifications array\" to an array of objects containing at least one notification with a message that contains non-utf8 characters.",
      }
    }
  ]
}
\`\`\`

Please write both the \`codeSnippet\` and \`fixSnippet\` with appropriate line breaks to increase readability.

Assume that all functions this function depends on exist even if they are not provided in the prompt. We have isolated this function for analysis but those dependencies do exist.

Only create error scenarios based on the code that is in the function provided.

Common Errors In Your Analysis:
- Typescript/javascript: 
    - Any object or primitive other than 0 can be used to satisfy a boolean. This will not cause an error.

Do not mark anything as a "10" for likelihood unless the error will literally happen every time the function is called. In general be cautious about high likelihood scores so that errors that are truly most likely to happen show up as higher priority.
`;
