import { Entity, ReadonlyAnalysis, ReadonlyAnalysisMap } from '~codeyam/types';
import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from './splitOutsideParentheses';
import { gatherAttributesMap } from './promptGenerators/gatherAttributesMap';

export default function gatherRelevantDependentKeyAttributes(
  entity: Pick<Entity, 'name' | 'metadata'>,
  dependentAnalyses: ReadonlyAnalysisMap,
) {
  // console.info(
  //   'CODEYAM DEBUG: gatherRelevantDependentKeyAttributes inputs',
  //   entity.name,
  //   JSON.stringify(
  //     {
  //       entity: {
  //         metadata: {
  //           isolatedDataStructure:
  //             entity.metadata?.isolatedDataStructure,
  //         },
  //       },
  //       dependentAnalyses: Object.keys(dependentAnalyses).reduce(
  //         (acc, path) => {
  //           acc[path] = Object.keys(dependentAnalyses[path]).reduce(
  //             (entityAcc, entityName) => {
  //               entityAcc[entityName] = {
  //                 metadata: {
  //                   keyAttributes:
  //                     dependentAnalyses[path][entityName].metadata
  //                       .keyAttributes,
  //                 },
  //                 entity: {
  //                   metadata: {
  //                     isolatedDataStructure:
  //                       dependentAnalyses[path][entityName].entity.metadata
  //                         ?.isolatedDataStructure,
  //                   },
  //                 },
  //               };
  //               return entityAcc;
  //             },
  //             {},
  //           );
  //           return acc;
  //         },
  //         {} as Record<string, Record<string, Record<string, unknown>[]>>,
  //       ),
  //     },
  //     null,
  //     2,
  //   ),
  // );

  const { associationMap } = gatherAttributesMap(entity);

  const dependencySchemas =
    entity.metadata?.isolatedDataStructure?.dependencySchemas;
  const relevantDependentKeyAttributes: ReadonlyAnalysis['metadata']['keyAttributes'][0][] =
    [];
  Object.keys(dependentAnalyses).forEach((path) => {
    Object.keys(dependentAnalyses[path]).forEach((entityName) => {
      const dependentAnalysis = dependentAnalyses[path][entityName];
      const dependentKeyAtttributes =
        dependentAnalysis?.metadata?.keyAttributes;
      if (!dependentKeyAtttributes || dependentKeyAtttributes.length === 0)
        return;

      const dependencySchema = dependencySchemas?.[path]?.[entityName];
      const signatureSchema = dependencySchema?.signatureSchema;
      if (!signatureSchema) return;

      for (const dependentKeyAttribute of dependentKeyAtttributes) {
        const dependentKeyAttributeExternalPathParts =
          splitOutsideParenthesesAndArrays(dependentKeyAttribute.externalPath);

        let matchFound = false;
        for (
          let i = dependentKeyAttributeExternalPathParts.length;
          i > 0;
          i--
        ) {
          const subExternalPath = joinParenthesesAndArrays(
            dependentKeyAttributeExternalPathParts.slice(0, i),
          );

          for (const sourceEquivalencyPath in dependencySchema?.sourceEquivalencies ??
            {}) {
            const sourceEquivalencyPathParts = splitOutsideParenthesesAndArrays(
              sourceEquivalencyPath,
            );

            const relevantSourceEquivalencyPath = joinParenthesesAndArrays(
              sourceEquivalencyPathParts.slice(1),
            );

            if (relevantSourceEquivalencyPath !== subExternalPath) continue;

            const sourcePath =
              dependencySchema?.sourceEquivalencies[sourceEquivalencyPath][0]
                ?.schemaPath;

            if (!sourcePath) continue;

            let externalPath = sourcePath;
            let internalPath = associationMap[sourcePath];

            if (i < dependentKeyAttributeExternalPathParts.length) {
              externalPath = joinParenthesesAndArrays([
                externalPath,
                ...dependentKeyAttributeExternalPathParts.slice(i),
              ]);

              internalPath = joinParenthesesAndArrays([
                internalPath,
                ...dependentKeyAttributeExternalPathParts.slice(i),
              ]);
            }

            const dependentEntityName =
              dependentKeyAttribute.dependentEntityName
                ? `${dependentKeyAttribute.dependentEntityName} (through ${entityName})`
                : entityName;

            relevantDependentKeyAttributes.push({
              ...dependentKeyAttribute,
              dependentEntityName,
              internalPath,
              externalPath,
            });

            matchFound = true;
            break;
          }

          if (matchFound) break;
        }
      }
    });
  });

  return relevantDependentKeyAttributes;
}
