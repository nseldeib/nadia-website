import { JsonTypeDefinition } from '~codeyam/types';
import { splitOutsideParenthesesAndArrays } from '../../splitOutsideParentheses';

const INDEXED_RE = /^(.+)\[(\d+)\]$/;
const isExplicitIndex = (s?: string) => !!s && INDEXED_RE.test(s);

// Treat these as structural placeholders (don't commit them as concrete leaves)
function isSkippableLeafType(t: string) {
  // 'unknown' by itself is a placeholder (but 'boolean | unknown' is not)
  return (
    t === 'object' ||
    t === 'array' ||
    t === 'function' ||
    t.trim() === 'unknown'
  );
}

export default function convertDotNotation(
  schema: Record<string, string>,
): JsonTypeDefinition {
  const result: any = {};

  for (const [rawPath, typ] of Object.entries(schema)) {
    const parts = splitOutsideParenthesesAndArrays(rawPath);
    if (!parts || parts.length === 0) continue;

    let cursor: any = result;

    for (let i = 0; i < parts.length; i++) {
      const seg = parts[i];
      const next = parts[i + 1];
      const isLast = i === parts.length - 1;

      // Handle explicit index, e.g. "signature[1]" or the start of "signature[1][]...."
      const idxMatch = seg.match(INDEXED_RE);
      if (idxMatch) {
        const name = idxMatch[1];
        const index = Number(idxMatch[2]);

        if (!Array.isArray(cursor[name])) cursor[name] = [];

        // If the *next* segment is '[]', then this indexed element itself is an array
        if (!isLast && next === '[]') {
          if (!Array.isArray(cursor[name][index])) cursor[name][index] = [];
          cursor = cursor[name][index]; // array at that index
          continue;
        }

        if (isLast) {
          // Terminal assignment for an indexed element
          if (!isSkippableLeafType(typ)) {
            cursor[name][index] = typ;
          } else if (typ === 'array') {
            // Make the indexed element an array
            if (!Array.isArray(cursor[name][index])) cursor[name][index] = [];
          } else if (
            typ === 'object' ||
            typ === 'function' ||
            typ.trim() === 'unknown'
          ) {
            // Keep the literal placeholder if nothing else defined
            if (cursor[name][index] === undefined) cursor[name][index] = typ;
          }
          break; // done with this path
        } else {
          // Non-terminal: before coercing, enforce "no properties on arrays unless [] or [n]"
          const cur = cursor[name][index];

          // If current element is an array and the next segment is neither [] nor an explicit index, ignore this path.
          if (Array.isArray(cur) && next !== '[]' && !isExplicitIndex(next)) {
            break;
          }

          if (
            cur === undefined ||
            typeof cur !== 'object' ||
            Array.isArray(cur)
          ) {
            cursor[name][index] = {};
          }
          cursor = cursor[name][index];
          continue;
        }
      }

      // Standalone '[]' segment — only valid when current cursor is an array
      if (seg === '[]') {
        // Ensure we are working with an array
        if (!Array.isArray(cursor)) {
          // Best-effort fallback: create a scratch array element to descend into
          const arr: any[] = [];
          arr[0] = {};
          cursor = arr[0];
          continue;
        }

        const terminalArray = isLast;
        if (terminalArray) {
          // Leaf like "...[]": "string"  -> array with first element being 'string'
          if (!isSkippableLeafType(typ)) {
            cursor[0] = typ;
          } else {
            if (cursor[0] === undefined) cursor[0] = {};
          }
        } else {
          // Descend into the first element (object), creating if needed
          if (
            !cursor[0] ||
            typeof cursor[0] !== 'object' ||
            Array.isArray(cursor[0])
          ) {
            cursor[0] = {};
          }
          cursor = cursor[0];
        }
        continue;
      }

      const key = seg;

      // If the *next* segment is '[]', the current key is an array.
      if (next === '[]') {
        const isTerminalArray = i + 2 === parts.length; // pattern: "<key>", "[]"

        if (isTerminalArray) {
          // Leaf like: "paramB[]": "string"  -> paramB: ['string']
          if (!isSkippableLeafType(typ)) {
            cursor[key] = [typ];
          } else {
            // structural/placeholder subtype — ensure array exists but don't clobber
            if (!Array.isArray(cursor[key])) cursor[key] = [];
          }
          i++; // consume '[]'
        } else {
          // Pattern like: "items", "[]", "id" -> items: [ { id: ... } ]
          if (!Array.isArray(cursor[key])) cursor[key] = [];
          if (
            !cursor[key][0] ||
            typeof cursor[key][0] !== 'object' ||
            Array.isArray(cursor[key][0])
          ) {
            cursor[key][0] = {};
          }
          cursor = cursor[key][0];
          i++; // consume '[]' and continue deeper
        }
        continue;
      }

      // No array indicator in the immediate next segment.
      if (isLast) {
        // Terminal leaf
        if (!isSkippableLeafType(typ)) {
          cursor[key] = typ;
        } else {
          // Structural/placeholder terminal
          if (typ === 'array') {
            if (!Array.isArray(cursor[key])) cursor[key] = [];
          } else if (
            typ === 'object' ||
            typ === 'function' ||
            typ.trim() === 'unknown'
          ) {
            if (cursor[key] === undefined) {
              cursor[key] = typ;
            }
          }
        }
      } else {
        // If current key already points to an array, and next is neither [] nor [n], ignore this path.
        if (
          Array.isArray(cursor[key]) &&
          next !== '[]' &&
          !isExplicitIndex(next)
        ) {
          break;
        }

        if (
          cursor[key] === undefined ||
          typeof cursor[key] !== 'object' ||
          Array.isArray(cursor[key])
        ) {
          cursor[key] = {};
        }
        cursor = cursor[key];
      }
    }
  }

  return result as JsonTypeDefinition;
}
