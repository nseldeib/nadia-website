import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from '../../splitOutsideParentheses';
import isGenericArray from './isGenericArray';

export default function cleanPath(path: string, allPaths: string[]): string {
  if (!path) return path;
  const pathParts = splitOutsideParenthesesAndArrays(path);

  const genericArray = isGenericArray(pathParts, allPaths);

  const cleanPathParts = pathParts.reduce((acc, pathPart) => {
    pathPart = pathPart.replace(/\?\s*$/, '');
    const arrayIndexRegEx = new RegExp(/\[.*\d.*\]/); // Trying to match array indices vs dynamic object indices (e.g. [1] or [varA + 1] (which are array indices) vs [id] (which is a dynamic object or map index))
    if (genericArray && !pathPart.startsWith('signature[')) {
      acc.push(pathPart.replace(arrayIndexRegEx, '[]'));
    } else {
      acc.push(pathPart);
    }
    return acc;
  }, []);

  return joinParenthesesAndArrays(cleanPathParts);
}
