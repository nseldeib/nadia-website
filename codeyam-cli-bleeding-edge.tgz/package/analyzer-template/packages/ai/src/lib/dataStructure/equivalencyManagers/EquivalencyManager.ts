import {
  EquivalencyValueChainItem,
  FunctionCallInfo,
  ScopeDataStructure,
  ScopeNode,
} from '../ScopeDataStructure';

export interface AddEquivalenciesInfo {
  scopeDataStructure: ScopeDataStructure;
  scopeNode: ScopeNode;
  path: string;
  subPathParts: string[];
  value: string;
  activeCallScopeName?: string;
  functionCallInfo?: FunctionCallInfo;
  equivalencyValueChain?: EquivalencyValueChainItem[];
  traceId?: number;
  debugLevel?: number;
}

export interface EquivalencyManager {
  addEquivalencies: (addEquivencyInfo: AddEquivalenciesInfo) => boolean;

  finalize: (
    scopeNode: ScopeNode,
    scopeDataStructure: ScopeDataStructure,
  ) => void;

  postProcess: (
    scopeNode: ScopeNode,
    scopeDataStructure: ScopeDataStructure,
  ) => void;

  // Optional method for performance optimization - if provided, allows the manager
  // to indicate whether it's interested in processing a specific subpath
  isInterestedInSubpath?: (
    subPathParts: string[],
    scopeNode: ScopeNode,
    scopeDataStructure: ScopeDataStructure,
  ) => boolean;

  internalFunctions: Set<string>;

  toString: () => string;
}
