import determineIsFunctionCall from '../helpers/determineIsFunctionCall';
import getFunctionCallScopeNodeName from '../helpers/getFunctionCallScopeNodeName';
import getFunctionCallSignature from '../helpers/getFunctionCallSignature';
import { ScopeDataStructure, ScopeNode } from '../ScopeDataStructure';
import { AddEquivalenciesInfo, EquivalencyManager } from './EquivalencyManager';
import getFunctionCallRoot from '../helpers/getFunctionCallRoot';

export default class FunctionCallManager implements EquivalencyManager {
  private signaturePathEstablished: Record<string, Set<string>> = {};

  postProcess(_scopeNode: ScopeNode, _scopeDataStructure: ScopeDataStructure) {}

  isInterestedInSubpath(
    subPathParts: string[],
    _scopeNode: ScopeNode,
    scopeDataStructure: ScopeDataStructure,
  ): boolean {
    // Skip if the first part matches the scope tree name (early exit condition)
    if (subPathParts[0].split('(')[0] === scopeDataStructure.scopeTree.name) {
      return false;
    }

    // We're interested in function calls and signature paths
    // Be conservative and assume we might be interested unless we know we're not
    return true;
  }

  addEquivalencies({
    scopeDataStructure,
    scopeNode,
    path,
    subPathParts,
    value,
    equivalencyValueChain,
    traceId,
    debugLevel,
  }: AddEquivalenciesInfo): boolean {
    if (subPathParts[0].split('(')[0] === scopeDataStructure.scopeTree.name) {
      return false;
    }

    const subPath = scopeDataStructure.joinPathParts(subPathParts);

    let propagated = false;
    const signaturePropagation = this.handleSignaturePath({
      scopeDataStructure,
      scopeNode,
      path,
      subPathParts,
      subPath,
      value,
      equivalencyValueChain,
      traceId,
      debugLevel,
    });

    if (signaturePropagation) {
      propagated = true;
    }

    const functionCallPropagation = this.handleFunctionCall({
      scopeDataStructure,
      scopeNode,
      path,
      subPath,
      subPathParts,
      value,
      equivalencyValueChain,
      traceId,
      debugLevel,
    });

    if (functionCallPropagation) {
      propagated = true;
    }

    return propagated;
  }

  finalize(_scopeNode: ScopeNode, _scopeDataStructure: ScopeDataStructure) {}

  internalFunctions: Set<string> = new Set([
    'returnValue',
    'functionCallReturnValue',
  ]);

  toString() {
    return 'FunctionCallManager';
  }

  private handleSignaturePath({
    scopeDataStructure,
    scopeNode,
    path,
    subPath,
    value,
    equivalencyValueChain,
    traceId,
    debugLevel,
  }: AddEquivalenciesInfo & { subPath: string }): boolean {
    let propagated = false;

    if (
      !this.signaturePathEstablished[scopeNode.name]?.has(path) &&
      subPath.startsWith('signature[') &&
      scopeDataStructure.getScopeOrFunctionCallInfo().name !== scopeNode.name
    ) {
      for (const functionCall of scopeNode.functionCalls ?? []) {
        const functionCallName = getFunctionCallRoot(
          functionCall.callSignature,
        );

        if (functionCallName !== scopeNode.name) {
          continue;
        }

        const functionCallScopeInfo =
          scopeDataStructure.getScopeOrFunctionCallInfo(functionCall.callScope);
        const equivalentPath = scopeDataStructure.joinPathParts([
          functionCall.callSignature.replace(/____cyScope\d+F/, ''),
          scopeDataStructure.splitPath(subPath)[0],
        ]);

        if (traceId && debugLevel > 1) {
          console.info(
            'Debug Propagation: signature executed',
            JSON.stringify(
              {
                functionCallName,
                traceId,
                equivalentPath,
                path,
                subPath,
                value,
                functionCall,
                scopeNodeName: scopeNode.name,
                functionCallScopeInfoName: functionCallScopeInfo?.name,
                scopeInfoFunctionCalls: scopeNode.functionCalls,
              },
              null,
              2,
            ),
          );
        }

        this.signaturePathEstablished[scopeNode.name] ||= new Set();
        this.signaturePathEstablished[scopeNode.name].add(path);

        propagated = true;
        scopeDataStructure.addEquivalency(
          subPath,
          equivalentPath,
          functionCall.callScope,
          scopeNode,
          'signature of functionCall',
          equivalencyValueChain,
          traceId,
        );
      }

      // Check if parent has a function call signature regardless
      const parentScopeName =
        scopeNode.tree?.length > 0
          ? scopeNode.tree[scopeNode.tree.length - 1]
          : undefined;
      if (parentScopeName) {
        const parentScopeInfo =
          scopeDataStructure.getScopeOrFunctionCallInfo(parentScopeName);

        const expectedKey = scopeDataStructure.joinPathParts([
          scopeNode.name + '()',
          subPath,
        ]);

        const equivalentValues = parentScopeInfo.equivalencies[expectedKey];
        if (equivalentValues) {
          if (traceId && debugLevel > 0) {
            console.info(
              'Debug Propagation: explicit parent signature executed',
              JSON.stringify(
                {
                  traceId,
                  path,
                  subPath,
                  value,
                  expectedKey,
                  equivalentValues,
                  parentScopeName,
                  scopeNodeName: scopeNode.name,
                },
                null,
                2,
              ),
            );
          }

          propagated = true;
          scopeDataStructure.addEquivalency(
            subPath,
            expectedKey,
            parentScopeName,
            scopeNode,
            'explicit parent signature',
            equivalencyValueChain,
            traceId,
          );
        }
      }
    }

    return propagated;
  }

  private handleFunctionCall({
    scopeDataStructure,
    scopeNode,
    path,
    subPath,
    subPathParts,
    value,
    equivalencyValueChain,
    traceId,
    debugLevel,
  }: AddEquivalenciesInfo & { subPath: string }): boolean {
    let propagated = false;

    const isFunctionCall = determineIsFunctionCall(subPathParts);

    const firstCall = equivalencyValueChain?.find(
      (equiv) => equiv.currentPath.schemaPath === path,
    );

    if (firstCall && firstCall.currentPath.scopeNodeName !== scopeNode.name) {
      if (traceId && debugLevel > 1) {
        console.info('Skipping FunctionCallManager - not in same scope', {
          traceId,
          path,
          subPath,
          scopeNodeName: scopeNode.name,
          firstCallScopeInfoName: firstCall.currentPath.scopeNodeName,
          isFunctionCall,
        });
      }
      return propagated;
    }

    if (traceId && debugLevel > 1) {
      console.info('Debug Propagation: functionCall', {
        traceId,
        path,
        subPath,
        scopeNodeName: scopeNode.name,
        isFunctionCall,
      });
    }

    if (isFunctionCall && scopeNode.functionCalls) {
      const functionCallSignature = getFunctionCallSignature(subPathParts);

      const functionCallRoot = getFunctionCallRoot(functionCallSignature);

      if (functionCallRoot.length === 0) {
        return propagated;
      }

      const functionCallScopeInfoName = getFunctionCallScopeNodeName(
        functionCallRoot,
        scopeDataStructure,
      );

      const functionCallScopeInfo =
        functionCallScopeInfoName &&
        scopeDataStructure.scopeNodes[functionCallScopeInfoName];

      const isExternal =
        !scopeNode.instantiatedVariables?.includes(functionCallRoot) &&
        !scopeNode.parentInstantiatedVariables?.includes(functionCallRoot) &&
        !functionCallRoot.startsWith('signature[') &&
        functionCallRoot !== 'returnValue';

      if (!functionCallScopeInfo) {
        if (!isExternal) return propagated;

        let externalFunctionCallInfo =
          scopeDataStructure.getExternalFunctionCallInfo(functionCallRoot);

        if (!externalFunctionCallInfo) {
          externalFunctionCallInfo = {
            name: functionCallRoot,
            callSignature: functionCallSignature,
            callScope: equivalencyValueChain[0].currentPath.scopeNodeName,
            schema: {},
            equivalencies: {},
          };
          if (traceId && debugLevel > 0) {
            console.info('Debug Propagation: addFunctionCall external', {
              externalFunctionCallInfo,
            });
          }
          scopeDataStructure.addFunctionCall(
            scopeNode,
            externalFunctionCallInfo,
          );
        }

        if (traceId && debugLevel > 0) {
          console.info(
            'Debug Propagation: add equivalency to external function call',
            {
              scopeNodeName: scopeNode.name,
              path,
              subPath,
              value,
              externalFunctionCallInfoName: externalFunctionCallInfo.name,
            },
          );
        }

        propagated = true;

        scopeDataStructure.addEquivalency(
          subPath,
          subPath,
          externalFunctionCallInfo.name,
          scopeNode,
          'equivalency to external function call',
        );

        if (subPathParts[subPathParts.length - 1].startsWith('signature[')) {
          externalFunctionCallInfo.equivalencies[subPath] ||= [];

          const existing = externalFunctionCallInfo.equivalencies[subPath].find(
            (eq) =>
              eq.scopeNodeName === scopeNode.name && eq.schemaPath === subPath,
          );
          if (!existing) {
            externalFunctionCallInfo.equivalencies[subPath].push({
              id: -1,
              schemaPath: subPath,
              scopeNodeName: scopeNode.name,
              equivalencyReason: 'where was this function called from',
            });
          }
        }
      } else if (
        subPathParts[subPathParts.length - 1] === 'functionCallReturnValue' &&
        subPathParts.filter(
          (p) =>
            p.startsWith('signature[') ||
            p.startsWith('functionCallReturnValue'),
        ).length === 1
      ) {
        if (traceId && debugLevel > 0) {
          console.info(
            'Debug Propagation: functionCallReturnValue executed',
            JSON.stringify(
              {
                traceId,
                path,
                subPath,
                scopeNodeName: scopeNode.name,
                functionCallScopeInfoName: functionCallScopeInfo?.name,
              },
              null,
              2,
            ),
          );
        }

        propagated = true;
        scopeDataStructure.addEquivalency(
          subPath,
          'returnValue',
          functionCallScopeInfo.name,
          scopeNode,
          'returnValue to functionCallReturnValue equivalency',
          equivalencyValueChain,
          traceId,
        );
      } else {
        const pathParts = scopeDataStructure.splitPath(path);
        const signaturePath = scopeDataStructure.joinPathParts(
          pathParts.slice(1),
        );
        const equivalentSignaturePath = Object.values(
          functionCallScopeInfo.equivalencies,
        ).find((equivalentValues) =>
          equivalentValues.find(
            (equivalentValue) => equivalentValue.schemaPath === signaturePath,
          ),
        )?.[0]?.schemaPath;

        if (equivalentSignaturePath) {
          scopeDataStructure.addEquivalency(
            equivalentSignaturePath,
            path,
            scopeNode.name,
            functionCallScopeInfo,
            'functionCall to function signature equivalency',
            equivalencyValueChain,
            traceId,
          );
        }
      }
    }

    return propagated;
  }
}
