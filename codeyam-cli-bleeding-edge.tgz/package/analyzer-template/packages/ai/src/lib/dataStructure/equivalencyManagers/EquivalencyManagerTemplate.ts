import { ScopeDataStructure, ScopeNode } from '../ScopeDataStructure';
import { AddEquivalenciesInfo, EquivalencyManager } from './EquivalencyManager';

export default class EquivalencyManagerTemplate implements EquivalencyManager {
  postProcess(_scopeNode: ScopeNode, _scopeDataStructure: ScopeDataStructure) {}

  addEquivalencies(_addEquivalenciesInfo: AddEquivalenciesInfo): boolean {
    return false;
  }

  finalize(_scopeNode: ScopeNode, _scopeDataStructure: ScopeDataStructure) {}

  internalFunctions: Set<string> = new Set<string>();

  toString() {
    return 'EquivalencyManagerTemplate';
  }
}
