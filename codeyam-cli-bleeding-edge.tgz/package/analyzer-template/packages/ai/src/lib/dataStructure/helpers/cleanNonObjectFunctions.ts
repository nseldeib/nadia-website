// Handles the signature and return values for known javascript non-object functions (e.g. array methods).

import splitOutsideParentheses, {
  splitOutsideParenthesesAndArrays,
  joinParenthesesAndArrays,
} from '../../splitOutsideParentheses';
import knownMethodCalls from './knownMethodCalls';
import { ScopeDataStructure, ScopeNode } from '../ScopeDataStructure';

const firstArgumentMethodsSet = new Set([
  'forEach',
  'map',
  'filter',
  'find',
  'findIndex',
  'some',
  'every',
  'flatMap',
  'sort',
]);
const secondArgumentMethodsSet = new Set(['sort', 'reduce', 'reduceRight']);

export const nonTransformingArrayMethodsSet = new Set([
  'filter',
  'sort',
  'slice',
  'splice',
  'unshift',
  'push',
  'reverse',
]);
const isolatingArrayMethodsSet = new Set(['find', 'at', 'pop', 'shift']);
export const transformingArrayMethodsSet = new Set([
  'map',
  'reduce',
  'flatMap',
  'concat',
  'join',
  'some',
]);

export const arrayMethodsSet = new Set([
  ...nonTransformingArrayMethodsSet,
  ...isolatingArrayMethodsSet,
  ...transformingArrayMethodsSet,
]);

export const nonTransformingStringMethodsSet = new Set([
  'trim',
  'concat',
  'replace',
  'replaceAll',
  'toLowerCase',
  'toUpperCase',
  'trimStart',
  'trimEnd',
  'padStart',
  'padEnd',
  'normalize',
  'slice',
  'substring',
  'substr',
  'toString()',
  'toLocaleLowerCase',
  'toLocaleUpperCase',
]);

const transformingStringMethodsSet = new Set([
  'split',
  'match',
  'endsWith',
  'startsWith',
  'includes',
  'indexOf',
  'lastIndexOf',
  'charAt',
  'charCodeAt',
  'codePointAt',
  'repeat',
  'search',
  'valueOf',
  'localeCompare',
  'length',
]);

const stringMethodsSet = new Set([
  ...nonTransformingStringMethodsSet,
  ...transformingStringMethodsSet,
]);
export const allMethodsSet = new Set([...arrayMethodsSet, ...stringMethodsSet]);

const signatureKeyWord = 'signature';
const returnValueKeyWord = 'functionCallReturnValue';

// Regular expression to detect function call arguments.
const functionRegExp = /\([^\)]*\)/;
const signatureRegExp = new RegExp(`^${signatureKeyWord}\\[\\d+\\]$`);

// --- Caching splitOutsideParentheses ---
// Instead of splitting the same string repeatedly, we cache the result.
const splitCache = new Map<string, string[]>();
function cachedSplit(str: string): string[] {
  if (splitCache.has(str)) return splitCache.get(str)!;
  const parts = splitOutsideParentheses(str).map((p) =>
    p.replace(/::cyDuplicateKey\d+::/g, ''),
  );
  splitCache.set(str, parts);
  return parts;
}

// --- Helper functions ---
function getMethodName(s: string): string {
  if (!s) return s;
  const idx = s.indexOf('(');
  return idx === -1 ? s : s.substring(0, idx);
}

function isValidFunctionCall(s: string): boolean {
  return functionRegExp.test(s);
}

function isValidSignature(s: string): boolean {
  return signatureRegExp.test(s);
}

function isValidArrayMethod(s: string): boolean {
  return knownMethodCalls(s).includes('array');
}

function isValidStringMethod(s: string): boolean {
  return knownMethodCalls(s).includes('string');
}

/**
 * Returns true if s represents a function call whose method name is in methodSet.
 */
function checkMethod(s: string, methodSet: Set<string>): boolean {
  return isValidFunctionCall(s) && methodSet.has(getMethodName(s));
}

// --- Main export ---
export default function cleanNonObjectFunctions(
  scopeNode: ScopeNode,
  scopeDataStructure: Pick<
    ScopeDataStructure,
    | 'getScopeOrFunctionCallInfo'
    | 'addToSchema'
    | 'removeFromSchema'
    | 'addEquivalency'
    | 'removeEquivalency'
    | 'splitPath'
    | 'joinPathParts'
  >,
  final: boolean = false,
): Record<string, string> {
  // Clear the cache per invocation so that stale data is not reused.
  splitCache.clear();

  const nonObjectFunctionScopes = identifyNonObjectFunctionScopes(scopeNode);
  handleArgumentEquivalencies(scopeNode, scopeDataStructure);
  if (!final) {
    handleArrayMethods(scopeNode, scopeDataStructure);
  }

  const { schema, equivalencies } = scopeNode;

  if (final) {
    transformKeyMapping(schema);
    handleEquivalencyKeywordMapping(equivalencies);

    const knownBasePaths = new Set<string>();
    clearAttributes(schema, knownBasePaths);
    clearEquivalencies(equivalencies, knownBasePaths, scopeDataStructure);
  }

  return nonObjectFunctionScopes;
}

function transformPath({
  oldPath,
  newPath,
  scopeNode,
  scopeDataStructure,
}: {
  oldPath: string;
  newPath?: string;
  scopeNode: ScopeNode;
  scopeDataStructure: Pick<
    ScopeDataStructure,
    'addToSchema' | 'removeFromSchema' | 'addEquivalency' | 'removeEquivalency'
  >;
}) {
  const oldPathParts = splitOutsideParenthesesAndArrays(oldPath);

  for (const schemaPath in scopeNode.schema) {
    const schemaPathParts = splitOutsideParenthesesAndArrays(schemaPath);
    if (oldPathParts.every((part, index) => part === schemaPathParts[index])) {
      if (!newPath) {
        scopeDataStructure.removeFromSchema(
          schemaPath,
          scopeNode.schema,
          scopeNode.name,
        );
        continue;
      }

      const newSchemaPath = joinParenthesesAndArrays([
        newPath,
        ...schemaPathParts.slice(oldPathParts.length),
      ]);

      scopeDataStructure.addToSchema({
        path: newSchemaPath,
        value: scopeNode.schema[schemaPath],
        scopeNode,
        equivalencyValueChain: [
          {
            id: -1,
            source: 'Start: cleanNonObjectFunctions transformPath',
            previousPath: {
              scopeNodeName: scopeNode.name,
              schemaPath,
              value: scopeNode.schema[schemaPath],
            },
            reason: 'cleanNonObjectFunctions transformPath',
          },
        ],
      });
      scopeDataStructure.removeFromSchema(
        schemaPath,
        scopeNode.schema,
        scopeNode.name,
      );
    }
  }

  for (const equivalentPath in scopeNode.equivalencies) {
    const equivalentPathParts =
      splitOutsideParenthesesAndArrays(equivalentPath);

    let newEquivalentPath = equivalentPath;
    if (
      newPath &&
      oldPathParts.every((part, index) => part === equivalentPathParts[index])
    ) {
      newEquivalentPath = joinParenthesesAndArrays([
        newPath,
        ...equivalentPathParts.slice(oldPathParts.length),
      ]);
    }

    const uniqueEquivalentValues = scopeNode.equivalencies[
      equivalentPath
    ].filter(
      (equiv, index, self) =>
        self.findIndex(
          (e) =>
            e.schemaPath === equiv.schemaPath &&
            e.scopeNodeName === equiv.scopeNodeName,
        ) === index,
    );

    for (const equivalentValue of uniqueEquivalentValues) {
      const equivalentValueSchemaPathParts = splitOutsideParenthesesAndArrays(
        equivalentValue.schemaPath,
      );
      if (
        oldPathParts.every(
          (part, index) => part === equivalentValueSchemaPathParts[index],
        )
      ) {
        if (!newPath) {
          scopeDataStructure.removeEquivalency(
            equivalentPath,
            equivalentValue,
            scopeNode,
          );
          continue;
        }

        const newEquivalentValueSchemaPath = joinParenthesesAndArrays([
          newPath,
          ...equivalentValueSchemaPathParts.slice(oldPathParts.length),
        ]);
        scopeDataStructure.addEquivalency(
          newEquivalentPath,
          newEquivalentValueSchemaPath,
          scopeNode.name,
          scopeNode,
          `transformed non-object function equivalency - ${equivalentValue.equivalencyReason}`,
        );
        scopeDataStructure.removeEquivalency(
          equivalentPath,
          equivalentValue,
          scopeNode,
        );
      }
    }
  }
}

function identifyNonObjectFunctionScopes(
  scopeNode: ScopeNode,
): Record<string, string> {
  const nonObjectFunctionScopes: Record<string, string> = {};
  for (const [path, equivalentValues] of Object.entries(
    scopeNode.equivalencies,
  )) {
    const pathParts = cachedSplit(path);
    if (pathParts.length < 3) continue;
    const lastPart = pathParts[pathParts.length - 1];
    const previousPart = pathParts[pathParts.length - 2];
    if (isValidSignature(lastPart) && isValidFunctionCall(previousPart)) {
      const methodName = getMethodName(previousPart);
      if (
        isolatingArrayMethodsSet.has(methodName) ||
        nonTransformingArrayMethodsSet.has(methodName)
      ) {
        for (const equivalentValue of equivalentValues) {
          nonObjectFunctionScopes[equivalentValue.schemaPath.split('(')[0]] =
            'boolean';
        }
      }
    }
  }
  return nonObjectFunctionScopes;
}

function removeNonTransformingArrayMethods(variablePath: string): string {
  const validParts: string[] = [];
  const keyParts = cachedSplit(variablePath);
  for (let i = 0; i < keyParts.length; ++i) {
    const part = keyParts[i];

    const arrayMethod = getMethodName(part);
    if (isValidArrayMethod(arrayMethod)) {
      const nextPart = keyParts[i + 1];
      if (
        !nonTransformingArrayMethodsSet.has(arrayMethod) ||
        (nextPart && nextPart.startsWith('signature['))
      ) {
        validParts.push(part);
      } else if (
        nonTransformingArrayMethodsSet.has(arrayMethod) &&
        nextPart &&
        nextPart.startsWith('functionCallReturnValue')
      ) {
        if (nextPart.endsWith('[]')) {
          validParts.push('[]');
        }
        i += 1;
      }
    } else {
      validParts.push(part);
    }
  }
  return joinParenthesesAndArrays(validParts);
}

function removeIsolatingArrayMethods(
  variablePath: string,
  schema: ScopeNode['schema'],
): string {
  const validParts: string[] = [];
  const keyParts = cachedSplit(variablePath);
  for (let i = 0; i < keyParts.length; ++i) {
    const part = keyParts[i];

    const arrayMethod = getMethodName(part);
    if (isValidArrayMethod(arrayMethod)) {
      const nextPart = keyParts[i + 1];
      const prevPart = i > 1 ? keyParts[i - 1] : undefined;
      if (
        !isolatingArrayMethodsSet.has(arrayMethod) ||
        (nextPart && nextPart.startsWith('signature['))
      ) {
        validParts.push(part);
      } else if (isolatingArrayMethodsSet.has(arrayMethod)) {
        if (nextPart && nextPart.startsWith('functionCallReturnValue')) {
          const prevSubPath = joinParenthesesAndArrays(keyParts.slice(0, i));
          if (prevPart?.endsWith(')') || schema[prevSubPath] === 'function') {
            validParts.push(nextPart);
          }
          i++;
        }
        validParts.push('[]');
      }
    } else {
      validParts.push(part);
    }
  }
  return joinParenthesesAndArrays(validParts);
}

function handleArrayMethods(
  scopeNode: ScopeNode,
  scopeDataStructure: Pick<
    ScopeDataStructure,
    'addToSchema' | 'removeFromSchema' | 'addEquivalency' | 'removeEquivalency'
  >,
) {
  const { schema, equivalencies } = scopeNode;

  const allPaths = [
    ...Object.keys(schema),
    ...Object.keys(equivalencies),
    ...Object.values(equivalencies).flatMap((values) =>
      values.map((v) => v.schemaPath),
    ),
  ];

  for (const oldPath of allPaths) {
    if (oldPath.endsWith(')') || schema[oldPath] === 'function') continue;

    if (oldPath.length === 0 || oldPath.match(/^['"/]/)) {
      transformPath({
        oldPath,
        scopeNode,
        scopeDataStructure,
      });
      continue;
    }

    const nonTransformedPath = removeNonTransformingArrayMethods(oldPath);
    const isolatedPath = removeIsolatingArrayMethods(
      nonTransformedPath,
      schema,
    );

    if (isolatedPath !== oldPath) {
      let newPath = isolatedPath;
      if (isolatedPath.endsWith(')')) {
        const oldPathParts = splitOutsideParenthesesAndArrays(oldPath);
        newPath = joinParenthesesAndArrays([
          isolatedPath,
          oldPathParts[oldPathParts.length - 1],
        ]);
      }
      transformPath({
        oldPath,
        newPath,
        scopeNode,
        scopeDataStructure,
      });
    }
  }
}

function handleArgumentEquivalencies(
  scopeNode: ScopeNode,
  scopeDataStructure: Pick<
    ScopeDataStructure,
    'addEquivalency' | 'removeEquivalency' | 'splitPath' | 'joinPathParts'
  >,
): void {
  const { equivalencies } = scopeNode;
  for (const keyPath in equivalencies) {
    const keyPathParts = scopeDataStructure.splitPath(keyPath);
    const lastPart = keyPathParts[keyPathParts.length - 1];
    if (lastPart.startsWith(signatureKeyWord)) {
      const previousPart = keyPathParts[keyPathParts.length - 2];
      if (
        isValidFunctionCall(previousPart) &&
        (checkMethod(previousPart, firstArgumentMethodsSet) ||
          checkMethod(previousPart, secondArgumentMethodsSet))
      ) {
        let basePath = scopeDataStructure.joinPathParts(
          keyPathParts.slice(0, -2),
        );
        if (basePath.endsWith(')')) {
          basePath += `.${returnValueKeyWord}`;
        }
        for (const equivalentValue of equivalencies[keyPath]) {
          const argumentFunction = equivalentValue.schemaPath.replace(
            `.${returnValueKeyWord}`,
            '',
          );

          if (checkMethod(previousPart, firstArgumentMethodsSet)) {
            scopeDataStructure.addEquivalency(
              scopeDataStructure.joinPathParts([
                argumentFunction,
                'signature[0]',
              ]),
              scopeDataStructure.joinPathParts([basePath, '[]']),
              scopeNode.name,
              scopeNode,
              'non-object function argument function signature equivalency1',
            );
          }
          if (checkMethod(previousPart, secondArgumentMethodsSet)) {
            scopeDataStructure.addEquivalency(
              scopeDataStructure.joinPathParts([
                argumentFunction,
                'signature[1]',
              ]),
              scopeDataStructure.joinPathParts([basePath, '[]']),
              scopeNode.name,
              scopeNode,
              'non-object function argument function signature equivalency2',
            );
          }
          scopeDataStructure.removeEquivalency(
            keyPath,
            equivalentValue,
            scopeNode,
          );
        }
      }
    }
  }
}

function handleFunctionMapping(
  path: string,
  keyMapping: Record<string, string>,
): boolean {
  const keyParts = cachedSplit(path);
  const lastPart = keyParts[keyParts.length - 1];
  if (
    isValidFunctionCall(lastPart) &&
    allMethodsSet.has(getMethodName(lastPart))
  ) {
    const previousParts = keyParts.slice(0, -1);
    const previousPath = joinParenthesesAndArrays(previousParts);
    const previousPart = previousParts[previousParts.length - 1];
    if (
      (isValidFunctionCall(previousPart) &&
        !handleFunctionMapping(previousPath, keyMapping)) ||
      !isValidFunctionCall(previousPart)
    ) {
      if (
        stringMethodsSet.has(getMethodName(lastPart)) &&
        arrayMethodsSet.has(getMethodName(lastPart))
      ) {
        if (['array', 'string'].includes(keyMapping[previousPath])) {
          return false;
        }
      }

      const allProperties = Object.keys(keyMapping)
        .filter((otherKey) => {
          const otherKeyParts = cachedSplit(otherKey);
          if (otherKeyParts.length !== keyParts.length) return false;

          const relevantOtherKey = joinParenthesesAndArrays(
            otherKeyParts.slice(0, previousParts.length),
          );
          return relevantOtherKey === previousPath;
        })
        .map((k) => {
          const parts = cachedSplit(k);
          return parts[parts.length - 1];
        })
        .filter((k) => {
          if (!k) return false;
          if (
            k.startsWith('functionCallReturnValue') ||
            k.startsWith('signature[')
          ) {
            return false;
          }
          return true;
        });

      if (
        allProperties.every((prop) => stringMethodsSet.has(getMethodName(prop)))
      ) {
        if (allProperties.every((prop) => isValidStringMethod(prop))) {
          keyMapping[previousPath] = 'string';
        } else {
          return false;
        }
      } else {
        if (allProperties.every((prop) => isValidArrayMethod(prop))) {
          keyMapping[previousPath] = 'array';
        } else {
          return false;
        }
      }
    }

    if (
      !isValidFunctionCall(previousPart) &&
      arrayMethodsSet.has(getMethodName(lastPart)) &&
      !keyMapping[previousPath + '[]']
    ) {
      keyMapping[previousPath + '[]'] = 'unknown';
    }

    delete keyMapping[path];
    return true;
  }

  return false;
}

function transformKeywords(path: string, allPaths: string[]): string {
  const pathParts = cachedSplit(path);
  const newPathParts: string[] = [];
  const reversePathParts = [...pathParts].reverse();

  const partIsValidFunction = (part: string) =>
    (nonTransformingArrayMethodsSet.has(getMethodName(part)) ||
      isolatingArrayMethodsSet.has(getMethodName(part))) &&
    isValidFunctionCall(part);

  const subPathIsFromKnownObject = (subPath: string) => {
    const subPathParts = cachedSplit(subPath);

    const allProperties = allPaths
      .filter((otherPath) => {
        const otherParts = cachedSplit(otherPath);
        const relevantParts = otherParts.slice(0, subPathParts.length - 1);
        return (
          joinParenthesesAndArrays(relevantParts) ===
          joinParenthesesAndArrays(subPathParts.slice(0, -1))
        );
      })
      .map((otherPath) => {
        const otherParts = cachedSplit(otherPath);
        return otherParts[subPathParts.length - 1]?.split('(')?.[0];
      })
      .filter(Boolean);

    const isValidKnownObject = allProperties.every(
      (prop) => prop in Array.prototype || prop in String.prototype,
    );

    return isValidKnownObject;
  };

  for (let i = 0; i < reversePathParts.length - 1; ++i) {
    let part = reversePathParts[i];
    if (
      [signatureKeyWord, returnValueKeyWord].some((k) => part.startsWith(k))
    ) {
      let nextPart = reversePathParts[i + 1];
      const nextPartSubPath = joinParenthesesAndArrays(
        reversePathParts.slice(i + 1).reverse(),
      );

      if (isValidSignature(nextPart)) {
        const argumentIndex = Number(
          nextPart.split('[')[1]?.split(']')?.[0] ?? 0,
        );
        // Extract out the arguments from the function call
        const functionCallSignature = reversePathParts[i + 2];
        if (!functionCallSignature) {
          return path;
        }
        const argumentsForSignature = functionCallSignature
          .slice(
            functionCallSignature.indexOf('(') + 1,
            functionCallSignature.lastIndexOf(')'),
          )
          .split(',')
          .map((arg) => arg.trim());

        const newPath = joinParenthesesAndArrays([
          argumentsForSignature[argumentIndex],
          ...reversePathParts.slice(0, i + 1).reverse(),
        ]);
        return newPath;
      }

      while (
        subPathIsFromKnownObject(nextPartSubPath) &&
        partIsValidFunction(nextPart)
      ) {
        if (isolatingArrayMethodsSet.has(getMethodName(nextPart))) {
          part += '[]';
        }
        if (part.startsWith(returnValueKeyWord)) {
          const suffix = part.replace(returnValueKeyWord, '');
          if (suffix.length > 0 && reversePathParts[i + 2]) {
            reversePathParts[i + 2] += suffix;
          }
        }
        i++;
        nextPart = reversePathParts[i + 1];
      }
      if (
        (isValidFunctionCall(nextPart) || isValidSignature(nextPart)) &&
        [signatureKeyWord, returnValueKeyWord].some((k) => part.startsWith(k))
      ) {
        newPathParts.push(part);
      }
    } else {
      newPathParts.push(part);
    }
  }
  newPathParts.push(reversePathParts[reversePathParts.length - 1]);
  const newPath = joinParenthesesAndArrays(newPathParts.reverse());

  return newPath;
}

function handleSchemaKeywordMapping(keyMapping: ScopeNode['schema']): boolean {
  let changeMade = false;
  const allPaths = [
    ...Object.keys(keyMapping),
    ...Object.values(keyMapping),
  ].filter(Boolean);
  for (const [keyPath, valuePath] of Object.entries(keyMapping)) {
    const newKeyPath = transformKeywords(keyPath, allPaths);
    const newValuePath = transformKeywords(valuePath, allPaths);
    if (newKeyPath !== keyPath) {
      const keyPathParts = splitOutsideParenthesesAndArrays(keyPath);
      const newKeyPathParts = splitOutsideParenthesesAndArrays(newKeyPath);
      const lastPart = keyPathParts[keyPathParts.length - 1];
      const newLastPart = newKeyPathParts[newKeyPathParts.length - 1];
      if (!keyMapping[newKeyPath] && newLastPart === lastPart) {
        keyMapping[newKeyPath] = valuePath;
      }
      delete keyMapping[keyPath];
      changeMade = true;
    } else if (newValuePath !== valuePath) {
      keyMapping[newKeyPath] = newValuePath;
      changeMade = true;
    }
  }
  return changeMade;
}

function handleEquivalencyKeywordMapping(
  keyMapping: ScopeNode['equivalencies'],
): boolean {
  let changeMade = false;
  const allPaths = [
    ...Object.keys(keyMapping),
    ...Object.values(keyMapping).flatMap((values) =>
      values.map((v) => v.schemaPath),
    ),
  ];
  for (const [keyPath, values] of Object.entries(keyMapping)) {
    const newKeyPath = transformKeywords(keyPath, allPaths);

    for (let i = 0; i < values.length; ++i) {
      const newValuePath = transformKeywords(values[i].schemaPath, allPaths);

      if (newKeyPath !== keyPath) {
        const keyPathParts = splitOutsideParenthesesAndArrays(keyPath);
        const newKeyPathParts = splitOutsideParenthesesAndArrays(newKeyPath);
        const lastPart = keyPathParts[keyPathParts.length - 1];
        const newLastPart = newKeyPathParts[newKeyPathParts.length - 1];
        if (!keyMapping[newKeyPath] && newLastPart === lastPart) {
          keyMapping[newKeyPath] = values;
        }
        delete keyMapping[keyPath];
        changeMade = true;
      } else if (newValuePath !== values[i].schemaPath) {
        values[i].schemaPath = newValuePath;
        keyMapping[newKeyPath] = values;
        changeMade = true;
      }
    }
  }
  return changeMade;
}

function transformKeyMapping(keyMapping: ScopeNode['schema']): void {
  const sortedKeys = Object.keys(keyMapping).sort(
    (a, b) => b.length - a.length,
  );
  for (const keyPath of sortedKeys) {
    handleFunctionMapping(keyPath, keyMapping);
  }

  handleSchemaKeywordMapping(keyMapping);
}

function clearAttributes(
  mapping: Record<string, string>,
  knownBasePaths: Set<string>,
): void {
  const knownTypes = new Set(['string', 'array']);
  const functionCallsOnObjects: { [key: string]: string[] } = {};

  for (const key in mapping) {
    if (key.match(/^['"/]/)) {
      // Key is a string literal or regex. Delete it as it is not helpful.
      delete mapping[key];
      continue;
    }

    const keyParts = cachedSplit(key);
    const lastPart = keyParts[keyParts.length - 1];
    const previousPath = joinParenthesesAndArrays(keyParts.slice(0, -1));
    const previousValue = mapping[previousPath];
    const previousPreviousPath = joinParenthesesAndArrays(
      keyParts.slice(0, -2),
    );
    const previousPreviousValue = mapping[previousPreviousPath];

    if (
      (previousPreviousValue === 'object' ||
        previousPreviousPath === 'unknown') &&
      lastPart.startsWith('functionCallReturnValue')
    ) {
      functionCallsOnObjects[previousPreviousPath] ||= [];
      functionCallsOnObjects[previousPreviousPath].push(
        keyParts[keyParts.length - 2],
      );
    }

    if (
      (previousValue === 'object' || previousValue === 'unknown') &&
      mapping[key] === 'function'
    ) {
      functionCallsOnObjects[previousPath] ||= [];
      functionCallsOnObjects[previousPath].push(lastPart);
    }
  }

  for (const key in functionCallsOnObjects) {
    const functionCalls = functionCallsOnObjects[key];
    if (
      functionCalls.every(
        (f) => stringMethodsSet.has(getMethodName(f)) && isValidStringMethod(f),
      )
    ) {
      mapping[key] = 'string';
    } else if (
      functionCalls.every(
        (f) => arrayMethodsSet.has(getMethodName(f)) && isValidArrayMethod(f),
      )
    ) {
      mapping[key] = 'array';
    }
  }

  for (const key in mapping) {
    const value = mapping[key];
    if (knownTypes.has(value)) {
      knownBasePaths.add(key);
    }
  }

  for (const key in mapping) {
    const keyParts = cachedSplit(key);
    for (const basePath of knownBasePaths) {
      const basePathParts = cachedSplit(basePath);
      if (keyParts.length <= basePathParts.length) continue;
      if (
        joinParenthesesAndArrays(keyParts.slice(0, basePathParts.length)) !==
        basePath
      )
        continue;
      if (
        mapping[basePath] !== 'string' &&
        keyParts[basePathParts.length + 1]?.startsWith(
          'functionCallReturnValue',
        )
      )
        continue;

      delete mapping[key];
      break;
    }
  }
}

function clearEquivalencies(
  equivalencies: ScopeNode['equivalencies'],
  knownBasePaths: Set<string>,
  scopeDataStructure: Pick<
    ScopeDataStructure,
    'addEquivalency' | 'removeEquivalency'
  >,
): void {
  const keys = Object.keys(equivalencies);
  for (const key of keys) {
    const keyParts = cachedSplit(key);

    for (const basePath of knownBasePaths) {
      const basePathParts = cachedSplit(basePath);

      if (
        keyParts.length > basePathParts.length &&
        joinParenthesesAndArrays(keyParts.slice(0, basePathParts.length)) ===
          basePath
      ) {
        for (const equivalentValue of equivalencies[key] ?? []) {
          scopeDataStructure.removeEquivalency(key, equivalentValue, {
            equivalencies,
          });
        }
        continue;
      }

      const equivalentValues = structuredClone(equivalencies[key] ?? []);
      for (const equivalentValue of equivalentValues) {
        const equivalentValueSchemaPathParts = cachedSplit(
          equivalentValue.schemaPath,
        );

        if (equivalentValueSchemaPathParts.length <= basePathParts.length)
          continue;
        if (
          joinParenthesesAndArrays(
            equivalentValueSchemaPathParts.slice(0, basePathParts.length),
          ) !== basePath
        )
          continue;

        scopeDataStructure.removeEquivalency(key, equivalentValue, {
          equivalencies,
        });
      }
    }
  }
}
