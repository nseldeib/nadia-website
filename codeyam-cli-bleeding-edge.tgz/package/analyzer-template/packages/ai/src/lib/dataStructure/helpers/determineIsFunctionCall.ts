export default function determineIsFunctionCall(
  subPathParts: string[],
): boolean {
  if (subPathParts[0].startsWith('signature[')) return false;

  const lastSubPathPart = subPathParts[subPathParts.length - 1];
  const nextLastSubPathPart = subPathParts[subPathParts.length - 2];

  return (
    lastSubPathPart?.endsWith(')') ||
    (subPathParts.length > 1 && lastSubPathPart?.startsWith('signature[')) ||
    lastSubPathPart?.startsWith('functionCallReturnValue') ||
    (nextLastSubPathPart === '[]' &&
      lastSubPathPart?.startsWith('functionCallReturnValue'))
  );
}
