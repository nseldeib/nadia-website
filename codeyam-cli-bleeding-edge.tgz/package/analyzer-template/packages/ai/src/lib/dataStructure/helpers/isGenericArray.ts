import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from '../../splitOutsideParentheses';

export default function isGenericArray(
  pathParts: string[],
  allPaths: string[],
): boolean {
  const hasGenericArray = pathParts.some((part) => {
    return part.match(/\[\]/);
  });

  const hasNonGenericArray = pathParts.some((part) => {
    return isNonGenericArrayPart(part);
  });

  if (!hasGenericArray && !hasNonGenericArray) return false;

  if (hasNonGenericArray) {
    const partIndices: number[] = [];

    pathParts.forEach((part, index) => {
      if (isNonGenericArrayPart(part)) {
        partIndices.push(index);
      }
    });

    for (const allPath of allPaths) {
      for (const partIndex of partIndices) {
        const subPath = joinParenthesesAndArrays(pathParts.slice(0, partIndex));

        if (!allPath.startsWith(subPath)) {
          continue;
        }

        const allPathParts = splitOutsideParenthesesAndArrays(allPath);

        if (
          allPathParts[partIndex] &&
          allPathParts[partIndex] !== pathParts[partIndex] &&
          isArrayIndex(allPathParts[partIndex]) &&
          isArrayIndex(pathParts[partIndex]) &&
          !isGenericArrayIndex(allPathParts[partIndex]) &&
          !isGenericArrayIndex(pathParts[partIndex]) &&
          !isComplexArrayIndex(allPathParts[partIndex]) &&
          !isComplexArrayIndex(pathParts[partIndex])
        ) {
          return false;
        }
      }
    }

    return true;
  }

  return hasGenericArray;
}

function isArrayIndex(part: string): boolean {
  return part.startsWith('[') && part.endsWith(']');
}

function isNonGenericArrayPart(part: string): boolean {
  if (!part.startsWith('[') || !part.endsWith(']')) return false;

  const contents = part.slice(1, -1);
  if (/\d/.test(contents)) return true;
  if (/[+\-*/]/.test(contents)) return true;
  return false;
}

function isComplexArrayIndex(part: string): boolean {
  if (!part.startsWith('[') || !part.endsWith(']')) return false;

  const contents = part.slice(1, -1);
  if (/[+\-*/]/.test(contents)) return true;
  return false;
}

function isGenericArrayIndex(part: string): boolean {
  return part.match(/^\s*\[\s*\]\s*$/) !== null;
}
