import {
  splitOutsideParenthesesAndArrays,
  joinParenthesesAndArrays,
} from '../../splitOutsideParentheses';
import {
  nonTransformingArrayMethodsSet,
  nonTransformingStringMethodsSet,
} from './cleanNonObjectFunctions';

// This function is a temporary band-aid that will linger longer than it should.
// Needs to be more conscious of other methods being called on a given object to ensure it is a known type.
export default function cleanPathOfNonTransformingFunctions(path: string) {
  const allNonTransformingMethodsSet = new Set([
    ...nonTransformingArrayMethodsSet,
    ...nonTransformingStringMethodsSet,
  ]);
  if (
    Array.from(allNonTransformingMethodsSet).some((method) =>
      path.includes(method),
    )
  ) {
    const pathParts = splitOutsideParenthesesAndArrays(path);
    const validParts: string[] = [];
    for (let i = 0; i < pathParts.length; i++) {
      const part = pathParts[i];
      if (
        allNonTransformingMethodsSet.has(part.split('(')[0]) &&
        !pathParts[i + 1]?.startsWith('signature[')
      ) {
        if (pathParts[i + 1] === 'functionCallReturnValue') {
          i += 1;
        }
      } else {
        validParts.push(part);
      }
    }

    let cleanedPath = joinParenthesesAndArrays(validParts);

    if (cleanedPath.endsWith(')') && !path.endsWith(')')) {
      cleanedPath = joinParenthesesAndArrays([
        cleanedPath,
        pathParts[pathParts.length - 1],
      ]);
    }

    if (cleanedPath.endsWith(')[]')) {
      cleanedPath = joinParenthesesAndArrays([
        ...validParts.slice(0, -1),
        ...pathParts.slice(-2),
      ]);
    }

    return cleanedPath;
  }

  return path;
}
