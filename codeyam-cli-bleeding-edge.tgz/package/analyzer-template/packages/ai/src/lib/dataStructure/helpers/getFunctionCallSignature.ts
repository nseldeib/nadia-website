import { joinParenthesesAndArrays } from '../../splitOutsideParentheses';

export default function getFunctionCallSignature(subPathParts: string[]) {
  const lastPart = subPathParts[subPathParts.length - 1];

  if (lastPart.endsWith(')')) {
    return joinParenthesesAndArrays(subPathParts);
  }

  if (
    lastPart.startsWith('signature[') ||
    lastPart.startsWith('functionCallReturnValue')
  ) {
    const relevantSubPathParts = subPathParts.slice(0, -1);
    return joinParenthesesAndArrays(relevantSubPathParts);
  }
}
