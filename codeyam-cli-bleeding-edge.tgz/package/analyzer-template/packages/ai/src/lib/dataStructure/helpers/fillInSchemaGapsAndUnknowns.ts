import {
  splitOutsideParenthesesAndArrays,
  joinParenthesesAndArrays,
} from '../../splitOutsideParentheses';
import pluralize from 'pluralize';
import knownMethodCalls from './knownMethodCalls';
import { ScopeNode } from '../ScopeDataStructure';
import cleanOutBoundary from '../../cleanOutBoundary';

export default function fillInSchemaGapsAndUnknowns(
  scopeNode: Pick<ScopeNode, 'name' | 'schema' | 'equivalencies'>,
  fillInUnknowns = false,
  attempts = 0,
) {
  const { name, schema, equivalencies } = scopeNode;

  const existingSchema = (path) => {
    const options = [path, `${name}.${path}`, `${name}().${path}`];
    for (const option of options) {
      if (schema[option] && schema[option] !== 'unknown') return schema[option];
    }
  };

  const functionKeysMapping = [...Object.keys(schema)]
    .filter((key) => {
      if (key.endsWith(')') || schema[key] === 'function') return true;
      const parts = splitOutsideParenthesesAndArrays(key);
      if (parts[parts.length - 1] === 'length') return true;
    })
    .reduce(
      (acc, key) => {
        const parts = splitOutsideParenthesesAndArrays(key);
        const allButLastPart = joinParenthesesAndArrays(parts.slice(0, -1));
        const lastPart = parts[parts.length - 1];
        acc[allButLastPart] ||= [];
        acc[allButLastPart].push(lastPart);
        return acc;
      },
      {} as Record<string, string[]>,
    );

  let changeMade = false;
  const guessTypeForPath = (path: string, defaultType = 'string') => {
    let knownType = checkIfKnownType(path, functionKeysMapping);
    if (!knownType) {
      knownType = checkIfObjectOrFunction(path, schema);
    }

    if (knownType && schema[path] !== knownType) {
      return knownType;
    }

    const keyParts = splitOutsideParenthesesAndArrays(path);
    const lastPart = keyParts[keyParts.length - 1];

    if (isLikelyBoolean(lastPart)) {
      return 'boolean';
    } else if (isLikelyDate(lastPart)) {
      return 'date';
    } else if (isLikelyAction(lastPart)) {
      return 'function';
    } else if (pluralize.isPlural(lastPart)) {
      return 'array';
    } else {
      return defaultType;
    }
  };

  if (fillInUnknowns) {
    for (const [equivalentKey, equivalentValues] of Object.entries(
      equivalencies,
    )) {
      for (const equivalentValue of equivalentValues) {
        if (
          schema[equivalentKey] === 'unknown' &&
          schema[equivalentValue.schemaPath] === 'unknown'
        ) {
          const newEquivalentValueType = guessTypeForPath(
            equivalentValue.schemaPath,
          );
          if (newEquivalentValueType) {
            schema[equivalentValue.schemaPath] = newEquivalentValueType;
            changeMade = true;
          }
        }

        if (
          schema[equivalentKey] === 'unknown' &&
          schema[equivalentValue.schemaPath] &&
          schema[equivalentValue.schemaPath] !== 'unknown'
        ) {
          schema[equivalentKey] = schema[equivalentValue.schemaPath];
          changeMade = true;
        }
      }
    }
  }

  for (const key in schema) {
    if (fillInUnknowns) {
      if (!schema[key]) schema[key] = 'unknown';
      if (schema[key].includes(' | unknown')) {
        schema[key] = schema[key].replace(' | unknown', '');
        changeMade = true;
      } else if (schema[key] === 'unknown') {
        const newType = guessTypeForPath(key, 'string');
        if (newType) {
          schema[key] = newType;
          changeMade = true;
        }
      }
    }

    const keyParts = splitOutsideParenthesesAndArrays(key);
    for (let i = 0; i < keyParts.length; i++) {
      const subPathParts = keyParts.slice(0, i + 1);
      const lastSubPathPart = subPathParts[subPathParts.length - 1];

      const previousSubPathParts = subPathParts.slice(0, i);
      if (previousSubPathParts.length === 0) continue;

      const previousSubPath = joinParenthesesAndArrays(previousSubPathParts);

      if (
        cleanOutBoundary(lastSubPathPart).match(/\[\d*\]/) &&
        !lastSubPathPart.match(/signature\[\d+\]/)
      ) {
        if (schema[previousSubPath] !== 'array') {
          schema[previousSubPath] = 'array';
          changeMade = true;
        }
      }

      const isFunction =
        lastSubPathPart.endsWith(')') ||
        lastSubPathPart === 'functionCallReturnValue' ||
        lastSubPathPart.match(/signature\[\d+\]/);

      if (
        !isFunction &&
        !['object', 'array', 'function', 'async-function'].includes(
          schema[previousSubPath],
        )
      ) {
        const newValue =
          checkIfKnownType(previousSubPath, functionKeysMapping) ?? 'object';

        if (
          !schema[previousSubPath] ||
          (fillInUnknowns && schema[previousSubPath] !== newValue)
        ) {
          schema[previousSubPath] = newValue;
          changeMade = true;
        }
      }

      // Handle the wrong function chaining function().function()
      if (isFunction && !existingSchema(previousSubPath)) {
        schema[previousSubPath] = previousSubPath.endsWith(')')
          ? 'function'
          : (checkIfKnownType(previousSubPath, functionKeysMapping) ??
            'object');
        changeMade = true;
      }
    }
  }

  if (changeMade && attempts < 10) {
    fillInSchemaGapsAndUnknowns(scopeNode, fillInUnknowns, ++attempts);
  }
}

export function fillInDirectSchemaGapsAndUnknowns({
  scopeName,
  schema,
  attempts = 0,
}: {
  scopeName?: string;
  schema: Record<string, string>;
  attempts?: number;
}) {
  try {
    const existingSchema = (path) => {
      const options = [path, `${scopeName}.${path}`, `${scopeName}().${path}`];
      for (const option of options) {
        if (schema[option] && schema[option] !== 'unknown')
          return schema[option];
      }
    };

    const functionKeysMapping = [...Object.keys(schema)]
      .filter((key) => {
        if (key.endsWith(')') || schema[key] === 'function') return true;
        const parts = splitOutsideParenthesesAndArrays(key);
        if (parts[parts.length - 1] === 'length') return true;
      })
      .reduce(
        (acc, key) => {
          const parts = splitOutsideParenthesesAndArrays(key);
          const allButLastPart = joinParenthesesAndArrays(parts.slice(0, -1));
          const lastPart = parts[parts.length - 1];
          acc[allButLastPart] ||= [];
          acc[allButLastPart].push(lastPart);
          return acc;
        },
        {} as Record<string, string[]>,
      );

    let changeMade = false;
    const guessTypeForPath = (path: string, defaultType = 'string') => {
      let knownType = checkIfKnownType(path, functionKeysMapping);
      if (!knownType) {
        knownType = checkIfObjectOrFunction(path, schema);
      }

      if (knownType && schema[path] !== knownType) {
        return knownType;
      }

      const keyParts = splitOutsideParenthesesAndArrays(path);
      const lastPart = keyParts[keyParts.length - 1];

      if (isLikelyBoolean(lastPart)) {
        return 'boolean';
      } else if (isLikelyDate(lastPart)) {
        return 'date';
      } else if (isLikelyAction(lastPart)) {
        return 'function';
      } else if (pluralize.isPlural(lastPart)) {
        return 'array';
      } else {
        return defaultType;
      }
    };

    for (const key in schema) {
      if (!schema[key]) schema[key] = 'unknown';
      if (schema[key].includes(' | unknown')) {
        schema[key] = schema[key].replace(' | unknown', '');
        changeMade = true;
      } else if (schema[key] === 'unknown') {
        const newType = guessTypeForPath(key, 'string');
        if (newType) {
          schema[key] = newType;
          changeMade = true;
        }
      }

      const keyParts = splitOutsideParenthesesAndArrays(key);
      for (let i = 0; i < keyParts.length; i++) {
        const subPathParts = keyParts.slice(0, i + 1);
        const lastSubPathPart = subPathParts[subPathParts.length - 1];

        const previousSubPathParts = subPathParts.slice(0, i);
        if (previousSubPathParts.length === 0) continue;

        const previousSubPath = joinParenthesesAndArrays(previousSubPathParts);

        if (
          cleanOutBoundary(lastSubPathPart).match(/\[\d*\]/) &&
          !lastSubPathPart.match(/signature\[\d+\]/)
        ) {
          if (schema[previousSubPath] !== 'array') {
            schema[previousSubPath] = 'array';
            changeMade = true;
          }
        }

        const isFunction =
          lastSubPathPart.endsWith(')') ||
          lastSubPathPart === 'functionCallReturnValue' ||
          lastSubPathPart.match(/signature\[\d+\]/);

        if (
          !isFunction &&
          !['object', 'array', 'function', 'async-function'].includes(
            schema[previousSubPath],
          )
        ) {
          const newValue =
            checkIfKnownType(previousSubPath, functionKeysMapping) ?? 'object';

          if (
            !schema[previousSubPath] ||
            schema[previousSubPath] !== newValue
          ) {
            schema[previousSubPath] = newValue;
            changeMade = true;
          }
        }

        // Handle the wrong function chaining function().function()
        if (isFunction && !existingSchema(previousSubPath)) {
          schema[previousSubPath] = previousSubPath.endsWith(')')
            ? 'function'
            : (checkIfKnownType(previousSubPath, functionKeysMapping) ??
              'object');
          changeMade = true;
        }
      }
    }

    if (changeMade && attempts < 10) {
      fillInDirectSchemaGapsAndUnknowns({
        scopeName,
        schema,
        attempts: ++attempts,
      });
    }

    return schema;
  } catch (error) {
    console.info(
      'Failed to fill in schema gaps and unknowns for scope:',
      JSON.stringify(
        {
          scopeName,
          schema,
        },
        null,
        2,
      ),
    );
    throw error;
  }
}

function checkIfObjectOrFunction(path: string, schema: ScopeNode['schema']) {
  const pathParts = splitOutsideParenthesesAndArrays(path);
  for (const structureKey in schema) {
    if (structureKey.startsWith(path)) {
      const structureKeyParts = splitOutsideParenthesesAndArrays(structureKey);
      if (structureKeyParts[pathParts.length - 1].endsWith(')')) {
        return 'function';
      } else if (structureKeyParts.length > pathParts.length) {
        return 'object';
      }
    }
  }
}

function checkIfKnownType(
  key: string,
  functionAndAttributesKeysMapping: Record<string, string[]>,
) {
  let isArray: boolean | undefined;
  let isString: boolean | undefined;

  for (const functionOrAttributeName of functionAndAttributesKeysMapping[key] ??
    []) {
    const couldBeArray =
      knownMethodCalls(functionOrAttributeName).includes('array') ||
      functionOrAttributeName === 'length';
    const couldBeString =
      knownMethodCalls(functionOrAttributeName).includes('string') ||
      functionOrAttributeName === 'length';

    if (!couldBeArray) {
      isArray = false;
    }
    if (!couldBeString) {
      isString = false;
    }

    if (isArray !== false && couldBeArray) {
      isArray = true;
    }
    if (isString !== false && couldBeString) {
      isString = true;
    }
  }

  if (isString) return 'string';
  if (isArray) return 'array';
}

// --- Targeted Verb List for Programming ---
const commonProgrammingVerbs = new Set([
  'add',
  'get',
  'set',
  'create',
  'read',
  'update',
  'delete',
  'remove',
  'calculate',
  'validate',
  'parse',
  'load',
  'save',
  'init',
  'initialize',
  'start',
  'stop',
  'send',
  'receive',
  'build',
  'find',
  'search',
  'is',
  'has',
  'can',
  'should',
  'check',
  'process',
  'generate',
  'render',
  'fetch',
  'push',
  'pop',
  'open',
  'close',
  'connect',
  'disconnect',
  'enable',
  'disable',
  'append',
  'prepend',
  'insert',
  'select',
  'make',
  'perform',
  'execute',
  'run',
  'join',
  'split',
  'merge',
  'clear',
  'reset',
  'await',
  'handle',
  'log',
  'debug',
  'show',
  'hide',
  'toggle',
  'mount',
  'unmount',
  'register',
  'unregister',
  'emit',
  'broadcast',
  'apply',
  'format',
  'move',
  'copy',
  'compare',
  // Add more as needed based on your specific domain/codebase
]);

const commonBooleanIndicators = new Set([
  'is',
  'has',
  'can',
  'should',
  'was',
  'were',
  'are',
  'will',
  'would',
  'could',
  'might',
  'must',
  'need',
  'want',
  'allow',
  'permit',
  'enable',
  'disable',
  'diabled',
  'block',
  'prevent',
  'forbid',
  'prohibit',
  'accept',
  'reject',
  'agree',
  'disagree',
  'confirm',
  'deny',
  'validate',
  'invalidate',
  'check',
  'verify',
  'test',
  'assert',
  'ensure',
  'guarantee',
  'promise',
  'assure',
  'warrant',
  'certify',
]);

/**
 * Splits camelCase, PascalCase, or snake_case identifiers into words.
 * Handles simple acronyms (e.g., HTTPResponse -> ['http', 'response']).
 * @param {string} identifier
 * @returns {string[]} Array of words in lowercase.
 */
function splitIdentifier(identifier) {
  if (!identifier) return [];

  // Handle snake_case first
  identifier = identifier.replace(/_/g, ' ');

  // Split based on capital letters, including handling sequences of capitals (acronyms)
  // Example: "addData" -> "add Data"
  // Example: "HTTPResponse" -> "HTTP Response"
  // Example: "myNASAData" -> "my NASA Data"
  const words = identifier
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2') // Split acronym followed by word (HTTPRequest -> HTTP Request)
    .replace(/([a-z\d])([A-Z])/g, '$1 $2') // Split word/digit followed by capital (addData -> add Data)
    .split(' ');

  return words.map((word) => word.toLowerCase()).filter(Boolean); // Filter empty strings from potential multiple spaces
}

/**
 * Checks if a variable name likely represents an action (often starts with a verb).
 * @param {string} varName The variable name.
 * @returns {boolean}
 */
function isLikelyAction(varName) {
  const words = splitIdentifier(varName);
  if (words.length === 0) {
    return false;
  }
  // Check if the first word is a common programming verb
  return commonProgrammingVerbs.has(words[0]);
}

/**
 * Checks if a variable name likely represents a boolean value.
 * @param {string} varName The variable name.
 * @returns {boolean}
 */
function isLikelyBoolean(varName) {
  const words = splitIdentifier(varName);
  if (words.length === 0) {
    return false;
  }
  // Check if the first word is a common programming boolean indicator
  if (commonBooleanIndicators.has(words[0])) return true;

  const booleanOperators = ['===', '!==', '==', '!=', '>=', '<=', '>', '<'];

  if (booleanOperators.some((op) => varName.includes(op))) return true;
  return false;
}

/**
 * Checks if a variable name likely represents a date.
 * @param {string} varName The variable name.
 * @returns {boolean}
 */
function isLikelyDate(varName) {
  const words = splitIdentifier(varName);
  if (words.length === 0) {
    return false;
  }
  // Check for common date-related terms
  const dateIndicators = new Set([
    'date',
    'time',
    'timestamp',
    'datetime',
    'day',
    'month',
    'year',
    'calendar',
    'epoch',
  ]);

  return words.some((word) => dateIndicators.has(word));
}
