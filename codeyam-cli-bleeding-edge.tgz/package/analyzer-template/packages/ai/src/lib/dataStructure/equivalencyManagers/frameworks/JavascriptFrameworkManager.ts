import cleanKnownObjectFunctions from '../../helpers/cleanKnownObjectFunctions';
import cleanNonObjectFunctions from '../../helpers/cleanNonObjectFunctions';
import { ScopeDataStructure, ScopeNode } from '../../ScopeDataStructure';
import {
  AddEquivalenciesInfo,
  EquivalencyManager,
} from '../EquivalencyManager';

export class JavascriptFrameworkManager implements EquivalencyManager {
  private nonObjectFunctionScopes: Record<string, string> = {};

  postProcess(scopeNode: ScopeNode, scopeDataStructure: ScopeDataStructure) {
    const scopeNonObjectFunctionScopes = cleanNonObjectFunctions(
      scopeNode,
      scopeDataStructure,
      false,
    );
    this.nonObjectFunctionScopes = {
      ...this.nonObjectFunctionScopes,
      ...scopeNonObjectFunctionScopes,
    };

    if (this.nonObjectFunctionScopes[scopeNode.name]) {
      const returnValueEquivalentValues =
        scopeNode.equivalencies['returnValue'] ?? [];
      for (const equivalentValue of returnValueEquivalentValues) {
        scopeDataStructure.removeEquivalency(
          'returnValue',
          equivalentValue,
          scopeNode,
        );
      }
    }

    this.handleSpreadOperators(scopeNode, scopeDataStructure);
  }

  addEquivalencies(addEquivalenciesInfo: AddEquivalenciesInfo) {
    // This should probably be handled in the AST Analyzer
    let propagated = false;

    const handleExplicitArraysPropagated = this.handleExplicitArrays(
      addEquivalenciesInfo.path,
      addEquivalenciesInfo.scopeNode,
      addEquivalenciesInfo.scopeDataStructure,
    );

    if (handleExplicitArraysPropagated) {
      propagated = true;
    }

    const handleMapPropagated = this.handleMap(addEquivalenciesInfo);

    if (handleMapPropagated) {
      propagated = true;
    }

    const handleThenPropagated = this.handleThen(addEquivalenciesInfo);

    if (handleThenPropagated) {
      propagated = true;
    }

    return propagated;
  }

  finalize(scopeNode: ScopeNode, scopeDataStructure: ScopeDataStructure) {
    cleanNonObjectFunctions(scopeNode, scopeDataStructure, true);
    cleanKnownObjectFunctions(scopeNode, scopeDataStructure);
    this.handleUniformArrays(scopeNode, scopeDataStructure);
  }

  internalFunctions: Set<string> = new Set([
    'window',
    'document',
    'setTimeout',
    'setInterval',
    'clearTimeout',
    'clearInterval',
    'Promise',
    'console',
    'Math',
    'JSON',
    'Object',
    'Array',
    'String',
    'Number',
    'Boolean',
    'Date',
    'RegExp',
    'Error',
    'Map',
    'Set',
    'WeakMap',
    'WeakSet',
    'Symbol',
  ]);

  toString() {
    return 'JavascriptFrameworkManager';
  }

  isInterestedInSubpath(): boolean {
    return true;
  }

  // This is super awkward and should probably be handled in the AST Analyzer
  // An explicit array is something like [itemsA, itemsB].map(...)
  private handleExplicitArrays(
    path: string,
    scopeNode: ScopeNode,
    scopeDataStructure: ScopeDataStructure,
  ) {
    let propagated = false;

    if (
      !path.startsWith('[') ||
      !path.endsWith(']') ||
      path
        .trim()
        .replace(/(\[\])/g, '')
        .indexOf(']') !==
        path.length - 1
    ) {
      return false;
    }

    const innerParts = path
      .slice(1, -1)
      .split(',')
      .map((p) => p.trim());

    scopeDataStructure.removeFromSchema(path, scopeNode.schema, scopeNode.name);

    const changePath = (p: string, innerPart: string) =>
      p.replace(`${path}[]`, innerPart).replace(path, innerPart);

    const changeSchema = (schema: ScopeNode['schema']) => {
      const newSchema: ScopeNode['schema'] = {};
      for (const key in schema) {
        if (key.includes(path)) {
          for (const innerPart of innerParts) {
            newSchema[changePath(key, innerPart)] = schema[key];
          }
        } else {
          newSchema[key] = schema[key];
        }
      }
      return newSchema;
    };

    const changeEquivalencies = (schema: ScopeNode['equivalencies']) => {
      const newEquivalencies: ScopeNode['equivalencies'] = {};
      for (const key in schema) {
        if (key.includes(path)) {
          for (const innerPart of innerParts) {
            newEquivalencies[changePath(key, innerPart)] = schema[key];
          }
        } else {
          newEquivalencies[key] = schema[key];
        }
      }
      return newEquivalencies;
    };

    for (const equivalentPath in scopeNode.equivalencies) {
      const equivalentPathParts = scopeDataStructure.splitPath(equivalentPath);

      const index = equivalentPathParts.indexOf(path);
      if (index > -1) {
        propagated = true;

        for (const innerPart of innerParts) {
          const newEquivalentKey = scopeDataStructure.joinPathParts([
            innerPart,
            ...equivalentPathParts.slice(index + 1),
          ]);
          scopeDataStructure.addEquivalency(
            innerPart,
            newEquivalentKey,
            scopeNode.name,
            scopeNode,
            'Explicit array deconstruction equivalency key',
          );
        }

        for (const equivalentValue of scopeNode.equivalencies[equivalentPath]) {
          scopeDataStructure.removeEquivalency(
            equivalentPath,
            equivalentValue,
            scopeNode,
          );
        }
      }
    }

    for (const equivalentPath in scopeNode.equivalencies) {
      for (const equivalentValue of scopeNode.equivalencies[equivalentPath]) {
        if (equivalentValue.schemaPath.includes(path)) {
          for (const innerPart of innerParts) {
            const newSchemaPath = changePath(
              equivalentValue.schemaPath,
              innerPart,
            );
            scopeDataStructure.addEquivalency(
              equivalentPath,
              newSchemaPath,
              scopeNode.name,
              scopeNode,
              'Explicit array deconstruction equivalency value',
            );
          }
          scopeDataStructure.removeEquivalency(
            equivalentPath,
            equivalentValue,
            scopeNode,
          );
        }
      }
    }

    for (let i = 0; i < scopeDataStructure.externalFunctionCalls.length; ++i) {
      const externalFunctionCall = scopeDataStructure.externalFunctionCalls[i];
      if (
        externalFunctionCall.name.includes(path) ||
        externalFunctionCall.callSignature.includes(path)
      ) {
        for (const innerPart of innerParts) {
          const newFunctionCallName = changePath(
            externalFunctionCall.name,
            innerPart,
          );
          const newCallSignature = changePath(
            externalFunctionCall.callSignature,
            innerPart,
          );
          const newSchema = changeSchema(externalFunctionCall.schema);
          const newEquivalencies = changeEquivalencies(
            externalFunctionCall.equivalencies,
          );

          const newFunctionCallInfo = {
            ...externalFunctionCall,
            name: newFunctionCallName,
            callSignature: newCallSignature,
            schema: newSchema,
            equivalencies: newEquivalencies,
          };
          scopeDataStructure.addFunctionCall(scopeNode, newFunctionCallInfo);
        }
        scopeDataStructure.externalFunctionCalls.splice(i, 1);
      }
    }

    return propagated;
  }

  private handleMap({
    subPathParts,
    scopeNode,
    scopeDataStructure,
    equivalencyValueChain,
    traceId,
  }: AddEquivalenciesInfo) {
    if (subPathParts[0].startsWith('returnValue')) return false;

    const mapCall = subPathParts[subPathParts.length - 2];
    if (
      !mapCall?.startsWith('map(') ||
      (subPathParts[subPathParts.length - 1] !== 'functionCallReturnValue' &&
        !subPathParts[subPathParts.length - 1].endsWith(')'))
    ) {
      return false;
    }

    const relevantSubPath = scopeDataStructure.joinPathParts([
      ...subPathParts.slice(0, -1),
      'functionCallReturnValue',
    ]);

    let propagated = false;
    const mapFunction = mapCall.slice(4, -1); // remove 'map(' and ')'

    for (const [equivalentPath, equivalentValues] of Object.entries(
      scopeNode.equivalencies,
    )) {
      for (const equivalentValue of equivalentValues) {
        if (equivalentValue.scopeNodeName !== scopeNode.name) continue;

        const isEquivalent = equivalentValue.schemaPath === relevantSubPath;
        const arrayEquivalent =
          equivalentValue.schemaPath === `${relevantSubPath}[]`;

        if (isEquivalent || arrayEquivalent) {
          propagated = true;

          scopeDataStructure.removeEquivalency(
            equivalentPath,
            equivalentValue,
            scopeNode,
          );

          if (subPathParts[subPathParts.length - 1].endsWith(')')) {
            const equivalentPathParts =
              scopeDataStructure.splitPath(equivalentPath);

            if (!scopeDataStructure.scopeNodes[equivalentPathParts[0]])
              continue;

            scopeDataStructure.addEquivalency(
              scopeDataStructure.joinPathParts(equivalentPathParts.slice(1)),
              'returnValue',
              mapFunction.split('(')[0],
              scopeDataStructure.scopeNodes[equivalentPathParts[0]],
              '.map() function deconstruction',
              equivalencyValueChain,
              traceId,
            );
          } else {
            scopeDataStructure.addEquivalency(
              arrayEquivalent ? equivalentPath : `${equivalentPath}[]`,
              'returnValue',
              mapFunction.split('(')[0],
              scopeNode,
              '.map() function deconstruction',
              equivalencyValueChain,
              traceId,
            );
          }
        }
      }
    }

    return propagated;
  }

  private handleThen({ scopeDataStructure, scopeNode }: AddEquivalenciesInfo) {
    let propagated = false;
    if (!scopeNode.tree || scopeNode.tree.length === 0) return propagated;

    const parentScopeName = scopeNode.tree[scopeNode.tree.length - 1];
    const parentScopeInfo = scopeDataStructure.scopeNodes[parentScopeName];
    const thenStatement = Object.keys(parentScopeInfo.equivalencies).find(
      (path) => path.includes('.then(') && path.includes(`${scopeNode.name}()`),
    );

    if (!thenStatement) return propagated;

    const thenStatementParts = scopeDataStructure.splitPath(thenStatement);
    const asyncFunction = scopeDataStructure.joinPathParts(
      thenStatementParts.slice(0, -2),
    );

    if (
      parentScopeInfo.analysis.isolatedStructure[asyncFunction] ===
      'async-function'
    ) {
      return propagated;
    }

    parentScopeInfo.analysis.isolatedStructure[asyncFunction] =
      'async-function';

    const arraySignature = Object.values(scopeNode.equivalencies).find(
      (values) =>
        values.find((value) => value.schemaPath.startsWith('signature[1')),
    );

    for (const [equivalentPath, equivalentValues] of Object.entries(
      scopeNode.equivalencies,
    )) {
      for (const equivalentValue of equivalentValues) {
        if (equivalentValue.schemaPath.startsWith('signature[')) {
          const schemaPath = equivalentValue.schemaPath;
          const schemaPathParts = scopeDataStructure.splitPath(schemaPath);
          if (arraySignature) {
          } else {
            // const functionCallInfo =
            //   scopeDataStructure.getScopeOrFunctionCallInfo(thenStatement);

            // functionCallInfo.schema[
            //   scopeDataStructure.joinPathParts(thenStatementParts.slice(0, -2))
            // ] = 'async-function';

            const newReturnValuePath = scopeDataStructure.joinPathParts([
              ...thenStatementParts.slice(0, -2),
              'functionCallReturnValue',
              ...schemaPathParts.slice(1),
            ]);

            propagated = true;
            scopeDataStructure.addEquivalency(
              equivalentPath,
              newReturnValuePath,
              scopeNode.name,
              scopeNode,
              'Node .then() equivalency',
            );
          }
        }
      }
    }

    return propagated;
  }

  private handleSpreadOperators(
    scopeNode: ScopeNode,
    scopeDataStructure: ScopeDataStructure,
  ) {
    for (const path in scopeNode.equivalencies) {
      const clonedEquivalencies = structuredClone(
        scopeNode.equivalencies[path],
      );

      const clonedEquivalencies2 = structuredClone(
        scopeNode.equivalencies[path],
      );

      for (let i = 0; i < clonedEquivalencies.length; i++) {
        const equivalentValue = clonedEquivalencies[i];
        if (equivalentValue.schemaPath.startsWith('...')) {
          if (scopeNode.schema[path] === 'array') {
            let spreadItemType = 'unknown';
            const arrayItemType =
              scopeNode.schema[`${path.replace(/^\.\.\./, '')}[]`];
            if (arrayItemType) {
              spreadItemType = arrayItemType;
            }
            const newPath = path.replace(/\[.*\]$/, '[]');
            if (
              !scopeNode.schema[newPath] ||
              scopeNode.schema[newPath] === 'unknown'
            ) {
              scopeNode.analysis.isolatedStructure[newPath] = spreadItemType;
            }
            delete scopeNode.analysis.isolatedStructure[path];

            for (let j = 0; j < clonedEquivalencies2.length; j++) {
              const outDatedEquivalentValue = clonedEquivalencies2[j];

              if (j !== i) {
                scopeDataStructure.addEquivalency(
                  newPath,
                  outDatedEquivalentValue.schemaPath,
                  outDatedEquivalentValue.scopeNodeName,
                  scopeNode,
                  `Spread operator equivalency key update: ${outDatedEquivalentValue.equivalencyReason}`,
                );
              }

              scopeDataStructure.removeEquivalency(
                path,
                outDatedEquivalentValue,
                scopeNode,
              );
            }

            scopeDataStructure.addToSchema({
              path: newPath,
              value: spreadItemType,
              scopeNode,
              equivalencyValueChain: [
                {
                  id: -1,
                  source: 'Start: spread operator transformation',
                  previousPath: {
                    scopeNodeName: scopeNode.name,
                    schemaPath: path,
                    value: 'array',
                  },
                  reason: 'spread operator to array item equivalency',
                },
              ],
            });
          }
        }
      }
    }
  }

  private handleUniformArrays(
    scopeNode: ScopeNode,
    scopeDataStructure: ScopeDataStructure,
  ) {
    const arrays: Record<string, { paths: Set<string>; values: Set<string> }> =
      {};
    for (const path in scopeNode.schema) {
      const pathParts = scopeDataStructure.splitPath(path);
      if (pathParts[pathParts.length - 1].startsWith('[')) {
        const arrayPath = scopeDataStructure.joinPathParts(
          pathParts.slice(0, -1),
        );
        arrays[arrayPath] ||= { paths: new Set(), values: new Set() };
        arrays[arrayPath].paths.add(path);
        arrays[arrayPath].values.add(scopeNode.schema[path]);
      }
    }

    for (const [arrayPath, arrayInfo] of Object.entries(arrays)) {
      if (arrayInfo.paths.size > 1 && arrayInfo.values.size === 1) {
        arrayInfo.paths.forEach((path) => delete scopeNode.schema[path]);
        scopeNode.schema[`${arrayPath}[]`] = arrayInfo.values.values[0];
      }
    }
  }
}
