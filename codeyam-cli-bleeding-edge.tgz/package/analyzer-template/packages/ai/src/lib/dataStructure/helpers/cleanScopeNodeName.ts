export default function cleanScopeNodeName(scopeNodeName: string): string {
  return scopeNodeName.replace(/____cyScope\d+[A-Z]*/, '').split('(')[0];
}
