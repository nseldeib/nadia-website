import { splitOutsideParenthesesAndArrays } from '../../splitOutsideParentheses';

export default function getFunctionCallRoot(functionCallSignature: string) {
  const functionCallSignatureParts = splitOutsideParenthesesAndArrays(
    functionCallSignature,
  );

  return functionCallSignatureParts[0]
    .replace(/(cyScope\d+)F/, '$1')
    .split('(')[0];
}
