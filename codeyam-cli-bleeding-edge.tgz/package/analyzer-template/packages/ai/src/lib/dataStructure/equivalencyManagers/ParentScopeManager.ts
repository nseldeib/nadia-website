import { ScopeDataStructure, ScopeNode } from '../ScopeDataStructure';
import { AddEquivalenciesInfo, EquivalencyManager } from './EquivalencyManager';

// Handle implicit parent scope equivalencies
// Example:
//   function parentScopeFunction() {
//     const x = {};
//     const childScopeFunction = () => {
//       x.y = 1;
//     };
//   }
// In this case x in the child scope is implicitly equivalent to x in the parent scope
// Variables should be propagated to the parent scope if:
// - The parent scope exists
// - The variable is not instantiated in the child scope
// - The variable is not already defined in the parent scope with a more specific type than 'unknown'
// - The scope is a function call and:
//   - The variable is in the signature of the function call
//   - The variable is the return value of the function call
// - The root variable is not a function (handled by the FunctionCallManager)
// - An equivalency has not already been added to the parent scope for a subpath of the path

export default class ParentScopeManager implements EquivalencyManager {
  private addedToParent: Record<string, Set<string>> = {};

  postProcess(_scopeNode: ScopeNode, _scopeDataStructure: ScopeDataStructure) {}

  isInterestedInSubpath(subPathParts: string[], scopeNode: ScopeNode): boolean {
    return (
      !!(scopeNode.tree && scopeNode.tree.length >= 1) &&
      subPathParts.length === 1
    );
  }

  addEquivalencies({
    scopeDataStructure,
    scopeNode,
    path,
    subPathParts,
    equivalencyValueChain,
    traceId,
    debugLevel,
  }: AddEquivalenciesInfo): boolean {
    if (
      !scopeNode.tree ||
      scopeNode.tree.length < 1 ||
      subPathParts.length !== 1
    )
      return false;

    const rootPath = subPathParts[0];
    const parentScopeName = scopeNode.tree[scopeNode.tree.length - 1];
    if (parentScopeName && parentScopeName !== scopeNode.name) {
      const parentScope =
        scopeDataStructure.getScopeOrFunctionCallInfo(parentScopeName);

      if (!parentScope) return false;

      const instantiatedInParent =
        'parentInstantiatedVariables' in scopeNode &&
        scopeNode.parentInstantiatedVariables.includes(subPathParts[0]);

      const returnValueFromChildScope =
        path.startsWith('returnValue') && !scopeNode.isFunctionDefinition;

      if (traceId && debugLevel > 1) {
        console.info(
          'Debug Propagation: parentScope',
          JSON.stringify(
            {
              traceId,
              path,
              subPathParts,
              scopeNodeName: scopeNode.name,
              parentScopeName,
              instantiatedInParent,
              returnValueFromChildScope,
              notInstantiatedVariable:
                !scopeNode.instantiatedVariables.includes(subPathParts[0]),
              parentScopeExists: !!parentScope,
              parentScopeInstantiated:
                scopeNode.parentInstantiatedVariables.includes(subPathParts[0]),
              parentScopeMissingOrUnknown:
                !parentScope.schema[path] ||
                parentScope.schema[path] === 'unknown',
              notAFunction: !subPathParts[0].endsWith(')'), // What about lib.attr.func() if lib is an import
              notSignatureOrIsFunctionCallReturnValue: !(
                path.startsWith('returnValue') || path.startsWith('signature[')
              ),
              notAddedToParent: !this.addedToParent[scopeNode.name]?.has(path),
              // parentScope
            },
            null,
            2,
          ),
        );
      }

      if (instantiatedInParent || returnValueFromChildScope) {
        if (traceId && debugLevel > 0) {
          console.info(
            'Debug Propagation: parentScope executed',
            JSON.stringify(
              {
                traceId,
                path,
                rootPath,
                scopeNodeName: scopeNode.name,
                parentScopeName,
              },
              null,
              2,
            ),
          );
        }

        this.addedToParent[scopeNode.name] ||= new Set<string>();
        this.addedToParent[scopeNode.name].add(rootPath);

        scopeDataStructure.addEquivalency(
          rootPath,
          rootPath,
          parentScopeName,
          scopeNode,
          'implicit parent equivalency',
          equivalencyValueChain,
          traceId,
        );

        return true;
      }
    }
  }

  finalize(_scopeNode: ScopeNode, _scopeDataStructure: ScopeDataStructure) {
    // No finalization needed for parent scope management
  }

  internalFunctions: Set<string> = new Set([]);

  toString() {
    return 'ParentScopeManager';
  }
}
