import { ScopeDataStructure } from '../ScopeDataStructure';
import cleanScopeNodeName from './cleanScopeNodeName';

export default function getFunctionCallScopeNodeName(
  functionCallName: string,
  scopeDataStructure: ScopeDataStructure,
): string | undefined {
  if (functionCallName) {
    return Object.keys(scopeDataStructure.scopeNodes).find(
      (scopeNodeName) =>
        cleanScopeNodeName(scopeNodeName) ===
        cleanScopeNodeName(functionCallName),
    );
  }
}
