import {
  joinParenthesesAndArrays,
  splitOutsideParenthesesAndArrays,
} from '../../splitOutsideParentheses';
import { ScopeNode, ScopeDataStructure } from '../ScopeDataStructure';

type PrimitiveKind = 'array' | 'string' | 'number' | 'boolean' | 'date';

const IGNORE_CLASSES_AND_OBJECTS = [
  'Math',
  'JSON',
  'Reflect',
  'Promise',
  'Intl',
  'Date',
  'console',
  'useState',
  'useEffect',
  'useMemo',
  'useCallback',
  'useRef',
  'useContext',
  'useReducer',
  'useLayoutEffect',
];

/** cache the tokenised representation of every path we touch */
const partsCache = new Map<string, string[]>();
const getParts = (path: string): string[] => {
  let parts = partsCache.get(path);
  if (!parts) {
    parts = splitOutsideParenthesesAndArrays(path);
    partsCache.set(path, parts);
  }
  return parts;
};

/** pre-compute the prototype-method sets once per module load */
const protoMethodSets: Record<PrimitiveKind, Set<string>> = {
  array: new Set(
    Object.getOwnPropertyNames(Array.prototype).filter(
      (p) => typeof (Array.prototype as any)[p] === 'function',
    ),
  ),
  string: new Set(
    Object.getOwnPropertyNames(String.prototype).filter(
      (p) => typeof (String.prototype as any)[p] === 'function',
    ),
  ),
  number: new Set(
    Object.getOwnPropertyNames(Number.prototype).filter(
      (p) => typeof (Number.prototype as any)[p] === 'function',
    ),
  ),
  boolean: new Set(
    Object.getOwnPropertyNames(Boolean.prototype).filter(
      (p) => typeof (Boolean.prototype as any)[p] === 'function',
    ),
  ),
  date: new Set(
    Object.getOwnPropertyNames(Date.prototype).filter(
      (p) => typeof (Date.prototype as any)[p] === 'function',
    ),
  ),
};

/** build a map of every “root object” encountered in *any* mapping */
function collectRootObjects(
  mapping: Record<string, string>,
): Map<string, PrimitiveKind> {
  const roots = new Map<string, PrimitiveKind>();
  for (const [path, kind] of Object.entries(mapping)) {
    if ((protoMethodSets as any)[kind]) {
      roots.set(
        joinParenthesesAndArrays(getParts(path)),
        kind as PrimitiveKind,
      );
    }
  }
  return roots;
}

// helper that removes method-call entries from a single mapping
function scrub(
  mapping: Record<string, string>,
  rootTable: Map<string, PrimitiveKind>,
  onRemove: (key: string) => void,
): void {
  const sortedKeys = Object.keys(mapping).sort((a, b) => a.localeCompare(b));

  for (const keyPath of sortedKeys) {
    const keyParts = getParts(keyPath);

    if (
      IGNORE_CLASSES_AND_OBJECTS.find(
        (m) => keyParts[0] === m || keyParts[0].startsWith(`${m}(`),
      )
    ) {
      delete mapping[keyPath];
      continue;
    }

    // walk back through the prefixes: foo.bar.baz.qux → foo.bar.baz → foo.bar …
    for (let cut = keyParts.length - 1; cut > 0; --cut) {
      const prefix = joinParenthesesAndArrays(keyParts.slice(0, cut));
      const rootKind = rootTable.get(prefix);
      if (!rootKind) continue;

      const rawMethod = keyParts[cut].split('(')[0];
      if (protoMethodSets[rootKind].has(rawMethod)) {
        onRemove(keyPath);
        break;
      }
    }
  }
}

/**
 * O(N·L) drop-in replacement for the quadratic original.
 * Mutates the supplied `structure` and `functionFinalDataStructure`
 * in-place exactly like the original.
 */
export default function cleanKnownObjectFunctions(
  scopeNode: Pick<ScopeNode, 'name' | 'schema'>,
  scopeDataStructure: Pick<ScopeDataStructure, 'removeFromSchema'>,
): void {
  const { schema } = scopeNode;

  // one lookup table for every root object path → its primitive kind
  const rootTable = collectRootObjects(schema);

  const onRemove = (keyPath: string) => {
    scopeDataStructure.removeFromSchema(
      keyPath,
      scopeNode.schema,
      scopeNode.name,
    );
  };

  scrub(schema, rootTable, onRemove);
}

export function cleanKnownObjectFunctionsFromMapping(
  mapping: Record<string, string>,
): void {
  const rootTable = collectRootObjects(mapping);
  scrub(mapping, rootTable, (keyPath: string) => {
    delete mapping[keyPath];
  });
}
