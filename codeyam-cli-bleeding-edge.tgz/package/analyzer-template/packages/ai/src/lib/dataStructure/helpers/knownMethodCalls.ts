import { functionArguments } from '../../splitOutsideParentheses';

export default function knownMethodCalls(
  methodCall: string,
): 'string' | 'array' | 'string | array' | 'unknown' {
  const method = methodCall.split('(')[0].trim();
  const args = functionArguments(methodCall);

  const stringMetadata = STRING_METHODS[method];
  const arrayMetadata = ARRAY_METHODS[method];

  if (!args) {
    if (stringMetadata && arrayMetadata) {
      return 'string | array';
    } else if (stringMetadata) {
      return 'string';
    } else if (arrayMetadata) {
      return 'array';
    }
    return 'unknown';
  }

  const validStringMethod =
    stringMetadata &&
    args.length >= stringMetadata.minArgs &&
    args.length <= stringMetadata.maxArgs;
  const validArrayMethod =
    arrayMetadata &&
    args.length >= arrayMetadata.minArgs &&
    args.length <= arrayMetadata.maxArgs;
  if (validStringMethod && validArrayMethod) {
    return 'string | array';
  } else if (validStringMethod) {
    return 'string';
  } else if (validArrayMethod) {
    return 'array';
  }
  return 'unknown';
}

const STRING_METHODS = {
  // HTML Wrapper Methods (Deprecated)
  anchor: { minArgs: 1, maxArgs: 1 },
  big: { minArgs: 0, maxArgs: 0 },
  blink: { minArgs: 0, maxArgs: 0 },
  bold: { minArgs: 0, maxArgs: 0 },
  fixed: { minArgs: 0, maxArgs: 0 },
  fontcolor: { minArgs: 1, maxArgs: 1 },
  fontsize: { minArgs: 1, maxArgs: 1 },
  italics: { minArgs: 0, maxArgs: 0 },
  link: { minArgs: 1, maxArgs: 1 },
  small: { minArgs: 0, maxArgs: 0 },
  strike: { minArgs: 0, maxArgs: 0 },
  sub: { minArgs: 0, maxArgs: 0 },
  sup: { minArgs: 0, maxArgs: 0 },

  // Standard Methods
  at: { minArgs: 1, maxArgs: 1 },
  charAt: { minArgs: 1, maxArgs: 1 },
  charCodeAt: { minArgs: 1, maxArgs: 1 },
  codePointAt: { minArgs: 1, maxArgs: 1 },
  concat: { minArgs: 1, maxArgs: Infinity },
  endsWith: { minArgs: 1, maxArgs: 2 },
  includes: { minArgs: 1, maxArgs: 2 },
  indexOf: { minArgs: 1, maxArgs: 2 },
  isWellFormed: { minArgs: 0, maxArgs: 0 },
  lastIndexOf: { minArgs: 1, maxArgs: 2 },
  localeCompare: { minArgs: 1, maxArgs: 3 },
  match: { minArgs: 1, maxArgs: 1 },
  matchAll: { minArgs: 1, maxArgs: 1 },
  normalize: { minArgs: 0, maxArgs: 1 },
  padEnd: { minArgs: 1, maxArgs: 2 },
  padStart: { minArgs: 1, maxArgs: 2 },
  repeat: { minArgs: 1, maxArgs: 1 },
  replace: { minArgs: 2, maxArgs: 2 },
  replaceAll: { minArgs: 2, maxArgs: 2 },
  search: { minArgs: 1, maxArgs: 1 },
  slice: { minArgs: 1, maxArgs: 2 },
  split: { minArgs: 1, maxArgs: 2 },
  startsWith: { minArgs: 1, maxArgs: 2 },
  substr: { minArgs: 1, maxArgs: 2 },
  substring: { minArgs: 1, maxArgs: 2 },
  toLocaleLowerCase: { minArgs: 0, maxArgs: 1 },
  toLocaleUpperCase: { minArgs: 0, maxArgs: 1 },
  toLowerCase: { minArgs: 0, maxArgs: 0 },
  toString: { minArgs: 0, maxArgs: 0 },
  toWellFormed: { minArgs: 0, maxArgs: 0 },
  toUpperCase: { minArgs: 0, maxArgs: 0 },
  trim: { minArgs: 0, maxArgs: 0 },
  trimEnd: { minArgs: 0, maxArgs: 0 },
  trimStart: { minArgs: 0, maxArgs: 0 },
  valueOf: { minArgs: 0, maxArgs: 0 },
};

const ARRAY_METHODS = {
  at: { minArgs: 1, maxArgs: 1 },
  concat: { minArgs: 1, maxArgs: Infinity },
  copyWithin: { minArgs: 1, maxArgs: 3 },
  entries: { minArgs: 0, maxArgs: 0 },
  every: { minArgs: 1, maxArgs: 2 },
  fill: { minArgs: 1, maxArgs: 3 },
  filter: { minArgs: 1, maxArgs: 2 },
  find: { minArgs: 1, maxArgs: 2 },
  findIndex: { minArgs: 1, maxArgs: 2 },
  findLast: { minArgs: 1, maxArgs: 2 },
  findLastIndex: { minArgs: 1, maxArgs: 2 },
  flat: { minArgs: 0, maxArgs: 1 },
  flatMap: { minArgs: 1, maxArgs: 2 },
  forEach: { minArgs: 1, maxArgs: 2 },
  includes: { minArgs: 1, maxArgs: 2 },
  indexOf: { minArgs: 1, maxArgs: 2 },
  join: { minArgs: 0, maxArgs: 1 },
  keys: { minArgs: 0, maxArgs: 0 },
  lastIndexOf: { minArgs: 1, maxArgs: 2 },
  map: { minArgs: 1, maxArgs: 2 },
  pop: { minArgs: 0, maxArgs: 0 },
  push: { minArgs: 1, maxArgs: Infinity },
  reduce: { minArgs: 1, maxArgs: 2 },
  reduceRight: { minArgs: 1, maxArgs: 2 },
  reverse: { minArgs: 0, maxArgs: 0 },
  shift: { minArgs: 0, maxArgs: 0 },
  slice: { minArgs: 1, maxArgs: 2 },
  some: { minArgs: 1, maxArgs: 2 },
  sort: { minArgs: 0, maxArgs: 1 },
  splice: { minArgs: 1, maxArgs: Infinity },
  toLocaleString: { minArgs: 0, maxArgs: 2 },
  toReversed: { minArgs: 0, maxArgs: 0 },
  toSorted: { minArgs: 0, maxArgs: 1 },
  toSpliced: { minArgs: 1, maxArgs: Infinity },
  toString: { minArgs: 0, maxArgs: 0 },
  unshift: { minArgs: 1, maxArgs: Infinity },
  values: { minArgs: 0, maxArgs: 0 },
  with: { minArgs: 2, maxArgs: 2 },
};
