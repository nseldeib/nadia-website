import { AI } from './types';

export const DEFAULT_SMALLER_MODEL = AI.Model.OPENAI_GPT4_1_MINI;
export const DEFAULT_LARGER_MODEL = AI.Model.OPENAI_GPT4_1;
