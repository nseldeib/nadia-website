import { Entity } from '~codeyam/types';
import completionCall from './completionCall';
import generateEntityDocumentationGenerator from './promptGenerators/generateEntityDocumentationGenerator';
import * as lib from '.';
import { saveLlmCall } from '~codeyam/aws/dynamodb';
import { awsLog } from '~codeyam/utils';

interface DocumentationArgs {
  entity: Entity;
  model?: lib.types.AI.Model;
}

export default async function generateEntityDocumentation({
  entity,
  model,
}: DocumentationArgs) {
  if (!['visual', 'library'].includes(entity.entityType)) return null;

  if (!entity.code) {
    console.log(
      'CodeYam Error: No Entity Code Found',
      JSON.stringify(
        {
          name: entity.name,
          filePath: entity.filePath,
        },
        null,
        2,
      ),
    );
    throw new Error('CodeYam Error: No Code Found for entity documentation');
  }

  const prompt = generateEntityDocumentationGenerator(entity);

  const { completion: documentation, stats } = await completionCall({
    type: 'analyzeDocumentation',
    systemMessage:
      'You are an expert coder and educator. You think a lot about how people can understand new things, recognizing that it is a mixture of direct facts and numerous examples from different perspectives.',
    prompt,
    model,
    jsonResponse: false,
  });

  const llmCall = await saveLlmCall({
    object_type: 'entity',
    object_id: entity.sha,
    propsJson: {
      entity: {
        name: entity.name,
        filePath: entity.filePath,
        code: entity.code,
      },
      model,
    },
    ...stats,
  });

  if (!documentation) {
    console.log('CodeYam Error: Documentation failed: No response from AI');
    return null;
  }

  awsLog(
    `LLMCall ${llmCall ? llmCall.id : 'N/A'}: ${entity.filePath} (${entity.name}): ${entity.filePath} (${entity.name}) documentation :>> `,
    documentation,
  );

  return { documentation, llmCall };
}
