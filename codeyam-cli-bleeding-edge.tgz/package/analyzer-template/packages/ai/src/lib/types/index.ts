/* eslint-disable @typescript-eslint/no-namespace */
import _OpenAI from 'openai';
import { Commit } from '~codeyam/types';

export type JSON =
  | string
  | number
  | boolean
  | { [key: string]: JSON }
  | Array<JSON>;

export namespace JSON {
  export type Object = Record<string, JSON>;
}

export type TypePredicateFunction<T extends JSON.Object> = (
  t: JSON.Object,
) => t is T;

export type BranchSummary = {
  name: string;
  description: string;
};

export interface LlmCallStats {
  model: string;
  prompt_type: string;
  system_message: string;
  prompt_text: string;
  response: string;
  input_tokens?: number;
  output_tokens?: number;
  cost?: number;
  retries?: number;
  wait_ms?: number;
  duration_ms?: number;
  error?: string;
}

export namespace AI {
  export type ChatRequest = {
    // the 'type' type is actually 'branchSummary' | 'documentation' | ... but
    // it can't be refactored easily yet
    type: string;
    messages: {
      system: string;
      prompt: string;
    };
    model?: string;
    responseType?: 'json' | 'text';
  };

  export namespace Action {
    export type GetBranchSummary = (_: {
      branchName: string;
      commits: Commit[];
    }) => Promise<BranchSummary | null>;

    export type Builder<T> = (_: {
      aiService: OpenAI.Service;
      dbService: DBService;
    }) => T;
  }

  /**
   * The OpenAI model names identify the model when contacting the OpenAI API.
   * The other ones are OpenRouter model strings, and are unlikely to work
   * through any other API. TODO.
   */
  export enum Model {
    PHIND_CODELLAMA = 'phind/phind-codellama-34b',
    OPENAI_GPT5 = 'gpt-5',
    OPENAI_GPT5_MINI = 'gpt-5-mini',
    OPENAI_GPT5_NANO = 'gpt-5-nano',
    OPENAI_GPT4_1 = 'gpt-4.1',
    OPENAI_GPT4_1_MINI = 'gpt-4.1-mini',
    OPENAI_GPT4_O = 'gpt-4o',
    OPENAI_GPT4_O_MINI = 'gpt-4o-mini',
    OPENAI_GPT35_TURBO = 'openai-gpt-3-5-turbo',
    OPENAI_GPT4_PREVIEW = 'gpt-4-1106-preview',
    OPENAI_GPT4_TURBO_PREVIEW = 'gpt-4-turbo-preview',
    GOOGLE_GEMINI_PRO = 'google/gemini-pro',
    GOOGLE_PALM_2_CODE_CHAT_32K = 'google/palm-2-codechat-bison-32k',
    META_CODELLAMA_34B_INSTRUCT = 'meta-llama/codellama-34b-instruct',
    GEMINI_2_0_FLASH_001 = 'google/gemini-2.0-flash-001',
    DEEPSEEK_CHAT = 'deepseek/deepseek-chat',
    DEEPSEEK_R1 = 'deepseek/deepseek-r1',
    CLAUDE_3_5_SONNET = 'anthropic/claude-3.5-sonnet',
    CLAUDE_3_7_SONNET = 'anthropic/claude-3.7-sonnet',
    CLAUDE_4_0_SONNET = 'anthropic/claude-sonnet-4',
    CLAUDE_4_0_OPUS = 'anthropic/claude-opus-4',
    CLAUDE_4_1_OPUS = 'anthropic/claude-opus-4.1',
  }

  export interface DBService {
    saveAICall(callData: {
      chatRequest: AI.ChatRequest;
      chatCompletion: _OpenAI.ChatCompletion;
    }): Promise<void>;
  }

  /**
   * It is unclear at this time what lives in the fully abstracted AI.Service.
   * It should be minimal and applicable to the kind of calls we'd make to _any_
   * AI.Service until we have enough variation to understand what an abstracted
   * AI Service will really look like.
   */
  export interface Service {
    model: Model;
  }

  export namespace OpenAI {
    export interface Service extends AI.Service {
      sendChatRequest(
        chatRequest: ChatRequest,
      ): Promise<_OpenAI.ChatCompletion | null>;
    }
  }
}
