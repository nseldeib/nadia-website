/**
 * `lib` is the namespace for **internal functions** of `packages/ai`. The goal
 * of `lib` is a self-discovering namespace of well tested functions.
 *
 * ## Usage
 *
 * Always import from the `lib` namespace. It can be a bit more tedious to write
 * but makes it easy when reading to know at a glance where the function comes
 * from.
 *
 * ```ts
 * import * as lib from '../../lib';
 *
 * lib.someNamespace.someFunction();
 * ```
 */

export * as types from './types';
export * as services from './services';
export * as actions from './actions';
export { getLLMCallStats, getLLMCallStatsOld } from './getLLMCallStats';
export { default as completionCall } from './completionCall';
export * as parsers from './parsers';
export * as typePredicates from './typePredicates';
export * as openai from './openai';
export * as promptGenerators from './promptGenerators';

/**
 * This is a multiplier used in calculating the cost of AI calls
 */
export const COST_MULTIPLIER = 100000000;
