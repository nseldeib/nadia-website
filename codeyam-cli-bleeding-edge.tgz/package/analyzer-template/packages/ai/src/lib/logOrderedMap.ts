import { writeFileSync } from 'fs';

export default function logOrderedMap(
  map: { [key: string]: string },
  name?: string,
  write?: boolean,
  excludePatterns?: RegExp[],
) {
  const keys = Object.keys(map ?? {}).sort((a, b) => a.localeCompare(b));

  if (write) {
    writeFileSync(
      `./logOrderedMap-${name || 'Unknown'}.json`,
      JSON.stringify(
        keys
          .filter((k) => !excludePatterns?.some((pattern) => pattern.test(k)))
          .reduce((acc, k) => {
            acc[k] = map[k];
            return acc;
          }, {}),
        null,
        2,
      ),
    );
  }

  for (let i = 0; i * 100 < keys.length; ++i) {
    console.info(
      `CodeYam: ${name || 'Unknown'}: ${keys.length} items (${i} / ${keys.length / 100})`,
      JSON.stringify(
        keys
          .filter((k) => !excludePatterns?.some((pattern) => pattern.test(k)))
          .slice(i * 100, (i + 1) * 100)
          .reduce((acc, k) => {
            acc[k] = map[k];
            return acc;
          }, {}),
        null,
        2,
      ),
    );
  }
}
