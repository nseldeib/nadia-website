/**
 * This namespace is for functionality specific to working with openai
 */

import OpenAI from 'openai';
import { ChatCompletion } from 'openai/resources';
import * as lib from '../../lib';
import { DEFAULT_SMALLER_MODEL } from '../aiConfig';

export function extractReplyFromChatCompletion(
  chatCompletion: ChatCompletion,
): string {
  return chatCompletion.choices?.[0]?.message?.content;
}

function getMaxTokens(model: string): number {
  switch (model) {
    case lib.types.AI.Model.OPENAI_GPT5:
    case lib.types.AI.Model.OPENAI_GPT5_MINI:
    case lib.types.AI.Model.OPENAI_GPT5_NANO:
      return 128000;
    case lib.types.AI.Model.OPENAI_GPT4_1:
    case lib.types.AI.Model.OPENAI_GPT4_1_MINI:
      return 32768;
    case lib.types.AI.Model.OPENAI_GPT4_O:
    case lib.types.AI.Model.OPENAI_GPT4_O_MINI:
      return 16384;
    case lib.types.AI.Model.OPENAI_GPT4_PREVIEW:
      return 8192;
    case lib.types.AI.Model.CLAUDE_4_0_OPUS:
    case lib.types.AI.Model.CLAUDE_4_1_OPUS:
      return 32000;
    case lib.types.AI.Model.CLAUDE_4_0_SONNET:
    case lib.types.AI.Model.CLAUDE_3_7_SONNET:
      return 64000;
    case lib.types.AI.Model.CLAUDE_3_5_SONNET:
      return 8192;
    default:
      return 4096; // Default for other models
  }
}

export function chatRequestToOpenAIChatParams({
  messages: { system, prompt },
  model,
  responseType,
}: lib.types.AI.ChatRequest): OpenAI.Chat.Completions.ChatCompletionCreateParamsNonStreaming {
  return {
    messages: [
      {
        role: 'system',
        content: system,
      },
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: prompt,
          },
        ],
      },
    ],
    model: model ?? DEFAULT_SMALLER_MODEL,
    // temperature: 0,  // reasoning models don't support temperature
    max_completion_tokens: getMaxTokens(model),
    response_format: {
      type: responseType && responseType == 'text' ? 'text' : 'json_object',
    },
  };
}
