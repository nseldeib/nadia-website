import * as lib from '.';
import completionCall from './completionCall';

interface GetCodeExplanationArgs {
  entityCode: string;
  diff: string;
  title: string;
  commitMessage: string;
  aiCommitMessage: string;
  model?: lib.types.AI.Model;
}

export default async function describeCodeChange({
  entityCode,
  diff,
  title,
  commitMessage,
  aiCommitMessage,
  model,
}: GetCodeExplanationArgs) {
  const prompt = `## Change Diff
${diff}

## Resulting Code
${entityCode}
  
## Developer Commit Message
${commitMessage}

## Enhanced Commit Message
${title}:
${aiCommitMessage}`;

  const response = await completionCall({
    type: 'codeChangeDescription',
    systemMessage: SYSTEM_MESSAGE,
    prompt,
    model,
    jsonResponse: false,
  });

  return response;
}

const SYSTEM_MESSAGE = `You will be given the diff for a code change, the resulting code, the developer's commit message, and an enhanced commit message and description.

Your goal is to highlight what the user will see changed if they run this code (not how the code literally changed, but how the user experience or output changes).

This description will be read by non-technical users so avoid technical language like "the diff", or referencing specific variables from the code. In fact you should generally avoid referring to the code at all.

What will the user see changed when this code is called? We want to focus on how the experience or output changes, not how the code changes.

If the changes are essentially just a refactor, or the code is not changed in a way that is visible to the user, then describe the refactoring at a high level in general terms. It's helpful to know why the refactoring was done, but the details are not important.

Provide your response as short, simple text. Use bullets. Do not write paragraphs or even complete sentences. This needs to be as short and easy to read as possible.
`;
