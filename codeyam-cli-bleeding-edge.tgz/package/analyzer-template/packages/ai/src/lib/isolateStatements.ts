import * as ts from 'typescript';
import { StatementInfo } from '~codeyam/types';
import { ScopeInfo } from './dataStructure/ScopeDataStructure';

/**
 * AST-BASED STATEMENT ISOLATION APPROACH
 * =====================================
 *
 * This module uses TypeScript's AST (Abstract Syntax Tree) to robustly isolate
 * individual statements from complex code structures. Key principles:
 *
 * 1. AST TRAVERSAL: Uses ts.forEachChild() and TypeScript's built-in node types
 *    instead of string manipulation for reliable code analysis
 *
 * 2. TYPE GUARDS: Leverages TypeScript's ts.is*() functions for accurate
 *    node type detection (ts.isIfStatement, ts.isFunctionDeclaration, etc.)
 *
 * 3. SCOPE AWARENESS: Maintains proper parent-child relationships and
 *    boundary information through AST structure
 *
 * 4. LANGUAGE FEATURES: Handles modern TypeScript/JavaScript features:
 *    - Arrow functions, async/await
 *    - JSX/TSX components and fragments
 *    - Destructuring, spread operators
 *    - Class declarations and methods
 *    - Import/export statements
 *
 * 5. ISOLATION STRATEGY: Creates "wrapper" statements by removing inner content
 *    while preserving structural information for analysis
 */

/**
 * Isolates individual statements from a TypeScript code snippet using AST-based analysis.
 *
 * This function parses the code into an AST and extracts each statement,
 * handling nested blocks, functions, control structures, and JSX/TSX appropriately.
 *
 * The function focuses on isolating 'wrapper' statements by removing their inner content
 * in the returned result, enabling focused analysis on the structural elements.
 *
 * Key improvements:
 * - Uses TypeScript's AST for robust parsing and traversal
 * - Handles complex nested structures correctly
 * - Preserves proper scope boundaries and child relationships
 * - Supports JSX and TSX syntax appropriately
 *
 * @param scope.text A string containing TypeScript code
 * @returns An array of StatementInfo objects with text, position, and boundary information
 */
export default function isolateStatements(scope: ScopeInfo): StatementInfo[] {
  // Create a source file from the code snippet
  const sourceFile = ts.createSourceFile(
    'temp.tsx',
    scope.text,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TSX,
  );

  // Result array to store statement strings
  const statements: StatementInfo[] = [];

  if (sourceFile.statements.length === 1) {
    const stmt = sourceFile.statements[0];
    if (ts.isExpressionStatement(stmt) && ts.isArrowFunction(stmt.expression)) {
      const arrowFn = stmt.expression;
      if (ts.isBlock(arrowFn.body) && arrowFn.body.statements.length > 0) {
        // 1. Add the arrow function shell
        const arrowText = scope.text.substring(0, arrowFn.body.pos);
        const statementText = `${arrowText} { /* function body */ }`;
        statements.push({
          start: 0,
          end: sourceFile.getEnd(),
          text: statementText,
          childBoundaries: getDefaultChildBoundaries(scope, statementText),
        });

        // 2. Add each statement from the body
        arrowFn.body.statements.forEach((bodyStmt) => {
          const stmtText = scope.text.substring(bodyStmt.pos, bodyStmt.end);
          let formattedStmt = stmtText;
          if (
            !formattedStmt.trim().endsWith(';') &&
            !ts.isBlock(bodyStmt) &&
            !ts.isIfStatement(bodyStmt) &&
            !ts.isForStatement(bodyStmt) &&
            !ts.isWhileStatement(bodyStmt) &&
            !ts.isTryStatement(bodyStmt) &&
            !ts.isSwitchStatement(bodyStmt)
          ) {
            formattedStmt += ';';
          }
          statements.push({
            start: bodyStmt.pos,
            end: bodyStmt.end,
            text: formattedStmt,
            childBoundaries: getDefaultChildBoundaries(scope, formattedStmt),
          });
        });
      } else {
        const statementText = `${stripArrowBody(arrowFn, sourceFile)} { /* function body */ }`;
        statements.push({
          start: 0,
          end: sourceFile.getEnd(),
          text: statementText,
          childBoundaries: getDefaultChildBoundaries(scope, statementText),
        });
        let expr = arrowFn.body;
        if (ts.isParenthesizedExpression(expr)) {
          expr = expr.expression;
        }
        const exprText = scope.text.substring(
          expr.getStart(sourceFile),
          expr.getEnd(),
        );
        const returnStatementText = `return ${exprText};`;
        statements.push({
          start: expr.getStart(sourceFile),
          end: expr.getEnd(),
          text: returnStatementText,
          childBoundaries: getDefaultChildBoundaries(
            scope,
            returnStatementText,
          ),
        });
      }
    }
  }

  // Track statements we've seen to avoid duplicates
  const processedNodes = new Set<ts.Node>();
  // Track container nodes so we can create versions with bodies removed
  const containerNodes = new Map<ts.Node, string>();

  /**
   * Process any identified container nodes to isolate their wrappers
   */
  const processContainerNodes = () => {
    containerNodes.forEach((nodeText, node) => {
      let isolatedStatement = nodeText;
      if (ts.isIfStatement(node)) {
        isolatedStatement = isolateIfStatement(node, scope.text, sourceFile);
      } else if (
        ts.isForStatement(node) ||
        ts.isForInStatement(node) ||
        ts.isForOfStatement(node)
      ) {
        isolatedStatement = isolateLoopStatement(node, nodeText, sourceFile);
      } else if (ts.isWhileStatement(node) || ts.isDoStatement(node)) {
        isolatedStatement = isolateLoopStatement(node, nodeText, sourceFile);
      } else if (ts.isTryStatement(node)) {
        isolatedStatement = isolateTryStatement(node, scope.text, sourceFile);
      } else if (ts.isSwitchStatement(node)) {
        isolatedStatement = isolateSwitchStatement(
          node,
          scope.text,
          sourceFile,
        );
      } else if (isFunctionLike(node)) {
        isolatedStatement = isolateFunctionStatement(
          node,
          nodeText,
          scope.text,
          sourceFile,
        );
      } else if (ts.isClassDeclaration(node) || ts.isClassExpression(node)) {
        isolatedStatement = isolateClassStatement(node, scope.text, sourceFile);
      } else if (ts.isJsxElement(node)) {
        isolatedStatement = isolateJsxElement(node, scope.text, sourceFile);
      } else if (ts.isJsxFragment(node)) {
        isolatedStatement = isolateJsxFragment();
      }
      if (isolatedStatement && isolatedStatement.trim()) {
        statements.push({
          start: node.getStart(sourceFile),
          end: node.getEnd(),
          text: isolatedStatement,
          childBoundaries: getDefaultChildBoundaries(scope, isolatedStatement),
        });
      }
    });
  };

  /**
   * Process a node and its children, extracting statements
   */
  const processNode = (node: ts.Node): void => {
    if (processedNodes.has(node)) {
      return;
    }
    processedNodes.add(node);
    if (isJsxNode(node)) {
      processJsxNode(node);
      return;
    }
    if (ts.isArrowFunction(node)) {
      const nodeText = scope.text.substring(
        node.getStart(sourceFile),
        node.getEnd(),
      );
      containerNodes.set(node, nodeText);
      const arrowStart = nodeText.split('{')[0];
      const statementText = `${arrowStart}{ /* function body */ }`;
      statements.push({
        start: node.getStart(sourceFile),
        end: node.getEnd(),
        text: statementText,
        childBoundaries: getDefaultChildBoundaries(scope, statementText),
      });
      containerNodes.delete(node);
      if (node.body && ts.isBlock(node.body)) {
        const blockBody = node.body as ts.Block;
        blockBody.statements.forEach((stmt) => {
          const stmtText = scope.text.substring(
            stmt.getStart(sourceFile),
            stmt.getEnd(),
          );
          let formattedStmt = stmtText;
          if (
            !formattedStmt.trim().endsWith(';') &&
            !ts.isBlock(stmt) &&
            !ts.isIfStatement(stmt) &&
            !ts.isForStatement(stmt) &&
            !ts.isWhileStatement(stmt) &&
            !ts.isTryStatement(stmt) &&
            !ts.isSwitchStatement(stmt)
          ) {
            formattedStmt = formattedStmt + ';';
          }
          statements.push({
            start: stmt.getStart(sourceFile),
            end: stmt.getEnd(),
            text: formattedStmt,
            childBoundaries: getDefaultChildBoundaries(scope, formattedStmt),
          });
        });
      } else if (node.body) {
        processNode(node.body);
      }
      return;
    }
    const isTopLevelStatement = isStatement(node);
    if (isTopLevelStatement) {
      const statementText = scope.text.substring(
        node.getStart(sourceFile),
        node.getEnd(),
      );
      if (isContainerStatement(node)) {
        containerNodes.set(node, statementText);
        processContainerStatement(node);
      } else {
        if (statementText.trim()) {
          let formattedStatement = statementText;
          if (ts.isVariableStatement(node)) {
            const declaration = node.declarationList.declarations[0];
            if (
              declaration &&
              declaration.initializer &&
              ts.isArrowFunction(declaration.initializer) &&
              !ts.isBlock(declaration.initializer.body)
            ) {
              const arrowFn = declaration.initializer;
              const varName = declaration.name.getText(sourceFile);
              const params = scope.text.substring(
                arrowFn.parameters.pos,
                arrowFn.parameters.end,
              );
              const expressionText = scope.text.substring(
                arrowFn.body.getStart(sourceFile),
                arrowFn.body.getEnd(),
              );
              formattedStatement = `const ${varName} = ${params} => return ${expressionText};`;
            }
          } else if (
            ts.isExpressionStatement(node) &&
            !statementText.trim().endsWith(';')
          ) {
            formattedStatement = statementText + ';';
          }
          statements.push({
            start: node.getStart(sourceFile),
            end: node.getEnd(),
            text: formattedStatement,
            childBoundaries: getDefaultChildBoundaries(
              scope,
              formattedStatement,
            ),
          });
        }
      }
      return;
    }
    ts.forEachChild(node, processNode);
  };

  /**
   * Process JSX elements and expressions
   */
  const processJsxNode = (node: ts.Node): void => {
    if (processedNodes.has(node)) {
      return;
    }
    processedNodes.add(node);
    const nodeText = scope.text.substring(
      node.getStart(sourceFile),
      node.getEnd(),
    );
    if (ts.isJsxElement(node) || ts.isJsxFragment(node)) {
      containerNodes.set(node, nodeText);
    } else {
      if (nodeText.trim()) {
        statements.push({
          start: node.getStart(sourceFile),
          end: node.getEnd(),
          text: nodeText,
          childBoundaries: getDefaultChildBoundaries(scope, nodeText),
        });
      }
    }
    if (ts.isJsxElement(node) || ts.isJsxSelfClosingElement(node)) {
      const attributes = ts.isJsxElement(node)
        ? node.openingElement.attributes.properties
        : node.attributes.properties;
      attributes.forEach((attr) => {
        if (
          ts.isJsxAttribute(attr) &&
          attr.initializer &&
          ts.isJsxExpression(attr.initializer)
        ) {
          if (attr.initializer.expression) {
            processNode(attr.initializer.expression);
          }
        } else if (ts.isJsxSpreadAttribute(attr) && attr.expression) {
          processNode(attr.expression);
        }
      });
      if (ts.isJsxElement(node)) {
        node.children.forEach((child) => {
          if (ts.isJsxExpression(child) && child.expression) {
            processNode(child.expression);
          } else {
            processNode(child);
          }
        });
      }
    } else if (ts.isJsxFragment(node)) {
      node.children.forEach((child) => {
        if (ts.isJsxExpression(child) && child.expression) {
          processNode(child.expression);
        } else {
          processNode(child);
        }
      });
    } else if (ts.isJsxExpression(node) && node.expression) {
      processNode(node.expression);
    }
  };

  /**
   * Process a container statement (if, for, while, etc.) to extract inner statements
   */
  const processContainerStatement = (node: ts.Node): void => {
    // New branch for variable statements with arrow function initializer (block body)
    if (ts.isVariableStatement(node)) {
      const declaration = node.declarationList.declarations[0];
      if (
        declaration &&
        declaration.initializer &&
        ts.isArrowFunction(declaration.initializer) &&
        ts.isBlock(declaration.initializer.body)
      ) {
        const arrowFn = declaration.initializer;
        const varStmtText = scope.text.substring(
          node.getStart(sourceFile),
          node.getEnd(),
        );
        const relativeBodyPos = arrowFn.body.pos - node.getStart(sourceFile);
        const shell =
          varStmtText.substring(0, relativeBodyPos) + '{ /* function body */ }';
        statements.push({
          start: node.getStart(sourceFile),
          end: node.getEnd(),
          text: shell,
          childBoundaries: getDefaultChildBoundaries(scope, shell),
        });
        const blockBody = arrowFn.body as ts.Block;
        blockBody.statements.forEach((bodyStmt) => {
          let stmtText = scope.text.substring(bodyStmt.pos, bodyStmt.end);
          if (
            !stmtText.trim().endsWith(';') &&
            !ts.isBlock(bodyStmt) &&
            !ts.isIfStatement(bodyStmt) &&
            !ts.isForStatement(bodyStmt) &&
            !ts.isWhileStatement(bodyStmt) &&
            !ts.isTryStatement(bodyStmt) &&
            !ts.isSwitchStatement(bodyStmt)
          ) {
            stmtText += ';';
          }
          statements.push({
            start: bodyStmt.pos,
            end: bodyStmt.end,
            text: stmtText,
            childBoundaries: getDefaultChildBoundaries(scope, stmtText),
          });
        });
        return;
      }
    }
    if (ts.isIfStatement(node)) {
      if (node.thenStatement) {
        processBlockLike(node.thenStatement);
      }
      if (node.elseStatement) {
        processBlockLike(node.elseStatement);
      }
      return;
    }
    if (
      ts.isForStatement(node) ||
      ts.isForInStatement(node) ||
      ts.isForOfStatement(node)
    ) {
      if (node.statement) {
        processBlockLike(node.statement);
      }
      return;
    }
    if (ts.isWhileStatement(node) || ts.isDoStatement(node)) {
      if (node.statement) {
        processBlockLike(node.statement);
      }
      return;
    }
    if (ts.isTryStatement(node)) {
      if (node.tryBlock) {
        processBlock(node.tryBlock);
      }
      if (node.catchClause && node.catchClause.block) {
        processBlock(node.catchClause.block);
      }
      if (node.finallyBlock) {
        processBlock(node.finallyBlock);
      }
      return;
    }
    if (ts.isSwitchStatement(node)) {
      node.caseBlock.clauses.forEach((clause) => {
        clause.statements.forEach((stmt) => {
          processNode(stmt);
        });
      });
      return;
    }
    if (isFunctionLike(node)) {
      if (node.body) {
        if (ts.isBlock(node.body)) {
          processBlock(node.body);
        } else {
          processNode(node.body);
        }
      }
      return;
    }
    if (ts.isClassDeclaration(node) || ts.isClassExpression(node)) {
      node.members.forEach((member) => {
        if (ts.isMethodDeclaration(member) && member.body) {
          processBlock(member.body);
        } else if (ts.isPropertyDeclaration(member) && member.initializer) {
          processNode(member.initializer);
        } else if (ts.isConstructorDeclaration(member) && member.body) {
          processBlock(member.body);
        }
      });
      return;
    }
  };

  const processBlockLike = (node: ts.Node): void => {
    if (ts.isBlock(node)) {
      processBlock(node);
    } else {
      processNode(node);
    }
  };

  const processBlock = (block: ts.Block): void => {
    block.statements.forEach((stmt) => {
      processNode(stmt);
    });
  };

  // Start processing
  processNode(sourceFile);
  processContainerNodes();

  const refinedStatements: StatementInfo[] = statements
    .flatMap((statement) => furtherIsolateJSX(scope, statement))
    .sort((a, b) => a.start - b.start)
    .map((statement) => {
      if (statement.end - statement.start === scope.text.length) {
        return {
          ...statement,
          start: scope.start,
          end: scope.end,
        };
      }

      let startCalc = scope.start + statement.start;

      let cleanStatement = scope.text.slice(statement.start, statement.end);
      let childrenLength = 0;
      for (const childScopeId in scope.childScopes) {
        const childScope = scope.childScopes[childScopeId];
        const childScopeLength = childScope.end - childScope.start;
        let childScopeIndex = scope.text.indexOf(`${childScopeId}()`);
        if (childScopeIndex === -1) {
          childScopeIndex = scope.text.indexOf(`{${childScopeId}}`);
          if (childScopeIndex === -1) {
            childScopeIndex = scope.text.indexOf(`${childScopeId}F`);
            if (childScopeIndex > -1 && childScopeIndex < statement.start) {
              startCalc -= `${childScopeId}F`.length;
            }
          } else if (childScopeIndex < statement.start) {
            startCalc -= `{${childScopeId}}`.length;
          }
        } else if (childScopeIndex < statement.start) {
          startCalc -= `${childScopeId}()`.length;
        }
        if (childScopeIndex > -1 && childScopeIndex < statement.start) {
          startCalc += childScopeLength;
        }
        const childOptions = [
          `${childScopeId}()`,
          `{${childScopeId}}`,
          `${childScopeId}F`,
        ];
        const hasChildScope = childOptions.some((option) =>
          cleanStatement.includes(option),
        );

        let replacedStatement = cleanStatement;
        childOptions.forEach((option) => {
          replacedStatement = replacedStatement.replace(option, '');
        });
        if (hasChildScope) {
          cleanStatement = replacedStatement;
          childrenLength += childScopeLength;
        }
      }

      return {
        ...statement,
        start: startCalc,
        end: startCalc + cleanStatement.length + childrenLength,
      };
    })
    .filter(
      (statement) =>
        statement &&
        statement.text.replace(/^\n/, '').replace(/\n$/, '').trim().length > 0,
    );

  const statementsWithChildren = refinedStatements.map((statement) => {
    const childBoundaries = statement.childBoundaries ?? [];

    statement.childBoundaries.push(
      ...refinedStatements
        .filter(
          (child) =>
            child.start >= statement.start &&
            child.end <= statement.end &&
            !(child.start === statement.start && child.end === statement.end),
        )
        .map((child) => ({
          start: child.start,
          end: child.end,
        })),
    );
    childBoundaries.push(
      ...Object.values(scope.childScopes)
        .filter(
          (childScope) =>
            childScope.start >= statement.start &&
            childScope.end <= statement.end,
        )
        .map((childScope) => ({
          name: childScope.name,
          start: childScope.start,
          end: childScope.end,
        })),
    );

    statement.childBoundaries = childBoundaries.filter((boundary, i, self) => {
      return (
        !self.find((b) => b.start < boundary.start && b.end > boundary.end) &&
        self.findIndex(
          (b) =>
            b.name === boundary.name &&
            b.start === boundary.start &&
            b.end === boundary.end,
        ) === i
      );
    });

    return statement;
  });

  if (statementsWithChildren.length === 1) {
    return statementsWithChildren;
  }

  return statementsWithChildren.filter(
    (statement) =>
      statement.text.replace(/;$/, '') !== scope.text.replace(/;$/, ''),
  );
}

/**
 * Isolate an if statement by simplifying its body
 */
const isolateIfStatement = (
  node: ts.IfStatement,
  codeSnippet,
  sourceFile: ts.SourceFile,
): string => {
  let result = 'if (';
  const conditionText = codeSnippet.substring(
    node.expression.getStart(sourceFile),
    node.expression.getEnd(),
  );
  result += conditionText;
  result += ') { /* then block */ }';
  if (node.elseStatement) {
    result += ' else { /* else block */ }';
  }
  return result;
};

/**
 * Isolate a loop statement by simplifying its body
 */
const isolateLoopStatement = (
  node: ts.IterationStatement,
  nodeText: string,
  sourceFile: ts.SourceFile,
): string => {
  if (!node.statement) return nodeText;
  const bodyStart =
    node.statement.getStart(sourceFile) - node.getStart(sourceFile);
  let result = nodeText.substring(0, bodyStart);
  if (ts.isBlock(node.statement)) {
    result += '{ /* loop body */ }';
  } else {
    result += '/* loop body */';
  }
  return result;
};

/**
 * Isolate a try statement by simplifying its blocks
 */
const isolateTryStatement = (
  node: ts.TryStatement,
  codeSnippet: string,
  sourceFile: ts.SourceFile,
): string => {
  let result = 'try { /* try block */ }';
  if (node.catchClause) {
    const catchParam = node.catchClause.variableDeclaration
      ? codeSnippet.substring(
          node.catchClause.variableDeclaration.getStart(sourceFile),
          node.catchClause.variableDeclaration.getEnd(),
        )
      : '';
    result += ` catch${catchParam ? ` (${catchParam})` : ''} { /* catch block */ }`;
  }
  if (node.finallyBlock) {
    result += ' finally { /* finally block */ }';
  }
  return result;
};

/**
 * Isolate a switch statement by simplifying its cases
 */
const isolateSwitchStatement = (
  node: ts.SwitchStatement,
  codeSnippet: string,
  sourceFile: ts.SourceFile,
): string => {
  const expressionText = codeSnippet.substring(
    node.expression.getStart(sourceFile),
    node.expression.getEnd(),
  );
  let result = `switch (${expressionText}) {`;
  node.caseBlock.clauses.forEach((clause) => {
    if (ts.isCaseClause(clause)) {
      const caseExpression = codeSnippet.substring(
        clause.expression.getStart(sourceFile),
        clause.expression.getEnd(),
      );
      result += `\n  case ${caseExpression}: /* case body */`;
      if (clause.statements.some((stmt) => ts.isBreakStatement(stmt))) {
        result += ' break;';
      }
    } else if (ts.isDefaultClause(clause)) {
      result += '\n  default: /* default case */';
    }
  });
  result += '\n}';
  return result;
};

/**
 * Isolate a function declaration or expression by simplifying its body
 */
const isolateFunctionStatement = (
  node: ts.FunctionLikeDeclaration,
  nodeText: string,
  codeSnippet: string,
  sourceFile: ts.SourceFile,
): string => {
  if (!node.body) return nodeText;
  if (ts.isArrowFunction(node)) {
    const paramText = codeSnippet.substring(
      node.parameters.pos,
      node.parameters.end,
    );
    let functionName = '';
    if (
      node.parent &&
      ts.isVariableDeclaration(node.parent) &&
      node.parent.name
    ) {
      functionName = node.parent.name.getText(sourceFile);
    }
    if (ts.isBlock(node.body)) {
      if (functionName) {
        return `const ${functionName} = ${paramText} => { /* function body */ }`;
      } else {
        return `${paramText} => { /* function body */ }`;
      }
    } else {
      if (functionName) {
        return `const ${functionName} = ${paramText} => return /* expression */`;
      } else {
        return `${paramText} => return /* expression */`;
      }
    }
  }
  const bodyStart = node.body.getStart(sourceFile) - node.getStart(sourceFile);
  let result = nodeText.substring(0, bodyStart);
  if (ts.isBlock(node.body)) {
    result += '{ /* function body */ }';
  } else {
    result += ' /* body */';
  }
  return result;
};

/**
 * Isolate a class declaration by simplifying its methods
 */
function isolateClassStatement(
  node: ts.ClassDeclaration | ts.ClassExpression,
  codeSnippet: string,
  sourceFile: ts.SourceFile,
): string {
  const className =
    ts.isClassDeclaration(node) && node.name
      ? node.name.text
      : 'AnonymousClass';
  let result = `class ${className} {\n`;
  node.members.forEach((member) => {
    if (ts.isPropertyDeclaration(member)) {
      const propertyName = member.name.getText(sourceFile);
      result += `  ${propertyName}`;
      if (member.type) {
        const typeText = codeSnippet.substring(
          member.type.getStart(sourceFile),
          member.type.getEnd(),
        );
        result += `: ${typeText}`;
      }
      if (member.initializer) {
        result += ' = /* initializer */';
      }
      result += ';\n';
    } else if (ts.isMethodDeclaration(member)) {
      const methodName = member.name.getText(sourceFile);
      result += `  ${methodName}(...) { /* method body */ }\n`;
    } else if (ts.isConstructorDeclaration(member)) {
      result += `  constructor(...) { /* constructor body */ }\n`;
    }
  });
  result += '}';
  return result;
}

function stripArrowBody(
  arrowFn: ts.ArrowFunction,
  sourceFile: ts.SourceFile,
): string {
  const allText = arrowFn.getFullText(sourceFile);
  const indexOfFatArrow = allText.indexOf('=>');
  if (indexOfFatArrow >= 0) {
    return allText.slice(0, indexOfFatArrow + 2).trim();
  }
  return '(...) =>';
}

/**
 * Isolate a JSX element by simplifying its content
 */
function isolateJsxElement(
  node: ts.JsxElement,
  codeSnippet: string,
  sourceFile: ts.SourceFile,
): string {
  const tagName = node.openingElement.tagName.getText(sourceFile);
  let attributes = '';
  if (node.openingElement.attributes.properties.length > 0) {
    attributes =
      ' ' +
      codeSnippet
        .substring(
          node.openingElement.tagName.getEnd(),
          node.openingElement.getEnd() - 1,
        )
        .trim();
  }
  return `<${tagName}${attributes}>/* jsx content */</${tagName}>`;
}

/**
 * Isolate a JSX fragment by simplifying its content
 */
function isolateJsxFragment(): string {
  return '<>/* jsx fragment content */</>';
}

/**
 * Enhanced type guard: Check if a node is JSX-related using comprehensive AST node types
 * Covers all JSX node types for robust JSX handling in TypeScript AST
 */
function isJsxNode(node: ts.Node): boolean {
  return (
    ts.isJsxElement(node) ||
    ts.isJsxSelfClosingElement(node) ||
    ts.isJsxFragment(node) ||
    ts.isJsxExpression(node) ||
    ts.isJsxText(node) ||
    ts.isJsxOpeningElement(node) ||
    ts.isJsxClosingElement(node) ||
    ts.isJsxAttribute(node) ||
    ts.isJsxSpreadAttribute(node)
  );
}

/**
 * Enhanced AST-based statement detection: Check if a node is a statement that we want to extract
 * Comprehensive coverage of all TypeScript statement types for robust analysis
 */
function isStatement(node: ts.Node): boolean {
  return (
    // Variable and expression statements
    ts.isVariableStatement(node) ||
    ts.isExpressionStatement(node) ||
    // Control flow statements
    ts.isIfStatement(node) ||
    ts.isForStatement(node) ||
    ts.isForInStatement(node) ||
    ts.isForOfStatement(node) ||
    ts.isWhileStatement(node) ||
    ts.isDoStatement(node) ||
    ts.isSwitchStatement(node) ||
    // Exception handling statements
    ts.isTryStatement(node) ||
    // Jump statements
    ts.isReturnStatement(node) ||
    ts.isBreakStatement(node) ||
    ts.isContinueStatement(node) ||
    ts.isThrowStatement(node) ||
    // Declaration statements
    ts.isFunctionDeclaration(node) ||
    ts.isClassDeclaration(node) ||
    ts.isImportDeclaration(node) ||
    ts.isExportDeclaration(node) ||
    ts.isExportAssignment(node) ||
    // Other statements
    ts.isLabeledStatement(node) ||
    ts.isEmptyStatement(node) ||
    // JSX statements
    ts.isJsxElement(node) ||
    ts.isJsxSelfClosingElement(node) ||
    ts.isJsxFragment(node)
  );
}

/**
 * Enhanced AST-based container detection: Check if a node is a container statement that needs special handling
 * Uses TypeScript AST to identify statements that contain other statements and require isolation
 */
function isContainerStatement(node: ts.Node): boolean {
  return (
    // Control flow containers
    ts.isIfStatement(node) ||
    ts.isTryStatement(node) ||
    ts.isSwitchStatement(node) ||
    // Loop containers
    isLoopStatement(node) ||
    // Function containers
    isFunctionLike(node) ||
    // Class containers
    ts.isClassDeclaration(node) ||
    ts.isClassExpression(node) ||
    // JSX containers
    ts.isJsxElement(node) ||
    ts.isJsxFragment(node) ||
    // Variable declarations with arrow function blocks (special case)
    (ts.isVariableStatement(node) &&
      node.declarationList.declarations.some(
        (decl) =>
          decl.initializer &&
          ts.isArrowFunction(decl.initializer) &&
          ts.isBlock(decl.initializer.body),
      ))
  );
}

/**
 * Enhanced type guard: Check if a node is a function-like declaration or expression
 * Includes all TypeScript function-like constructs for comprehensive AST coverage
 */
function isFunctionLike(node: ts.Node): node is ts.FunctionLikeDeclaration {
  return (
    ts.isFunctionDeclaration(node) ||
    ts.isFunctionExpression(node) ||
    ts.isArrowFunction(node) ||
    ts.isMethodDeclaration(node) ||
    ts.isConstructorDeclaration(node) ||
    ts.isGetAccessorDeclaration(node) ||
    ts.isSetAccessorDeclaration(node)
  );
}

/**
 * Enhanced type guard: Check if a node represents a loop statement
 * Provides centralized loop detection for consistent AST handling
 */
function isLoopStatement(node: ts.Node): node is ts.IterationStatement {
  return (
    ts.isForStatement(node) ||
    ts.isForInStatement(node) ||
    ts.isForOfStatement(node) ||
    ts.isWhileStatement(node) ||
    ts.isDoStatement(node)
  );
}

/**
 * Determines whether a given AST node has a block body.
 *
 * A "block body" refers to a body enclosed in curly braces `{}`. This function
 * checks various node types to determine if they contain such a body:
 * - Function-like nodes (e.g., function declarations, arrow functions) must have
 *   a body that is a `ts.Block`.
 * - Loop statements (e.g., `for`, `while`) must have a statement that is a `ts.Block`.
 * - `if` statements are checked for block bodies in their `then` and `else` branches.
 * - `try` statements are assumed to always have block bodies.
 *
 * @param node - The AST node to check.
 * @returns `true` if the node has a block body; otherwise, `false`.
 */
function hasBlockBody(node: ts.Node): boolean {
  if (isFunctionLike(node)) {
    return node.body ? ts.isBlock(node.body) : false;
  }
  if (isLoopStatement(node)) {
    return ts.isBlock(node.statement);
  }
  if (ts.isIfStatement(node)) {
    return (
      ts.isBlock(node.thenStatement) ||
      (node.elseStatement && ts.isBlock(node.elseStatement))
    );
  }
  if (ts.isTryStatement(node)) {
    return true; // Try statements always have block bodies
  }
  return false;
}

/**
 * Splits the given code into multiple statements. If the code includes
 * a single top-level JsxElement, the outer element is returned as one
 * statement (with its children removed), and each original child is
 * returned as a separate statement.
 */
export function furtherIsolateJSX(
  scope: ScopeInfo,
  originalStatement: StatementInfo,
): StatementInfo[] {
  const sourceFile = ts.createSourceFile(
    'temp.tsx',
    originalStatement.text,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TSX,
  );
  const printer = ts.createPrinter({ newLine: ts.NewLineKind.LineFeed });
  const statements: StatementInfo[] = [];
  const topLevelStmt = sourceFile.statements[0];
  if (
    ts.isExpressionStatement(topLevelStmt) &&
    ts.isJsxElement(topLevelStmt.expression)
  ) {
    const jsxElement = topLevelStmt.expression;
    const emptyJsxElement = ts.factory.createJsxElement(
      jsxElement.openingElement,
      [],
      jsxElement.closingElement,
    );
    const statementText = printer.printNode(
      ts.EmitHint.Unspecified,
      emptyJsxElement,
      sourceFile,
    );
    statements.push({
      start: jsxElement.getStart(sourceFile),
      end: jsxElement.getEnd(),
      text: statementText,
      childBoundaries: getDefaultChildBoundaries(scope, statementText),
    });
    for (const child of jsxElement.children) {
      const statementText = printer.printNode(
        ts.EmitHint.Unspecified,
        child,
        sourceFile,
      );
      statements.push({
        start: child.getStart(sourceFile),
        end: child.getEnd(),
        text: statementText,
        childBoundaries: getDefaultChildBoundaries(scope, statementText),
      });
    }
    return statements;
  }
  return [originalStatement];
}

function getDefaultChildBoundaries(scope: ScopeInfo, statementText: string) {
  return Object.keys(scope.childScopes)
    .filter((childScopeName) => statementText.includes(childScopeName))
    .map((childScopeName) => ({
      name: childScopeName,
      start: scope.childScopes[childScopeName].start,
      end: scope.childScopes[childScopeName].end,
    }));
}
