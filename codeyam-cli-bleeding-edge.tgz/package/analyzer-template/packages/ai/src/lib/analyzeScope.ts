/**
 * Generates a ScopeAnalysis
 *
 * Important parts of the ScopeAnalysis:
 *
 * - structure: a map of variable names to their types. Includes signature and return values for this scope.
 * - equivalentVariables: a map of equivalencies within this scope (e.g. { 'a.b': 'c' } means that a.b has the same structure as c)
 * - functionDataStructure: a map of function calls equivalencies in all child scopes. Has mappings for signatures and return values.
 * - functionFinalDataStructure: a map of function call structures in all child scopes. Has mappings for signatures and return values.
 *
 * "structure" should capture the attributes of all variables in this scope, including attributes exposed in child scopes
 *
 * "equivalentVariables" should capture all equivalencies in this scope. Only needed for merging with a parent scope.
 *
 * "functionDataStructure" and "functionFinalDataStructure" are used to collect info about all function calls made in this scope and all
 * children so that they can be used to merge with dependencies.
 **/

import { Entity, ScopeAnalysis } from '~codeyam/types';
import * as lib from '.';
import instantiatedInScope from './instantiatedInScope';
import isolateStatements from './isolateStatements';
import generateStatementAnalysis from './generateStatementAnalysis';
import mergeStatements, { Statement } from './mergeStatements';
import { analyzeScopeWithAst } from './astScopes';
import { FileAnalyzer } from '~codeyam/analyze';
import { writeFile } from 'fs/promises';
import { saveEntityStatements } from '~codeyam/supabase';
import {
  ScopeDataStructure,
  ScopeInfo,
} from './dataStructure/ScopeDataStructure';
import FunctionCallManager from './dataStructure/equivalencyManagers/FunctionCallManager';
import { ReactFrameworkManager } from './dataStructure/equivalencyManagers/frameworks/ReactFrameworkManager';
import { JavascriptFrameworkManager } from './dataStructure/equivalencyManagers/frameworks/JavascriptFrameworkManager';
import ParentScopeManager from './dataStructure/equivalencyManagers/ParentScopeManager';

interface AnalyzeScopeArgs {
  entity: Entity;
  fileAnalyzer: FileAnalyzer;
  scope: ScopeInfo;
  scopeDataStructure?: ScopeDataStructure;
  parentScopeName?: string;
  model?: lib.types.AI.Model;
}

async function writeScopeToFile(scope: ScopeInfo) {
  await writeFile('analyzeScope.json', JSON.stringify(scope, null, 2));
}

export default async function analyzeScope({
  entity,
  fileAnalyzer,
  scope,
  scopeDataStructure,
  parentScopeName,
  model,
}: AnalyzeScopeArgs) {
  try {
    const statements = isolateStatements(scope);
    const statementScopes = statements.map((statement, index) => ({
      name: scope.name + ' statement ' + index,
      ...statement,
    }));

    const llmCalls: any[] = [];

    const astAnalysisResultWithStatements = statementScopes.map(
      (statementScope) => {
        const astAnalysisResult = analyzeScopeWithAst(
          fileAnalyzer,
          statementScope,
        );
        return {
          statementScope,
          astAnalysisResult,
        };
      },
    );

    const results: Statement[] = [];
    const shas: string[] = [];
    await Promise.all(
      astAnalysisResultWithStatements.map(
        async (astAnalysisResultWithStatement) => {
          const { statementScope, astAnalysisResult } =
            astAnalysisResultWithStatement;

          // console.log(
          //   `AST analysis for ${statementScope.name}: isComplete=${astAnalysisResult.isComplete}\n${statementScope.text}\n\n`,
          // );

          // const debugMatching = [
          //   // /findSelectedPerson/,
          //   // /cyScope[0-5]+/,
          //   'findSelectedPerson statement 1',
          // ];
          // const testStatements = statementScopes
          //   .map((s) => s.name)
          //   .filter((name) => debugMatching.some((test) => name.match(test)));
          // const debug = testStatements.includes(statementScope.name);
          // if (astAnalysisResult.isComplete) {
          //   if (!debug) {
          //     console.info(
          //       'Skipping complete AST analysis for',
          //       statementScope.name,
          //     );
          //   } else {
          //     console.info('Using AST analysis for', statementScope.name);
          //   }
          // }
          // if (astAnalysisResult.isComplete && debug) {
          if (astAnalysisResult.isComplete) {
            // console.log(
            //   `Using AST analysis for ${statementScope.name}: ${statementScope.text}`,
            // );
            const structure = { ...astAnalysisResult.structure };
            const equivalentVariables = {
              ...astAnalysisResult.equivalentVariables,
            };

            const relevantChildScopes = Object.entries(scope.childScopes)
              .filter(([_, childScope]) =>
                statementScope.childBoundaries.find(
                  (cb) =>
                    cb.start === childScope.start && cb.end === childScope.end,
                ),
              )
              .reduce(
                (acc, [id, childScope]) => {
                  acc[id] = childScope;
                  return acc;
                },
                {} as Record<string, ScopeInfo>,
              );

            const sortedEntries = Object.entries(relevantChildScopes).sort(
              ([_a, aScope], [_b, bScope]) => {
                return bScope.end - bScope.start - (aScope.end - aScope.start);
              },
            );

            for (const mapping of [structure, equivalentVariables]) {
              for (let [key, value] of Object.entries(mapping)) {
                for (const [childScopeId, childScope] of sortedEntries) {
                  const scopeText = fileAnalyzer.sourceFile.text.slice(
                    childScope.start,
                    childScope.end,
                  );

                  const replaceChildScopeId = (text: string) => {
                    if (statementScope.text.includes(`{${childScopeId}}`)) {
                      text = text.replace(scopeText, `{${childScopeId}}`);
                    } else if (
                      statementScope.text.includes(`${childScopeId}F`)
                    ) {
                      text = text.replace(scopeText, `${childScopeId}F`);
                    } else {
                      text = text.replace(scopeText, `${childScopeId}()`);
                    }
                    return text;
                  };

                  if (value.includes(scopeText)) {
                    value = replaceChildScopeId(value);
                    mapping[key] = value;
                  }
                  if (key.includes(scopeText)) {
                    const oldKey = key;
                    key = replaceChildScopeId(key);
                    mapping[key] = mapping[oldKey];
                    delete mapping[oldKey];
                  }
                }
              }
            }

            // if (
            //   (
            //     debugMatching.filter((m) => typeof m === 'string') as string[]
            //   ).includes(statementScope.name)
            // ) {
            //   const llm = await generateStatementAnalysis({
            //     entity,
            //     analysisId,
            //     scope: statementScope,
            //     issues: '',
            //     model,
            //   });

            //   console.info(
            //     'AST vs LLM DIFF',
            //     JSON.stringify(
            //       {
            //         name: statementScope.name,
            //         text: statementScope.text,
            //         AST: {
            //           structure,
            //           equivalentVariables,
            //         },
            //         LLM: {
            //           structure: llm.structure,
            //           equivalentVariables: llm.equivalentVariables,
            //         },
            //       },
            //       null,
            //       2,
            //     ),
            //   );
            //   // results.push({ structure: llm.structure, equivalentVariables: llm.equivalentVariables });
            // }

            llmCalls.push(
              JSON.stringify({
                input_tokes: 0,
                output_tokes: 0,
                prompt_text: statementScope.text,
                response: JSON.stringify({
                  choices: [
                    {
                      message: {
                        content: JSON.stringify(
                          {
                            structure,
                            equivalentVariables,
                          },
                          null,
                          2,
                        ),
                        role: 'assistant',
                      },
                      finish_reason: 'stop',
                      index: 0,
                    },
                  ],
                }),
              }),
            );

            results.push({ structure, equivalentVariables });
          } else {
            // console.log(
            //   `Falling back to LLM analysis for ${statementScope.name}: ${statementScope.text}`,
            // );

            // if (!astAnalysisResult.isComplete) {
            //   console.info(
            //     "CodeYam Debug: AST Issues",
            //     JSON.stringify(astAnalysisResult.completeness?.issues, null, 2)
            //   );
            // }

            const issues = JSON.stringify(
              astAnalysisResult.completeness?.issues.filter(
                (issue, index, self) =>
                  self.findIndex((i) => i.message === issue.message) === index,
              ),
              null,
              2,
            );

            const statementResult = await generateStatementAnalysis({
              entity,
              scope: statementScope,
              issues,
              model,
            });

            if (!statementResult) {
              console.info(
                'CodeYam Error: No statement result for',
                statementScope.name,
                issues,
                statementScope.text,
              );
              return;
              // throw new Error('No statement result');
            }

            shas.push(statementResult.sha);
            llmCalls.push(statementResult.llmCall);

            results.push({
              structure: statementResult.structure,
              equivalentVariables: statementResult.equivalentVariables,
              llmCall: statementResult.llmCall,
            });
          }
        },
      ),
    );

    if (shas.length > 0) {
      await saveEntityStatements(entity, shas);
    }

    const mergeResults = mergeStatements(results);
    const { structure, equivalentVariables } = mergeResults;

    const isolatedStructure = { ...structure };
    const isolatedEquivalentVariables = { ...equivalentVariables };

    const instantiatedVariables = instantiatedInScope(scope.text);

    const scopeAnalysis: ScopeAnalysis = {
      llmCalls,
      instantiatedVariables,
      isolatedStructure,
      isolatedEquivalentVariables,
    };

    if (!scopeDataStructure) {
      scopeDataStructure = new ScopeDataStructure(
        [
          new FunctionCallManager(),
          new ReactFrameworkManager(),
          new JavascriptFrameworkManager(),
          new ParentScopeManager(),
        ],
        scope.name,
        scope.text,
        scopeAnalysis,
      );
    } else {
      scopeDataStructure.addScopeAnalysis(
        scope.name,
        scope.text,
        scopeAnalysis,
        parentScopeName,
      );
    }

    // for (const childScope of Object.values(scope.childScopes)) {
    await Promise.all(
      Object.values(scope.childScopes).map(async (childScope) => {
        await analyzeScope({
          entity,
          fileAnalyzer,
          scope: childScope,
          scopeDataStructure,
          parentScopeName: scope.name,
          model,
        });
      }),
    );
    // }

    if (!parentScopeName) {
      await scopeDataStructure.captureCompleteSchema();
      scope.dataStructure = scopeDataStructure;
    }
  } catch (error) {
    console.error(
      'CodeYam Error: analyzeScope failed',
      entity.filePath,
      entity.name,
      scope.name,
      '\n\n',
      scope.text,
      '\n\n',
      error,
    );
    throw error;
  }
}
