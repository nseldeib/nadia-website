import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

/**
 * This module breaks out the path configuration for analyzeScope.ts
 * mainly so we can mock it out for Jest, which hates import.meta.url;
 * see __mocks__/analyzeScopeWorkerPaths.ts
 */
export default function analyzeScopeWorkerPaths() {
  const __dirname = dirname(fileURLToPath(import.meta.url));
  return {
    PRE_WORKER_PATH: join(__dirname, 'analyzeScopePreWorker.js'),
    POST_WORKER_PATH: join(__dirname, 'analyzeScopePostWorker.js'),
  };
}
