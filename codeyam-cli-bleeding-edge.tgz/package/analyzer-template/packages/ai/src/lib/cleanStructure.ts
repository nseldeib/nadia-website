import cleanOutBoundary from './cleanOutBoundary';
import splitOutsideParentheses from './splitOutsideParentheses';

function removeUnnecessaryCharacters(variablePath: string) {
  // Remove both '?' and '!' characters
  return variablePath.replace(/\?\./g, '.').replace(/!/g, '');
}

function removeFilters(variablePath: string) {
  if (!variablePath.includes('.filter(')) return variablePath;

  let output = '';
  let index = 0;

  while (index < variablePath.length) {
    const filterIndex = variablePath.indexOf('.filter(', index);
    if (filterIndex === -1) {
      // No more filter calls; append the rest of the string.
      output += variablePath.substring(index);
      break;
    }

    // Append text before the .filter(
    output += variablePath.substring(index, filterIndex);

    // Find the matching closing parenthesis
    let openParens = 0;
    const start = filterIndex;
    let i = filterIndex;
    let foundEnd = false;
    while (i < variablePath.length) {
      if (variablePath[i] === '(') {
        openParens++;
      } else if (variablePath[i] === ')') {
        openParens--;
        if (openParens === 0) {
          // Found the matching closing parenthesis for the .filter(
          foundEnd = true;
          i++; // include closing parenthesis
          break;
        }
      }
      i++;
    }

    if (!foundEnd) {
      // No matching parenthesis found; just append the rest and break.
      output += variablePath.substring(filterIndex);
      break;
    }

    // Check if what follows is one of the exceptions.
    const afterFilterCall = variablePath.substring(i).trim();
    if (
      afterFilterCall.startsWith('.signature[') ||
      afterFilterCall.startsWith('.functionCallReturnValue')
    ) {
      // If it's one of the exceptions, keep the .filter() call.
      output += variablePath.substring(filterIndex, i);
    }

    // Otherwise, we simply remove it by not appending anything.

    index = i;
  }

  return output;
}

function removeInvalidValues(variablePath: string) {
  const invalidValues = new Set([
    '{}',
    '[]',
    'null',
    'undefined',
    'true',
    'false',
    '0',
    '1',
    'NaN',
  ]);

  if (invalidValues.has(variablePath)) {
    return '';
  }
  return variablePath;
}

function cleanArrayNotation(variablePath: string) {
  // Replace array index notation like ".[0]" or ".[key]" with "[0]" or "[key]"
  let replaced = variablePath.replace(/\.?\[(.*?)\]/g, '[$1]');
  // Replace array index notation like "[0]" or "[1]" with "[]" except on signature and functionCallReturnValue variable paths
  replaced = replaced.replace(
    /(?<!\b(?:signature|functionCallReturnValue)(?:\[\d*\])*)\[\d+\]/g,
    '[]',
  );

  return replaced;
}

function removeWhereKeyValueEqual(structure: { [key: string]: string }) {
  for (const key in structure) {
    if (structure[key] === key) {
      delete structure[key];
    }
  }
  return structure;
}

function removeBooleanOperators(structure: { [key: string]: string }) {
  for (const key in structure) {
    const keyParts = splitOutsideParentheses(key);
    for (const part of keyParts) {
      const cleanPart = cleanOutBoundary(
        cleanOutBoundary(part, '<', '>').replace('<>', ''),
      );
      if (
        cleanPart.includes('&&') ||
        cleanPart.includes('??') ||
        cleanPart.includes('||') ||
        cleanPart.includes('>') ||
        cleanPart.includes('<') ||
        cleanPart.includes('>=') ||
        cleanPart.includes('<=') ||
        cleanPart.includes('==') ||
        cleanPart.includes('!=')
      ) {
        delete structure[key];
      }
    }
  }
  return structure;
}

// function removeMathematicalOperators(structure: { [key: string]: string }) {
//   const isMath = (path: string) => {
//     const keyParts = splitOutsideParentheses(path);
//     for (const part of keyParts) {
//       if (
//         part.match(/...\+.../) ||
//         part.match(/...-.../) ||
//         part.match(/...\*.../) ||
//         // part.match(/...\/.../) || // tests fail with this
//         part.match(/...%.../) ||
//         part.match(/...\*\*.../) ||
//         part.match(/...^.../)
//       ) {
//         return true;
//       }
//     }
//     return false;
//   };

//   for (const [key, value] of Object.entries(structure)) {
//     if (isMath(key)) {
//       {
//         delete structure[key];
//       }
//     }

//     if (isMath(value)) {
//       {
//         delete structure[key];
//       }
//     }
//   }
//   return structure;
// }

function allTransformations(variablePath: string) {
  let result = cleanArrayNotation(variablePath);
  result = removeFilters(result);
  result = removeUnnecessaryCharacters(result);
  result = removeInvalidValues(result);
  return result;
}

export default function cleanStructure(structure: { [key: string]: string }) {
  structure = removeWhereKeyValueEqual(structure);
  structure = removeBooleanOperators(structure);
  // structure = removeMathematicalOperators(structure);

  const result: { [key: string]: string } = {};
  for (const key of Object.keys(structure)) {
    const cleanedKey = allTransformations(key);
    const cleanedValue = allTransformations(structure[key]);

    delete structure[key];

    if (
      cleanedKey?.length > 0 &&
      cleanedValue?.length > 0 &&
      !structure[cleanedKey] &&
      !result[cleanedKey]
    ) {
      result[cleanedKey] = cleanedValue;
    }
  }

  Object.assign(structure, result);
}
