export default function cleanOutBoundary(
  str: string,
  openBoundary = '(',
  closeBoundary = ')',
) {
  const characters = str.split('');
  const boundaries: { start: number; end: number }[] = [];
  let openIndex: number | undefined;
  let openCount = 0;
  for (let i = 0; i < characters.length; ++i) {
    const char = characters[i];
    if (char === openBoundary) {
      if (!openIndex) openIndex = i;
      ++openCount;
    } else if (char === closeBoundary) {
      if (openCount === 1) {
        boundaries.push({ start: openIndex, end: i + 1 });
        openIndex = undefined;
      }
      --openCount;
    }
  }

  boundaries.reverse();
  for (const boundary of boundaries) {
    str =
      str.slice(0, boundary.start) +
      openBoundary +
      closeBoundary +
      str.slice(boundary.end);
  }
  return str;
}
